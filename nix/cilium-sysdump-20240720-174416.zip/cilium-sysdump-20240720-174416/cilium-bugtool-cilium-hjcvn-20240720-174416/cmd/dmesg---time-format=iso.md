2024-07-20T14:27:49,000000+00:00 Linux version 6.8.12 (nixbld@localhost) (gcc (GCC) 13.3.0, GNU ld (GNU Binutils) 2.42) #1-NixOS SMP PREEMPT_DYNAMIC Thu May 30 07:49:53 UTC 2024
2024-07-20T14:27:49,000000+00:00 Command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/hwhljgz6bjskfac07rqfwy5dwn3mk1s9-nixos-system-worker1-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:27:49,000000+00:00 BIOS-provided physical RAM map:
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x000000007ffdbfff] usable
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x000000007ffdc000-0x000000007fffffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x00000000b0000000-0x00000000bfffffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x00000000fed1c000-0x00000000fed1ffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2024-07-20T14:27:49,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000017fffffff] usable
2024-07-20T14:27:49,000000+00:00 NX (Execute Disable) protection: active
2024-07-20T14:27:49,000000+00:00 APIC: Static calls initialized
2024-07-20T14:27:49,000000+00:00 SMBIOS 2.8 present.
2024-07-20T14:27:49,000000+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 1.15.0-1 04/01/2014
2024-07-20T14:27:49,000000+00:00 Hypervisor detected: KVM
2024-07-20T14:27:49,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2024-07-20T14:27:49,000001+00:00 kvm-clock: using sched offset of 863241151553 cycles
2024-07-20T14:27:49,000002+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2024-07-20T14:27:49,000004+00:00 tsc: Detected 3593.200 MHz processor
2024-07-20T14:27:49,000882+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2024-07-20T14:27:49,000885+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2024-07-20T14:27:49,000889+00:00 last_pfn = 0x180000 max_arch_pfn = 0x400000000
2024-07-20T14:27:49,000912+00:00 MTRR map: 4 entries (3 fixed + 1 variable; max 19), built from 8 variable MTRRs
2024-07-20T14:27:49,000915+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2024-07-20T14:27:49,000948+00:00 last_pfn = 0x7ffdc max_arch_pfn = 0x400000000
2024-07-20T14:27:49,002965+00:00 found SMP MP-table at [mem 0x000f5b80-0x000f5b8f]
2024-07-20T14:27:49,003125+00:00 RAMDISK: [mem 0x367dd000-0x373e5fff]
2024-07-20T14:27:49,003131+00:00 ACPI: Early table checksum verification disabled
2024-07-20T14:27:49,003135+00:00 ACPI: RSDP 0x00000000000F5970 000014 (v00 BOCHS )
2024-07-20T14:27:49,003140+00:00 ACPI: RSDT 0x000000007FFE2842 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003145+00:00 ACPI: FACP 0x000000007FFE2632 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003148+00:00 ACPI: DSDT 0x000000007FFE0040 0025F2 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003151+00:00 ACPI: FACS 0x000000007FFE0000 000040
2024-07-20T14:27:49,003153+00:00 ACPI: APIC 0x000000007FFE2726 000080 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003155+00:00 ACPI: HPET 0x000000007FFE27A6 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003157+00:00 ACPI: MCFG 0x000000007FFE27DE 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003159+00:00 ACPI: WAET 0x000000007FFE281A 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:27:49,003160+00:00 ACPI: Reserving FACP table memory at [mem 0x7ffe2632-0x7ffe2725]
2024-07-20T14:27:49,003161+00:00 ACPI: Reserving DSDT table memory at [mem 0x7ffe0040-0x7ffe2631]
2024-07-20T14:27:49,003162+00:00 ACPI: Reserving FACS table memory at [mem 0x7ffe0000-0x7ffe003f]
2024-07-20T14:27:49,003163+00:00 ACPI: Reserving APIC table memory at [mem 0x7ffe2726-0x7ffe27a5]
2024-07-20T14:27:49,003163+00:00 ACPI: Reserving HPET table memory at [mem 0x7ffe27a6-0x7ffe27dd]
2024-07-20T14:27:49,003164+00:00 ACPI: Reserving MCFG table memory at [mem 0x7ffe27de-0x7ffe2819]
2024-07-20T14:27:49,003165+00:00 ACPI: Reserving WAET table memory at [mem 0x7ffe281a-0x7ffe2841]
2024-07-20T14:27:49,003320+00:00 No NUMA configuration found
2024-07-20T14:27:49,003321+00:00 Faking a node at [mem 0x0000000000000000-0x000000017fffffff]
2024-07-20T14:27:49,003323+00:00 NODE_DATA(0) allocated [mem 0x17fff9000-0x17fffefff]
2024-07-20T14:27:49,003339+00:00 Zone ranges:
2024-07-20T14:27:49,003339+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2024-07-20T14:27:49,003341+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2024-07-20T14:27:49,003342+00:00   Normal   [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:27:49,003343+00:00   Device   empty
2024-07-20T14:27:49,003344+00:00 Movable zone start for each node
2024-07-20T14:27:49,003345+00:00 Early memory node ranges
2024-07-20T14:27:49,003345+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2024-07-20T14:27:49,003346+00:00   node   0: [mem 0x0000000000100000-0x000000007ffdbfff]
2024-07-20T14:27:49,003347+00:00   node   0: [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:27:49,003348+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000017fffffff]
2024-07-20T14:27:49,003355+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2024-07-20T14:27:49,003374+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2024-07-20T14:27:49,009833+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2024-07-20T14:27:49,010448+00:00 ACPI: PM-Timer IO Port: 0x608
2024-07-20T14:27:49,010460+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2024-07-20T14:27:49,010488+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2024-07-20T14:27:49,010491+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2024-07-20T14:27:49,010492+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2024-07-20T14:27:49,010493+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2024-07-20T14:27:49,010494+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2024-07-20T14:27:49,010495+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2024-07-20T14:27:49,010498+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2024-07-20T14:27:49,010499+00:00 ACPI: HPET id: 0x8086a201 base: 0xfed00000
2024-07-20T14:27:49,010505+00:00 smpboot: Allowing 2 CPUs, 0 hotplug CPUs
2024-07-20T14:27:49,010523+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2024-07-20T14:27:49,010542+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2024-07-20T14:27:49,010544+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2024-07-20T14:27:49,010545+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2024-07-20T14:27:49,010545+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2024-07-20T14:27:49,010546+00:00 PM: hibernation: Registered nosave memory: [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:27:49,010547+00:00 PM: hibernation: Registered nosave memory: [mem 0x80000000-0xafffffff]
2024-07-20T14:27:49,010548+00:00 PM: hibernation: Registered nosave memory: [mem 0xb0000000-0xbfffffff]
2024-07-20T14:27:49,010548+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfed1bfff]
2024-07-20T14:27:49,010549+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed1c000-0xfed1ffff]
2024-07-20T14:27:49,010549+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed20000-0xfeffbfff]
2024-07-20T14:27:49,010550+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2024-07-20T14:27:49,010551+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2024-07-20T14:27:49,010551+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2024-07-20T14:27:49,010553+00:00 [mem 0xc0000000-0xfed1bfff] available for PCI devices
2024-07-20T14:27:49,010554+00:00 Booting paravirtualized kernel on KVM
2024-07-20T14:27:49,010555+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2024-07-20T14:27:49,014713+00:00 setup_percpu: NR_CPUS:384 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2024-07-20T14:27:49,014925+00:00 percpu: Embedded 84 pages/cpu s221184 r8192 d114688 u1048576
2024-07-20T14:27:49,014931+00:00 pcpu-alloc: s221184 r8192 d114688 u1048576 alloc=1*2097152
2024-07-20T14:27:49,014934+00:00 pcpu-alloc: [0] 0 1 
2024-07-20T14:27:49,014954+00:00 kvm-guest: PV spinlocks disabled, no host support
2024-07-20T14:27:49,014955+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/hwhljgz6bjskfac07rqfwy5dwn3mk1s9-nixos-system-worker1-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:27:49,015000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage", will be passed to user space.
2024-07-20T14:27:49,015386+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-07-20T14:27:49,015585+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-07-20T14:27:49,015611+00:00 Fallback order for Node 0: 0 
2024-07-20T14:27:49,015613+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1031900
2024-07-20T14:27:49,015615+00:00 Policy zone: Normal
2024-07-20T14:27:49,015829+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2024-07-20T14:27:49,015835+00:00 software IO TLB: area num 2.
2024-07-20T14:27:49,035961+00:00 Memory: 3996388K/4193768K available (16384K kernel code, 2371K rwdata, 11016K rodata, 3164K init, 4396K bss, 197120K reserved, 0K cma-reserved)
2024-07-20T14:27:49,058148+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-07-20T14:27:49,058254+00:00 ftrace: allocating 43348 entries in 170 pages
2024-07-20T14:27:49,064486+00:00 ftrace: allocated 170 pages with 4 groups
2024-07-20T14:27:49,065061+00:00 Dynamic Preempt: voluntary
2024-07-20T14:27:49,065175+00:00 rcu: Preemptible hierarchical RCU implementation.
2024-07-20T14:27:49,065175+00:00 rcu: 	RCU event tracing is enabled.
2024-07-20T14:27:49,065176+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=384 to nr_cpu_ids=2.
2024-07-20T14:27:49,065177+00:00 	Trampoline variant of Tasks RCU enabled.
2024-07-20T14:27:49,065177+00:00 	Rude variant of Tasks RCU enabled.
2024-07-20T14:27:49,065178+00:00 	Tracing variant of Tasks RCU enabled.
2024-07-20T14:27:49,065178+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2024-07-20T14:27:49,065179+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-07-20T14:27:49,067603+00:00 NR_IRQS: 24832, nr_irqs: 440, preallocated irqs: 16
2024-07-20T14:27:49,067827+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-07-20T14:27:49,067912+00:00 kfence: initialized - using 2097152 bytes for 255 objects at 0x(____ptrval____)-0x(____ptrval____)
2024-07-20T14:27:49,072735+00:00 Console: colour VGA+ 80x25
2024-07-20T14:27:49,072738+00:00 printk: legacy console [tty0] enabled
2024-07-20T14:27:49,072971+00:00 ACPI: Core revision 20230628
2024-07-20T14:27:49,073121+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604467 ns
2024-07-20T14:27:49,073192+00:00 APIC: Switch to symmetric I/O mode setup
2024-07-20T14:27:49,073310+00:00 x2apic enabled
2024-07-20T14:27:49,073484+00:00 APIC: Switched APIC routing to: physical x2apic
2024-07-20T14:27:49,074179+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2024-07-20T14:27:49,074194+00:00 tsc: Marking TSC unstable due to TSCs unsynchronized
2024-07-20T14:27:49,074198+00:00 Calibrating delay loop (skipped) preset value.. 7186.40 BogoMIPS (lpj=3593200)
2024-07-20T14:27:49,074299+00:00 process: using AMD E400 aware idle routine
2024-07-20T14:27:49,074302+00:00 Last level iTLB entries: 4KB 512, 2MB 255, 4MB 127
2024-07-20T14:27:49,074303+00:00 Last level dTLB entries: 4KB 512, 2MB 255, 4MB 127, 1GB 0
2024-07-20T14:27:49,074308+00:00 x86/fpu: x87 FPU will use FXSAVE
2024-07-20T14:27:49,091694+00:00 Freeing SMP alternatives memory: 36K
2024-07-20T14:27:49,091698+00:00 pid_max: default: 32768 minimum: 301
2024-07-20T14:27:49,092144+00:00 LSM: initializing lsm=capability,landlock,yama,selinux,bpf,integrity
2024-07-20T14:27:49,092329+00:00 landlock: Up and running.
2024-07-20T14:27:49,092329+00:00 Yama: becoming mindful.
2024-07-20T14:27:49,092332+00:00 SELinux:  Initializing.
2024-07-20T14:27:49,092510+00:00 LSM support for eBPF active
2024-07-20T14:27:49,092660+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:27:49,092665+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:27:49,195196+00:00 smpboot: CPU0: AMD QEMU Virtual CPU version 2.5+ (family: 0xf, model: 0x6b, stepping: 0x1)
2024-07-20T14:27:49,195196+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:27:49,195196+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:27:49,195196+00:00 RCU Tasks Trace: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:27:49,195196+00:00 Performance Events: AMD PMU driver.
2024-07-20T14:27:49,195196+00:00 ... version:                0
2024-07-20T14:27:49,195196+00:00 ... bit width:              48
2024-07-20T14:27:49,195196+00:00 ... generic registers:      4
2024-07-20T14:27:49,195196+00:00 ... value mask:             0000ffffffffffff
2024-07-20T14:27:49,195196+00:00 ... max period:             00007fffffffffff
2024-07-20T14:27:49,195196+00:00 ... fixed-purpose events:   0
2024-07-20T14:27:49,195196+00:00 ... event mask:             000000000000000f
2024-07-20T14:27:49,195196+00:00 signal: max sigframe size: 1440
2024-07-20T14:27:49,195196+00:00 rcu: Hierarchical SRCU implementation.
2024-07-20T14:27:49,195196+00:00 rcu: 	Max phase no-delay instances is 400.
2024-07-20T14:27:49,195196+00:00 smp: Bringing up secondary CPUs ...
2024-07-20T14:27:49,195196+00:00 smpboot: x86: Booting SMP configuration:
2024-07-20T14:27:49,195196+00:00 .... node  #0, CPUs:      #1
2024-07-20T14:27:49,195231+00:00 smp: Brought up 1 node, 2 CPUs
2024-07-20T14:27:49,195231+00:00 smpboot: Max logical packages: 2
2024-07-20T14:27:49,195231+00:00 smpboot: Total of 2 processors activated (14372.80 BogoMIPS)
2024-07-20T14:27:49,195407+00:00 devtmpfs: initialized
2024-07-20T14:27:49,195407+00:00 x86/mm: Memory block size: 128MB
2024-07-20T14:27:49,196412+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2024-07-20T14:27:49,196412+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-07-20T14:27:49,196412+00:00 pinctrl core: initialized pinctrl subsystem
2024-07-20T14:27:49,196412+00:00 PM: RTC time: 14:27:49, date: 2024-07-20
2024-07-20T14:27:49,196891+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-07-20T14:27:49,197215+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-07-20T14:27:49,197470+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-07-20T14:27:49,197697+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-07-20T14:27:49,197707+00:00 audit: initializing netlink subsys (disabled)
2024-07-20T14:27:49,197713+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2024-07-20T14:27:49,197713+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-07-20T14:27:49,197713+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-07-20T14:27:49,197713+00:00 audit: type=2000 audit(1721485669.203:1): state=initialized audit_enabled=0 res=1
2024-07-20T14:27:49,197713+00:00 cpuidle: using governor menu
2024-07-20T14:27:49,197713+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-07-20T14:27:49,197713+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] (base 0xb0000000) for domain 0000 [bus 00-ff]
2024-07-20T14:27:49,197713+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] reserved as E820 entry
2024-07-20T14:27:49,197713+00:00 PCI: Using configuration type 1 for base access
2024-07-20T14:27:49,197713+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2024-07-20T14:27:49,209967+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-07-20T14:27:49,209970+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2024-07-20T14:27:49,210848+00:00 ACPI: Added _OSI(Module Device)
2024-07-20T14:27:49,210851+00:00 ACPI: Added _OSI(Processor Device)
2024-07-20T14:27:49,210853+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-07-20T14:27:49,210854+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-07-20T14:27:49,212176+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-07-20T14:27:49,215864+00:00 ACPI: _OSC evaluation for CPUs failed, trying _PDC
2024-07-20T14:27:49,215864+00:00 ACPI: Interpreter enabled
2024-07-20T14:27:49,215864+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2024-07-20T14:27:49,215864+00:00 ACPI: Using IOAPIC for interrupt routing
2024-07-20T14:27:49,215864+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2024-07-20T14:27:49,215864+00:00 PCI: Using E820 reservations for host bridge windows
2024-07-20T14:27:49,216197+00:00 ACPI: Enabled 2 GPEs in block 00 to 3F
2024-07-20T14:27:49,218631+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2024-07-20T14:27:49,218642+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-07-20T14:27:49,218692+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR]
2024-07-20T14:27:49,218750+00:00 acpi PNP0A08:00: _OSC: OS now controls [PME PCIeCapability]
2024-07-20T14:27:49,218977+00:00 PCI host bridge to bus 0000:00
2024-07-20T14:27:49,218984+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2024-07-20T14:27:49,218987+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2024-07-20T14:27:49,218989+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2024-07-20T14:27:49,218991+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xafffffff window]
2024-07-20T14:27:49,218993+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:27:49,218995+00:00 pci_bus 0000:00: root bus resource [mem 0x180000000-0x97fffffff window]
2024-07-20T14:27:49,218997+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2024-07-20T14:27:49,219080+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2024-07-20T14:27:49,219567+00:00 pci 0000:00:01.0: [1013:00b8] type 00 class 0x030000 conventional PCI endpoint
2024-07-20T14:27:49,224205+00:00 pci 0000:00:01.0: BAR 0 [mem 0xfa000000-0xfbffffff pref]
2024-07-20T14:27:49,226207+00:00 pci 0000:00:01.0: BAR 1 [mem 0xfea10000-0xfea10fff]
2024-07-20T14:27:49,236204+00:00 pci 0000:00:01.0: ROM [mem 0xfea00000-0xfea0ffff pref]
2024-07-20T14:27:49,236268+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2024-07-20T14:27:49,236539+00:00 pci 0000:00:02.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,239198+00:00 pci 0000:00:02.0: BAR 0 [mem 0xfea11000-0xfea11fff]
2024-07-20T14:27:49,245200+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:27:49,245220+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:27:49,246007+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:27:49,246793+00:00 pci 0000:00:02.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,248834+00:00 pci 0000:00:02.1: BAR 0 [mem 0xfea12000-0xfea12fff]
2024-07-20T14:27:49,251207+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:27:49,251248+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:27:49,252230+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:27:49,253245+00:00 pci 0000:00:02.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,255198+00:00 pci 0000:00:02.2: BAR 0 [mem 0xfea13000-0xfea13fff]
2024-07-20T14:27:49,259205+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:27:49,259239+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:27:49,259796+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:27:49,260604+00:00 pci 0000:00:02.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,261558+00:00 pci 0000:00:02.3: BAR 0 [mem 0xfea14000-0xfea14fff]
2024-07-20T14:27:49,263246+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:27:49,263266+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:27:49,263853+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:27:49,264277+00:00 pci 0000:00:02.4: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,267198+00:00 pci 0000:00:02.4: BAR 0 [mem 0xfea15000-0xfea15fff]
2024-07-20T14:27:49,272208+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:27:49,272250+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:27:49,273651+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:27:49,274459+00:00 pci 0000:00:02.5: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,276785+00:00 pci 0000:00:02.5: BAR 0 [mem 0xfea16000-0xfea16fff]
2024-07-20T14:27:49,278202+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:27:49,278223+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:27:49,278621+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:27:49,279361+00:00 pci 0000:00:02.6: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,282571+00:00 pci 0000:00:02.6: BAR 0 [mem 0xfea17000-0xfea17fff]
2024-07-20T14:27:49,283890+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:27:49,283910+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:27:49,284397+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:27:49,284790+00:00 pci 0000:00:02.7: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,285893+00:00 pci 0000:00:02.7: BAR 0 [mem 0xfea18000-0xfea18fff]
2024-07-20T14:27:49,287202+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:27:49,287222+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:27:49,287637+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:27:49,288215+00:00 pci 0000:00:03.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:27:49,289197+00:00 pci 0000:00:03.0: BAR 0 [mem 0xfea19000-0xfea19fff]
2024-07-20T14:27:49,291006+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:27:49,291026+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:27:49,291505+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:27:49,291959+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2024-07-20T14:27:49,294198+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2024-07-20T14:27:49,294333+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2024-07-20T14:27:49,298197+00:00 pci 0000:00:1f.2: BAR 4 [io  0xc040-0xc05f]
2024-07-20T14:27:49,299198+00:00 pci 0000:00:1f.2: BAR 5 [mem 0xfea1a000-0xfea1afff]
2024-07-20T14:27:49,300083+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2024-07-20T14:27:49,301906+00:00 pci 0000:00:1f.3: BAR 4 [io  0x0700-0x073f]
2024-07-20T14:27:49,302988+00:00 acpiphp: Slot [0] registered
2024-07-20T14:27:49,303236+00:00 pci 0000:01:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:27:49,305198+00:00 pci 0000:01:00.0: BAR 1 [mem 0xfe880000-0xfe880fff]
2024-07-20T14:27:49,311198+00:00 pci 0000:01:00.0: BAR 4 [mem 0xfd000000-0xfd003fff 64bit pref]
2024-07-20T14:27:49,311847+00:00 pci 0000:01:00.0: ROM [mem 0xfe800000-0xfe87ffff pref]
2024-07-20T14:27:49,312745+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:27:49,313295+00:00 acpiphp: Slot [0-1] registered
2024-07-20T14:27:49,313377+00:00 pci 0000:02:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:27:49,314635+00:00 pci 0000:02:00.0: BAR 1 [mem 0xfe680000-0xfe680fff]
2024-07-20T14:27:49,317197+00:00 pci 0000:02:00.0: BAR 4 [mem 0xfce00000-0xfce03fff 64bit pref]
2024-07-20T14:27:49,317877+00:00 pci 0000:02:00.0: ROM [mem 0xfe600000-0xfe67ffff pref]
2024-07-20T14:27:49,318831+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:27:49,322289+00:00 acpiphp: Slot [0-2] registered
2024-07-20T14:27:49,322418+00:00 pci 0000:03:00.0: [1b36:000d] type 00 class 0x0c0330 PCIe Endpoint
2024-07-20T14:27:49,323592+00:00 pci 0000:03:00.0: BAR 0 [mem 0xfe400000-0xfe403fff 64bit]
2024-07-20T14:27:49,327873+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:27:49,328738+00:00 acpiphp: Slot [0-3] registered
2024-07-20T14:27:49,328906+00:00 pci 0000:04:00.0: [1af4:1043] type 00 class 0x078000 PCIe Endpoint
2024-07-20T14:27:49,331198+00:00 pci 0000:04:00.0: BAR 1 [mem 0xfe200000-0xfe200fff]
2024-07-20T14:27:49,336200+00:00 pci 0000:04:00.0: BAR 4 [mem 0xfca00000-0xfca03fff 64bit pref]
2024-07-20T14:27:49,339090+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:27:49,339758+00:00 acpiphp: Slot [0-4] registered
2024-07-20T14:27:49,340257+00:00 pci 0000:05:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:27:49,342851+00:00 pci 0000:05:00.0: BAR 1 [mem 0xfe000000-0xfe000fff]
2024-07-20T14:27:49,348199+00:00 pci 0000:05:00.0: BAR 4 [mem 0xfc800000-0xfc803fff 64bit pref]
2024-07-20T14:27:49,349702+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:27:49,350240+00:00 acpiphp: Slot [0-5] registered
2024-07-20T14:27:49,350324+00:00 pci 0000:06:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:27:49,351535+00:00 pci 0000:06:00.0: BAR 1 [mem 0xfde00000-0xfde00fff]
2024-07-20T14:27:49,353590+00:00 pci 0000:06:00.0: BAR 4 [mem 0xfc600000-0xfc603fff 64bit pref]
2024-07-20T14:27:49,354911+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:27:49,355498+00:00 acpiphp: Slot [0-6] registered
2024-07-20T14:27:49,355578+00:00 pci 0000:07:00.0: [1af4:1045] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:27:49,361406+00:00 pci 0000:07:00.0: BAR 4 [mem 0xfc400000-0xfc403fff 64bit pref]
2024-07-20T14:27:49,362578+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:27:49,363093+00:00 acpiphp: Slot [0-7] registered
2024-07-20T14:27:49,363171+00:00 pci 0000:08:00.0: [1af4:1044] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:27:49,364928+00:00 pci 0000:08:00.0: BAR 4 [mem 0xfc200000-0xfc203fff 64bit pref]
2024-07-20T14:27:49,365886+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:27:49,366496+00:00 acpiphp: Slot [0-8] registered
2024-07-20T14:27:49,366525+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:27:49,370440+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2024-07-20T14:27:49,370481+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2024-07-20T14:27:49,370516+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2024-07-20T14:27:49,370551+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2024-07-20T14:27:49,370585+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2024-07-20T14:27:49,370619+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2024-07-20T14:27:49,370653+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2024-07-20T14:27:49,370687+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2024-07-20T14:27:49,370702+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2024-07-20T14:27:49,370706+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2024-07-20T14:27:49,370709+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2024-07-20T14:27:49,370714+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2024-07-20T14:27:49,370717+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2024-07-20T14:27:49,370721+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2024-07-20T14:27:49,370725+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2024-07-20T14:27:49,370729+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2024-07-20T14:27:49,370876+00:00 iommu: Default domain type: Translated
2024-07-20T14:27:49,370878+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2024-07-20T14:27:49,370914+00:00 ACPI: bus type USB registered
2024-07-20T14:27:49,370923+00:00 usbcore: registered new interface driver usbfs
2024-07-20T14:27:49,370926+00:00 usbcore: registered new interface driver hub
2024-07-20T14:27:49,370932+00:00 usbcore: registered new device driver usb
2024-07-20T14:27:49,371273+00:00 NetLabel: Initializing
2024-07-20T14:27:49,371274+00:00 NetLabel:  domain hash size = 128
2024-07-20T14:27:49,371275+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-07-20T14:27:49,371289+00:00 NetLabel:  unlabeled traffic allowed by default
2024-07-20T14:27:49,371289+00:00 PCI: Using ACPI for IRQ routing
2024-07-20T14:27:49,403468+00:00 PCI: pci_cache_line_size set to 64 bytes
2024-07-20T14:27:49,403657+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2024-07-20T14:27:49,403675+00:00 e820: reserve RAM buffer [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:27:49,403751+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2024-07-20T14:27:49,403752+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2024-07-20T14:27:49,403753+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2024-07-20T14:27:49,403757+00:00 vgaarb: loaded
2024-07-20T14:27:49,403792+00:00 hpet: 3 channels of 0 reserved for per-cpu timers
2024-07-20T14:27:49,403802+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2024-07-20T14:27:49,403805+00:00 hpet0: 3 comparators, 64-bit 100.000000 MHz counter
2024-07-20T14:27:49,407236+00:00 clocksource: Switched to clocksource kvm-clock
2024-07-20T14:27:49,407641+00:00 VFS: Disk quotas dquot_6.6.0
2024-07-20T14:27:49,407666+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-07-20T14:27:49,407721+00:00 pnp: PnP ACPI init
2024-07-20T14:27:49,407838+00:00 system 00:04: [mem 0xb0000000-0xbfffffff window] has been reserved
2024-07-20T14:27:49,407961+00:00 pnp: PnP ACPI: found 5 devices
2024-07-20T14:27:49,413355+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2024-07-20T14:27:49,413507+00:00 NET: Registered PF_INET protocol family
2024-07-20T14:27:49,413557+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-07-20T14:27:49,422028+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-07-20T14:27:49,422043+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-07-20T14:27:49,422052+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-07-20T14:27:49,422142+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-07-20T14:27:49,422393+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-07-20T14:27:49,422463+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-07-20T14:27:49,422490+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:27:49,422521+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:27:49,422603+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-07-20T14:27:49,422614+00:00 NET: Registered PF_XDP protocol family
2024-07-20T14:27:49,422619+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2024-07-20T14:27:49,422622+00:00 pci 0000:00:02.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2024-07-20T14:27:49,422624+00:00 pci 0000:00:02.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2024-07-20T14:27:49,422625+00:00 pci 0000:00:02.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2024-07-20T14:27:49,422626+00:00 pci 0000:00:02.4: bridge window [io  0x1000-0x0fff] to [bus 05] add_size 1000
2024-07-20T14:27:49,422627+00:00 pci 0000:00:02.5: bridge window [io  0x1000-0x0fff] to [bus 06] add_size 1000
2024-07-20T14:27:49,422629+00:00 pci 0000:00:02.6: bridge window [io  0x1000-0x0fff] to [bus 07] add_size 1000
2024-07-20T14:27:49,422630+00:00 pci 0000:00:02.7: bridge window [io  0x1000-0x0fff] to [bus 08] add_size 1000
2024-07-20T14:27:49,422631+00:00 pci 0000:00:03.0: bridge window [io  0x1000-0x0fff] to [bus 09] add_size 1000
2024-07-20T14:27:49,422637+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x1fff]: assigned
2024-07-20T14:27:49,422639+00:00 pci 0000:00:02.1: bridge window [io  0x2000-0x2fff]: assigned
2024-07-20T14:27:49,422640+00:00 pci 0000:00:02.2: bridge window [io  0x3000-0x3fff]: assigned
2024-07-20T14:27:49,422641+00:00 pci 0000:00:02.3: bridge window [io  0x4000-0x4fff]: assigned
2024-07-20T14:27:49,422642+00:00 pci 0000:00:02.4: bridge window [io  0x5000-0x5fff]: assigned
2024-07-20T14:27:49,422643+00:00 pci 0000:00:02.5: bridge window [io  0x6000-0x6fff]: assigned
2024-07-20T14:27:49,422644+00:00 pci 0000:00:02.6: bridge window [io  0x7000-0x7fff]: assigned
2024-07-20T14:27:49,422645+00:00 pci 0000:00:02.7: bridge window [io  0x8000-0x8fff]: assigned
2024-07-20T14:27:49,422646+00:00 pci 0000:00:03.0: bridge window [io  0x9000-0x9fff]: assigned
2024-07-20T14:27:49,422649+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:27:49,422661+00:00 pci 0000:00:02.0:   bridge window [io  0x1000-0x1fff]
2024-07-20T14:27:49,423851+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:27:49,424513+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:27:49,425711+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:27:49,425720+00:00 pci 0000:00:02.1:   bridge window [io  0x2000-0x2fff]
2024-07-20T14:27:49,426587+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:27:49,427152+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:27:49,428330+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:27:49,428338+00:00 pci 0000:00:02.2:   bridge window [io  0x3000-0x3fff]
2024-07-20T14:27:49,429208+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:27:49,429787+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:27:49,430944+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:27:49,430951+00:00 pci 0000:00:02.3:   bridge window [io  0x4000-0x4fff]
2024-07-20T14:27:49,431868+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:27:49,432469+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:27:49,433649+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:27:49,435198+00:00 pci 0000:00:02.4:   bridge window [io  0x5000-0x5fff]
2024-07-20T14:27:49,437320+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:27:49,437800+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:27:49,438593+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:27:49,438600+00:00 pci 0000:00:02.5:   bridge window [io  0x6000-0x6fff]
2024-07-20T14:27:49,439282+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:27:49,439861+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:27:49,441044+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:27:49,441052+00:00 pci 0000:00:02.6:   bridge window [io  0x7000-0x7fff]
2024-07-20T14:27:49,441939+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:27:49,442522+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:27:49,443630+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:27:49,443637+00:00 pci 0000:00:02.7:   bridge window [io  0x8000-0x8fff]
2024-07-20T14:27:49,444278+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:27:49,444716+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:27:49,445710+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:27:49,445717+00:00 pci 0000:00:03.0:   bridge window [io  0x9000-0x9fff]
2024-07-20T14:27:49,446630+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:27:49,448815+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:27:49,451015+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2024-07-20T14:27:49,451017+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2024-07-20T14:27:49,451019+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2024-07-20T14:27:49,451020+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xafffffff window]
2024-07-20T14:27:49,451021+00:00 pci_bus 0000:00: resource 8 [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:27:49,451022+00:00 pci_bus 0000:00: resource 9 [mem 0x180000000-0x97fffffff window]
2024-07-20T14:27:49,451023+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2024-07-20T14:27:49,451024+00:00 pci_bus 0000:01: resource 1 [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:27:49,451025+00:00 pci_bus 0000:01: resource 2 [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:27:49,451027+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2024-07-20T14:27:49,451027+00:00 pci_bus 0000:02: resource 1 [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:27:49,451028+00:00 pci_bus 0000:02: resource 2 [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:27:49,451030+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2024-07-20T14:27:49,451030+00:00 pci_bus 0000:03: resource 1 [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:27:49,451031+00:00 pci_bus 0000:03: resource 2 [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:27:49,451033+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2024-07-20T14:27:49,451033+00:00 pci_bus 0000:04: resource 1 [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:27:49,451034+00:00 pci_bus 0000:04: resource 2 [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:27:49,451035+00:00 pci_bus 0000:05: resource 0 [io  0x5000-0x5fff]
2024-07-20T14:27:49,451036+00:00 pci_bus 0000:05: resource 1 [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:27:49,451037+00:00 pci_bus 0000:05: resource 2 [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:27:49,451038+00:00 pci_bus 0000:06: resource 0 [io  0x6000-0x6fff]
2024-07-20T14:27:49,451039+00:00 pci_bus 0000:06: resource 1 [mem 0xfde00000-0xfdffffff]
2024-07-20T14:27:49,451040+00:00 pci_bus 0000:06: resource 2 [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:27:49,451041+00:00 pci_bus 0000:07: resource 0 [io  0x7000-0x7fff]
2024-07-20T14:27:49,451042+00:00 pci_bus 0000:07: resource 1 [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:27:49,451043+00:00 pci_bus 0000:07: resource 2 [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:27:49,451044+00:00 pci_bus 0000:08: resource 0 [io  0x8000-0x8fff]
2024-07-20T14:27:49,451044+00:00 pci_bus 0000:08: resource 1 [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:27:49,451045+00:00 pci_bus 0000:08: resource 2 [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:27:49,451046+00:00 pci_bus 0000:09: resource 0 [io  0x9000-0x9fff]
2024-07-20T14:27:49,451047+00:00 pci_bus 0000:09: resource 1 [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:27:49,451048+00:00 pci_bus 0000:09: resource 2 [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:27:49,451315+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2024-07-20T14:27:49,452158+00:00 PCI: CLS 0 bytes, default 64
2024-07-20T14:27:49,452225+00:00 Trying to unpack rootfs image as initramfs...
2024-07-20T14:27:49,454589+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2024-07-20T14:27:49,454592+00:00 software IO TLB: mapped [mem 0x000000007bfdc000-0x000000007ffdc000] (64MB)
2024-07-20T14:27:49,454879+00:00 Initialise system trusted keyrings
2024-07-20T14:27:49,455153+00:00 workingset: timestamp_bits=40 max_order=20 bucket_order=0
2024-07-20T14:27:49,464843+00:00 Key type asymmetric registered
2024-07-20T14:27:49,464845+00:00 Asymmetric key parser 'x509' registered
2024-07-20T14:27:49,464861+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 251)
2024-07-20T14:27:49,466421+00:00 io scheduler mq-deadline registered
2024-07-20T14:27:49,466422+00:00 io scheduler kyber registered
2024-07-20T14:27:49,467866+00:00 pcieport 0000:00:02.0: PME: Signaling with IRQ 24
2024-07-20T14:27:49,468867+00:00 pcieport 0000:00:02.1: PME: Signaling with IRQ 25
2024-07-20T14:27:49,469380+00:00 pcieport 0000:00:02.2: PME: Signaling with IRQ 26
2024-07-20T14:27:49,470353+00:00 pcieport 0000:00:02.3: PME: Signaling with IRQ 27
2024-07-20T14:27:49,472234+00:00 pcieport 0000:00:02.4: PME: Signaling with IRQ 28
2024-07-20T14:27:49,473255+00:00 pcieport 0000:00:02.5: PME: Signaling with IRQ 29
2024-07-20T14:27:49,474205+00:00 pcieport 0000:00:02.6: PME: Signaling with IRQ 30
2024-07-20T14:27:49,475196+00:00 pcieport 0000:00:02.7: PME: Signaling with IRQ 31
2024-07-20T14:27:49,475483+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2024-07-20T14:27:49,476234+00:00 pcieport 0000:00:03.0: PME: Signaling with IRQ 32
2024-07-20T14:27:49,476574+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2024-07-20T14:27:49,476669+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2024-07-20T14:27:49,476959+00:00 Linux agpgart interface v0.103
2024-07-20T14:27:49,476966+00:00 ACPI: bus type drm_connector registered
2024-07-20T14:27:49,477185+00:00 usbcore: registered new interface driver usbserial_generic
2024-07-20T14:27:49,477189+00:00 usbserial: USB Serial support registered for generic
2024-07-20T14:27:49,477191+00:00 amd_pstate: the _CPC object is not present in SBIOS or ACPI disabled
2024-07-20T14:27:49,477233+00:00 drop_monitor: Initializing network drop monitor service
2024-07-20T14:27:49,477393+00:00 NET: Registered PF_INET6 protocol family
2024-07-20T14:27:49,541745+00:00 Freeing initrd memory: 12324K
2024-07-20T14:27:49,542038+00:00 Segment Routing with IPv6
2024-07-20T14:27:49,542060+00:00 In-situ OAM (IOAM) with IPv6
2024-07-20T14:27:49,542315+00:00 IPI shorthand broadcast: enabled
2024-07-20T14:27:49,544952+00:00 sched_clock: Marking stable (539016494, 5363780)->(547328974, -2948700)
2024-07-20T14:27:49,545198+00:00 registered taskstats version 1
2024-07-20T14:27:49,545328+00:00 Loading compiled-in X.509 certificates
2024-07-20T14:27:49,551626+00:00 Key type .fscrypt registered
2024-07-20T14:27:49,551629+00:00 Key type fscrypt-provisioning registered
2024-07-20T14:27:49,551747+00:00 PM:   Magic number: 0:919:485
2024-07-20T14:27:49,555056+00:00 RAS: Correctable Errors collector initialized.
2024-07-20T14:27:49,555117+00:00 clk: Disabling unused clocks
2024-07-20T14:27:49,556905+00:00 Freeing unused decrypted memory: 2028K
2024-07-20T14:27:49,557390+00:00 Freeing unused kernel image (initmem) memory: 3164K
2024-07-20T14:27:49,557391+00:00 Write protecting the kernel read-only data: 28672k
2024-07-20T14:27:49,557755+00:00 Freeing unused kernel image (rodata/data gap) memory: 1272K
2024-07-20T14:27:49,580225+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2024-07-20T14:27:49,580233+00:00 Run /init as init process
2024-07-20T14:27:49,580235+00:00   with arguments:
2024-07-20T14:27:49,580236+00:00     /init
2024-07-20T14:27:49,580237+00:00   with environment:
2024-07-20T14:27:49,580238+00:00     HOME=/
2024-07-20T14:27:49,580239+00:00     TERM=linux
2024-07-20T14:27:49,580240+00:00     BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage
2024-07-20T14:27:49,605412+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] loading module virtio_balloon...
2024-07-20T14:27:49,612009+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] loading module virtio_console...
2024-07-20T14:27:49,616006+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] loading module virtio_rng...
2024-07-20T14:27:49,619679+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] loading module virtio_gpu...
2024-07-20T14:27:49,627194+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] loading module dm_mod...
2024-07-20T14:27:49,642048+00:00 device-mapper: ioctl: 4.48.0-ioctl (2023-03-01) initialised: dm-devel@redhat.com
2024-07-20T14:27:49,643565+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] running udev...
2024-07-20T14:27:49,654710+00:00 stage-1-init: [Sat Jul 20 14:27:49 UTC 2024] Starting systemd-udevd version 255.6
2024-07-20T14:27:49,715134+00:00 rtc_cmos 00:03: RTC can wake from S4
2024-07-20T14:27:49,726455+00:00 rtc_cmos 00:03: registered as rtc0
2024-07-20T14:27:49,726536+00:00 rtc_cmos 00:03: setting system clock to 2024-07-20T14:27:50 UTC (1721485670)
2024-07-20T14:27:49,726599+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram, hpet irqs
2024-07-20T14:27:49,733285+00:00 SCSI subsystem initialized
2024-07-20T14:27:49,736251+00:00 random: crng init done
2024-07-20T14:27:49,742924+00:00 virtio_blk virtio3: 2/0/0 default/read/poll queues
2024-07-20T14:27:49,743325+00:00 virtio_blk virtio3: [vda] 1048576000 512-byte logical blocks (537 GB/500 GiB)
2024-07-20T14:27:49,744048+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2024-07-20T14:27:49,747039+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2024-07-20T14:27:49,747048+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2024-07-20T14:27:49,750480+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input0
2024-07-20T14:27:49,751062+00:00  vda: vda1 vda2 vda3 vda4
2024-07-20T14:27:49,751656+00:00 virtio_blk virtio4: 2/0/0 default/read/poll queues
2024-07-20T14:27:49,753816+00:00 virtio_blk virtio4: [vdb] 1048576000 512-byte logical blocks (537 GB/500 GiB)
2024-07-20T14:27:49,756172+00:00  vdb: vdb1 vdb2 vdb3 vdb4
2024-07-20T14:27:49,765459+00:00 libata version 3.00 loaded.
2024-07-20T14:27:49,770295+00:00 ahci 0000:00:1f.2: version 3.0
2024-07-20T14:27:49,770485+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2024-07-20T14:27:49,770859+00:00 ahci 0000:00:1f.2: AHCI 0001.0000 32 slots 6 ports 1.5 Gbps 0x3f impl SATA mode
2024-07-20T14:27:49,770862+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2024-07-20T14:27:49,773425+00:00 scsi host0: ahci
2024-07-20T14:27:49,773638+00:00 scsi host1: ahci
2024-07-20T14:27:49,773768+00:00 scsi host2: ahci
2024-07-20T14:27:49,773892+00:00 scsi host3: ahci
2024-07-20T14:27:49,774576+00:00 scsi host4: ahci
2024-07-20T14:27:49,775758+00:00 scsi host5: ahci
2024-07-20T14:27:49,775802+00:00 ata1: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a100 irq 44 lpm-pol 0
2024-07-20T14:27:49,775807+00:00 ata2: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a180 irq 44 lpm-pol 0
2024-07-20T14:27:49,775811+00:00 ata3: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a200 irq 44 lpm-pol 0
2024-07-20T14:27:49,775815+00:00 ata4: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a280 irq 44 lpm-pol 0
2024-07-20T14:27:49,775819+00:00 ata5: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a300 irq 44 lpm-pol 0
2024-07-20T14:27:49,775822+00:00 ata6: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a380 irq 44 lpm-pol 0
2024-07-20T14:27:50,087766+00:00 ata2: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:27:50,087919+00:00 ata1: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:27:50,088066+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:27:50,088205+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:27:50,088335+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:27:50,088491+00:00 ata4: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2024-07-20T14:27:50,088576+00:00 ata4.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2024-07-20T14:27:50,088581+00:00 ata4.00: applying bridge limits
2024-07-20T14:27:50,088672+00:00 ata4.00: configured for UDMA/100
2024-07-20T14:27:50,089150+00:00 scsi 3:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2024-07-20T14:27:50,093830+00:00 virtio_net virtio0 enp1s0: renamed from eth0
2024-07-20T14:27:50,102003+00:00 virtio_net virtio1 enp2s0: renamed from eth1
2024-07-20T14:27:50,103810+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:27:50,103824+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 1
2024-07-20T14:27:50,104125+00:00 xhci_hcd 0000:03:00.0: hcc params 0x00087001 hci version 0x100 quirks 0x0000000000000010
2024-07-20T14:27:50,104785+00:00 sr 3:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2024-07-20T14:27:50,104790+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2024-07-20T14:27:50,105013+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:27:50,105020+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 2
2024-07-20T14:27:50,105024+00:00 xhci_hcd 0000:03:00.0: Host supports USB 3.0 SuperSpeed
2024-07-20T14:27:50,105123+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.08
2024-07-20T14:27:50,105128+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:27:50,105131+00:00 usb usb1: Product: xHCI Host Controller
2024-07-20T14:27:50,105134+00:00 usb usb1: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:27:50,105136+00:00 usb usb1: SerialNumber: 0000:03:00.0
2024-07-20T14:27:50,105302+00:00 hub 1-0:1.0: USB hub found
2024-07-20T14:27:50,105345+00:00 hub 1-0:1.0: 4 ports detected
2024-07-20T14:27:50,105762+00:00 usb usb2: We don't know the algorithms for LPM for this host, disabling LPM.
2024-07-20T14:27:50,105805+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.08
2024-07-20T14:27:50,105809+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:27:50,105812+00:00 usb usb2: Product: xHCI Host Controller
2024-07-20T14:27:50,105814+00:00 usb usb2: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:27:50,105816+00:00 usb usb2: SerialNumber: 0000:03:00.0
2024-07-20T14:27:50,107558+00:00 hub 2-0:1.0: USB hub found
2024-07-20T14:27:50,107603+00:00 hub 2-0:1.0: 4 ports detected
2024-07-20T14:27:50,108156+00:00 sr 3:0:0:0: Attached scsi CD-ROM sr0
2024-07-20T14:27:50,130572+00:00 md/raid1:md126: not clean -- starting background reconstruction
2024-07-20T14:27:50,130569+00:00 md/raid1:md127: active with 2 out of 2 mirrors
2024-07-20T14:27:50,130579+00:00 md/raid1:md126: active with 2 out of 2 mirrors
2024-07-20T14:27:50,130605+00:00 md126: detected capacity change from 0 to 125761536
2024-07-20T14:27:50,130617+00:00 md127: detected capacity change from 0 to 1023872
2024-07-20T14:27:50,130802+00:00 md: resync of RAID array md126
2024-07-20T14:27:50,130917+00:00  md127:
2024-07-20T14:27:50,135638+00:00  md126: p1
2024-07-20T14:27:50,165942+00:00 stage-1-init: [Sat Jul 20 14:27:50 UTC 2024] starting device mapper and LVM...
2024-07-20T14:27:50,196707+00:00 stage-1-init: [Sat Jul 20 14:27:50 UTC 2024] checking /dev/disk/by-id/md-name-any:system-part1...
2024-07-20T14:27:50,197298+00:00 stage-1-init: [Sat Jul 20 14:27:50 UTC 2024] fsck (busybox 1.36.1)
2024-07-20T14:27:50,197852+00:00 stage-1-init: [Sat Jul 20 14:27:50 UTC 2024] [fsck.ext4 (1) -- /mnt-root/] fsck.ext4 -a /dev/disk/by-id/md-name-any:system-part1
2024-07-20T14:27:50,504117+00:00 stage-1-init: [Sat Jul 20 14:27:51 UTC 2024] /dev/disk/by-id/md-name-any_system-part1: clean, 128481/3932160 files, 843259/15719680 blocks
2024-07-20T14:27:50,587631+00:00 stage-1-init: [Sat Jul 20 14:27:51 UTC 2024] mounting /dev/disk/by-id/md-name-any:system-part1 on /...
2024-07-20T14:27:51,044999+00:00 EXT4-fs (md126p1): mounted filesystem 85376261-ceab-4a9d-b15e-6cf5673c06ef r/w with ordered data mode. Quota mode: none.
2024-07-20T14:27:51,054400+00:00 EXT4-fs (md126p1): re-mounted 85376261-ceab-4a9d-b15e-6cf5673c06ef r/w. Quota mode: none.
2024-07-20T14:27:51,195386+00:00 EXT4-fs (md126p1): re-mounted 85376261-ceab-4a9d-b15e-6cf5673c06ef r/w. Quota mode: none.
2024-07-20T14:27:51,195926+00:00 booting system configuration /nix/store/hwhljgz6bjskfac07rqfwy5dwn3mk1s9-nixos-system-worker1-24.11.20240716.ad0b5ee
2024-07-20T14:27:51,210198+00:00 stage-2-init: running activation script...
2024-07-20T14:27:51,648461+00:00 stage-2-init: setting up /etc...
2024-07-20T14:27:51,756421+00:00 systemd[1]: Inserted module 'autofs4'
2024-07-20T14:27:51,768423+00:00 systemd[1]: systemd 255.6 running in system mode (+PAM +AUDIT -SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -BPF_FRAMEWORK -XKBCOMMON +UTMP -SYSVINIT default-hierarchy=unified)
2024-07-20T14:27:51,768428+00:00 systemd[1]: Detected virtualization kvm.
2024-07-20T14:27:51,768433+00:00 systemd[1]: Detected architecture x86-64.
2024-07-20T14:27:51,769241+00:00 systemd[1]: Hostname set to <worker1>.
2024-07-20T14:27:51,769490+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-07-20T14:27:52,270059+00:00 systemd[1]: Queued start job for default target Multi-User System.
2024-07-20T14:27:52,281189+00:00 systemd[1]: Created slice Slice /system/getty.
2024-07-20T14:27:52,281897+00:00 systemd[1]: Created slice Slice /system/modprobe.
2024-07-20T14:27:52,282619+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2024-07-20T14:27:52,283332+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2024-07-20T14:27:52,283937+00:00 systemd[1]: Created slice User and Session Slice.
2024-07-20T14:27:52,284377+00:00 systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
2024-07-20T14:27:52,284760+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2024-07-20T14:27:52,285165+00:00 systemd[1]: Expecting device /dev/hvc0...
2024-07-20T14:27:52,285443+00:00 systemd[1]: Expecting device /dev/md/boot...
2024-07-20T14:27:52,285729+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp1s0...
2024-07-20T14:27:52,286125+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp2s0...
2024-07-20T14:27:52,286478+00:00 systemd[1]: Reached target Local Encrypted Volumes.
2024-07-20T14:27:52,286770+00:00 systemd[1]: Reached target Containers.
2024-07-20T14:27:52,287085+00:00 systemd[1]: Reached target Path Units.
2024-07-20T14:27:52,287407+00:00 systemd[1]: Reached target Remote File Systems.
2024-07-20T14:27:52,287692+00:00 systemd[1]: Reached target Slice Units.
2024-07-20T14:27:52,288000+00:00 systemd[1]: Reached target Swaps.
2024-07-20T14:27:52,289534+00:00 systemd[1]: Listening on Process Core Dump Socket.
2024-07-20T14:27:52,289891+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2024-07-20T14:27:52,290325+00:00 systemd[1]: Listening on Journal Socket.
2024-07-20T14:27:52,290744+00:00 systemd[1]: Listening on Userspace Out-Of-Memory (OOM) Killer Socket.
2024-07-20T14:27:52,291190+00:00 systemd[1]: Listening on udev Control Socket.
2024-07-20T14:27:52,291630+00:00 systemd[1]: Listening on udev Kernel Socket.
2024-07-20T14:27:52,308621+00:00 systemd[1]: Mounting Huge Pages File System...
2024-07-20T14:27:52,310605+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2024-07-20T14:27:52,314644+00:00 systemd[1]: Mounting Kernel Debug File System...
2024-07-20T14:27:52,318411+00:00 systemd[1]: Starting domainname.service...
2024-07-20T14:27:52,320557+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2024-07-20T14:27:52,322462+00:00 systemd[1]: Starting Load Kernel Module configfs...
2024-07-20T14:27:52,327427+00:00 systemd[1]: Starting Load Kernel Module drm...
2024-07-20T14:27:52,337852+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2024-07-20T14:27:52,340476+00:00 systemd[1]: Starting Load Kernel Module fuse...
2024-07-20T14:27:52,342428+00:00 systemd[1]: Starting mount-pstore.service...
2024-07-20T14:27:52,344473+00:00 systemd[1]: Starting Create SUID/SGID Wrappers...
2024-07-20T14:27:52,346408+00:00 systemd[1]: File System Check on Root Device was skipped because of an unmet condition check (ConditionPathIsReadWrite=!/).
2024-07-20T14:27:52,348456+00:00 systemd[1]: Starting Journal Service...
2024-07-20T14:27:52,349972+00:00 systemd[1]: Starting Load Kernel Modules...
2024-07-20T14:27:52,352471+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2024-07-20T14:27:52,354064+00:00 fuse: init (API version 7.39)
2024-07-20T14:27:52,356476+00:00 systemd[1]: Starting Coldplug All udev Devices...
2024-07-20T14:27:52,359410+00:00 systemd[1]: Mounted Huge Pages File System.
2024-07-20T14:27:52,359717+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2024-07-20T14:27:52,359996+00:00 systemd[1]: Mounted Kernel Debug File System.
2024-07-20T14:27:52,360334+00:00 systemd[1]: domainname.service: Deactivated successfully.
2024-07-20T14:27:52,360452+00:00 systemd[1]: Finished domainname.service.
2024-07-20T14:27:52,360881+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2024-07-20T14:27:52,361583+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-07-20T14:27:52,362394+00:00 systemd[1]: Finished Load Kernel Module configfs.
2024-07-20T14:27:52,362789+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-07-20T14:27:52,362867+00:00 systemd[1]: Finished Load Kernel Module drm.
2024-07-20T14:27:52,363227+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-07-20T14:27:52,363310+00:00 systemd[1]: Finished Load Kernel Module efi_pstore.
2024-07-20T14:27:52,364620+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-07-20T14:27:52,364700+00:00 systemd[1]: Finished Load Kernel Module fuse.
2024-07-20T14:27:52,369001+00:00 systemd-journald[406]: Collecting audit messages is disabled.
2024-07-20T14:27:52,371541+00:00 systemd[1]: Mounting FUSE Control File System...
2024-07-20T14:27:52,374415+00:00 systemd[1]: Mounting Kernel Configuration File System...
2024-07-20T14:27:52,379967+00:00 systemd[1]: Starting Create Static Device Nodes in /dev gracefully...
2024-07-20T14:27:52,381957+00:00 systemd[1]: Mounted FUSE Control File System.
2024-07-20T14:27:52,384583+00:00 systemd[1]: Mounted Kernel Configuration File System.
2024-07-20T14:27:52,396391+00:00 EXT4-fs (md126p1): re-mounted 85376261-ceab-4a9d-b15e-6cf5673c06ef r/w. Quota mode: none.
2024-07-20T14:27:52,398815+00:00 systemd[1]: Finished Remount Root and Kernel File Systems.
2024-07-20T14:27:52,405594+00:00 systemd[1]: Starting Load/Save OS Random Seed...
2024-07-20T14:27:52,416546+00:00 systemd[1]: Finished Create Static Device Nodes in /dev gracefully.
2024-07-20T14:27:52,418759+00:00 systemd[1]: Starting Create Static Device Nodes in /dev...
2024-07-20T14:27:52,435060+00:00 systemd[1]: Started Journal Service.
2024-07-20T14:27:52,435740+00:00 Key type ceph registered
2024-07-20T14:27:52,435811+00:00 libceph: loaded (mon/osd proto 15/24)
2024-07-20T14:27:52,449899+00:00 rbd: loaded (major 251)
2024-07-20T14:27:52,453645+00:00 systemd-journald[406]: Received client request to flush runtime journal.
2024-07-20T14:27:52,455381+00:00 NET: Registered PF_ALG protocol family
2024-07-20T14:27:52,502562+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2024-07-20T14:27:52,509808+00:00 tun: Universal TUN/TAP device driver, 1.6
2024-07-20T14:27:52,511895+00:00 loop: module loaded
2024-07-20T14:27:53,000183+00:00 cirrus 0000:00:01.0: vgaarb: deactivate vga console
2024-07-20T14:27:53,002298+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input2
2024-07-20T14:27:53,005612+00:00 ACPI: button: Power Button [PWRF]
2024-07-20T14:27:53,010495+00:00 Console: switching to colour dummy device 80x25
2024-07-20T14:27:53,042246+00:00 [drm] Initialized cirrus 2.0.0 2019 for 0000:00:01.0 on minor 0
2024-07-20T14:27:53,046250+00:00 fbcon: cirrusdrmfb (fb0) is primary device
2024-07-20T14:27:53,075189+00:00  md127:
2024-07-20T14:27:53,095712+00:00 Console: switching to colour frame buffer device 128x48
2024-07-20T14:27:53,096846+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2024-07-20T14:27:53,114538+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2024-07-20T14:27:53,114608+00:00 i2c i2c-0: 1/1 memory slots populated (from DMI)
2024-07-20T14:27:53,114609+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2024-07-20T14:27:53,152481+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2024-07-20T14:27:53,152667+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2024-07-20T14:27:53,157606+00:00 mousedev: PS/2 mouse device common for all mice
2024-07-20T14:27:53,176051+00:00 iTCO_wdt iTCO_wdt.1.auto: Found a ICH9 TCO device (Version=2, TCOBASE=0x0660)
2024-07-20T14:27:53,176926+00:00 iTCO_wdt iTCO_wdt.1.auto: initialized. heartbeat=30 sec (nowayout=0)
2024-07-20T14:27:53,189394+00:00 cirrus 0000:00:01.0: [drm] fb0: cirrusdrmfb frame buffer device
2024-07-20T14:27:53,257073+00:00 kvm_amd: Nested Virtualization enabled
2024-07-20T14:27:53,257078+00:00 kvm_amd: Nested Paging disabled
2024-07-20T14:27:53,267425+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:27:53,267430+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:27:53,271244+00:00 EDAC MC: Ver: 3.0.0
2024-07-20T14:27:54,159038+00:00 8021q: 802.1Q VLAN Support v1.8
2024-07-20T14:27:54,254584+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2024-07-20T14:27:54,255976+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2024-07-20T14:27:54,256104+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2024-07-20T14:27:54,337027+00:00 8021q: adding VLAN 0 to HW filter on device enp2s0
2024-07-20T14:27:54,388946+00:00 8021q: adding VLAN 0 to HW filter on device enp1s0
2024-07-20T14:27:54,418356+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:27:54,418361+00:00 private: port 1(vlan4000) entered disabled state
2024-07-20T14:27:54,418408+00:00 vlan4000: entered allmulticast mode
2024-07-20T14:27:54,418410+00:00 virtio_net virtio1 enp2s0: entered allmulticast mode
2024-07-20T14:27:54,418687+00:00 vlan4000: entered promiscuous mode
2024-07-20T14:27:54,418689+00:00 virtio_net virtio1 enp2s0: entered promiscuous mode
2024-07-20T14:27:54,420357+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:27:54,420359+00:00 private: port 1(vlan4000) entered forwarding state
2024-07-20T14:27:54,433953+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:27:54,433958+00:00 public: port 1(enp1s0) entered disabled state
2024-07-20T14:27:54,435624+00:00 virtio_net virtio0 enp1s0: entered allmulticast mode
2024-07-20T14:27:54,435714+00:00 virtio_net virtio0 enp1s0: entered promiscuous mode
2024-07-20T14:27:54,451587+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:27:54,451593+00:00 public: port 1(enp1s0) entered forwarding state
2024-07-20T14:27:55,269155+00:00 NET: Registered PF_PACKET protocol family
2024-07-20T14:28:01,392244+00:00 Bridge firewalling registered
2024-07-20T14:31:55,395043+00:00 Initializing XFRM netlink socket
2024-07-20T14:32:38,927082+00:00 eth0: renamed from tmp1b7a3
2024-07-20T14:32:40,562102+00:00 eth0: renamed from tmpb3b1d
2024-07-20T14:32:41,374121+00:00 eth0: renamed from tmp1c89c
2024-07-20T14:32:42,271987+00:00 eth0: renamed from tmp72187
2024-07-20T14:32:42,504515+00:00 eth0: renamed from tmp677dd
2024-07-20T14:32:42,645479+00:00 eth0: renamed from tmp3e034
2024-07-20T14:32:43,010977+00:00 eth0: renamed from tmpc65ad
2024-07-20T14:32:43,257601+00:00 eth0: renamed from tmpc1fd2
2024-07-20T14:32:43,716302+00:00 eth0: renamed from tmpc2731
2024-07-20T14:32:44,276076+00:00 eth0: renamed from tmp7f8af
2024-07-20T14:38:23,077529+00:00 md: md126: resync done.
2024-07-20T14:38:25,919077+00:00 eth0: renamed from tmp0b494
2024-07-20T14:38:27,293195+00:00 eth0: renamed from tmp6bf4c
2024-07-20T14:38:27,564053+00:00 eth0: renamed from tmp58085
2024-07-20T14:38:27,651349+00:00 eth0: renamed from tmp6c674
2024-07-20T14:38:27,776979+00:00 eth0: renamed from tmp29ca3
2024-07-20T14:38:27,871682+00:00 eth0: renamed from tmp82807
2024-07-20T14:38:28,343091+00:00 eth0: renamed from tmp9df8b
2024-07-20T14:38:28,919019+00:00 eth0: renamed from tmp184d2
2024-07-20T14:38:29,701979+00:00 eth0: renamed from tmp7d400
2024-07-20T14:38:29,920360+00:00 eth0: renamed from tmpb2003
2024-07-20T14:38:30,796411+00:00 eth0: renamed from tmp7150a
2024-07-20T14:38:31,158283+00:00 eth0: renamed from tmp90b04
2024-07-20T14:38:31,320082+00:00 eth0: renamed from tmpe3b27
2024-07-20T14:38:31,411288+00:00 eth0: renamed from tmpae59a
2024-07-20T14:38:31,990026+00:00 eth0: renamed from tmp9bd0e
2024-07-20T14:38:50,197951+00:00 eth0: renamed from tmp62f38
