{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.97.59:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:14.663Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:15.109Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:15.109Z",
  "value": "0 1 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:15.109Z",
  "value": "13 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:15.109Z",
  "value": "0 1 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5556 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:26.764Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5557 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:26.764Z",
  "value": "0 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:31.855Z",
  "value": "0 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.213.42:9402 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:33.896Z",
  "value": "0 0 (27) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:36.376Z",
  "value": "0 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:36.376Z",
  "value": "0 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.174.214:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:36.627Z",
  "value": "0 0 (28) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:38.101Z",
  "value": "0 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:38.101Z",
  "value": "0 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:39.356Z",
  "value": "0 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.115.248:8082 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:40.071Z",
  "value": "0 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:46.406Z",
  "value": "16 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:46.407Z",
  "value": "0 1 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:46.407Z",
  "value": "16 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:46.407Z",
  "value": "0 1 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.115.248:8082 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:47.904Z",
  "value": "17 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.115.248:8082 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:47.904Z",
  "value": "0 1 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.602Z",
  "value": "18 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.602Z",
  "value": "0 1 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "16 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "19 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "0 2 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "16 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "19 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.148.50:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:55.967Z",
  "value": "0 2 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "9 0 (22) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "0 1 (22) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:26379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "10 0 (20) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:26379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "0 1 (20) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:9121 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "11 0 (21) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.178.184:9121 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:00.976Z",
  "value": "0 1 (21) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:06.373Z",
  "value": "18 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:06.373Z",
  "value": "20 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.192.200:8081 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:06.373Z",
  "value": "0 2 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5556 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:12.482Z",
  "value": "21 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5556 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:12.482Z",
  "value": "0 1 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5557 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:12.507Z",
  "value": "22 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.145.33:5557 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:12.507Z",
  "value": "0 1 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.509Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.509Z",
  "value": "23 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.509Z",
  "value": "0 2 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.510Z",
  "value": "13 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.510Z",
  "value": "24 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:44:13.510Z",
  "value": "0 2 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "25 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "0 1 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:26379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "26 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:26379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "0 1 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:9121 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "27 0 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:9121 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:46.899Z",
  "value": "0 1 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.253.13:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:52.553Z",
  "value": "5 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.253.13:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:52.553Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.213.42:9402 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:58.302Z",
  "value": "28 0 (27) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.213.42:9402 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:45:58.302Z",
  "value": "0 1 (27) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.174.214:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:00.837Z",
  "value": "0 0 (28) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.174.214:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:08.399Z",
  "value": "29 0 (28) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.174.214:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:08.399Z",
  "value": "0 1 (28) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "25 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "0 1 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:26379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "26 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:26379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "0 1 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:9121 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "27 0 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.243.160:9121 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:32.841Z",
  "value": "0 1 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.253.13:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:47:38.604Z",
  "value": "5 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.253.13:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:47:38.604Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "23 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "0 2 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "13 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "24 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:10.838Z",
  "value": "0 2 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:9121 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.150Z",
  "value": "30 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:9121 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.150Z",
  "value": "0 1 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.151Z",
  "value": "31 0 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.151Z",
  "value": "0 1 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:26379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.151Z",
  "value": "32 0 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:26379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:13.151Z",
  "value": "0 1 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "31 0 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "0 1 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:26379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "32 0 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:26379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "0 1 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:9121 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "30 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.70.170:9121 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:51.102Z",
  "value": "0 1 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "23 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "33 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:9101 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "0 3 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "13 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "24 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "34 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.180.197:6379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:48:56.485Z",
  "value": "0 3 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.155.14:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.365Z",
  "value": "0 0 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.365Z",
  "value": "0 0 (30) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.365Z",
  "value": "0 0 (31) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.365Z",
  "value": "0 0 (32) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.26.204:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.875Z",
  "value": "0 0 (33) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.875Z",
  "value": "0 0 (34) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.875Z",
  "value": "0 0 (35) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:47.875Z",
  "value": "0 0 (36) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.155.14:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:03.730Z",
  "value": "0 0 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:03.730Z",
  "value": "0 0 (32) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:03.730Z",
  "value": "0 0 (30) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:03.730Z",
  "value": "0 0 (31) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.155.14:8080 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "35 0 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.155.14:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "0 1 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:32495 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "35 0 (31) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "0 1 (31) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32495 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "35 0 (32) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "0 1 (32) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:32495 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "35 0 (30) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:32495 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:04.712Z",
  "value": "0 1 (30) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.26.204:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.507Z",
  "value": "0 0 (33) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.507Z",
  "value": "0 0 (34) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.507Z",
  "value": "0 0 (35) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.507Z",
  "value": "0 0 (36) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.26.204:8080 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "36 0 (33) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.26.204:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "0 1 (33) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30568 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "36 0 (36) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "0 1 (36) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:30568 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "36 0 (34) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "0 1 (34) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:30568 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "36 0 (35) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.21:30568 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:09:05.561Z",
  "value": "0 1 (35) [0x42 0x0]"
}

