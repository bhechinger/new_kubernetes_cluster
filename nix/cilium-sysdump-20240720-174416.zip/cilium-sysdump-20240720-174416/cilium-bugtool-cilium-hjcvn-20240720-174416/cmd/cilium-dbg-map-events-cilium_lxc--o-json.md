{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.328Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.328Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.330Z",
  "value": "id=3597  sec_id=9426  flags=0x0000 ifindex=54  mac=5E:9F:6B:12:D3:4B nodemac=BA:86:31:6E:B2:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.331Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.331Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.332Z",
  "value": "id=1236  sec_id=45318 flags=0x0000 ifindex=22  mac=7A:A0:78:D7:A9:3A nodemac=3A:61:5C:1E:55:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.332Z",
  "value": "id=3756  sec_id=18175 flags=0x0000 ifindex=58  mac=12:4D:D8:65:DA:E8 nodemac=9A:FE:E4:9A:0E:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.332Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.332Z",
  "value": "id=290   sec_id=13815 flags=0x0000 ifindex=60  mac=92:28:59:5B:09:D6 nodemac=EE:10:CD:AE:EF:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.332Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:51.333Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.3.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:18.635Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.3.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:19.954Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.3.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:19.981Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.3.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:43:22.381Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.3.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:46:19.340Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.489Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.490Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.490Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.490Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.491Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.491Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.492Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.492Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.493Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.493Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.494Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.496Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.499Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.500Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.503Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.512Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.490Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.491Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.491Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.492Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.492Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.493Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.493Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.493Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.494Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.494Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.495Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.495Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.495Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.496Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.497Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.499Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.491Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.491Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.491Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.492Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.492Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.493Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.493Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.495Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.496Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.496Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.497Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.498Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.498Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.499Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.499Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.501Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.566Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.566Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.567Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.567Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.567Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.568Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.568Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.568Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.569Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.569Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.569Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.570Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.571Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.571Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.571Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.572Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.028Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.029Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.029Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.030Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.030Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.031Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.032Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.032Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.033Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.033Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.033Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.034Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.035Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.035Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.036Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.038Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.030Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.030Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.031Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.031Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.032Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.032Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.033Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.033Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.034Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.034Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.035Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.035Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.036Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.037Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.038Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.039Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.029Z",
  "value": "id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.029Z",
  "value": "id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.029Z",
  "value": "id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.030Z",
  "value": "id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.030Z",
  "value": "id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.031Z",
  "value": "id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.032Z",
  "value": "id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.032Z",
  "value": "id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.032Z",
  "value": "id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.033Z",
  "value": "id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.033Z",
  "value": "id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.034Z",
  "value": "id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.034Z",
  "value": "id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.034Z",
  "value": "id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.035Z",
  "value": "id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.3.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.035Z",
  "value": "id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC"
}

