goroutine 179 [running]:
runtime/pprof.writeGoroutineStacks({0x3f07700, 0xc000ef8000})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x6a
runtime/pprof.writeGoroutine({0x3f07700?, 0xc000ef8000?}, 0xc000e0d400?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x25
runtime/pprof.(*Profile).WriteTo(0x394e735?, {0x3f07700?, 0xc000ef8000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x146
github.com/google/gops/agent.handle({0x7fd688a07e38?, 0xc000ef8000}, {0xc0009d6000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xd2
github.com/google/gops/agent.listen({0x3f44240, 0xc001143220})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1a5
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x379

goroutine 1 [select, 192 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc000c0f4a0)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:232 +0x16e
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc000c0f4a0)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:216 +0x112
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0xc0000fac00?, {0x3940fc9?, 0x4?, 0x3940e35?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:39 +0x17b
github.com/spf13/cobra.(*Command).execute(0xc0001a6300, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:987 +0xaa3
github.com/spf13/cobra.(*Command).ExecuteC(0xc0001a6300)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1115 +0x3ff
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1039
github.com/cilium/cilium/daemon/cmd.Execute(0xc000c0f4a0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:79 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x57

goroutine 468 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:53 +0x134
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit in goroutine 466
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:48 +0x3d8

goroutine 34 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000721b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 173 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00072bc20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 49 [select, 192 minutes]:
io.(*pipe).read(0xc001695920, {0xc001910000, 0x10000, 0x1?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc001910000?, 0xc000096e20?, 0x410b34?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c9df28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc00159bf28, 0xc0016b5120)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 50 [select, 192 minutes]:
io.(*pipe).read(0xc001695980, {0xc001920000, 0x10000, 0x1?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc001920000?, 0xc000090e20?, 0x410b34?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c9ff28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc000090fd0?, 0xc00159bf38, 0xc0016b5140)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 51 [select, 192 minutes]:
io.(*pipe).read(0xc0016959e0, {0xc001930000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x7fd688ecd4c8?, {0xc001930000?, 0x410ba5?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000091728)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc00159bf48, 0xc0016b5160)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 52 [select, 192 minutes]:
io.(*pipe).read(0xc001695a40, {0xc001900000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x7fd688f299e0?, {0xc001900000?, 0x410ba5?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c9bf28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc00159bf58, 0xc0016b5180)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 47 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x58
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x90

goroutine 152 [IO wait]:
internal/poll.runtime_pollWait(0x7fd6cfc4bc48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdd400?, 0xc0015ca000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdd400, {0xc0015ca000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdd400, {0xc0015ca000?, 0x33ccd60?, 0xc0011902e0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017b8048, {0xc0015ca000?, 0xc0015ca000?, 0x5?})
	/usr/local/go/src/net/net.go:179 +0x45
crypto/tls.(*atLeastReader).Read(0xc004586630, {0xc0015ca000?, 0xc004586630?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:805 +0x3b
bytes.(*Buffer).ReadFrom(0xc0018de2a8, {0x3f0ca20, 0xc004586630})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc0018de000, {0x7fd688dd9c00?, 0xc0018c2090}, 0xc?)
	/usr/local/go/src/crypto/tls/conn.go:827 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc0018de000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:625 +0x250
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:587
crypto/tls.(*Conn).Read(0xc0018de000, {0xc002003000, 0x1000, 0xc004eadbc8?})
	/usr/local/go/src/crypto/tls/conn.go:1369 +0x158
bufio.(*Reader).Read(0xc0017c21e0, {0xc0018f62e0, 0x9, 0xc000868598?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc0017c21e0}, {0xc0018f62e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc0018f62e0, 0x9, 0x0?}, {0x3f07920?, 0xc0017c21e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0018f62a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc001fa3f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2275 +0x11f
golang.org/x/net/http2.(*ClientConn).readLoop(0xc00019fc80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2170 +0x65
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 151
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:821 +0xcbe

goroutine 211 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc002000398, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000cc7d00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002000370, 0xc001117740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f06e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc00202c7e0}, 0x1, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0009d71c0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f06e0, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc001190880, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 155
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 175 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:151 +0x71
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:145 +0x67

goroutine 176 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00072bd60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 177 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00072bea0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1156 [select, 12 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9ea00, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0009cb980}, 0xc0016f3320, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1097
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 180 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4bd40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0018da000?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0018da000)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0018da000)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc001190000)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc001190000)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc000b5e2d0, {0x3f44240, 0xc001190000})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc000b5e2d0)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xa8
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xc5

goroutine 183 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e97400, {{{0x395f226, 0xd}}, {0x0, 0x0}, 0xc001143420, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 223 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0xc001f61a00, {0x3f59438?, 0xc000777630?}, 0xc000b53900?)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xae
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:106 +0x31
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:105 +0x2c5

goroutine 275 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446a0, {0x3f59400, 0xc001f1cf30?}, 0x0, {0x3f445d0?, 0xc000afce98}, {{{0xc000fddbc0, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 212 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 155
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 203 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 223
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 185 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0xc001497578, 0x37)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00103a1e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001497550, 0xc001362ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2ce60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001f89170}, 0x1, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0008686f0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2ce60, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc001143500, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 154
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 186 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 154
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 214 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 211
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 205 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 224
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 188 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 185
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 190 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 185
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 191 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc003b279c0}, {0x7fd688db1bc8, 0xc001497550}, {0x3f8d658?, 0x38fdc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001736540, {0x0?, 0x0?}, 0xc001c5db60, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001736540, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001f9a240?, {0x3f0dec0, 0xc001c625a0}, 0x1, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001736540, 0xc001c5db60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 185
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 209 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001736540, 0xc001c5db60, 0xc0018e2e40, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 191
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 460 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000f39080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 200 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00166b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 223
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 201 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00166b1a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 223
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 202 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0xc001363b90, 0x6c)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00166b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc001c629b0}, 0xc001fc22a0, {0x3f6a9c8, 0xc001c19da0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 223
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 133436 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002440000, 0xc0037f7e00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc000e16e60?, 0xc001f1ac60?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 639
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 216 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 211
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 276 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001694360, {0x3f59400, 0xc001f1cf90}, 0x0?, {0x3f445d0, 0xc000afce98}, {{{0xc000fddbc0, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 217 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004948780}, {0x7fd688db1bc8, 0xc002000370}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f6460, {0x0?, 0x0?}, 0xc0018e3320, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f6460, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0018d17c0?, {0x3f0dec0, 0xc0007a7680}, 0x1, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f6460, 0xc0018e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 211
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 220 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f6460, 0xc0018e3320, 0xc0018e3980, 0xc000092f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 224 [select, 2 minutes]:
github.com/cilium/cilium/pkg/statedb.graveyardWorker(0xc0016bb7a0, {0x3f59438, 0xc0007a79f0}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/pkg/statedb/graveyard.go:28 +0x136
created by github.com/cilium/cilium/pkg/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/statedb/db.go:231 +0x152

goroutine 1096 [select, 192 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc000b57cc0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9e780, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc001415b30, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 984
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 226 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 227 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0xc00072b0e0, 0xc0018e3ec0, 0xc0018e3f80, 0xc002072000)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:335 +0x286
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0xc00072b0e0, {0x3f59438?, 0xc0007a7bd0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:227 +0x305
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0xc00072b0e0, {0x3f59438, 0xc0007a7bd0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:169 +0x97
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:149 +0x156

goroutine 228 [chan receive, 192 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:350 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:349 +0x14f

goroutine 229 [syscall, 4 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc004c94501?, 0x0?, 0xc0020afca0?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fd688cc15a8?, {0xc0020afd70?, 0x58?, 0xc001fd6800?}, 0xc004bd90e0?, 0xc004bd90e0?, 0x1400000058?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc004bd90e0?, {0xc0020afd70, 0x10000, 0x10000}, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc0042a71d0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:366 +0x94
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:363 +0x35f

goroutine 230 [chan receive, 192 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1512 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1511 +0x14f

goroutine 231 [syscall, 177 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc004322501?, 0x0?, 0xc00210f878?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fd688ece098?, {0xc00210f948?, 0x3c?, 0x60ce8a0?}, 0xc0010abb00?, 0xc0010abb00?, 0x60000180000003c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc0010abb00?, {0xc00210f948, 0x10000, 0x10000}, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x5?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1528 +0x9a
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1525 +0x35f

goroutine 232 [chan receive, 192 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2338 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2337 +0x13e

goroutine 233 [syscall, 178 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0x6124401?, 0x425d05?, 0xc00218fdc8?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fd688decd58?, {0xc00218fe98?, 0x294?, 0xc002aa9c00?}, 0xc00421a000?, 0xc00421a000?, 0x1100000294?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc00421a000?, {0xc00218fe98, 0x10000, 0x10000}, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc00219fef8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2354 +0x7f
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2351 +0x34f

goroutine 234 [select, 4 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0xc001214ab0, {0x3f59400, 0xc0020ee150}, {0x3f43ff0?, 0xc000b0a0c0})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:260 +0x24b
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc000104cc0, {0x3f59400, 0xc0020ee150}, 0x1000100010001?, {0x3f445d0, 0xc001413040}, {{{0x0, 0x0, 0x0}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 235 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 234
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 236 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4bb50, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000e10d20?, 0xc001b03eb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000e10d20, {0xc001b03eb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc000738010, {0xc001b03eb0?, 0x3ef8148?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000b0abc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 237 [select, 192 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e96280, {{{0x3963cb9, 0xe}}, {0x0, 0x0}, 0xc000de08f0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 238 [select, 192 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc001104f70)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0x105
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x3ee

goroutine 457 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc0010f4a10, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000f38cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f770e0, {0x3f59438, 0xc000c101e0}, 0xc000d996e0, {0x3f6a7b8, 0xc0012431a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 274 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446e0, {0x3f59400, 0xc001f1ced0?}, 0x0, {0x3f445d0?, 0xc000afce98}, {{{0xc000fddbc0, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 208 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 264
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xa5

goroutine 245 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 246 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e96500, {{{0x39565a6, 0xb}}, {0x3f43ff0, 0xc000b0ad40}, 0xc000de11c0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 247 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc000091fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001fc2cc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 248 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0000937d0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001457180?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 249 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93940)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 250 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94980)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 251 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 459 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000f38f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 465 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc0020042c0, {0x3f99588, 0xc001f3f970}, 0xc000869f70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:112 +0x585
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:572 +0x51b

goroutine 1172 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff738, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0018da780?, 0xc002038000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0018da780, {0xc002038000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0018da780, {0xc002038000?, 0xc001d8aec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001830330, {0xc002038000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002066ea0, {0xc002038000?, 0x450260?, 0xc001d8aec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001bf7ec0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf7ec0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002066ea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1162
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 456 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000f38e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 444 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc0007fb2b8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001cf3cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007fb290, 0xc001199dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2cfa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e42450}, 0x1, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001461760?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2cfa0, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc0004c69e0, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x25b

goroutine 5752 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7cc0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc000de3158, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5715
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1690 [select, 12 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9edc0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc00108c880}, 0xc000cbfa40, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1661
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 24665 [IO wait, 158 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6d258, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc004770a00?, 0xc0047aa000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004770a00, {0xc0047aa000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004770a00, {0xc0047aa000?, 0x703620?, 0xc0033d5540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e13970, {0xc0047aa000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0047a0360, {0xc0047aa000?, 0xc000d99260?, 0xc002652d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003c6f800)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003c6f800, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0047a0360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 24664
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1190 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff358, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0018db900?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0018db900)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0018db900)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc001748e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc0023bacc0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc00277aff0, {0x3f44270, 0xc0023bacc0})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3f44270?, 0xc0023bacc0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:358 +0x78
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1125
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:356 +0x4d9

goroutine 261 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 262 [chan receive, 192 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc001c62e60, {0x3f59438?, 0xc001c62eb0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x5e
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14a

goroutine 263 [select, 1 minutes]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc0011c2140, {0x3f59438, 0xc001c62eb0})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:363 +0x31e
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x75
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 262
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4c

goroutine 264 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4ba58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001fc5780?, 0x2fd54c0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001fc5780)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001fc5780)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x40a19e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc0015f7530)
	/usr/local/go/src/net/unixsock.go:260 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc001142ba0, {0x3f59438?, 0xc00014b860}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xe2
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x192

goroutine 265 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94e60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 266 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 349 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:47 +0xc5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:45 +0x1ed

goroutine 268 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b960, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001fc5980?, 0x38801a0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001fc5980)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001fc5980)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x1?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0xc0015f7a70)
	/usr/local/go/src/net/unixsock.go:247 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:58 +0xaf
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:53 +0x136

goroutine 269 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x2f
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:75 +0x199

goroutine 270 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b868, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001fc5b00?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001fc5b00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001fc5b00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x447380?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc0015f7da0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc000b4da00, {0x3f44270?, 0xc0015f7da0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0xa5
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x191

goroutine 271 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 272 [syscall, 192 minutes]:
syscall.Syscall6(0xc001fb5960?, 0xc001fb5948?, 0x4e4a5c?, 0xc0013ce090?, 0x80000000000?, 0xc001fb5960?, 0x4e82e5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0x0?, {0xc001b8bc20?, 0x0?, 0x0?}, 0x4e82c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc001142fe0, {0xc001b8bc20?, 0x2, 0x2}, {0xc001fb5ae8?, 0x73c0d8?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0015da180, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(0xc0003f6c40?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328 +0x45
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x82
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x118

goroutine 277 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 289 [select, 192 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xd0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 274
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xcc

goroutine 682 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0xf4
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 681
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 278 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 281 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000ac6ae0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 282 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0018f0be0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 283 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc0020eb4f0)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:237 +0x89
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:207 +0x1b6

goroutine 284 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc0020042c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:691 +0xe5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:704 +0x4f

goroutine 285 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000640000, {{{0x3990b5c, 0x19}}, {0x0, 0x0}, 0xc000a932d0, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 286 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000640140, {{{0x398150a, 0x15}}, {0x0, 0x0}, 0xc000a93370, 0x0, 0x3b61ab0, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 307 [IO wait]:
internal/poll.runtime_pollWait(0x7fd6cfc4b678, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0008c5d80?, 0xc0001d9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc0008c5d80, {0xc0001d9000, 0x200, 0x200}, {0xc001f30630, 0x2c, 0x2c}, 0x7fd688b21c60?, 0x0?)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x339
net.(*netFD).readMsgInet4(0xc0008c5d80, {0xc0001d9000?, 0x41013e?, 0xaaed83c269f?}, {0xc001f30630?, 0xc002165828?, 0x45c1de?}, 0xc002627800?, 0x8d?)
	/usr/local/go/src/net/fd_posix.go:84 +0x31
net.(*UDPConn).readMsg(0x3b622b8?, {0xc0001d9000?, 0x419188?, 0x1691?}, {0xc001f30630?, 0x0?, 0xffffffffffffffff?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x15c
net.(*UDPConn).ReadMsgUDPAddrPort(0xc000102e08, {0xc0001d9000?, 0x7fd6cfc4b678?, 0x47e538?}, {0xc001f30630?, 0xc002165988?, 0x47e325?})
	/usr/local/go/src/net/udpsock.go:203 +0x3e
net.(*UDPConn).ReadMsgUDP(0xc001515d70?, {0xc0001d9000?, 0xc000e0d400?, 0xc0017cc020?}, {0xc001f30630?, 0xc0021659e8?, 0x410c25?})
	/usr/local/go/src/net/udpsock.go:191 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc000102e08?, 0xc000102e08)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x58
github.com/cilium/dns.(*Server).readUDP(0xc000591900, 0xc000102e08, 0xc003f1bea0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xeb
github.com/cilium/dns.defaultReader.ReadUDP({0xc000591900?}, 0x3f07580?, 0xc003f1bea0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0xc000591900, {0x3f667c8?, 0xc000102e08})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x29c
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000591900)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x1c7
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000591900)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 306 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b488, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0008c5d00?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0008c5d00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0008c5d00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000ae2100)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000ae2100)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
github.com/cilium/dns.(*Server).serveTCP(0xc000591800, {0x3f44240?, 0xc000ae2100})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x142
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000591800)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x26c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000591800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 458 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 453 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0010f4610, 0x192)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000f38a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77160, {0x3f59438, 0xc000c100f0}, 0xc000d99620, {0x3f6a810, 0xc0012430e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 346 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0017c20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 348 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 367 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc001497ba8, 0x3f)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00103a980?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001497b80, 0xc00157b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2c960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e0ccf0}, 0x1, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001460040?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2c960, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc001143fa0, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 253
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 352 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0017c2180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 466 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit(0xc0020042c0, {0x3f59438, 0xc0007d60a0}, 0xc000869f70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:79 +0x445
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1045 +0xc5

goroutine 356 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:42 +0xec
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:40 +0x236

goroutine 358 [select, 45 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPolicyEventLoop(0xc0020042c0, 0xc000869fc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:41 +0x129
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NetworkPoliciesInit.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:28 +0x157

goroutine 360 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0017c2ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 358
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 354 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc00157aa50, 0x7f)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x4?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0017c2180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc0008eb090}, 0xc000e8e3c0, {0x3f6a708, 0xc001f12078})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 362 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 358
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 332 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0016950e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 361 [sync.Cond.Wait, 45 minutes]:
sync.runtime_notifyListWait(0xc00157aed0, 0x3e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0017c24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f771e0, {0x3f59438, 0xc0008eb1d0}, 0xc000e8e660, {0x3f6a868, 0xc001f12138})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 358
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 363 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:125 +0x116
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1 in goroutine 350
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0xe5

goroutine 333 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc000ed7250, 0x29)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001694d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc000b57db0}, 0xc00015ade0, {0x3f6aa20, 0xc002129ce0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 343
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1024 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002394000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 984
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 343 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc0020042c0, 0xc000869f80, 0x2dc7293?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:40 +0x11d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:28 +0x168

goroutine 345 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00156df20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 326 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0016940c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 347 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc00157a610, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00156df20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77260, {0x3f59438, 0xc0008eaf50}, 0xc000e8e120, {0x3f6a8c0, 0xc002129c38})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1686 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9eb40, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc000d2f7e8, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1663
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 451 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000f38a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 353 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0017c2420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 355 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 133564 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002ff6ac8, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001ccdd40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002ff6ab0, {0xc000cc2d30, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc000cc2d30?}, {0xc000cc2d30?, 0xc001ccdce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc002ff6a80}, {0xc000cc2d30, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0046f6390, {0xc001e21800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc004169270, 0xc002b7b200?, {0x3f3b448, 0xc001424a40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00055c700)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00491d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 404
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 359 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0017c24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 358
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 334 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 343
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 331 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001694d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 327 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001694480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 328 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc000b57b80}, 0xc00015aa80, {0x3f6a9c8, 0xc001c19da0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:664 +0x5a6
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 329 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 368 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 253
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 5670 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001ce8fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc003682300?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5654
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 638 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 634
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 452 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000f38c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 336 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc002000708, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0006a7300?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0020006e0, 0xc000ed73c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f10e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001548ed0}, 0x1, 0xc00015b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d29f50?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f10e0, 0xc00015b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000ae2620, 0xc00015b560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 255
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 372 [sync.Cond.Wait, 45 minutes]:
sync.runtime_notifyListWait(0xc001497c58, 0x1e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0004432c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001497c30, 0xc00157b0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2ca00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e0ce70}, 0x1, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001460100?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2ca00, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0000720a0, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 256
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 373 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 256
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 385 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 255
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 445 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:93 +0x352
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:74 +0x13a

goroutine 454 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 376 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0017c3440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 388 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc0020007b8, 0x14)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0013f4c00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002000790, 0xc000ed7400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001549290}, 0x1, 0xc00015b980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0010ac0f0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1180, 0xc00015b980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000ae2680, 0xc00015b980)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 252
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 389 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 252
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 455 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000f38cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 377 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0017c3680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 378 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc00157b390, 0x137)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0017c3440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f772e0, {0x3f59438, 0xc0003405f0}, 0xc000e8f140, {0x3f6a918, 0xc001f12408})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 379 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 392 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 336
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 380 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 367
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 130608 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7a620, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00245fd80?, 0xc004fea000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00245fd80, {0xc004fea000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00245fd80, {0xc004fea000?, 0x703620?, 0xc0046912c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e50f98, {0xc004fea000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000ed5320, {0xc004fea000?, 0xc0034377a0?, 0xc001c7dd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0038b8c00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0038b8c00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000ed5320)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 130607
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 472 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 444
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 382 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 367
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 394 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 336
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 395 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004970640}, {0x7fd688db1bc8, 0xc0020006e0}, {0x3f8d658?, 0x38fdfc0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f6c40, {0x0?, 0x0?}, 0xc00015b560, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f6c40, 0xc00015b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00205ff00?, {0x3f0dec0, 0xc0000c84b0}, 0x1, 0xc00015b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f6c40, 0xc00015b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 336
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 383 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004546d00}, {0x7fd688db1bc8, 0xc001497b80}, {0x3f8d658?, 0x38ffa00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f04380, {0x0?, 0x0?}, 0xc000e8f320, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f04380, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faaa00?, {0x3f0dec0, 0xc000340820}, 0x1, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f04380, 0xc000e8f320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 367
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 423 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f04380, 0xc000e8f320, 0xc000d98d20, 0xc001c7bf10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 383
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 435 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f6c40, 0xc00015b560, 0xc00161ed20, 0xc001c77f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 395
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 401 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 372
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 411 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 407
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 403 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 372
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 404 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00491d9c0}, {0x7fd688db1bc8, 0xc001497c30}, {0x3f8d658?, 0x38feec0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f047e0, {0x0?, 0x0?}, 0xc000e8f440, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f047e0, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faaa40?, {0x3f0dec0, 0xc0003408c0}, 0x1, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f047e0, 0xc000e8f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 372
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 421 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f047e0, 0xc000e8f440, 0xc000d988a0, 0xc001c7df10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 404
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 111547 [select, 37 minutes]:
net/http.(*persistConn).writeLoop(0xc0006f19e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 111545
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 121075 [select, 23 minutes]:
net/http.(*persistConn).writeLoop(0xc003f81e60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 121073
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 407 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc001497e68, 0x9e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001191e60?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001497e40, 0xc00157b640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2caa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e0d380}, 0x1, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001460250?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2caa0, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000072aa0, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 254
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 408 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 254
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1890 [select, 11 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000640640, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0012e5e00}, 0xc0015a6b70, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1877
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 413 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 407
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 414 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004c4f5c0}, {0x7fd688db1bc8, 0xc001497e40}, {0x3f8d658?, 0x38fd0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f04b60, {0x0?, 0x0?}, 0xc000e8f9e0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f04b60, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faab00?, {0x3f0dec0, 0xc000340f50}, 0x1, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f04b60, 0xc000e8f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 407
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 437 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f04b60, 0xc000e8f9e0, 0xc00161f560, 0xc001c81f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 398 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 388
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 476 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 519
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 400 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 388
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 417 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004757980}, {0x7fd688db1bc8, 0xc002000790}, {0x3f8d658?, 0x38fd480}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f6fc0, {0x0?, 0x0?}, 0xc00015b980, 0x419101?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f6fc0, 0xc00015b980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00205ff40?, {0x3f0dec0, 0xc0000c85a0}, 0x1, 0xc00015b980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f6fc0, 0xc00015b980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 388
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 433 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f6fc0, 0xc00015b980, 0xc00161e300, 0xc001c8df10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 27858 [IO wait, 152 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6ce78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002dab500?, 0xc00415f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002dab500, {0xc00415f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002dab500, {0xc00415f000?, 0x703620?, 0xc003462c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0007ad7a0, {0xc00415f000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00360b680, {0xc00415f000?, 0xc002a85320?, 0xc0027eed38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0042b0ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0042b0ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00360b680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 27857
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 469 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc0008ceb70?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 466
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 134966 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001cc9548, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc001cc9530, {0xc00241be00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0023fbd48?}, {0xc00241be00?, 0x2?, 0x10000050d?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc002e5f180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc002e5f180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc002e5f180, {0x326cdc0, 0xc0014c7488})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0023ba0f0, {0xc003e28000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00353d4f0, 0x8?, {0x3f3b448, 0xc00389a840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001328a60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00389a800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 64496 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6a58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00260d000?, 0xc002be0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00260d000, {0xc002be0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00260d000, {0xc002be0000?, 0x703620?, 0xc000641b80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00086c4e0, {0xc002be0000?, 0x0?, 0xc0048161a0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00123c7e0, {0xc002be0000?, 0xc002df5bc0?, 0xc002ab1d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b91e60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b91e60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00123c7e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 64495
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 461 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc0010f4e10, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000f38f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77060, {0x3f59438, 0xc000c10320}, 0xc000d99da0, {0x3f6a760, 0xc001243248})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 462 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 445
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1161 [select]:
net/http.(*persistConn).writeLoop(0xc00363cd80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1170
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1104 [select, 12 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002eadc0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0011af380}, 0xc0015a6440, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 947
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 481 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002000de8, 0xc8)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00103bce0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002000dc0, 0xc0010f4f80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e2dda0}, 0x1, 0xc00085b200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0010ada20?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1a40, 0xc00085b200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000ae39e0, 0xc00085b200)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 482 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 5795 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0031a5fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0016c0350?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5759
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 485 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc002000e98, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001d15c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002000e70, 0xc0010f4fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e5c120}, 0x1, 0xc00085b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0010adb80?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1ae0, 0xc00085b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000ae3a40, 0xc00085b560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 258
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 486 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 258
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1547 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001c2de00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 489 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc002000f48, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001d17c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002000f20, 0xc0010f5000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e5c480}, 0x1, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0010adce0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1b80, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000ae3aa0, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 259
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 490 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 259
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 5741 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0029a0cd0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f6500, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000cc45d0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5720
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 493 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 481
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 513 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc0010f55d0, 0x6a)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00135ce40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76ee0, {0x3f59438, 0xc000c10d20}, 0xc00085bf20, {0x3f6a658, 0xc0012436e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 468
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 495 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 481
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 496 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0012a8640}, {0x7fd688db1bc8, 0xc002000dc0}, {0x3f8d658?, 0x38e2420}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f75e0, {0x0?, 0x0?}, 0xc00085b200, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f75e0, 0xc00085b200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001066740?, {0x3f0dec0, 0xc000c108c0}, 0x1, 0xc00085b200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f75e0, 0xc00085b200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 481
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 557 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f75e0, 0xc00085b200, 0xc0011324e0, 0xc001d13f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 496
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 96814 [IO wait, 52 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae5cc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002474d80?, 0xc002478000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002474d80, {0xc002478000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002474d80, {0xc002478000?, 0x703620?, 0xc0033d4500?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e518b8, {0xc002478000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002c17b00, {0xc002478000?, 0xc004a3f380?, 0xc00257bd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002878180)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002878180, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002c17b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 96813
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 499 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 485
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 512 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00135cfc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 468
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 501 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 485
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 502 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00389a800}, {0x7fd688db1bc8, 0xc002000e70}, {0x3f8d658?, 0x38d6500}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f7960, {0x0?, 0x0?}, 0xc00085b560, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f7960, 0xc00085b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001066800?, {0x3f0dec0, 0xc000c10aa0}, 0x1, 0xc00085b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f7960, 0xc00085b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 485
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 555 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f7960, 0xc00085b560, 0xc001113e60, 0xc001d1ff10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 135241 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003799e00, 0xc00461fe00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc00153e900?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 479
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 505 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 489
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 511 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00135ce40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 468
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 507 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 489
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 508 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004b31540}, {0x7fd688db1bc8, 0xc002000f20}, {0x3f8d658?, 0x38c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018f7dc0, {0x0?, 0x0?}, 0xc00085ba40, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018f7dc0, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001066cc0?, {0x3f0dec0, 0xc000c10be0}, 0x1, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018f7dc0, 0xc00085ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 489
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 559 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018f7dc0, 0xc00085ba40, 0xc001132ae0, 0xc001d1bf10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 473 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000c05c40}, {0x7fd688db1bc8, 0xc0007fb290}, {0x3f8d658?, 0x38fe380}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f05180, {0x0?, 0x0?}, 0xc000ac71a0, 0x419188?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f05180, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faae80?, {0x3f0dec0, 0xc000341a90}, 0x1, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f05180, 0xc000ac71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 444
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 609 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f05180, 0xc000ac71a0, 0xc0011332c0, 0xc001d07f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 473
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 514 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 468
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 84106 [select, 72 minutes]:
net/http.(*persistConn).writeLoop(0xc001273680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 84104
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 516 [sync.Cond.Wait, 177 minutes]:
sync.runtime_notifyListWait(0xc002001158, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00112a860?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002001130, 0xc0010f5740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e42ae0}, 0x1, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001461a50?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1c20, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000312900, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit in goroutine 465
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:110 +0x579

goroutine 517 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc000092710?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 465
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 652 [select, 192 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000356f00, {{{0x3999d77, 0x1b}}, {0x0, 0x0}, 0xc0011aeac0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 519 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc002001208, 0x34)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000e577a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0020011e0, 0xc0010f57c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f1cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e427b0}, 0x1, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001461900?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f1cc0, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000312940, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 260
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 520 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 260
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1023 [syscall, 192 minutes]:
syscall.Syscall6(0xc0007540d0?, 0x0?, 0xc002b1ece0?, 0x446db1?, 0x0?, 0xc002b1ed68?, 0xc00136f860?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
os.(*Process).blockUntilWaitable(0xc001c645d0)
	/usr/local/go/src/os/wait_waitid.go:32 +0x76
os.(*Process).wait(0xc001c645d0)
	/usr/local/go/src/os/exec_unix.go:22 +0x25
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0xc001230000)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 984
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4d9

goroutine 1838 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e97040, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001fc1e30, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1879
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 980 [select, 192 minutes]:
github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start.func1()
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:144 +0xc8
created by github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:142 +0x16d

goroutine 5677 [sync.Cond.Wait, 42 minutes]:
sync.runtime_notifyListWait(0xc000f48d90, 0x28)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0049d1a30?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0xc00104ed80)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:162 +0xdb
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 175
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:179 +0x56

goroutine 135164 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0028b0480, 0xc003394800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc0028e9ec0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 538 [select, 192 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:214 +0x1d5
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:204 +0x199

goroutine 478 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 519
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 479 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004084a40}, {0x7fd688db1bc8, 0xc0020011e0}, {0x3f8d658?, 0x38c4ac0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f05500, {0x0?, 0x0?}, 0xc00154eea0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f05500, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faaf40?, {0x3f0dec0, 0xc000341ae0}, 0x1, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f05500, 0xc00154eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 519
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 611 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f05500, 0xc00154eea0, 0xc001133b00, 0xc001d3bf10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 479
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 537 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 531 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 516
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 532 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004c2ac40}, {0x7fd688db1bc8, 0xc002001130}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f05960, {0x0?, 0x0?}, 0xc0011122a0, 0xc000e285a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f05960, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000faaf80?, {0x3f0dec0, 0xc000341bd0}, 0x1, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f05960, 0xc0011122a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 516
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 604 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f05960, 0xc0011122a0, 0xc0011eaf00, 0xc001d47f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 532
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 5669 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc002b20870})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da780, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000e1ee50, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5654
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 561 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc0007fb368, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001d57cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007fb340, 0xc00108c5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2d0e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e78360}, 0x1, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001461f20?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2d0e0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc0003944a0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit in goroutine 524
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x317

goroutine 1549 [select, 192 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc003366640})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000356780, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000cfa410, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 634 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc0007fb628, 0x2e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000f569e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007fb600, 0xc00141a880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2da40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001ed44b0}, 0x1, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001139550?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2da40, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc0008b00a0, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc001ed40c0, {0x44619c?, 0xc002044780?}, {0x3f5aa90?, 0xc001637c58}, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x556
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:243 +0x4c
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 653
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:242 +0x10f

goroutine 563 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc0007fb418, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001d30cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007fb3f0, 0xc00108c6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001c2d220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001e786f0}, 0x1, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011380a0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001c2d220, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000394540, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit in goroutine 524
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:85 +0x4b4

goroutine 47006 [select, 122 minutes]:
net/http.(*persistConn).writeLoop(0xc00253cfc0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 47004
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 983 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x125
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc001487020, 0xc0016c0350?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x5b1
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x21e

goroutine 985 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 984 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000985540, {{{0x395ed53, 0xd}}, {0x0, 0x0}, 0xc00151bba0, 0x0, 0xc0003329a8, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 986 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 987 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 988 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 989 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 80916 [IO wait, 77 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6390, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0030d5d00?, 0xc003675000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0030d5d00, {0xc003675000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0030d5d00, {0xc003675000?, 0x703620?, 0xc003463540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001140968, {0xc003675000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00185f9e0, {0xc003675000?, 0xc002d5f3e0?, 0xc002b4dd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028d9020)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028d9020, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00185f9e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 80915
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 690 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e16540, 0xc0011ebf80, 0xc0020e1ce0, 0xc001debf10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 639 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc004550f00}, {0x7fd688db1bc8, 0xc0007fb600}, {0x3f8d658?, 0x38c3780}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e16540, {0x0?, 0x0?}, 0xc0011ebf80, 0x1008aff0173656d?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e16540, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000fab900?, {0x3f0dec0, 0xc000722f50}, 0x1, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e16540, 0xc0011ebf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 634
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1167 [select]:
net/http.(*persistConn).writeLoop(0xc002066fc0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1164
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 693 [select, 2 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc001637ba0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:889 +0x266
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 635
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:881 +0x5a

goroutine 1166 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff640, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0018dab00?, 0xc001fc7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0018dab00, {0xc001fc7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0018dab00, {0xc001fc7000?, 0xc001d89ec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f4a00, {0xc001fc7000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002066fc0, {0xc001fc7000?, 0x450260?, 0xc001d89ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002bf1560)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002bf1560, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002066fc0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1164
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1185 [select]:
net/http.(*persistConn).writeLoop(0xc00363cea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1174
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5796 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7680, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc002febd00}, 0xc0034c6980, 0x0, 0xc003610e10, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5943 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e91cc0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc000722ff0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5863
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5849 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002395cc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5842
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 134510 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002431e00, 0xc004f84c00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x224d7a7?, 0xc000099d40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 601
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 114718 [select, 32 minutes]:
net/http.(*persistConn).writeLoop(0xc001c13c20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 114716
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 66936 [IO wait, 92 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae5eb8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00060cf00?, 0xc004571000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00060cf00, {0xc004571000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00060cf00, {0xc004571000?, 0x703620?, 0xc0008db040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0011412b8, {0xc004571000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001125c20, {0xc004571000?, 0xc004cd5800?, 0xc00321bd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004b33320)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004b33320, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001125c20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 66935
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 670 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b580, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001551080?, 0xc001dc5eb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001551080, {0xc001dc5eb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc000103e30, {0xc001dc5eb0?, 0x61726620656d6974?, 0x1fe00000100656d?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc001554740)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 661
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 661 [select, 192 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc0007326e0, {0x3f59438, 0xc000733040})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:350 +0x209
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003577c0, {{{0x397d38e, 0x14}}, {0x0, 0x0}, 0xc000ccc030, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1662 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9e280, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc000f61200}, 0xc003641f00, 0x0, 0xc002393290, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 18323 [IO wait, 167 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6d068, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00305fb80?, 0xc00306c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00305fb80, {0xc00306c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00305fb80, {0xc00306c000?, 0x703620?, 0xc0004a8b40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e51b18, {0xc00306c000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0030498c0, {0xc00306c000?, 0xc002f36a20?, 0xc003167d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002878de0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002878de0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0030498c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 18322
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1550 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc002634fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001031ac0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1663 [select, 191 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9e3c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0008ea640, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 642 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:233 +0xf4
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:231 +0x2f8

goroutine 107522 [select, 42 minutes]:
net/http.(*persistConn).writeLoop(0xc0046b1560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 107488
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 594 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 561
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 595 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc003e428c0}, {0x7fd688db1bc8, 0xc0007fb340}, {0x3f8d658?, 0x38c4540}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f05ce0, {0x0?, 0x0?}, 0xc000ac7440, 0x72500a0100b0ff01?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f05ce0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000fab180?, {0x3f0dec0, 0xc000712910}, 0x1, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f05ce0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 561
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 621 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f05ce0, 0xc000ac7440, 0xc001bd0ea0, 0xc001d53f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 595
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 87294 [IO wait, 67 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae61a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0030d4580?, 0xc002fa1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0030d4580, {0xc002fa1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0030d4580, {0xc002fa1000?, 0x703620?, 0xc003494140?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017b9d98, {0xc002fa1000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0047a1d40, {0xc002fa1000?, 0xc002b7a360?, 0xc002ad3d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004ed9620)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004ed9620, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0047a1d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 87293
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1660 [select, 191 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0008ea500})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9e140, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc001415470, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 27859 [select, 152 minutes]:
net/http.(*persistConn).writeLoop(0xc00360b680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 27857
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 600 [chan receive, 192 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 563
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 601 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0045e8180}, {0x7fd688db1bc8, 0xc0007fb3f0}, {0x3f8d658?, 0x38c4280}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e161c0, {0x0?, 0x0?}, 0xc000ac7440, 0xc00214bda0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e161c0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000fab280?, {0x3f0dec0, 0xc000712aa0}, 0x1, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e161c0, 0xc000ac7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 563
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 619 [select, 192 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e161c0, 0xc000ac7440, 0xc001bd0900, 0xc001d61f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 601
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 5672 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008daa00, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc002b20b40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5654
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 40545 [select, 133 minutes]:
net/http.(*persistConn).writeLoop(0xc0042b7680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 40527
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 945 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001e33360)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1188 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc000f6ba70, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x5c9
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1125
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x145

goroutine 1103 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc000b0ae90, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0003f6e00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc000b0ae40, {0x3f59438, 0xc000733400}, {0xc0010abe80, 0x33}, 0x1, {0xc001789365, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1114
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 951 [select, 192 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000984c80, {{{0x39a7c52, 0x1e}}, {0x0, 0x0}, 0xc001eeceb8, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 944
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 942 [select, 11 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:166 +0x4bd
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:82 +0xa5

goroutine 977 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b298, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002721aa0?, 0xc002a0feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002721aa0, {0xc002a0feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0016f4198, {0xc002a0feb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0014da340)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 960 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000985180, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001eedad0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1125 [semacquire, 192 minutes]:
sync.runtime_Semacquire(0x339db00?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0xc00236be00?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc00236be00)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0x57
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc00236be00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x105
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1123
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:386 +0xc7

goroutine 958 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc00268ffd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 939 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x105
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:409 +0xcf

goroutine 969 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 936 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009848c0, {{{0x395ed6d, 0xd}}, {0x0, 0x0}, 0xc001eec810, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 957 [select, 192 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc002748b90})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000985040, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000cb0b40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 950 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000984b40, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001eece40, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 954 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001e33540)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1123 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc00236be00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:391 +0xdc
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x66
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 983
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1ff

goroutine 1159 [select]:
net/http.(*persistConn).writeLoop(0xc00363cb40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1146
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 53365 [IO wait, 112 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6cd80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003718180?, 0xc003631000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003718180, {0xc003631000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003718180, {0xc003631000?, 0x703620?, 0xc002e5eb40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144e0e0, {0xc003631000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003714120, {0xc003631000?, 0xc002df4ae0?, 0xc002145d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004bffa40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004bffa40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003714120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 53364
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1071 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688df0048, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0008c5380?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0008c5380)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0008c5380)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc002ae5e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc001548de0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc00016ca50, {0x3f44270, 0xc001548de0})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3f44270?, 0xc001548de0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:475 +0x78
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:473 +0x4f9

goroutine 946 [select, 192 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0020c5ef0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000984a00, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc00158b3e0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5783 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e90500, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc002e07740, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5797
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 947 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc00262ffd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1097 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc002aecfd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001c1c930?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 984
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 990 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 1114 [select, 192 minutes]:
reflect.rselect({0xc001b27320, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc0023bd200?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001fc0ae0, {0x3f59400, 0xc001e6ad50}, 0xc0004c5f10, {0x7fd688df6840, 0xc000cb8b40}, 0xc001c23c80, {0x3a0d583?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001fc0ae0, {0x3f59400, 0xc001e6ad50}, {0x7fd688df6840?, 0xc000cb8b40?}, {0x3a0d583, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc0017a7a88?, {0x3f6d6f0, 0xc000cb8b40})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x6e
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x38335e0?, 0xc001fc0ae0}, {0x3f640d8?, 0xc00016def0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc000b4da00, {0x3f59400, 0xc001e6abd0}, {0x3f71660, 0xc002744000}, 0xc00185eb40, 0xc0013e6810, 0x608fe80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc000b4da00, {0x3f71660, 0xc002744000}, 0xc00185eb40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1113
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 1072 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 991 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 992 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 993 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 994 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 995 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 996 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 997 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 998 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 999 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 1000 [IO wait]:
internal/poll.runtime_pollWait(0x7fd6cfc4b1a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002778700?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002778700)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002778700)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc00151bc00)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc00151bc00)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc00277a4b0, {0x3f44240, 0xc00151bc00})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc000b70200, 0xe}, {0x3f44240, 0xc00151bc00})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xcf
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x67e

goroutine 1076 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f6140, {{{0x397c75e, 0x14}}, {0x3f43ff0, 0xc000ed6880}, 0xc001c63db0, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1099 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9e8c0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc0008e5338, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 984
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1004 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1005 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc001d79c20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001694780, {0x3f59400, 0xc00151c4b0}, 0x2be1c6b?, {0x3f445d0, 0xc000afdb60}, {{{0xc001069180, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1006 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc000e30c20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0016947e0, {0x3f59400, 0xc00151c600}, 0x0?, {0x3f445d0, 0xc000afdb60}, {{{0xc001069520, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1075 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1008 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0029cd260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1006
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1025 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029cd380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1006
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 1026 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc000c51e10, 0x7b)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x5?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029cd260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc0029fc0f0}, 0xc0029a3920, {0x3f6a708, 0xc001f12078})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1006
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1027 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1006
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1115 [select, 192 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000afed20, {0xc001e6ad00, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000afed20, {0xc001e6ad00?, 0xc00059d800?, 0xc002515550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc001e6aae0, {0xc001e6ad00?, 0xc0025155c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc001e6aae0}, {0xc001e6ad00, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00185eb40, {0xc001e6ad00, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc001e6acf0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc0025157a8?, 0xc00185eb40, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc001e6acf0, {0x7fd688df6818, 0x6628060}, 0xc002515818?, {0x0, 0x0}, {0x37a56a0, 0xc0023950e0}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00016def0, {0x37a56a0?, 0xc0023950e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc000cb8b40)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1114
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 1113 [IO wait, 72 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4afb0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b72680?, 0xc002464000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000b72680, {0xc002464000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc000b72680, {0xc002464000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001831790, {0xc002464000?, 0xc0024e6c10?, 0x3?})
	/usr/local/go/src/net/net.go:179 +0x45
bufio.(*Reader).Read(0xc000f38060, {0xc0018f70e0, 0x9, 0x7fd6cfe1d108?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc000f38060}, {0xc0018f70e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc0018f70e0, 0x9, 0xc003c8ec90?}, {0x3f07920?, 0xc000f38060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0018f70a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc002744000, {0x3f59400, 0xc001e6a8d0}, 0x6628060?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:617 +0x15d
google.golang.org/grpc.(*Server).serveStreams(0xc000b4da00, {0x3f592e8?, 0x6628060?}, {0x3f71660?, 0xc002744000}, {0x3f6a138?, 0xc001831790?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x3e2
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1110
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d8

goroutine 1112 [select, 72 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc002744000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1138 +0x225
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1110
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:328 +0x18c5

goroutine 1111 [select, 72 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000afeaf0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x113
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc0004a5ce0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x86
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:325 +0xd2
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1110
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:322 +0x187e

goroutine 1109 [runnable]:
github.com/cilium/cilium/pkg/monitor/agent.(*listenerv1_2).drainQueue(0xc001e6a390)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:54 +0x265
created by github.com/cilium/cilium/pkg/monitor/agent.newListenerv1_2 in goroutine 264
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:33 +0xd6

goroutine 1140 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688def698, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0014dfb80?, 0xc001470000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0014dfb80, {0xc001470000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0014dfb80, {0xc001470000?, 0xc001747ec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001830268, {0xc001470000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002066d80, {0xc001470000?, 0x450260?, 0xc001747ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001bf7380)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf7380, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002066d80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1157
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1141 [select]:
net/http.(*persistConn).writeLoop(0xc002066d80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1157
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1100 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd688defd60, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001f64a00?, 0xc001794000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001f64a00, {0xc001794000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001f64a00, {0xc001794000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f42b8, {0xc001794000?, 0x0?, 0xc001e5c6f8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001e5c6f0, {0xc001794000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc000b22de0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc000b22de0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001782510, {0x3f59400, 0xc0015493b0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1071
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 1124 [chan receive, 192 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0xc000332900)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1123
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:382 +0x78

goroutine 1086 [syscall, 192 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x29
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x1f

goroutine 1084 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc001bdcf80, {0x3f59400, 0xc001e146c0}, 0x398a51c?, 0x0?, 0xc002a99c80)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:168 +0x25f
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc001bdcf80, {0x3f59400, 0xc001e146c0}, {0x4a4b64?, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:113 +0x2db
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001695020, {0x3f59400, 0xc001e146c0}, 0x3a6b222c7d7d7b3a?, {0x3f445d0, 0xc0007388f0}, {{{0xc001142820, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1083 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1082 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001694e40, {0x3f59400, 0xc001e14000}, 0x72547473616c3a66?, {0x3f445d0, 0xc000738390}, {{{0x0, 0x0, 0x0}}, {0x3f8bac0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1081 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1080 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f6280, {{{0x395302a, 0xa}}, {0x0, 0x0}, 0xc000cb6670, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1079 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1078 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001694ba0, {0x3f59400, 0xc001549b00}, 0x0?, {0x3f445d0, 0xc000099d40}, {{{0xc0010fcd80, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1077 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1065 [select, 192 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x17c
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1056
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x226

goroutine 1048 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000985b80, {{{0x3952850, 0xa}}, {0x0, 0x0}, 0x3b623c8, 0x0, 0x3b61ab0, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1001
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1049 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0xe?, {0x3f59438, 0xc0007d60a0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xfe
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:199 +0x19fc

goroutine 1050 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc000985cc0)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x98
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:211 +0x1bdb

goroutine 1051 [syscall]:
syscall.Syscall6(0xc0009cba80?, 0xc00038d838?, 0x35b9760?, 0xc00268f848?, 0xc00268f838?, 0x1000000004df2f0?, 0x3f07220?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0xffffffffffffff00?, {0xc0029d0e88?, 0x6069af0?, 0x3f07220?}, 0x227d925?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc0014d6300, {0xc0029d0e88?, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0027552c0, 0xc000469a40?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc00158c620, {0x3f59438, 0xc0029fca50})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x495
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1001
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 1052 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd6cfc4b0a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0028e7e00?, 0xc0014d6360?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0028e7e00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0028e7e00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc0029d0ea0?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc00153ed80)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc0028de800, {0x3f44270?, 0xc00153ed80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:255 +0x4d
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:254 +0x286b

goroutine 1053 [chan receive, 192 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:260 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:259 +0x28dd

goroutine 1054 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd688df0330, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002a82ea0?, 0xc00280feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002a82ea0, {0xc00280feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0016f4520, {0xc00280feb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0009caac0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1001
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 1055 [select, 192 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc00153f560)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xd1
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1001
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1e5

goroutine 1067 [chan receive, 192 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:326 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:325 +0x3479

goroutine 1066 [IO wait, 184 minutes]:
internal/poll.runtime_pollWait(0x7fd688df0140, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002a95280?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002a95280)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002a95280)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc0014d6620)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc0014d6620)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
google.golang.org/grpc.(*Server).Serve(0xc002aac200, {0x3f44240?, 0xc0014d6620})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:317 +0x56
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1001
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:316 +0x3405

goroutine 1059 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc002a833e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1005
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1060 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002a83500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1005
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 1061 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc0009cab90, 0x27)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002a833e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc0029fcc80}, 0xc002a84cc0, {0x3f6aa20, 0xc002129ce0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1005
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1062 [select, 192 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1005
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1120 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd688defa78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00396d300?, 0xc000ee8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00396d300, {0xc000ee8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00396d300, {0xc000ee8000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018301f0, {0xc000ee8000?, 0x0?, 0xc0015a2f68?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0015a2f60, {0xc000ee8000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001550d20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001550d20, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0039a2870, {0x3f59400, 0xc0015493b0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1071
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 1118 [IO wait, 192 minutes]:
internal/poll.runtime_pollWait(0x7fd688defb70, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00396d080?, 0xc00075c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00396d080, {0xc00075c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00396d080, {0xc00075c000?, 0x703620?, 0xc0027f6000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018301e0, {0xc00075c000?, 0x0?, 0xc001213860?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363c6c0, {0xc00075c000?, 0xc002bd8240?, 0xc0024e1d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001bf6660)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf6660, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363c6c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1117
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1119 [select, 192 minutes]:
net/http.(*persistConn).writeLoop(0xc00363c6c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1117
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1137 [IO wait, 177 minutes]:
internal/poll.runtime_pollWait(0x7fd688def980, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00396d400?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc00396d400)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc00396d400)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000ae22a0)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000ae22a0)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc00277a3c0, {0x3f44240, 0xc000ae22a0})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc00277a3c0)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1124
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 8370 [select, 177 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc003839100)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x11f
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x39
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 8351
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0x96

goroutine 1144 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688defe58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00396df00?, 0xc00147c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00396df00, {0xc00147c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00396df00, {0xc00147c000?, 0xc001d8cec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018302a0, {0xc00147c000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363ca20, {0xc00147c000?, 0x450260?, 0xc001d8cec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001bf7680)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf7680, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363ca20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1142
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1145 [select]:
net/http.(*persistConn).writeLoop(0xc00363ca20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1142
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1158 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688def5a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc280?, 0xc001f2f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdc280, {0xc001f2f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdc280, {0xc001f2f000?, 0xc001d8dec8?, 0xc00348bf80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f4880, {0xc001f2f000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363cb40, {0xc001f2f000?, 0x450260?, 0xc001d8dec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002bf0d80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002bf0d80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363cb40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1146
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1152 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff928, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc380?, 0xc002034000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdc380, {0xc002034000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdc380, {0xc002034000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001830300, {0xc002034000?, 0x0?, 0xc001432f68?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001432f60, {0xc002034000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001bf7c20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf7c20, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0039a3290, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 1150 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688def4a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc300?, 0xc00202a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdc300, {0xc00202a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdc300, {0xc00202a000?, 0xc001d8fec8?, 0xc00348bf80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018302f8, {0xc00202a000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363cc60, {0xc00202a000?, 0x450260?, 0xc001d8fec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001bf7b60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf7b60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363cc60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1148
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1151 [select]:
net/http.(*persistConn).writeLoop(0xc00363cc60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1148
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1189 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:384 +0x8b
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1125
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:379 +0x5a

goroutine 1160 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff830, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc400?, 0xc001f99000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdc400, {0xc001f99000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdc400, {0xc001f99000?, 0xc00263aec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f48f0, {0xc001f99000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363cd80, {0xc001f99000?, 0x450260?, 0xc00263aec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002bf11a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002bf11a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363cd80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1170
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1173 [select]:
net/http.(*persistConn).writeLoop(0xc002066ea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1162
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1168 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff548, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc800?, 0xc00217d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdc800, {0xc00217d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdc800, {0xc00217d000?, 0xc002ae4ec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f4a28, {0xc00217d000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00363cea0, {0xc00217d000?, 0x450260?, 0xc002ae4ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002bf1620)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002bf1620, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00363cea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1174
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1176 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff450, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdc980?, 0xc0038e1200?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc001bdc980, {0xc0038e1200, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x285
net.(*netFD).readFrom(0xc001bdc980, {0xc0038e1200?, 0x50?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x25
net.(*IPConn).readFrom(0x53ff68?, {0xc0038e1200, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0xc001830370, {0xc0038e1200?, 0xc002636ec0?, 0xc002636e88?})
	/usr/local/go/src/net/iprawsock.go:129 +0x30
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc19f1bbc4d5e5954?, {0xc0038e1200?, 0x60ccea0?, 0x60ccea0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x2f
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc000f6ba70, 0xc000ae2ac0, 0xc0016e18c0, 0xc000ae2ae0, 0xc002151fb8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x139
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1188
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x377

goroutine 1211 [select, 192 minutes]:
reflect.rselect({0xc001f0d0e0, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc00367ca00?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001fc0ae0, {0x3f59400, 0xc00264cab0}, 0xc00038f260, {0x7fd688e01400, 0xc001717cc0}, 0xc001fc33e0, {0x3a15de3?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001fc0ae0, {0x3f59400, 0xc00264cab0}, {0x7fd688e01400?, 0xc001717cc0?}, {0x3a15de3, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc0026a8a88?, {0x3f6d7f8, 0xc001717cc0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x6e
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x38335e0?, 0xc001fc0ae0}, {0x3f640d8?, 0xc0027e20f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc000b4da00, {0x3f59400, 0xc00264c9c0}, {0x3f71660, 0xc002744000}, 0xc001fb1560, 0xc0013e69c0, 0x608ff20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc000b4da00, {0x3f71660, 0xc002744000}, 0xc001fb1560)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1113
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 1212 [select, 192 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000c82d0, {0xc00264ca60, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000c82d0, {0xc00264ca60?, 0xc00264a780?, 0xc001da1550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc00264c930, {0xc00264ca60?, 0xc001da15c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc00264c930}, {0xc00264ca60, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001fb1560, {0xc00264ca60, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc00264ca50, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc001da17a8?, 0xc001fb1560, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc00264ca50, {0x7fd688df6818, 0x6628060}, 0xc001da1818?, {0x0, 0x0}, {0x37a56a0, 0xc002394c80}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0027e20f0, {0x37a56a0?, 0xc002394c80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc001717cc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001717b50?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1211
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 5744 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f6a00, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0029a0e10, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5720
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1236 [sync.Cond.Wait, 192 minutes]:
sync.runtime_notifyListWait(0xc000b0b110, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0003f6e00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc000b0b0c0, {0x3f59438, 0xc000b560f0}, {0xc0029e8ac0, 0x35}, 0x1, {0xc00007d065, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1211
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 107521 [IO wait, 42 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7a810, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0046cde00?, 0xc00479c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0046cde00, {0xc00479c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0046cde00, {0xc00479c000?, 0x703620?, 0xc002fd7180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016f5f20, {0xc00479c000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0046b1560, {0xc00479c000?, 0xc003a99980?, 0xc0026d9d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0045c87e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0045c87e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0046b1560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 107488
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5488 [select, 187 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc002f89220})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e90640, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc001275640, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5479
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 37343 [select, 137 minutes]:
net/http.(*persistConn).writeLoop(0xc002f9cc60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 37341
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5501 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003494640, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc002d9cee8, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5507
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5580 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001e326e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5573
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1661 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0026a9fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc003350780?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 12389 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688c6d350, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00245ef00?, 0xc002377000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00245ef00, {0xc002377000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00245ef00, {0xc002377000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0006af428, {0xc002377000?, 0x0?, 0xc0020ed958?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0020ed950, {0xc002377000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0016e1d40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0016e1d40, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00243be60, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 5710 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011c2d20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5698
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5647 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5e280, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0014578c0}, 0xc00314bb80, 0x0, 0xc001bb93b0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5643 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003416000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5627
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5582 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0035f9720})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003494dc0, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000b4efd0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5573
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5853 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da140, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc001457080}, 0xc00314bc00, 0x0, 0xc0031f94a0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5842
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1551 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000357040, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0014dba80}, 0xc00334bd80, 0x0, 0xc003351ef0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1552 [select, 192 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003572c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc003366780, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5505 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc002936fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002eee120?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5479
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 50185 [IO wait, 117 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6cb90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002e52400?, 0xc002e01000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002e52400, {0xc002e01000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002e52400, {0xc002e01000?, 0x703620?, 0xc003494280?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e8a768, {0xc002e01000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002e5a000, {0xc002e01000?, 0xc003436f00?, 0xc00257dd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002e3a4e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e3a4e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002e5a000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 50184
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1658 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003417400)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1559 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000357900, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001057c38, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1552
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1561 [select, 12 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e96000, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc00106bcc0}, 0xc00044b250, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1550
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 15147 [IO wait, 172 minutes]:
internal/poll.runtime_pollWait(0x7fd688dfec90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002379b00?, 0xc00237e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002379b00, {0xc00237e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002379b00, {0xc00237e000?, 0x703620?, 0xc004691540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000740f80, {0xc00237e000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00455a7e0, {0xc00237e000?, 0xc003646720?, 0xc002ab8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002412ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002412ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00455a7e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 15146
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 56548 [select, 107 minutes]:
net/http.(*persistConn).writeLoop(0xc0014fe000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 56546
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5671 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da8c0, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0013d5f40}, 0xc002aa3900, 0x0, 0xc0025bd320, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5654
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5648 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5e500, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc003367ae0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1874 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0034161e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1827
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 131542 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc003b46ac8, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002018d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003b46ab0, {0xc004956a1c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc004956a10?}, {0xc004956a1c?, 0xc002018ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc003b46a80}, {0xc004956a1c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0044ad1b8, {0xc001e21c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc004730140, 0xc002917e60?, {0x3f3b448, 0xc00442c800})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0005a19e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004757980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 5742 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x45d964b800?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0034952c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5720
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5507 [select, 187 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e908c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc002f89360, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5479
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5601 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003495040, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0035f9860, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5573
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5879 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5f2c0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc000f40b80}, 0xc0016c1940, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5852
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 134965 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001cc9500, 0xc0037f6000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc0015493b0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 53366 [select, 112 minutes]:
net/http.(*persistConn).writeLoop(0xc003714120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 53364
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 13305 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688c6d540, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003ea3700?, 0xc003f45000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003ea3700, {0xc003f45000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003ea3700, {0xc003f45000?, 0xc00328cec8?, 0xc004bf1620?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00086c050, {0xc003f45000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003ea47e0, {0xc003f45000?, 0x450260?, 0xc00328cec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003cb1f80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003cb1f80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003ea47e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 13290
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 134565 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00292b3c8, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002b4ad40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00292b3b0, {0xc003a4553c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc003a45532?}, {0xc003a4553c?, 0xc002b4ace0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc00292b380}, {0xc003a4553c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00294b548, {0xc0018ef400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0046005a0, 0xc00161fbc0?, {0x3f3b448, 0xc0039d5380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0007d34a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004c4f5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 13289 [select]:
net/http.(*persistConn).writeLoop(0xc003ea46c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 13286
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5739 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011c3540)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5720
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5794 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0030119f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7180, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0013e3530, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5683 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5f680, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc00169b100}, 0xc000de1370, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5646
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1876 [select, 191 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0007b9c70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f72c0, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000e17120, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1827
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1877 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0033b2000?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000e8faa0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1827
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1878 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7400, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0016fbc80}, 0xc0027e5580, 0x0, 0xc003d215f0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1827
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1879 [select, 191 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7540, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0007b9db0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1827
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5936 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004808c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0007d6b40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5949
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5756 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9fb80, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc003022700}, 0xc000752580, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5742
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5743 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f6780, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc000af3e80}, 0xc002eab980, 0x0, 0xc003cdfa70, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5720
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 8350 [IO wait, 56 minutes]:
internal/poll.runtime_pollWait(0x7fd688def790, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003827d00?, 0xc000800b00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003827d00, {0xc000800b00, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003827d00, {0xc000800b00?, 0xc000800b05?, 0x22?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00140a190, {0xc000800b00?, 0x2af7d05?, 0xc001e4ba38?})
	/usr/local/go/src/net/net.go:179 +0x45
crypto/tls.(*atLeastReader).Read(0xc004d2f308, {0xc000800b00?, 0xc004d2f308?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:805 +0x3b
bytes.(*Buffer).ReadFrom(0xc001e4bb28, {0x3f0ca20, 0xc004d2f308})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001e4b880, {0x3f07620?, 0xc00140a190}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:827 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc001e4b880, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:625 +0x250
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:587
crypto/tls.(*Conn).Read(0xc001e4b880, {0xc00384c000, 0x8000, 0x4108a5?})
	/usr/local/go/src/crypto/tls/conn.go:1369 +0x158
bufio.(*Reader).Read(0xc003843920, {0xc0018f7540, 0x9, 0x7fd6cfe1d108?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc003843920}, {0xc0018f7540, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc0018f7540, 0x9, 0xc0046c7f68?}, {0x3f07920?, 0xc003843920?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0018f7500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc0037e44e0, {0x3f59400, 0xc002bbd2f0}, 0x6628060?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:617 +0x15d
google.golang.org/grpc.(*Server).serveStreams(0xc002aac200, {0x3f592e8?, 0x6628060?}, {0x3f71660?, 0xc0037e44e0}, {0x3f6a030?, 0xc00140a190?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x3e2
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 8347
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d8

goroutine 130604 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0020d5e00, 0xc0037f6500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0013bbe00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 473
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 5971 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000480b40, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc0007e29f0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5943
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5608 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0034952c0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc003282d38, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5601
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5757 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9fcc0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc003022e80}, 0xc000752d70, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5713
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5732 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008dbcc0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc000edc5a0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 87295 [select, 67 minutes]:
net/http.(*persistConn).writeLoop(0xc0047a1d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 87293
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5712 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc000afe1e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008db540, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000cb8ad0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5698
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5583 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001ceafd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002f37d40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5573
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5694 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5fcc0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001ebc228, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5744
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 31012 [select, 147 minutes]:
net/http.(*persistConn).writeLoop(0xc000ede240)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 31010
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5830 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e90c80, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc003531740}, 0xc000e16ca0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5795
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5612 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da500, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0010b7540}, 0xc00044a310, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5583
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 47005 [IO wait, 122 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6cc88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002534f00?, 0xc002515000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002534f00, {0xc002515000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002534f00, {0xc002515000?, 0x703620?, 0xc0046903c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000d82420, {0xc002515000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00253cfc0, {0xc002515000?, 0xc0023d2720?, 0xc003170d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0038cee40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0038cee40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00253cfc0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 47004
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 117895 [select, 28 minutes]:
net/http.(*persistConn).writeLoop(0xc004f23200)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 117893
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 6044 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e96c80, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001242000, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6036
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5486 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001c2d900)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5479
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 8352 [select, 184 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xbe
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 8351
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0x96

goroutine 2358 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fd688def888, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0008c5580?, 0xc001406000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0008c5580, {0xc001406000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0008c5580, {0xc001406000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001831100, {0xc001406000?, 0x0?, 0xc0020eeea8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0020eeea0, {0xc001406000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001bf67e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001bf67e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc002d50870, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 5532 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003494000, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0030228c0}, 0xc00137a5d0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5505
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 6622 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008db900, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0036ce780}, 0xc000f0a2a0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6557
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 4521 [IO wait, 189 minutes]:
internal/poll.runtime_pollWait(0x7fd688dfee80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003489880?, 0xc003497000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003489880, {0xc003497000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003489880, {0xc003497000?, 0x703620?, 0xc003494780?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144e238, {0xc003497000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001e81440, {0xc003497000?, 0xc003646d80?, 0xc002578d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003605440)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003605440, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001e81440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 4520
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5713 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0027ebfd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0016c0350?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5698
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5851 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0007134a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da000, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0017057f0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5842
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 134613 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002bf8648, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37a08?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002bf8630, {0xc003955801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc003955801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc000984640)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000984640)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc000984640, {0x326cdc0, 0xc003fe7560})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc003ef1f80, {0xc003e29800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0047d2b40, 0xc0024d6ae0?, {0x3f3b448, 0xc004ea46c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011439e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004b31540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 2155 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dff168, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034df080?, 0xc0026c8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034df080, {0xc0026c8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034df080, {0xc0026c8000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0007380c8, {0xc0026c8000?, 0x0?, 0xc0034e4398?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0034e4390, {0xc0026c8000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0026ce720)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0026ce720, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0034e27e0, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 5715 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008db7c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc000afe460, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5698
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5854 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da280, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc000713a40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5842
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5852 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0031a4fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000b4f7a0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5842
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5645 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0033679a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5e140, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0016f35e0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 8802 [IO wait, 182 minutes]:
internal/poll.runtime_pollWait(0x7fd688dfed88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00338da80?, 0xc001b89000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00338da80, {0xc001b89000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00338da80, {0xc001b89000?, 0x703620?, 0xc002fd7540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c17f0, {0xc001b89000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0010c2480, {0xc001b89000?, 0xc001bfd6e0?, 0xc0026d8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0029a5b00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0029a5b00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0010c2480)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 8801
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5978 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002bb180, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001ea1830, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5936
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5934 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc00319ffd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001c1c930?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5949
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5667 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011c25a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5654
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 37342 [IO wait, 137 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6ca98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002f92780?, 0xc002d97000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f92780, {0xc002d97000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002f92780, {0xc002d97000?, 0x703620?, 0xc003462f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e12850, {0xc002d97000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002f9cc60, {0xc002d97000?, 0xc0011eae40?, 0xc00321cd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003cb0c60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003cb0c60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002f9cc60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 37341
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5681 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e5e780, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc003533908, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5648
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5584 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003494f00, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0016849c0}, 0xc0014df880, 0x0, 0xc003683f50, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5573
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5646 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc003171fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc003682300?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5627
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2349 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fd688dff070, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00396c680?, 0xc0023e6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00396c680, {0xc0023e6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00396c680, {0xc0023e6000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0007393b0, {0xc0023e6000?, 0x0?, 0xc0015f6998?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0015f6990, {0xc0023e6000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002a992c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002a992c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0015c2000, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 62887 [select, 97 minutes]:
net/http.(*persistConn).writeLoop(0xc0011d9d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 62885
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 124246 [select, 17 minutes]:
net/http.(*persistConn).writeLoop(0xc001c12b40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 124244
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5876 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008da3c0, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc00118b500, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5854
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5506 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e90780, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc002ef4cc0}, 0xc002f82a00, 0x0, 0xc003405080, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5479
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 13306 [select]:
net/http.(*persistConn).writeLoop(0xc003ea47e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 13290
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5940 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc000722960})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e91a40, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc001716ec0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5863
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 6033 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc003576c30})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002eb2c0, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0013e8b00, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6007
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 15148 [select, 172 minutes]:
net/http.(*persistConn).writeLoop(0xc00455a7e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 15146
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5931 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003416b40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5949
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 66937 [select, 92 minutes]:
net/http.(*persistConn).writeLoop(0xc001125c20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 66935
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 34192 [IO wait, 142 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6d160, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027b4800?, 0xc0025d1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027b4800, {0xc0025d1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027b4800, {0xc0025d1000?, 0x703620?, 0xc004691b80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c0a48, {0xc0025d1000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0027b30e0, {0xc0025d1000?, 0xc0011338c0?, 0xc003ad8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0045c8a80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0045c8a80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0027b30e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 34191
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 131151 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0013d93c8, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37be8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0013d93b0, {0xc002c23201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002c23201?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc000641cc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000641cc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc000641cc0, {0x326cdc0, 0xc001f138c0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0032b0000, {0xc003e28400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00457d810, 0xc0026d2780?, {0x3f3b448, 0xc004313a80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0006a6340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0012a8640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 496
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 56547 [IO wait, 107 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6868, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bdcc80?, 0xc0044dd000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bdcc80, {0xc0044dd000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bdcc80, {0xc0044dd000?, 0x703620?, 0xc004690140?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000afcfe0, {0xc0044dd000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0014fe000, {0xc0044dd000?, 0xc0043744e0?, 0xc001c7cd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0048f0a20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0048f0a20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0014fe000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 56546
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5749 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f7900, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc001086a00}, 0xc0014d3660, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5670
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 6094 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a9f540, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc000eee400}, 0xc00087de10, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6034
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 8715 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dfef78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0018dba00?, 0xc001ea9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0018dba00, {0xc001ea9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0018dba00, {0xc001ea9000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0011402e8, {0xc001ea9000?, 0x0?, 0xc00184bce8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc00184bce0, {0xc001ea9000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002bf02a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002bf02a0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc002f13680, {0x3f59400, 0xc001c4b3e0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1137
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 5714 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008db680, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc000ee52c0}, 0xc003498180, 0x0, 0xc00287c7e0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5698
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 77762 [select, 82 minutes]:
net/http.(*persistConn).writeLoop(0xc0010e4d80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 77728
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5776 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002394280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5759
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5797 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027f77c0, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc003011b30, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 4522 [select, 189 minutes]:
net/http.(*persistConn).writeLoop(0xc001e81440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 4520
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 135010 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001f8f6c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc003174c48?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc001f8f6b0, {0xc00315a768, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x2?}, {0xc00315a768?, 0xc003174ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc001f8f680}, {0xc00315a768, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0010569d8, {0xc003e28800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003cda050, 0x8?, {0x3f3b448, 0xc004546d40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001191100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004546d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 383
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 43843 [select, 127 minutes]:
net/http.(*persistConn).writeLoop(0xc001339d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 43841
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 6031 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003b85b80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 6007
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5976 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002ba8c0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc002089a00}, 0xc0008e9db0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5941
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 6035 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002eb900, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc0008fc600}, 0xc002e13e80, 0x0, 0xc0032f3dd0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6007
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 18324 [select, 167 minutes]:
net/http.(*persistConn).writeLoop(0xc0030498c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 18322
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 62886 [IO wait, 97 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6c7b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00213ab80?, 0xc0025d0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00213ab80, {0xc0025d0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00213ab80, {0xc0025d0000?, 0x703620?, 0xc0034637c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0011411d0, {0xc0025d0000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0011d9d40, {0xc0025d0000?, 0xc002a856e0?, 0xc003290d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0045ee120)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0045ee120, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0011d9d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 62885
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5967 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002ea140, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc002432940}, 0xc000872930, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5934
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 43842 [IO wait, 127 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6c8a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ddd100?, 0xc003fc6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ddd100, {0xc003fc6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ddd100, {0xc003fc6000?, 0x703620?, 0xc004347040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e503c0, {0xc003fc6000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001339d40, {0xc003fc6000?, 0xc002fd27e0?, 0xc0026a2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003470c60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003470c60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001339d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 43841
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5942 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e91b80, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc002e79b00}, 0xc003734400, 0x0, 0xc00362f080, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5863
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5935 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000480640, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc00232ef40}, 0xc0034f9f00, 0x0, 0xc0039a0150, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5949
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5938 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001c2c460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 5863
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 5941 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0017a5fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00044b510?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 5863
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 5933 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0007d6a00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000480500, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000cb9000, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 5949
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 111546 [IO wait, 37 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae5dc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002535f80?, 0xc00415e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002535f80, {0xc00415e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002535f80, {0xc00415e000?, 0x703620?, 0xc0034948c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000ef8408, {0xc00415e000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0006f19e0, {0xc00415e000?, 0xc00345fce0?, 0xc002937d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0049b9f80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0049b9f80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0006f19e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 111545
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 96815 [select, 52 minutes]:
net/http.(*persistConn).writeLoop(0xc002c17b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 96813
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 73713 [IO wait, 87 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6488, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003bc8700?, 0xc002e65000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003bc8700, {0xc002e65000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003bc8700, {0xc002e65000?, 0x703620?, 0xc0033d4000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016c3220, {0xc002e65000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0008feb40, {0xc002e65000?, 0xc0045aa900?, 0xc00216cd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002fbd440)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002fbd440, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0008feb40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 73696
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 134564 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00292b380, 0xc0027da700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc004513d00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 414
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 6034 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc003170fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0014084f0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 6007
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 6036 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000e96780, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc003576f00, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6007
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 135009 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001f8f680, 0xc0037f6800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc00441d780?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 383
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 130243 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0023e1e48, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f38020?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0023e1e30, {0xc002786c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002786c01?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc002e5ef00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc002e5ef00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc002e5ef00, {0x326cdc0, 0xc004979da0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0031eb740, {0xc000b46400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0034ebbd0, 0xc003343e00?, {0x3f3b448, 0xc004fb1d40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00055ccc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004c2ac40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 532
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 129935 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc003d1fb48, 0x8)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001cd1d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003d1fb30, {0xc0026bbc00, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0026bbc00?}, {0xc0026bbc00?, 0xc001cd1ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc003d1fb00}, {0xc0026bbc00, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc004b7d4a0, {0xc000b46800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003d32be0, 0xc002a85c20?, {0x3f3b448, 0xc0041c5280})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0005d47e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004970640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 395
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 13288 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688c6d448, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003ea3380?, 0xc003eb8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003ea3380, {0xc003eb8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003ea3380, {0xc003eb8000?, 0xc0031a3ec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000cf43e0, {0xc003eb8000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003ea46c0, {0xc003eb8000?, 0x450260?, 0xc0031a3ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0039b5500)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0039b5500, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003ea46c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 13286
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 80917 [select, 77 minutes]:
net/http.(*persistConn).writeLoop(0xc00185f9e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 80915
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 59717 [select, 102 minutes]:
net/http.(*persistConn).writeLoop(0xc0010e5440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 59715
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 100752 [IO wait, 48 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7abf0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0043aeb80?, 0xc0043ce000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0043aeb80, {0xc0043ce000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0043aeb80, {0xc0043ce000?, 0x703620?, 0xc0033d5cc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000e8bbf0, {0xc0043ce000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00414bc20, {0xc0043ce000?, 0xc00348c420?, 0xc0024acd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0033c92c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0033c92c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00414bc20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 100751
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 21503 [IO wait, 163 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6cf70, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003ae8380?, 0xc003aea000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003ae8380, {0xc003aea000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003ae8380, {0xc003aea000?, 0x703620?, 0xc000356000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014c0788, {0xc003aea000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003ac70e0, {0xc003aea000?, 0xc0018e2840?, 0xc0024aed38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0038b92c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0038b92c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003ac70e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 21502
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 11900 [IO wait, 178 minutes]:
internal/poll.runtime_pollWait(0x7fd688dfeaa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003528580?, 0xc003534000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003528580, {0xc003534000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003528580, {0xc003534000?, 0x703620?, 0xc004346c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000afda80, {0xc003534000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00352e240, {0xc003534000?, 0xc002d5f1a0?, 0xc00257fd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003d76c60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003d76c60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00352e240)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 11899
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 31011 [IO wait, 147 minutes]:
internal/poll.runtime_pollWait(0x7fd688dff260, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001dddc80?, 0xc001e18000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001dddc80, {0xc001e18000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001dddc80, {0xc001e18000?, 0x703620?, 0xc0034632c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014c1448, {0xc001e18000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000ede240, {0xc001e18000?, 0xc0045aa780?, 0xc0026a7d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00410ce40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00410ce40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000ede240)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 31010
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 6617 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008dba40, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc002680138, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6559
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 50186 [select, 117 minutes]:
net/http.(*persistConn).writeLoop(0xc002e5a000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 50184
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 34193 [select, 142 minutes]:
net/http.(*persistConn).writeLoop(0xc0027b30e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 34191
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 133799 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc0012b59e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 133797
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 8855 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688dfeb98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0035be800?, 0xc00240d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0035be800, {0xc00240d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0035be800, {0xc00240d000?, 0xc0024afec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c1d58, {0xc00240d000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001338d80, {0xc00240d000?, 0x450260?, 0xc0024afec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028d8960)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028d8960, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001338d80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 8865
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 8859 [IO wait]:
internal/poll.runtime_pollWait(0x7fd688c6d638, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0037aca80?, 0xc00242b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0037aca80, {0xc00242b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0037aca80, {0xc00242b000?, 0xc0032a3ec8?, 0xc0043f6360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c1d98, {0xc00242b000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0011f6240, {0xc00242b000?, 0x450260?, 0xc0032a3ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028d8ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028d8ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0011f6240)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 8857
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 93663 [select, 57 minutes]:
net/http.(*persistConn).writeLoop(0xc001280ea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 93661
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 8348 [select, 56 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc00383e370, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x113
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc000375490)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x86
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:325 +0xd2
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 8347
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:322 +0x187e

goroutine 11901 [select, 178 minutes]:
net/http.(*persistConn).writeLoop(0xc00352e240)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 11899
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 131541 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003b46a80, 0xc0038a0800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc004f49e40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 417
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 8349 [select, 56 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc0037e44e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1138 +0x225
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 8347
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:328 +0x18c5

goroutine 8369 [select, 177 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0x106
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 8351
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0x96

goroutine 100753 [select, 48 minutes]:
net/http.(*persistConn).writeLoop(0xc00414bc20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 100751
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 134612 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002bf8600, 0xc0027db300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc00046c428?, 0xc001e50840?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 40528 [IO wait, 133 minutes]:
internal/poll.runtime_pollWait(0x7fd688c6c9a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0042ded00?, 0xc003fc7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0042ded00, {0xc003fc7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0042ded00, {0xc003fc7000?, 0x703620?, 0xc002a9f180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00086dfc8, {0xc003fc7000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0042b7680, {0xc003fc7000?, 0xc002bd9680?, 0xc002654d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b91bc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b91bc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0042b7680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 40527
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 64497 [select, 49 minutes]:
net/http.(*persistConn).writeLoop(0xc00123c7e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 64495
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 21504 [select, 163 minutes]:
net/http.(*persistConn).writeLoop(0xc003ac70e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 21502
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 6556 [select, 185 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc002d91d60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003495900, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000dd6c60, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6543
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 90453 [select, 62 minutes]:
net/http.(*persistConn).writeLoop(0xc00308c5a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 90451
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 8860 [select]:
net/http.(*persistConn).writeLoop(0xc0011f6240)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 8857
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 64474 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6298, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003bc8b00?, 0xc00468f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003bc8b00, {0xc00468f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003bc8b00, {0xc00468f000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014c0078, {0xc00468f000?, 0x0?, 0xc0017a37a8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0017a37a0, {0xc00468f000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0048f0f00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0048f0f00, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0013d0ab0, {0x3f59400, 0xc0023bae40})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1190
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 132419 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0025c4c00, 0xc0027da900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc0023bae40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 191
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 6559 [select, 185 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008daf00, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc002d91f40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6543
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 129934 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003d1fb00, 0xc003395700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc001220300?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 395
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 6554 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001c2d9a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 6543
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 24666 [select, 158 minutes]:
net/http.(*persistConn).writeLoop(0xc0047a0360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 24664
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 8856 [select]:
net/http.(*persistConn).writeLoop(0xc001338d80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 8865
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 8351 [semacquire, 184 minutes]:
sync.runtime_Semacquire(0xc001e790b0?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0xc001e12d50?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
golang.org/x/sync/errgroup.(*Group).Wait(0xc0038390c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:53 +0x25
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc0009caa00, 0x3586f60?, {0x3f689f0?, 0xc001463300})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:106 +0x40e
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x326bd40?, 0xc0009caa00}, {0x3f640d8, 0xc00481b3b0})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:114 +0xd0
google.golang.org/grpc.(*Server).processStreamingRPC(0xc002aac200, {0x3f59400, 0xc002bbd680}, {0x3f71660, 0xc0037e44e0}, 0xc0010b9200, 0xc0016a8c90, 0x607ff60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc002aac200, {0x3f71660, 0xc0037e44e0}, 0xc0010b9200)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 8350
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 90452 [IO wait, 62 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6960, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001d24080?, 0xc0018eb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001d24080, {0xc0018eb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001d24080, {0xc0018eb000?, 0x703620?, 0xc004346b40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000d821b0, {0xc0018eb000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00308c5a0, {0xc0018eb000?, 0xc002d5faa0?, 0xc0026dad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028ee840)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028ee840, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00308c5a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 90451
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 6558 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003495a40, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc003221cc0}, 0xc003247800, 0x0, 0xc0032dac90, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 6543
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 77761 [IO wait, 82 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6580, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc004771d80?, 0xc001f2e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004771d80, {0xc001f2e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004771d80, {0xc001f2e000?, 0x703620?, 0xc0034628c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017b9e80, {0xc001f2e000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0010e4d80, {0xc001f2e000?, 0xc002d5e7e0?, 0xc002931d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004bfe720)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004bfe720, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0010e4d80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 77728
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 8803 [select, 182 minutes]:
net/http.(*persistConn).writeLoop(0xc0010c2480)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 8801
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 6557 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc00321bfd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0013ef930?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 6543
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 121074 [IO wait, 23 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7aa00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc004015980?, 0xc00407e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004015980, {0xc00407e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004015980, {0xc00407e000?, 0x703620?, 0xc000480c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014e3198, {0xc00407e000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003f81e60, {0xc00407e000?, 0xc0023d22a0?, 0xc00201dd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b91080)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b91080, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003f81e60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 121073
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 59716 [IO wait, 102 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6770, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034c7300?, 0xc002514000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034c7300, {0xc002514000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034c7300, {0xc002514000?, 0x703620?, 0xc002a9e640?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00140a360, {0xc002514000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0010e5440, {0xc002514000?, 0xc003437320?, 0xc0024e5d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003afe840)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003afe840, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0010e5440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 59715
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 124245 [IO wait, 17 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae5bd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002bc4900?, 0xc002de8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002bc4900, {0xc002de8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002bc4900, {0xc002de8000?, 0x703620?, 0xc002e5ec80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001785c60, {0xc002de8000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001c12b40, {0xc002de8000?, 0xc0043759e0?, 0xc00201ad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004fbfd40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004fbfd40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001c12b40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 124244
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 73714 [select, 87 minutes]:
net/http.(*persistConn).writeLoop(0xc0008feb40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 73696
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 130625 [select, 7 minutes]:
net/http.(*persistConn).writeLoop(0xc000ed5320)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 130607
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 93662 [IO wait, 57 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae5fb0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001fbf600?, 0xc001fd4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001fbf600, {0xc001fd4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001fbf600, {0xc001fd4000?, 0x703620?, 0xc002fd77c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000ef8068, {0xc001fd4000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001280ea0, {0xc001fd4000?, 0xc0033ad440?, 0xc002aafd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003041b00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003041b00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001280ea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 93661
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 133798 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7a430, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003b4f780?, 0xc0044dc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003b4f780, {0xc0044dc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003b4f780, {0xc0044dc000?, 0x703620?, 0xc004346640?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00086c7c0, {0xc0044dc000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0012b59e0, {0xc0044dc000?, 0xc002df52c0?, 0xc0024b2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004ed93e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004ed93e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0012b59e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 133797
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 127441 [select, 12 minutes]:
net/http.(*persistConn).writeLoop(0xc000c91c20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 127423
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 133563 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002ff6a80, 0xc000e48900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0032e89c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 404
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 135242 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc003799e48, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003799e30, {0xc00365aa00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0041edd48?}, {0xc00365aa00?, 0x2?, 0x100000525?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc003462140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc003462140)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc003462140, {0x326cdc0, 0xc004586678})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0041be7b0, {0xc0024ba000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00461bc20, 0x8?, {0x3f3b448, 0xc004084ac0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000a55760)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004084a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 479
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 132420 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0025c4c48, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001defd40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0025c4c30, {0xc001033ac0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001033ac0?}, {0xc001033ac0?, 0xc001defce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc0025c4c00}, {0xc001033ac0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00294bd28, {0xc003ee2000, 0x4000, 0x5000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003fd7d10, 0xc002d5f680?, {0x3f3b448, 0xc00233d540})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000a650a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc003b279c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 191
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 84105 [IO wait, 72 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae6678, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003abb780?, 0xc003f4d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003abb780, {0xc003f4d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003abb780, {0xc003f4d000?, 0x703620?, 0xc002fd6b40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000103af0, {0xc003f4d000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001273680, {0xc003f4d000?, 0xc002b7bce0?, 0xc0025cbd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003cb1b60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003cb1b60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001273680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 84104
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 132362 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0024547c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f3a380?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0024547b0, {0xc0032f6c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0032f6c01?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc004347900)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc004347900)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc004347900, {0x326cdc0, 0xc004d2f158})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00339b260, {0xc00264e800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003c73c20, 0xc0032ed140?, {0x3f3b448, 0xc002417e80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001143e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc003e428c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 595
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 132361 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002454780, 0xc004549300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc0023bae40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 595
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 135165 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0028b04c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0028b04b0, {0xc0028ac600, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001cf9d48?}, {0xc0028ac600?, 0x2?, 0x10000051f?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc004347a40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc004347a40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc004347a40, {0x326cdc0, 0xc002d9d248})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00301c270, {0xc0018eec00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00476a9b0, 0x8?, {0x3f3b448, 0xc0049487c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011426a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004948780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 114717 [IO wait, 32 minutes]:
internal/poll.runtime_pollWait(0x7fd688ae60a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027b4f80?, 0xc004d47000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027b4f80, {0xc004d47000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027b4f80, {0xc004d47000?, 0x703620?, 0xc003494c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001140638, {0xc004d47000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001c13c20, {0xc004d47000?, 0xc0033ca1e0?, 0xc003162d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c69620)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c69620, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001c13c20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 114716
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 134511 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002431e48, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001d63b90?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002431e30, {0xc002dd4001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002dd4001?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc000641e00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000641e00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc000641e00, {0x326cdc0, 0xc0041ab698})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0031cfd70, {0xc0018ef000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0045b0d20, 0xc00187b500?, {0x3f3b448, 0xc004a6f940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013f4e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0045e8180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 601
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 131150 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0013d9380, 0xc003aab600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc004e6c000?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 496
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 130605 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0020d5e48, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00321dd40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0020d5e30, {0xc0040c7158, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0040c714a?}, {0xc0040c7158?, 0xc00321dce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fd688db1ac8, 0xc0020d5e00}, {0xc0040c7158, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc004afa348, {0xc001e21000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002f0c5a0, 0xc002fb9560?, {0x3f3b448, 0xc003b26280})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000ae2040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000c05c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 473
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 117894 [IO wait, 28 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7a908, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc004f69f00?, 0xc005054000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004f69f00, {0xc005054000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004f69f00, {0xc005054000?, 0x703620?, 0xc0006417c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00044dd98, {0xc005054000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc004f23200, {0xc005054000?, 0xc004bd8c00?, 0xc004b2ed38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc004e7c960)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc004e7c960, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc004f23200)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 117893
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 133437 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc002440048, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37dc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002440030, {0xc0024a7201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0024a7201?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0033d57c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0033d57c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0033d57c0, {0x326cdc0, 0xc0043f97b8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0026cba70, {0xc0018ef800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc005134c80, 0xc00187a420?, {0x3f3b448, 0xc003f03440})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00101eca0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc004550f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 130242 [select, 8 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0023e1e00, 0xc00163ef00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc0023bae40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 532
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 127424 [IO wait, 12 minutes]:
internal/poll.runtime_pollWait(0x7fd688a7a718, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002c26000?, 0xc0046d5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002c26000, {0xc0046d5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002c26000, {0xc0046d5000?, 0x703620?, 0xc0004a8640?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00044c0c0, {0xc0046d5000?, 0x0?, 0xc002a81040?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000c91c20, {0xc0046d5000?, 0xc0026c46c0?, 0xc0025cad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028d9c20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028d9c20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000c91c20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 127423
	/usr/local/go/src/net/http/transport.go:1776 +0x169f
