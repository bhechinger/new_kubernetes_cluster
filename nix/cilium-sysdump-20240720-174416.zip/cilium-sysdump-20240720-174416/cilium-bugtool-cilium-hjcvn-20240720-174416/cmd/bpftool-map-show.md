2: prog_array  name hid_jmp_table  flags 0x0
	key 4B  value 4B  max_entries 1024  memlock 8512B
	owner_prog_type tracing  owner jited
3: array  name I__.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
4: array  name E__.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
5: array  name I_init.scope  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
6: array  name E_init.scope  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
7: array  name I_system.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
8: array  name E_system.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
9: array  name I_system_getty.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
10: array  name E_system_getty.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
11: array  name I_system_modpro  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
12: array  name E_system_modpro  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
13: array  name I_system_serial  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
14: array  name E_system_serial  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
15: array  name I_system_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
16: array  name E_system_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
17: array  name I_user.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
18: array  name E_user.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
19: array  name I_dev_hugepages  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
20: array  name E_dev_hugepages  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
21: array  name I_dev_mqueue.mo  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
22: array  name E_dev_mqueue.mo  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
23: array  name I_sys_kernel_de  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
24: array  name E_sys_kernel_de  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
25: array  name I_domainname.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
26: array  name E_domainname.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
27: array  name I_kmod_static_n  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
28: array  name E_kmod_static_n  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
29: array  name I_modprobe_conf  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
30: array  name E_modprobe_conf  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
31: array  name I_modprobe_drm.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
32: array  name E_modprobe_drm.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
33: array  name I_modprobe_efi_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
34: array  name E_modprobe_efi_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
35: array  name I_modprobe_fuse  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
36: array  name E_modprobe_fuse  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
37: array  name I_mount_pstore.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
38: array  name E_mount_pstore.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
39: array  name I_suid_sgid_wra  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
40: array  name E_suid_sgid_wra  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
41: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
42: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
43: array  name I_systemd_modul  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
44: array  name E_systemd_modul  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
45: array  name I_systemd_remou  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
46: array  name E_systemd_remou  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
47: array  name I_systemd_udev_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
48: array  name E_systemd_udev_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
49: array  name I_sys_fs_fuse_c  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
50: array  name E_sys_fs_fuse_c  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
51: array  name I_sys_kernel_co  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
52: array  name E_sys_kernel_co  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
53: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
54: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
55: array  name I_systemd_rando  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
56: array  name E_systemd_rando  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
57: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
58: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
59: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
60: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
61: array  name I_systemd_udevd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
62: array  name E_systemd_udevd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
63: array  name I_systemd_sysct  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
64: array  name E_systemd_sysct  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
65: array  name I_mdmonitor.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
66: array  name E_mdmonitor.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
67: array  name I_systemd_fsck_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
68: array  name E_systemd_fsck_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
69: array  name I_systemd_vcons  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
70: array  name E_systemd_vcons  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
71: array  name I_boot.mount  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
72: array  name E_boot.mount  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
73: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
74: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
75: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
76: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
77: array  name I_systemd_oomd.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
78: array  name E_systemd_oomd.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
79: array  name I_systemd_times  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
80: array  name E_systemd_times  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
81: array  name I_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
82: array  name E_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
83: array  name I_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
84: array  name E_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
85: array  name I_audit.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
86: array  name E_audit.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
87: array  name I_dhcpcd.servic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
88: array  name E_dhcpcd.servic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
89: array  name I_logrotate_che  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
90: array  name E_logrotate_che  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
91: array  name I_nscd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
92: array  name E_nscd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
93: array  name I_reload_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
94: array  name E_reload_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
95: array  name I_resolvconf.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
96: array  name E_resolvconf.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
97: array  name I_dbus.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
98: array  name E_dbus.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
99: array  name I_systemd_login  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
100: array  name E_systemd_login  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
101: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
102: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
103: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
104: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
105: array  name I_vlan4000_netd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
106: array  name E_vlan4000_netd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
107: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
108: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
109: array  name I_private_netde  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
110: array  name E_private_netde  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
111: array  name I_public_netdev  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
112: array  name E_public_netdev  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
113: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
114: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
115: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
116: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
117: array  name I_network_setup  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
118: array  name E_network_setup  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
119: array  name I_network_local  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
120: array  name E_network_local  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
121: array  name I_sshd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
122: array  name E_sshd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
123: array  name I_systemd_user_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
124: array  name E_systemd_user_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
125: array  name I_getty_tty1.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
126: array  name E_getty_tty1.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
127: array  name I_serial_getty_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
128: array  name E_serial_getty_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
129: array  name I_rke2_agent.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
130: array  name E_rke2_agent.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
131: array  name I_kubepods.slic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
132: array  name E_kubepods.slic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
133: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
134: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
135: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
136: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
137: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
138: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
139: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
140: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
141: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
142: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
144: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
145: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
147: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
148: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
171: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
172: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
209: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 8389568B
210: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 2368B
211: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 336B
212: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 264688B
213: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 336B
214: hash  name cilium_throttle  flags 0x1
	key 8B  value 56B  max_entries 65535  memlock 1049536B
215: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 1051968B
216: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 4320B
217: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 18064B
218: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 5768128B
219: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1056400B
220: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1052416B
221: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1051984B
222: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
223: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
224: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 17826752B
225: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 8913856B
226: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 15729600B
227: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 10486720B
228: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 721856B
229: lpm_trie  name cilium_ipmasq_v  flags 0x1
	key 8B  value 1B  max_entries 16384  memlock 90B
230: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1049536B
231: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6292416B
232: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 0B
234: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 66496B
	btf_id 142
235: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 328B
	btf_id 143
236: lru_hash  name cilium_ratelimi  flags 0x0
	key 4B  value 16B  max_entries 1024  memlock 91072B
	btf_id 144
237: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 144B
238: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
239: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
240: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
243: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
244: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
246: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
248: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
250: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 206
251: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
254: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
255: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
268: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
269: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
270: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
271: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
275: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
276: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
277: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 234
284: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
285: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 262
286: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
299: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
300: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
302: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
303: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
304: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 332
311: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
312: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
329: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
330: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
332: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
333: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
338: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
339: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
340: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
341: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
342: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
343: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
344: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
345: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
346: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
347: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
348: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
349: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
350: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
351: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
352: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
353: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
360: array  name I_kubepods_pod3  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
361: array  name E_kubepods_pod3  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
374: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
375: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
376: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
377: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
386: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 288B
387: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
388: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 360
389: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 1728B
390: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 374
391: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
395: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 288B
396: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 388
397: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
398: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
399: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 402
400: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
401: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
402: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
403: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 416
404: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
405: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
406: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 420
407: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
408: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 444
409: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
410: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
411: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
413: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 288B
414: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 458
415: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
416: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
417: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
419: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
420: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
422: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
423: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
425: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
426: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 472
427: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
428: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
429: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 486
430: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
431: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
432: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
434: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
435: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
437: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
438: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
440: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
441: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
443: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
444: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
445: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 500
452: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
453: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
456: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
457: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
464: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
465: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
466: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
467: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
481: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
482: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 570
483: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
484: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
485: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
487: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
488: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
490: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
491: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
493: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
494: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
499: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
500: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
505: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
506: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
508: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
509: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
511: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
512: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
513: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
514: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
516: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
517: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
522: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
523: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
528: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
529: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
546: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
547: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
549: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
550: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
558: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
559: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
561: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
562: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
564: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
565: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
567: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
568: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
570: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
571: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
573: array  name I_user_0.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
574: array  name E_user_0.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
581: array  name I_user_1000.sli  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
582: array  name E_user_1000.sli  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
593: array  name I_logrotate.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
594: array  name E_logrotate.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
595: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
596: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
597: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
598: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
600: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
601: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
