[
  {
    "containers": [
      {
        "cgroup-id": 13319,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode73d0124_199c_4560_91f9_7c32ba302000.slice/cri-containerd-1e0d6ab256470a003cdf4a3265501004dc4596c9529f4522ea2c29e6e7ea8b4b.scope"
      }
    ],
    "ips": [
      "10.22.30.21"
    ],
    "name": "host-netns-6f55k",
    "namespace": "cilium-test"
  },
  {
    "containers": [
      {
        "cgroup-id": 10234,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod955f2bb5_ea0b_4cd2_9f0c_cc5debfccc08.slice/cri-containerd-c6a922aaac0610c5bd31f3640f7be1b35b983ec92620122f017cb8fcf867fc87.scope"
      }
    ],
    "ips": [
      "10.55.3.12"
    ],
    "name": "rke2-snapshot-controller-59cc9cd8f4-s4vrs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10382,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57ea01af_2084_48cf_802b_3eb5ecb9912c.slice/cri-containerd-dc6bd200a20a68ac0141b1fe135bed884a793ec8459abdfdc67a072c662b0c48.scope"
      }
    ],
    "ips": [
      "10.55.3.78"
    ],
    "name": "rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 11480,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode13f20a4_22d9_448a_aea9_da97a332c7e0.slice/cri-containerd-f453ba073e1c6c436fbdb6dae8ed96eae61e29efb01dae5a289beda39e18c3f2.scope"
      }
    ],
    "ips": [
      "10.55.3.90"
    ],
    "name": "rke2-argocd-server-b55ff85f8-fmtn7",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 11702,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79bc45c7_45c5_460c_8da6_d6e832c83522.slice/cri-containerd-15167af9eff3b086853b69a92d854c8f446b2716c8c529c6753df6698e49b8ee.scope"
      }
    ],
    "ips": [
      "10.55.3.50"
    ],
    "name": "rke2-argocd-repo-server-7bf6499cb6-lpnlc",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 11998,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f0d762_5c6b_4672_8a24_711193064fc2.slice/cri-containerd-109dd775d98d9a19e1d98265269fff62709bfbe6bc2225c6bb1cccdd931f928a.scope"
      }
    ],
    "ips": [
      "10.55.3.19"
    ],
    "name": "rke2-argocd-dex-server-76bb6677d7-8rntq",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 5276,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice/cri-containerd-d561a8579b66c2d6c4d25806d0ad9c8d01867e52da55f8b189e79e50e0d9d9aa.scope"
      },
      {
        "cgroup-id": 5350,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice/cri-containerd-952edcc7065534514376a04b7178393d4629122d7dddbcb4e68ef971963ac747.scope"
      }
    ],
    "ips": [
      "10.22.30.21"
    ],
    "name": "cilium-hjcvn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9938,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice/cri-containerd-8386611406a3294ed71a626960ada13109bdc79087941fd16ae70b3f13f1c74b.scope"
      },
      {
        "cgroup-id": 10962,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice/cri-containerd-f36a9d1e9466dd2a37c9719da11f13e6835655cec89e891b5dd51aac5f4b7ee3.scope"
      }
    ],
    "ips": [
      "10.55.3.129"
    ],
    "name": "hubble-ui-6969854c48-vkb2p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6904,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e9a8f9a_96d9_4525_88dc_03c6e27f2274.slice/cri-containerd-c1a64216356a27a79089c5d2ac086ef927be84881c4a93385473e706b7fd1395.scope"
      }
    ],
    "ips": [
      "10.55.3.218"
    ],
    "name": "rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 11924,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5c5a9b3_fb4d_4d34_b491_c9af8de5e30b.slice/cri-containerd-e1e18caf4fc9ff180ef674bf56f301f032f96e8e06254ea7fc5cba292d86ee42.scope"
      }
    ],
    "ips": [
      "10.55.3.23"
    ],
    "name": "rke2-argocd-repo-server-7bf6499cb6-jh2wl",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 11406,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcf029ae_9eec_4f02_82c7_9e1ee5d35f52.slice/cri-containerd-2ec8d9d65c5051090c5173b5a793659c23324fbc7015399c84dbff32e44b5281.scope"
      }
    ],
    "ips": [
      "10.55.3.252"
    ],
    "name": "rke2-argocd-application-controller-654f4c59bd-m5tpw",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 10666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-a8cecb147bb6cf1a1447a09c8bcf9122e434575520321eef01852bc7d7608cc2.scope"
      },
      {
        "cgroup-id": 11776,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-cf6cb019fe94c4b641a9251537a752a90855bebfab224b500dd28eabe7d2227c.scope"
      },
      {
        "cgroup-id": 10592,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-532a1c89b8d72d54ba28381e4de677dc6e933b6cef306b9e4aae6f3b4292b9ed.scope"
      }
    ],
    "ips": [
      "10.55.3.253"
    ],
    "name": "rke2-argocd-redis-ha-server-0",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 10814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-pod3679cb86_735f_49bf_a560_3c5a7fc5ec0d.slice/cri-containerd-a3fe580a4939f6bb26f3d2514685c50a0d4a72b02393865e0da7d351e5574001.scope"
      }
    ],
    "ips": [
      "10.55.3.164"
    ],
    "name": "rke2-origin-ca-issuer-7bd586658-pmrc8",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 10012,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa92d1b_43ee_4455_b77a_e6383f018ca0.slice/cri-containerd-6d48740b76e79947aca3adbebdc64de3ec9b7267d73685c5cfbcf6dc44203a6a.scope"
      }
    ],
    "ips": [
      "10.55.3.27"
    ],
    "name": "rke2-metrics-server-655477f655-khcbm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10456,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91b2d7cf_e4ed_44dc_a705_da8bd9f77a41.slice/cri-containerd-0565943388e944d9cfcad4dae1faf1c26d6f1621b1ae44a28fb7e8f6127f23e9.scope"
      }
    ],
    "ips": [
      "10.55.3.210"
    ],
    "name": "rke2-snapshot-validation-webhook-54c5989b65-v2s9c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 11554,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4553a32c_66c4_4de1_9f9f_49d5114d8f60.slice/cri-containerd-6b082d5ff549790f165f20df5adf4e4b0bc161c8c02f3377993108fa0806c8cc.scope"
      },
      {
        "cgroup-id": 11850,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4553a32c_66c4_4de1_9f9f_49d5114d8f60.slice/cri-containerd-4bb69f8236d3ddacebd892350e5aaff7ca1fd54d58ff7136ee76e7ffed308512.scope"
      }
    ],
    "ips": [
      "10.55.3.60"
    ],
    "name": "rke2-argocd-server-b55ff85f8-26zmv",
    "namespace": "argocd"
  },
  {
    "containers": [
      {
        "cgroup-id": 10086,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc13e077c_0db8_414e_9837_72b27fed4816.slice/cri-containerd-611adfd18427a7e18555b34c69216df249ccfdc48cc49035ef5e7cf34eb30f5b.scope"
      }
    ],
    "ips": [
      "10.55.3.167"
    ],
    "name": "hubble-relay-6f89c7f794-xdxwj",
    "namespace": "kube-system"
  }
]

