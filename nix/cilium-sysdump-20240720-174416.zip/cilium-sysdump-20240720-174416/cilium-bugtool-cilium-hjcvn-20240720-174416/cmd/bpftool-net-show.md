xdp:

tc:
private(5) clsact/ingress cil_from_netdev-private id 693
private(5) clsact/egress cil_to_netdev-private id 698
public(6) clsact/ingress cil_from_netdev-public id 706
public(6) clsact/egress cil_to_netdev-public id 700
cilium_net(7) clsact/ingress cil_to_host-cilium_net id 682
cilium_host(8) clsact/ingress cil_to_host-cilium_host id 671
cilium_host(8) clsact/egress cil_from_host-cilium_host id 670
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 718
lxc61049c152f38(14) clsact/ingress cil_from_container-lxc61049c152f38 id 825
lxc1896987652ee(18) clsact/ingress cil_from_container-lxc1896987652ee id 862
lxc997092fbbf0c(28) clsact/ingress cil_from_container-lxc997092fbbf0c id 943
lxc9d12cfe86baf(32) clsact/ingress cil_from_container-lxc9d12cfe86baf id 1275
lxc3cc9bcffd79e(34) clsact/ingress cil_from_container-lxc3cc9bcffd79e id 1295
lxce8bba62763ef(36) clsact/ingress cil_from_container-lxce8bba62763ef id 1314
lxc5ea93d8c6b49(38) clsact/ingress cil_from_container-lxc5ea93d8c6b49 id 1318
lxccb0f8eb2e152(40) clsact/ingress cil_from_container-lxccb0f8eb2e152 id 1338
lxc32f643cce124(42) clsact/ingress cil_from_container-lxc32f643cce124 id 1343
lxc5ec43035a653(44) clsact/ingress cil_from_container-lxc5ec43035a653 id 1358
lxc4bf8bc230540(46) clsact/ingress cil_from_container-lxc4bf8bc230540 id 1391
lxc04551b4a009f(48) clsact/ingress cil_from_container-lxc04551b4a009f id 1428
lxca88df1e13933(50) clsact/ingress cil_from_container-lxca88df1e13933 id 1438
lxcb4837a858eef(52) clsact/ingress cil_from_container-lxcb4837a858eef id 1498
lxc06aae3131e3b(62) clsact/ingress cil_from_container-lxc06aae3131e3b id 1651

flow_dissector:

netfilter:

