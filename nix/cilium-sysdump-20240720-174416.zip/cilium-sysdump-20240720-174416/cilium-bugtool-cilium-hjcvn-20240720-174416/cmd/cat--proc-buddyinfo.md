Node 0, zone      DMA      0      0      0      0      0      0      0      1      0      1      3 
Node 0, zone    DMA32    421    112    119    117     45     18     14      4      4      2      7 
Node 0, zone   Normal    268    207    167    128    104     50     39     28     15      7      9 
