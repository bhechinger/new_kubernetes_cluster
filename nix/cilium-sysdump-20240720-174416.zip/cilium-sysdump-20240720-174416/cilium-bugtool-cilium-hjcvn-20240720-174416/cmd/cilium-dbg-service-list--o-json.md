[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.155",
          "nodeName": "worker3",
          "port": 9121,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-2",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.70.170",
        "port": 9121,
        "scope": "external"
      },
      "id": 17
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.155",
            "nodeName": "worker3",
            "port": 9121,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-2",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.70.170",
          "port": 9121,
          "scope": "external"
        },
        "id": 17
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.253",
          "nodeName": "worker1",
          "port": 26379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-0",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.178.184",
        "port": 26379,
        "scope": "external"
      },
      "id": 20
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.253",
            "nodeName": "worker1",
            "port": 26379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-0",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.178.184",
          "port": 26379,
          "scope": "external"
        },
        "id": 20
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.253",
          "nodeName": "worker1",
          "port": 9121,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-0",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.178.184",
        "port": 9121,
        "scope": "external"
      },
      "id": 21
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.253",
            "nodeName": "worker1",
            "port": 9121,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-0",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.178.184",
          "port": 9121,
          "scope": "external"
        },
        "id": 21
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.210",
          "nodeName": "worker1",
          "port": 8443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-snapshot-validation-webhook",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.51.64",
        "port": 443,
        "scope": "external"
      },
      "id": 23
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.210",
            "nodeName": "worker1",
            "port": 8443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-snapshot-validation-webhook",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.51.64",
          "port": 443,
          "scope": "external"
        },
        "id": 23
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.152",
          "nodeName": "worker2",
          "port": 9402,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-cert-manager",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.213.42",
        "port": 9402,
        "scope": "external"
      },
      "id": 27
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.152",
            "nodeName": "worker2",
            "port": 9402,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-cert-manager",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.213.42",
          "port": 9402,
          "scope": "external"
        },
        "id": 27
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.22.20.12",
          "port": 6443,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.22.20.13",
          "port": 6443,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.22.20.11",
          "port": 6443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.22.20.12",
            "port": 6443,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.22.20.13",
            "port": 6443,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.22.20.11",
            "port": 6443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.252",
          "nodeName": "worker1",
          "port": 8082,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-application-controller",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.115.248",
        "port": 8082,
        "scope": "external"
      },
      "id": 10
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.252",
            "nodeName": "worker1",
            "port": 8082,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-application-controller",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.115.248",
          "port": 8082,
          "scope": "external"
        },
        "id": 10
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.218",
          "nodeName": "worker2",
          "port": 9121,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-1",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.243.160",
        "port": 9121,
        "scope": "external"
      },
      "id": 14
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.218",
            "nodeName": "worker2",
            "port": 9121,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-1",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.243.160",
          "port": 9121,
          "scope": "external"
        },
        "id": 14
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.211",
          "nodeName": "worker2",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-cert-manager-webhook",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.174.214",
        "port": 443,
        "scope": "external"
      },
      "id": 28
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.211",
            "nodeName": "worker2",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-cert-manager-webhook",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.174.214",
          "port": 443,
          "scope": "external"
        },
        "id": 28
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.129",
          "nodeName": "worker3",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "10.22.20.21",
        "port": 32495,
        "scope": "external"
      },
      "id": 30
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.129",
            "nodeName": "worker3",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "10.22.20.21",
          "port": 32495,
          "scope": "external"
        },
        "id": 30
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.253",
          "nodeName": "worker1",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-0",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.178.184",
        "port": 6379,
        "scope": "external"
      },
      "id": 22
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.253",
            "nodeName": "worker1",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-0",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.178.184",
          "port": 6379,
          "scope": "external"
        },
        "id": 22
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.129",
          "nodeName": "worker3",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.155.14",
        "port": 8080,
        "scope": "external"
      },
      "id": 29
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.129",
            "nodeName": "worker3",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.155.14",
          "port": 8080,
          "scope": "external"
        },
        "id": 29
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.112",
          "nodeName": "worker2",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-other-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "10.22.20.21",
        "port": 30568,
        "scope": "external"
      },
      "id": 34
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.112",
            "nodeName": "worker2",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-other-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "10.22.20.21",
          "port": 30568,
          "scope": "external"
        },
        "id": 34
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.0.129",
          "nodeName": "master1",
          "port": 53,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.2.204",
          "nodeName": "master3",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-coredns-rke2-coredns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.0.129",
            "nodeName": "master1",
            "port": 53,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.2.204",
            "nodeName": "master3",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-coredns-rke2-coredns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.19",
          "nodeName": "worker1",
          "port": 5556,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-dex-server",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.145.33",
        "port": 5556,
        "scope": "external"
      },
      "id": 8
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.19",
            "nodeName": "worker1",
            "port": 5556,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-dex-server",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.145.33",
          "port": 5556,
          "scope": "external"
        },
        "id": 8
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.50",
          "nodeName": "worker1",
          "port": 8081,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.3.23",
          "nodeName": "worker1",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-repo-server",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.192.200",
        "port": 8081,
        "scope": "external"
      },
      "id": 11
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.50",
            "nodeName": "worker1",
            "port": 8081,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.3.23",
            "nodeName": "worker1",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-repo-server",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.192.200",
          "port": 8081,
          "scope": "external"
        },
        "id": 11
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.78",
          "nodeName": "worker1",
          "port": 9101,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.4.213",
          "nodeName": "worker2",
          "port": 9101,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.5.149",
          "nodeName": "worker3",
          "port": 9101,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-haproxy",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.180.197",
        "port": 9101,
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.78",
            "nodeName": "worker1",
            "port": 9101,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.4.213",
            "nodeName": "worker2",
            "port": 9101,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.5.149",
            "nodeName": "worker3",
            "port": 9101,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-haproxy",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.180.197",
          "port": 9101,
          "scope": "external"
        },
        "id": 6
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.90",
          "nodeName": "worker1",
          "port": 8080,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.3.60",
          "nodeName": "worker1",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-server",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.148.50",
        "port": 443,
        "scope": "external"
      },
      "id": 15
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.90",
            "nodeName": "worker1",
            "port": 8080,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.3.60",
            "nodeName": "worker1",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-server",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.148.50",
          "port": 443,
          "scope": "external"
        },
        "id": 15
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.90",
          "nodeName": "worker1",
          "port": 8080,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.3.60",
          "nodeName": "worker1",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-server",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.148.50",
        "port": 80,
        "scope": "external"
      },
      "id": 16
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.90",
            "nodeName": "worker1",
            "port": 8080,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.3.60",
            "nodeName": "worker1",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-server",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.148.50",
          "port": 80,
          "scope": "external"
        },
        "id": 16
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.78",
          "nodeName": "worker1",
          "port": 6379,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.4.213",
          "nodeName": "worker2",
          "port": 6379,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.55.5.149",
          "nodeName": "worker3",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-haproxy",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.180.197",
        "port": 6379,
        "scope": "external"
      },
      "id": 7
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.78",
            "nodeName": "worker1",
            "port": 6379,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.4.213",
            "nodeName": "worker2",
            "port": 6379,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.55.5.149",
            "nodeName": "worker3",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-haproxy",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.180.197",
          "port": 6379,
          "scope": "external"
        },
        "id": 7
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.155",
          "nodeName": "worker3",
          "port": 26379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-2",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.70.170",
        "port": 26379,
        "scope": "external"
      },
      "id": 19
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.155",
            "nodeName": "worker3",
            "port": 26379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-2",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.70.170",
          "port": 26379,
          "scope": "external"
        },
        "id": 19
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.27",
          "nodeName": "worker1",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-metrics-server",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.48.249",
        "port": 443,
        "scope": "external"
      },
      "id": 24
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.27",
            "nodeName": "worker1",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-metrics-server",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.48.249",
          "port": 443,
          "scope": "external"
        },
        "id": 24
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.22.30.21",
          "nodeName": "worker1",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.253.13",
        "port": 443,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.22.30.21",
            "nodeName": "worker1",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.253.13",
          "port": 443,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.19",
          "nodeName": "worker1",
          "port": 5557,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-dex-server",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.145.33",
        "port": 5557,
        "scope": "external"
      },
      "id": 9
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.19",
            "nodeName": "worker1",
            "port": 5557,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-dex-server",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.145.33",
          "port": 5557,
          "scope": "external"
        },
        "id": 9
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.129",
          "nodeName": "worker3",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 32495,
        "scope": "external"
      },
      "id": 32
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.129",
            "nodeName": "worker3",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 32495,
          "scope": "external"
        },
        "id": 32
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.112",
          "nodeName": "worker2",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-other-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 30568,
        "scope": "external"
      },
      "id": 36
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.112",
            "nodeName": "worker2",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-other-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 30568,
          "scope": "external"
        },
        "id": 36
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.129",
          "nodeName": "worker1",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.97.59",
        "port": 80,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.129",
            "nodeName": "worker1",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.97.59",
          "port": 80,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.218",
          "nodeName": "worker2",
          "port": 26379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-1",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.243.160",
        "port": 26379,
        "scope": "external"
      },
      "id": 13
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.218",
            "nodeName": "worker2",
            "port": 26379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-1",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.243.160",
          "port": 26379,
          "scope": "external"
        },
        "id": 13
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.155",
          "nodeName": "worker3",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-2",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.70.170",
        "port": 6379,
        "scope": "external"
      },
      "id": 18
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.155",
            "nodeName": "worker3",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-2",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.70.170",
          "port": 6379,
          "scope": "external"
        },
        "id": 18
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.3.167",
          "nodeName": "worker1",
          "port": 4245,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.203.48",
        "port": 80,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.3.167",
            "nodeName": "worker1",
            "port": 4245,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.203.48",
          "port": 80,
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.112",
          "nodeName": "worker2",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-other-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.26.204",
        "port": 8080,
        "scope": "external"
      },
      "id": 33
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.112",
            "nodeName": "worker2",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-other-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.26.204",
          "port": 8080,
          "scope": "external"
        },
        "id": 33
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.112",
          "nodeName": "worker2",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-other-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "10.22.30.21",
        "port": 30568,
        "scope": "external"
      },
      "id": 35
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.112",
            "nodeName": "worker2",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-other-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "10.22.30.21",
          "port": 30568,
          "scope": "external"
        },
        "id": 35
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.4.218",
          "nodeName": "worker2",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "rke2-argocd-redis-ha-announce-1",
        "namespace": "argocd",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.65.243.160",
        "port": 6379,
        "scope": "external"
      },
      "id": 12
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.4.218",
            "nodeName": "worker2",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "rke2-argocd-redis-ha-announce-1",
          "namespace": "argocd",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.65.243.160",
          "port": 6379,
          "scope": "external"
        },
        "id": 12
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.55.5.129",
          "nodeName": "worker3",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "10.22.30.21",
        "port": 32495,
        "scope": "external"
      },
      "id": 31
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.55.5.129",
            "nodeName": "worker3",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "10.22.30.21",
          "port": 32495,
          "scope": "external"
        },
        "id": 31
      }
    }
  }
]

