# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
709        Disabled           Disabled          11758      k8s:app=redis-ha-haproxy                                                              10.55.3.78    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha-haproxy                                        
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
                                                           k8s:release=rke2-argocd                                                                                     
                                                           k8s:revision=1                                                                                              
924        Disabled           Disabled          24197      k8s:app.kubernetes.io/instance=rke2-snapshot-validation-webhook                       10.55.3.210   ready   
                                                           k8s:app.kubernetes.io/name=rke2-snapshot-validation-webhook                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-validation-webhook                                    
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
1192       Disabled           Disabled          16822      k8s:app.kubernetes.io/instance=rke2-metrics-server                                    10.55.3.27    ready   
                                                           k8s:app.kubernetes.io/name=rke2-metrics-server                                                              
                                                           k8s:app=rke2-metrics-server                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-metrics-server                                                 
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
1202       Disabled           Disabled          10448      k8s:app=redis-ha                                                                      10.55.3.253   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha                                                
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
                                                           k8s:release=rke2-argocd                                                                                     
                                                           k8s:rke2-argocd-redis-ha=replica                                                                            
1301       Enabled            Disabled          30951      k8s:app.kubernetes.io/component=application-controller                                10.55.3.252   ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-application-controller                                                    
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.2.5                                                                        
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=argocd-application-controller                                       
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
1812       Enabled            Disabled          33708      k8s:app.kubernetes.io/component=server                                                10.55.3.60    ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-server                                                                    
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.2.5                                                                        
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=argocd-server                                                       
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
2033       Disabled           Disabled          8          reserved:ingress                                                                      10.55.3.251   ready   
2117       Enabled            Disabled          33708      k8s:app.kubernetes.io/component=server                                                10.55.3.90    ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-server                                                                    
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.2.5                                                                        
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=argocd-server                                                       
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
2507       Disabled           Disabled          50180      k8s:app.kubernetes.io/instance=rke2-coredns                                           10.55.3.218   ready   
                                                           k8s:app.kubernetes.io/name=rke2-coredns-autoscaler                                                          
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-coredns-rke2-coredns-autoscaler                                
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns-autoscaler                                                                             
2654       Disabled           Disabled          4          reserved:health                                                                       10.55.3.209   ready   
2722       Disabled           Disabled          16381      k8s:app.kubernetes.io/name=hubble-ui                                                  10.55.3.129   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-ui                                                                                       
2992       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=rke2                                                           ready   
                                                           reserved:host                                                                                               
3073       Enabled            Disabled          29762      k8s:app.kubernetes.io/component=repo-server                                           10.55.3.23    ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-repo-server                                                               
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.2.5                                                                        
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-repo-server                                             
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
3150       Enabled            Disabled          14678      k8s:app.kubernetes.io/component=dex-server                                            10.55.3.19    ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-dex-server                                                                
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.30.0                                                                       
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=argocd-dex-server                                                   
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
3677       Disabled           Disabled          2139       k8s:app.kubernetes.io/name=hubble-relay                                               10.55.3.167   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                        
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-relay                                                                                    
3706       Enabled            Disabled          29762      k8s:app.kubernetes.io/component=repo-server                                           10.55.3.50    ready   
                                                           k8s:app.kubernetes.io/instance=rke2-argocd                                                                  
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=argocd-repo-server                                                               
                                                           k8s:app.kubernetes.io/part-of=argocd                                                                        
                                                           k8s:app.kubernetes.io/version=v2.2.5                                                                        
                                                           k8s:helm.sh/chart=argo-cd-3.35.4                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd                                       
                                                           k8s:io.cilium.k8s.namespace.labels.name=argocd                                                              
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-repo-server                                             
                                                           k8s:io.kubernetes.pod.namespace=argocd                                                                      
3811       Disabled           Disabled          1344       k8s:app.kubernetes.io/component=controller                                            10.55.3.164   ready   
                                                           k8s:app.kubernetes.io/instance=rke2-origin-ca-issuer                                                        
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=origin-ca-issuer                                                                 
                                                           k8s:helm.sh/chart=origin-ca-issuer-0.1.0                                                                    
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-origin-ca-issuer                                               
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
3979       Disabled           Disabled          1111       k8s:app.kubernetes.io/instance=rke2-snapshot-controller                               10.55.3.12    ready   
                                                           k8s:app.kubernetes.io/name=rke2-snapshot-controller                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-controller                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
```

#### BPF Policy Get 709

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1494968    16643     0        
Allow    Ingress     1          ANY          NONE         disabled    3461448    39562     0        
Allow    Egress      0          ANY          NONE         disabled    46228580   628811    0        

```


#### BPF CT List 709

```
Invalid argument: unknown type 709
```


#### Endpoint Get 709

```
[
  {
    "id": 709,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-709-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "94ac75ac-5b24-46a7-8369-69dccc6817dd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-709",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:27.919Z",
            "success-count": 38
          },
          "uuid": "d5a02b8d-6e6b-426a-942e-303837ee9401"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:27.893Z",
            "success-count": 1
          },
          "uuid": "7bc55b54-c952-4cc4-b258-e7daccf35d47"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-709",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:27.952Z",
            "success-count": 13
          },
          "uuid": "37c86f4b-0160-45e8-9eff-dadca3ebbb46"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (709)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:08.951Z",
            "success-count": 1116
          },
          "uuid": "e39737c6-8c35-49dd-b7b3-34dc388e4808"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "6c6742e16d494dcf88362a1e94335021cd6ff3856160f1d27864fd6b81450f82:eth0",
        "container-id": "6c6742e16d494dcf88362a1e94335021cd6ff3856160f1d27864fd6b81450f82",
        "k8s-namespace": "argocd",
        "k8s-pod-name": "rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm",
        "pod-name": "argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 11758,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:release=rke2-argocd",
          "k8s:io.kubernetes.pod.namespace=argocd",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha-haproxy",
          "k8s:revision=1",
          "k8s:io.cilium.k8s.namespace.labels.name=argocd",
          "k8s:app=redis-ha-haproxy",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7548cbd54c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=redis-ha-haproxy",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd",
          "k8s:io.cilium.k8s.namespace.labels.name=argocd",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha-haproxy",
          "k8s:io.kubernetes.pod.namespace=argocd",
          "k8s:release=rke2-argocd",
          "k8s:revision=1"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics-port",
          "port": 9101,
          "protocol": "TCP"
        },
        {
          "name": "redis",
          "port": 6379,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.78",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a2:af:3e:f9:68:fc",
        "interface-index": 38,
        "interface-name": "lxc5ea93d8c6b49",
        "mac": "36:70:48:32:28:98"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11758,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11758,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 709

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 709

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:27Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 11758

```
ID      LABELS
11758   k8s:app=redis-ha-haproxy
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha-haproxy
        k8s:io.kubernetes.pod.namespace=argocd
        k8s:release=rke2-argocd
        k8s:revision=1

```


#### BPF Policy Get 924

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    2226109   17679     0        
Allow    Egress      0          ANY          NONE         disabled    74982     850       0        

```


#### BPF CT List 924

```
Invalid argument: unknown type 924
```


#### Endpoint Get 924

```
[
  {
    "id": 924,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-924-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7311786f-4c3f-4fd4-959c-473d0f8566c1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-924",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:31.124Z",
            "success-count": 38
          },
          "uuid": "51bb6735-cc45-45c9-8c2a-5ad396d798e0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:31.102Z",
            "success-count": 1
          },
          "uuid": "573e9ac5-c7ce-4e76-ad2d-19c08482ad2a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-924",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:31.367Z",
            "success-count": 13
          },
          "uuid": "4017b05c-65d1-4e25-86db-a9dddcbe5341"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (924)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:12.215Z",
            "success-count": 1116
          },
          "uuid": "fe7986be-b934-4051-9d07-9e5ba8b16661"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7150a121ae388a896b76c394f7141bf6b156ffa47c2bea56d59c924b71ee01b4:eth0",
        "container-id": "7150a121ae388a896b76c394f7141bf6b156ffa47c2bea56d59c924b71ee01b4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "rke2-snapshot-validation-webhook-54c5989b65-v2s9c",
        "pod-name": "kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 24197,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-validation-webhook",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app.kubernetes.io/instance=rke2-snapshot-validation-webhook",
          "k8s:app.kubernetes.io/name=rke2-snapshot-validation-webhook"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=54c5989b65"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=rke2-snapshot-validation-webhook",
          "k8s:app.kubernetes.io/name=rke2-snapshot-validation-webhook",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-validation-webhook",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 8443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.210",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:e2:45:31:f3:1e",
        "interface-index": 52,
        "interface-name": "lxcb4837a858eef",
        "mac": "a2:74:0c:79:19:9d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 24197,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 24197,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 924

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 924

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:31Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 24197

```
ID      LABELS
24197   k8s:app.kubernetes.io/instance=rke2-snapshot-validation-webhook
        k8s:app.kubernetes.io/name=rke2-snapshot-validation-webhook
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-validation-webhook
        k8s:io.kubernetes.pod.namespace=kube-system

```


#### BPF Policy Get 1192

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1788363   20048     0        
Allow    Ingress     1          ANY          NONE         disabled    3053955   27258     0        
Allow    Egress      0          ANY          NONE         disabled    1684847   15976     0        

```


#### BPF CT List 1192

```
Invalid argument: unknown type 1192
```


#### Endpoint Get 1192

```
[
  {
    "id": 1192,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1192-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a118b3d6-1528-46a9-905f-253da5174fe4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:29.993Z",
            "success-count": 38
          },
          "uuid": "a31c3b3b-2073-4bdc-97ec-003bf6740b79"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/rke2-metrics-server-655477f655-khcbm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:29.972Z",
            "success-count": 1
          },
          "uuid": "74d16092-0bfd-48c8-8eaa-77270cd4b97c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:30.033Z",
            "success-count": 13
          },
          "uuid": "3bfcecff-759c-4688-a615-fe04a8e3ecdf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1192)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:11.290Z",
            "success-count": 1116
          },
          "uuid": "19713303-c4d8-47bb-8197-04fba77245f3"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7d4004af23744bfcc8bce4ad092039a2a19cee5e7c120e2daa3d8e1fbda21c73:eth0",
        "container-id": "7d4004af23744bfcc8bce4ad092039a2a19cee5e7c120e2daa3d8e1fbda21c73",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "rke2-metrics-server-655477f655-khcbm",
        "pod-name": "kube-system/rke2-metrics-server-655477f655-khcbm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 16822,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-metrics-server",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app=rke2-metrics-server",
          "k8s:app.kubernetes.io/instance=rke2-metrics-server",
          "k8s:app.kubernetes.io/name=rke2-metrics-server"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=655477f655"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=rke2-metrics-server",
          "k8s:app.kubernetes.io/name=rke2-metrics-server",
          "k8s:app=rke2-metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.27",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:ff:4c:46:0e:5f",
        "interface-index": 48,
        "interface-name": "lxc04551b4a009f",
        "mac": "be:e9:ca:9a:59:a7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16822,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16822,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1192

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1192

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:29Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 16822

```
ID      LABELS
16822   k8s:app.kubernetes.io/instance=rke2-metrics-server
        k8s:app.kubernetes.io/name=rke2-metrics-server
        k8s:app=rke2-metrics-server
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-metrics-server
        k8s:io.kubernetes.pod.namespace=kube-system

```


#### BPF Policy Get 1202

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    70284584   921345    0        
Allow    Ingress     1          ANY          NONE         disabled    1054090    13471     0        
Allow    Egress      0          ANY          NONE         disabled    16594670   195325    0        

```


#### BPF CT List 1202

```
Invalid argument: unknown type 1202
```


#### Endpoint Get 1202

```
[
  {
    "id": 1202,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1202-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2d83dc46-1375-48fb-a76a-f9a5c3e88f19"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1202",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:28.519Z",
            "success-count": 38
          },
          "uuid": "2240fc52-8600-4dab-b95b-cb5c9186b4e1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-argocd/rke2-argocd-redis-ha-server-0",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:28.497Z",
            "success-count": 1
          },
          "uuid": "584b14c8-dbe7-4f9e-bcac-0f6d86b931a7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1202",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:28.586Z",
            "success-count": 13
          },
          "uuid": "3be9f793-4981-425d-8615-783ce9a2c6da"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1202)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:09.485Z",
            "success-count": 1116
          },
          "uuid": "494d8097-07a8-4ede-9476-e02f44bb7e70"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9df8b44d7d27ec373dff4568fd343b50f3d3db193ee7a82e4a6d0f4210fd5b6e:eth0",
        "container-id": "9df8b44d7d27ec373dff4568fd343b50f3d3db193ee7a82e4a6d0f4210fd5b6e",
        "k8s-namespace": "argocd",
        "k8s-pod-name": "rke2-argocd-redis-ha-server-0",
        "pod-name": "argocd/rke2-argocd-redis-ha-server-0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 10448,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha",
          "k8s:rke2-argocd-redis-ha=replica",
          "k8s:release=rke2-argocd",
          "k8s:app=redis-ha",
          "k8s:io.cilium.k8s.namespace.labels.name=argocd",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd",
          "k8s:io.kubernetes.pod.namespace=argocd"
        ]
      },
      "labels": {
        "derived": [
          "k8s:apps.kubernetes.io/pod-index=0",
          "k8s:controller-revision-hash=rke2-argocd-redis-ha-server-56b9f65b9d",
          "k8s:statefulset.kubernetes.io/pod-name=rke2-argocd-redis-ha-server-0"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=redis-ha",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd",
          "k8s:io.cilium.k8s.namespace.labels.name=argocd",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha",
          "k8s:io.kubernetes.pod.namespace=argocd",
          "k8s:release=rke2-argocd",
          "k8s:rke2-argocd-redis-ha=replica"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "exporter-port",
          "port": 9121,
          "protocol": "TCP"
        },
        {
          "name": "redis",
          "port": 6379,
          "protocol": "TCP"
        },
        {
          "name": "sentinel",
          "port": 26379,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.253",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:59:79:19:51:2a",
        "interface-index": 44,
        "interface-name": "lxc5ec43035a653",
        "mac": "0e:d3:a3:2b:79:e9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10448,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10448,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1202

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1202

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:28Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 10448

```
ID      LABELS
10448   k8s:app=redis-ha
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-redis-ha
        k8s:io.kubernetes.pod.namespace=argocd
        k8s:release=rke2-argocd
        k8s:rke2-argocd-redis-ha=replica

```


#### BPF Policy Get 1301

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    820542   10363     0        
Allow    Ingress     1111       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     1344       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     2139       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     3394       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     3859       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     9426       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     10448      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     11758      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     13815      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     14678      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     15581      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     16381      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     16822      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     21496      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     24197      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     29667      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     29762      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     30951      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     50180      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     50725      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     53865      8082/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    577336   3738      0        

```


#### BPF CT List 1301

```
Invalid argument: unknown type 1301
```


#### Endpoint Get 1301

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{},MatchExpressions:[]LabelSelectorRequirement{LabelSelectorRequirement{Key:k8s.io.kubernetes.pod.namespace,Operator:Exists,Values:[],},},}
)

```


#### Endpoint Health 1301

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1301

```
Timestamp              Status    State                   Message
2024-07-20T16:08:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:27Z   OK        ready                   Set identity for this endpoint
2024-07-20T14:38:27Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 30951

```
ID      LABELS
30951   k8s:app.kubernetes.io/component=application-controller
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-application-controller
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.2.5
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=argocd-application-controller
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 1812

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    3336882   29525     0        
Allow    Egress      0          ANY          NONE         disabled    720565    9400      0        

```


#### BPF CT List 1812

```
Invalid argument: unknown type 1812
```


#### Endpoint Get 1812

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{},MatchExpressions:[]LabelSelectorRequirement{},}
)

```


#### Endpoint Health 1812

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1812

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:28Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 33708

```
ID      LABELS
33708   k8s:app.kubernetes.io/component=server
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-server
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.2.5
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=argocd-server
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 2033

```
Error: Failed to open map: loading pinned map /sys/fs/bpf/tc/globals/cilium_policy_02033: no such file or directory


```


#### BPF CT List 2033

```
Invalid argument: unknown type 2033
```


#### Endpoint Get 2033

```
[
  {
    "id": 2033,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2033-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d0974c2c-298b-4a09-abc3-e9bfc59f2eb6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2033",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:41:57.103Z",
            "success-count": 39
          },
          "uuid": "3fa32909-3ed7-406c-b862-457100239fde"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 8,
        "labels": [
          "reserved:ingress"
        ]
      },
      "labels": {
        "derived": [
          "reserved:ingress"
        ],
        "realized": {},
        "security-relevant": [
          "reserved:ingress"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.251"
          }
        ]
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2033

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2033

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:46Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:31:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:31:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:31:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:31:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:31:57Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:31:57Z   OK       waiting-for-identity    Ingress Endpoint creation

```


#### Identity get 8

```
ID   LABELS
8    reserved:ingress

```


#### BPF Policy Get 2117

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    3340158   29543     0        
Allow    Egress      0          ANY          NONE         disabled    725548    9389      0        

```


#### BPF CT List 2117

```
Invalid argument: unknown type 2117
```


#### Endpoint Get 2117

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{},MatchExpressions:[]LabelSelectorRequirement{},}
)

```


#### Endpoint Health 2117

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2117

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:28Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 33708

```
ID      LABELS
33708   k8s:app.kubernetes.io/component=server
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-server
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.2.5
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=argocd-server
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 2507

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    186636   2152      0        
Allow    Egress      0          ANY          NONE         disabled    535386   6218      0        

```


#### BPF CT List 2507

```
Invalid argument: unknown type 2507
```


#### Endpoint Get 2507

```
[
  {
    "id": 2507,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2507-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c606ecce-007b-42d2-9cef-eda788d5d283"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2507",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:42:42.411Z",
            "success-count": 39
          },
          "uuid": "f28f8169-6b5f-4e0a-a7ea-64c3358bc66b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:32:42.388Z",
            "success-count": 1
          },
          "uuid": "1d0ba258-973d-4829-b7e1-d67bc58e8b24"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2507",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:32:42.455Z",
            "success-count": 13
          },
          "uuid": "ce66da1e-9e77-430e-9c96-fc63d29bdcde"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2507)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:13.358Z",
            "success-count": 1151
          },
          "uuid": "28adb1b9-02b6-47c9-8691-58408a900500"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "72187057a8aac71a6b2a828454cfd39b8adc480b1ef2f2e3f18760996bfb2404:eth0",
        "container-id": "72187057a8aac71a6b2a828454cfd39b8adc480b1ef2f2e3f18760996bfb2404",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c",
        "pod-name": "kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 50180,
        "labels": [
          "k8s:app.kubernetes.io/instance=rke2-coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-coredns-rke2-coredns-autoscaler",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app.kubernetes.io/name=rke2-coredns-autoscaler",
          "k8s:k8s-app=kube-dns-autoscaler"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=b49765765"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=rke2-coredns",
          "k8s:app.kubernetes.io/name=rke2-coredns-autoscaler",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-coredns-rke2-coredns-autoscaler",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns-autoscaler"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.218",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8e:fc:c5:3b:ea:dd",
        "interface-index": 18,
        "interface-name": "lxc1896987652ee",
        "mac": "02:64:8a:ad:4f:02"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 50180,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 50180,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2507

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2507

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:32:42Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:32:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 50180

```
ID      LABELS
50180   k8s:app.kubernetes.io/instance=rke2-coredns
        k8s:app.kubernetes.io/name=rke2-coredns-autoscaler
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-coredns-rke2-coredns-autoscaler
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns-autoscaler

```


#### BPF Policy Get 2654

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    523548   6582      0        
Allow    Ingress     1          ANY          NONE         disabled    152996   1742      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2654

```
Invalid argument: unknown type 2654
```


#### Endpoint Get 2654

```
[
  {
    "id": 2654,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2654-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "72e571ae-76d0-415e-a556-1da4567f2367"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2654",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:41:58.170Z",
            "success-count": 39
          },
          "uuid": "f7c994d8-1a08-41c4-9b8f-6afc7c02d449"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2654",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:32:00.193Z",
            "success-count": 13
          },
          "uuid": "c4840deb-a55a-4baf-bdd5-ed51b36aaedc"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.209",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "fe:74:6f:d6:76:42",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "ba:88:a8:d1:59:ac"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2654

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2654

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:46Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:32:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:31:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:31:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:31:58Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:31:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2722

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1108090   13016     0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 2722

```
Invalid argument: unknown type 2722
```


#### Endpoint Get 2722

```
[
  {
    "id": 2722,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2722-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0dbfc034-6ec0-41e5-ac63-0e2f9e90c2d5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2722",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:42:43.838Z",
            "success-count": 39
          },
          "uuid": "c3786b71-4ad9-435b-9516-a87958c213d3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-ui-6969854c48-vkb2p",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:32:43.815Z",
            "success-count": 1
          },
          "uuid": "46424f8b-ecd7-4ee4-b17d-60ca9bd7d723"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2722",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:32:43.875Z",
            "success-count": 13
          },
          "uuid": "e16ad728-a7ad-405e-aa16-fe603b357f12"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2722)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:14.747Z",
            "success-count": 1151
          },
          "uuid": "6f6a8ef6-2bf3-48fc-b36f-d702157d1bfc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c27319099549875b891b534c5faf1562ae6288660a14f03511a3879567b422c2:eth0",
        "container-id": "c27319099549875b891b534c5faf1562ae6288660a14f03511a3879567b422c2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-ui-6969854c48-vkb2p",
        "pod-name": "kube-system/hubble-ui-6969854c48-vkb2p"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 16381,
        "labels": [
          "k8s:k8s-app=hubble-ui",
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app.kubernetes.io/part-of=cilium"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6969854c48"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.129",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:8f:b6:3a:2c:90",
        "interface-index": 28,
        "interface-name": "lxc997092fbbf0c",
        "mac": "5a:db:08:4b:fa:e4"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16381,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16381,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2722

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2722

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:46Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:32:43Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:32:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 16381

```
ID      LABELS
16381   k8s:app.kubernetes.io/name=hubble-ui
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 2992

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2992

```
Invalid argument: unknown type 2992
```


#### Endpoint Get 2992

```
[
  {
    "id": 2992,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2992-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4bd94572-fdc9-4575-82fd-639a3b5f5a29"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2992",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:41:57.091Z",
            "success-count": 39
          },
          "uuid": "6027751e-e4cb-48be-9e46-a83ae6903ece"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2992",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:31:59.193Z",
            "success-count": 13
          },
          "uuid": "b3a9e3c0-7e81-4864-962b-8b02c2853dd2"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "e6:21:a4:fc:b9:c8",
        "interface-name": "cilium_host",
        "mac": "e6:21:a4:fc:b9:c8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2992

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2992

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:46Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:31:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:31:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:31:57Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:31:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3073

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    588608   8656      0        
Allow    Ingress     30951      8081/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8081/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3073

```
Invalid argument: unknown type 3073
```


#### Endpoint Get 3073

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{k8s.app.kubernetes.io/instance: rke2-argocd,k8s.app.kubernetes.io/name: argocd-application-controller,k8s.io.kubernetes.pod.namespace: argocd,},MatchExpressions:[]LabelSelectorRequirement{},}
)

```


#### Endpoint Health 3073

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3073

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:28Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29762

```
ID      LABELS
29762   k8s:app.kubernetes.io/component=repo-server
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-repo-server
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.2.5
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-repo-server
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 3150

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Ingress     33708      5556/TCP     NONE         disabled    0       0         24       
Allow    Ingress     33708      5557/TCP     NONE         disabled    0       0         24       
Allow    Egress      0          ANY          NONE         disabled    84429   979       0        

```


#### BPF CT List 3150

```
Invalid argument: unknown type 3150
```


#### Endpoint Get 3150

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{k8s.app.kubernetes.io/instance: rke2-argocd,k8s.app.kubernetes.io/name: argocd-server,k8s.io.kubernetes.pod.namespace: argocd,},MatchExpressions:[]LabelSelectorRequirement{},}
)

```


#### Endpoint Health 3150

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3150

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:26Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 14678

```
ID      LABELS
14678   k8s:app.kubernetes.io/component=dex-server
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-dex-server
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.30.0
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=argocd-dex-server
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 3677

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1960696   21609     0        
Allow    Egress      0          ANY          NONE         disabled    112432    1519      0        

```


#### BPF CT List 3677

```
Invalid argument: unknown type 3677
```


#### Endpoint Get 3677

```
[
  {
    "id": 3677,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3677-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f2534462-fe90-4a1b-8461-6c3c21f3d303"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3677",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:42:40.840Z",
            "success-count": 39
          },
          "uuid": "323baf30-2f7f-4afe-8e94-d4f9195a45ac"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-relay-6f89c7f794-xdxwj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:32:40.815Z",
            "success-count": 1
          },
          "uuid": "468c7ddc-e599-4eaa-b810-f8aa2d417918"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3677",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:32:40.892Z",
            "success-count": 13
          },
          "uuid": "ff7a2fce-a09e-4eb2-86a1-2b44dbddfc4f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3677)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:21.769Z",
            "success-count": 1152
          },
          "uuid": "12c11aae-1e51-47c1-b3ee-a49f9ba60434"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b3b1d206b9baae51ea6e81e4d62d765070bb1fc0768544b155ac569424bdaf3b:eth0",
        "container-id": "b3b1d206b9baae51ea6e81e4d62d765070bb1fc0768544b155ac569424bdaf3b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-relay-6f89c7f794-xdxwj",
        "pod-name": "kube-system/hubble-relay-6f89c7f794-xdxwj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2139,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:k8s-app=hubble-relay",
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6f89c7f794"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.167",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:1b:89:fe:06:bc",
        "interface-index": 14,
        "interface-name": "lxc61049c152f38",
        "mac": "d6:1f:bc:9d:3a:35"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2139,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2139,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3677

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3677

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:32:40Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:32:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2139

```
ID     LABELS
2139   k8s:app.kubernetes.io/name=hubble-relay
       k8s:app.kubernetes.io/part-of=cilium
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=hetzner
       k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
       k8s:io.kubernetes.pod.namespace=kube-system
       k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 3706

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    589152   8664      0        
Allow    Ingress     30951      8081/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8081/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3706

```
Invalid argument: unknown type 3706
```


#### Endpoint Get 3706

```
Error: Failed to decode nested JSON: invalid character 'M' looking for beginning of object key string (
{MatchLabels:map[string]string{k8s.app.kubernetes.io/instance: rke2-argocd,k8s.app.kubernetes.io/name: argocd-application-controller,k8s.io.kubernetes.pod.namespace: argocd,},MatchExpressions:[]LabelSelectorRequirement{},}
)

```


#### Endpoint Health 3706

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3706

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:27Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29762

```
ID      LABELS
29762   k8s:app.kubernetes.io/component=repo-server
        k8s:app.kubernetes.io/instance=rke2-argocd
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=argocd-repo-server
        k8s:app.kubernetes.io/part-of=argocd
        k8s:app.kubernetes.io/version=v2.2.5
        k8s:helm.sh/chart=argo-cd-3.35.4
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=argocd
        k8s:io.cilium.k8s.namespace.labels.name=argocd
        k8s:io.cilium.k8s.policy.cluster=hetzner
        k8s:io.cilium.k8s.policy.serviceaccount=rke2-argocd-repo-server
        k8s:io.kubernetes.pod.namespace=argocd

```


#### BPF Policy Get 3811

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    77941   905       0        

```


#### BPF CT List 3811

```
Invalid argument: unknown type 3811
```


#### Endpoint Get 3811

```
[
  {
    "id": 3811,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3811-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0227892b-8456-4829-a34a-c1621128d352"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3811",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:30.301Z",
            "success-count": 38
          },
          "uuid": "b794978e-2f5a-45e3-94c3-46e8b0948e34"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:30.278Z",
            "success-count": 1
          },
          "uuid": "8efe4f71-a2bc-4da8-b4fe-a6814b5fec2f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3811",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:30.391Z",
            "success-count": 13
          },
          "uuid": "429607f7-d74a-48dc-89e7-0010322e0953"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3811)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:21.241Z",
            "success-count": 1117
          },
          "uuid": "5a034d9c-f4a0-4564-b303-14c8d9a21b43"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b2003f4fbeb8ca01a5b664cbd3c000ab184bb416437969edb1f40fd699cf3801:eth0",
        "container-id": "b2003f4fbeb8ca01a5b664cbd3c000ab184bb416437969edb1f40fd699cf3801",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "rke2-origin-ca-issuer-7bd586658-pmrc8",
        "pod-name": "cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1344,
        "labels": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-origin-ca-issuer",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:app.kubernetes.io/instance=rke2-origin-ca-issuer",
          "k8s:helm.sh/chart=origin-ca-issuer-0.1.0",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:app.kubernetes.io/name=origin-ca-issuer",
          "k8s:io.cilium.k8s.policy.cluster=hetzner"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7bd586658"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=rke2-origin-ca-issuer",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=origin-ca-issuer",
          "k8s:helm.sh/chart=origin-ca-issuer-0.1.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-origin-ca-issuer",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.164",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d2:ca:a3:a8:b3:9a",
        "interface-index": 50,
        "interface-name": "lxca88df1e13933",
        "mac": "4a:a3:99:a6:77:10"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1344,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1344,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3811

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3811

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:30Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:38:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1344

```
ID     LABELS
1344   k8s:app.kubernetes.io/component=controller
       k8s:app.kubernetes.io/instance=rke2-origin-ca-issuer
       k8s:app.kubernetes.io/managed-by=Helm
       k8s:app.kubernetes.io/name=origin-ca-issuer
       k8s:helm.sh/chart=origin-ca-issuer-0.1.0
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
       k8s:io.cilium.k8s.namespace.labels.name=cert-manager
       k8s:io.cilium.k8s.policy.cluster=hetzner
       k8s:io.cilium.k8s.policy.serviceaccount=rke2-origin-ca-issuer
       k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 3979

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    2734627   12705     0        

```


#### BPF CT List 3979

```
Invalid argument: unknown type 3979
```


#### Endpoint Get 3979

```
[
  {
    "id": 3979,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3979-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "058337da-00eb-468a-8eb9-8c37e6a40c9d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3979",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:43:50.349Z",
            "success-count": 38
          },
          "uuid": "7cfb7d6d-4723-4819-af18-f8a2ce0e7647"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:38:50.325Z",
            "success-count": 1
          },
          "uuid": "8574b618-ba7b-4e6d-9771-ae7f36b5119d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3979",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:38:50.424Z",
            "success-count": 13
          },
          "uuid": "dca333d2-b79a-4c1d-83ff-65fa2d51274f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3979)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:21.187Z",
            "success-count": 1115
          },
          "uuid": "184ff16e-6e5e-45f8-8707-dc8db21c5056"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "62f384d55d1a29489cd62b7154fb13b3f275852d6b3cce6fbd65de4938bb3fb2:eth0",
        "container-id": "62f384d55d1a29489cd62b7154fb13b3f275852d6b3cce6fbd65de4938bb3fb2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "rke2-snapshot-controller-59cc9cd8f4-s4vrs",
        "pod-name": "kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1111,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-controller",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app.kubernetes.io/instance=rke2-snapshot-controller",
          "k8s:app.kubernetes.io/name=rke2-snapshot-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=59cc9cd8f4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=rke2-snapshot-controller",
          "k8s:app.kubernetes.io/name=rke2-snapshot-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-controller",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.3.12",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ce:2c:8f:ce:a3:27",
        "interface-index": 62,
        "interface-name": "lxc06aae3131e3b",
        "mac": "9e:c2:06:8b:4b:c0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1111,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1111,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3979

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3979

```
Timestamp              Status    State                   Message
2024-07-20T16:08:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:38:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:38:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:38:50Z   OK        ready                   Set identity for this endpoint
2024-07-20T14:38:50Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1111

```
ID     LABELS
1111   k8s:app.kubernetes.io/instance=rke2-snapshot-controller
       k8s:app.kubernetes.io/name=rke2-snapshot-controller
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=hetzner
       k8s:io.cilium.k8s.policy.serviceaccount=rke2-snapshot-controller
       k8s:io.kubernetes.pod.namespace=kube-system

```


#### Service list

```
ID   Frontend              Service Type   Backend                           
1    10.65.0.1:443         ClusterIP      1 => 10.22.20.12:6443 (active)    
                                          2 => 10.22.20.13:6443 (active)    
                                          3 => 10.22.20.11:6443 (active)    
2    10.65.253.13:443      ClusterIP      1 => 10.22.30.21:4244 (active)    
3    10.65.203.48:80       ClusterIP      1 => 10.55.3.167:4245 (active)    
4    10.65.97.59:80        ClusterIP      1 => 10.55.3.129:8081 (active)    
5    10.65.0.10:53         ClusterIP      1 => 10.55.0.129:53 (active)      
                                          2 => 10.55.2.204:53 (active)      
6    10.65.180.197:9101    ClusterIP      1 => 10.55.3.78:9101 (active)     
                                          2 => 10.55.4.213:9101 (active)    
                                          3 => 10.55.5.149:9101 (active)    
7    10.65.180.197:6379    ClusterIP      1 => 10.55.3.78:6379 (active)     
                                          2 => 10.55.4.213:6379 (active)    
                                          3 => 10.55.5.149:6379 (active)    
8    10.65.145.33:5556     ClusterIP      1 => 10.55.3.19:5556 (active)     
9    10.65.145.33:5557     ClusterIP      1 => 10.55.3.19:5557 (active)     
10   10.65.115.248:8082    ClusterIP      1 => 10.55.3.252:8082 (active)    
11   10.65.192.200:8081    ClusterIP      1 => 10.55.3.50:8081 (active)     
                                          2 => 10.55.3.23:8081 (active)     
12   10.65.243.160:6379    ClusterIP      1 => 10.55.4.218:6379 (active)    
13   10.65.243.160:26379   ClusterIP      1 => 10.55.4.218:26379 (active)   
14   10.65.243.160:9121    ClusterIP      1 => 10.55.4.218:9121 (active)    
15   10.65.148.50:443      ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
16   10.65.148.50:80       ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
17   10.65.70.170:9121     ClusterIP      1 => 10.55.5.155:9121 (active)    
18   10.65.70.170:6379     ClusterIP      1 => 10.55.5.155:6379 (active)    
19   10.65.70.170:26379    ClusterIP      1 => 10.55.5.155:26379 (active)   
20   10.65.178.184:26379   ClusterIP      1 => 10.55.3.253:26379 (active)   
21   10.65.178.184:9121    ClusterIP      1 => 10.55.3.253:9121 (active)    
22   10.65.178.184:6379    ClusterIP      1 => 10.55.3.253:6379 (active)    
23   10.65.51.64:443       ClusterIP      1 => 10.55.3.210:8443 (active)    
24   10.65.48.249:443      ClusterIP      1 => 10.55.3.27:10250 (active)    
27   10.65.213.42:9402     ClusterIP      1 => 10.55.4.152:9402 (active)    
28   10.65.174.214:443     ClusterIP      1 => 10.55.4.211:10250 (active)   
29   10.65.155.14:8080     ClusterIP      1 => 10.55.5.129:8080 (active)    
30   10.22.20.21:32495     NodePort       1 => 10.55.5.129:8080 (active)    
31   10.22.30.21:32495     NodePort       1 => 10.55.5.129:8080 (active)    
32   0.0.0.0:32495         NodePort       1 => 10.55.5.129:8080 (active)    
33   10.65.26.204:8080     ClusterIP      1 => 10.55.4.112:8080 (active)    
34   10.22.20.21:30568     NodePort       1 => 10.55.4.112:8080 (active)    
35   10.22.30.21:30568     NodePort       1 => 10.55.4.112:8080 (active)    
36   0.0.0.0:30568         NodePort       1 => 10.55.4.112:8080 (active)    
```

#### Policy get

```
:
 [
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-dex-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "http",
                "protocol": "TCP"
              }
            ]
          },
          {
            "ports": [
              {
                "port": "grpc",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-dex-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "0ca9b40f-9a3f-4ecd-bb56-154eebd0bf62",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-repo-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      },
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-application-controller",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-repo-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "44e84fdf-5ef5-4516-8cf8-2e5e1e3f3523",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-application-controller",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchExpressions": [
              {
                "key": "k8s:io.kubernetes.pod.namespace",
                "operator": "Exists"
              }
            ]
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "controller",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-application-controller",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d14d3df5-1c32-43ce-9f4b-9fd13f1cacf6",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {}
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d6baf548-03ff-49f8-93db-5f25fa513dc6",
        "source": "k8s"
      }
    ]
  }
]
Revision: 233

```


#### Cilium encryption



#### Kernel version

```
6.8.12
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [private   10.22.30.21 fe80::5054:ff:fe86:13c3 (Direct Routing), public   10.22.20.21 fe80::5054:ff:fea6:3e20]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 18/254 allocated from 10.55.3.0/24, 
Allocated addresses:
  10.55.3.12 (kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs)
  10.55.3.129 (kube-system/hubble-ui-6969854c48-vkb2p)
  10.55.3.164 (cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8)
  10.55.3.167 (kube-system/hubble-relay-6f89c7f794-xdxwj)
  10.55.3.19 (argocd/rke2-argocd-dex-server-76bb6677d7-8rntq)
  10.55.3.206 (router)
  10.55.3.209 (health)
  10.55.3.210 (kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c)
  10.55.3.218 (kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c)
  10.55.3.23 (argocd/rke2-argocd-repo-server-7bf6499cb6-jh2wl)
  10.55.3.251 (ingress)
  10.55.3.252 (argocd/rke2-argocd-application-controller-654f4c59bd-m5tpw)
  10.55.3.253 (argocd/rke2-argocd-redis-ha-server-0)
  10.55.3.27 (kube-system/rke2-metrics-server-655477f655-khcbm)
  10.55.3.50 (argocd/rke2-argocd-repo-server-7bf6499cb6-lpnlc)
  10.55.3.60 (argocd/rke2-argocd-server-b55ff85f8-26zmv)
  10.55.3.78 (argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm)
  10.55.3.90 (argocd/rke2-argocd-server-b55ff85f8-fmtn7)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [private, public]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [private, public]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      96/96 healthy
  Name                                                                              Last success   Last error     Count   Message
  cilium-health-ep                                                                  25s ago        never          0       no error   
  dns-garbage-collector-job                                                         27s ago        never          0       no error   
  endpoint-1192-regeneration-recovery                                               never          never          0       no error   
  endpoint-1202-regeneration-recovery                                               never          never          0       no error   
  endpoint-1301-regeneration-recovery                                               never          never          0       no error   
  endpoint-1812-regeneration-recovery                                               never          never          0       no error   
  endpoint-2033-regeneration-recovery                                               never          never          0       no error   
  endpoint-2117-regeneration-recovery                                               never          never          0       no error   
  endpoint-2507-regeneration-recovery                                               never          never          0       no error   
  endpoint-2654-regeneration-recovery                                               never          never          0       no error   
  endpoint-2722-regeneration-recovery                                               never          never          0       no error   
  endpoint-2992-regeneration-recovery                                               never          never          0       no error   
  endpoint-3073-regeneration-recovery                                               never          never          0       no error   
  endpoint-3150-regeneration-recovery                                               never          never          0       no error   
  endpoint-3677-regeneration-recovery                                               never          never          0       no error   
  endpoint-3706-regeneration-recovery                                               never          never          0       no error   
  endpoint-3811-regeneration-recovery                                               never          never          0       no error   
  endpoint-3979-regeneration-recovery                                               never          never          0       no error   
  endpoint-709-regeneration-recovery                                                never          never          0       no error   
  endpoint-924-regeneration-recovery                                                never          never          0       no error   
  endpoint-gc                                                                       2m27s ago      never          0       no error   
  ep-bpf-prog-watchdog                                                              25s ago        never          0       no error   
  ipcache-inject-labels                                                             26s ago        3h12m27s ago   0       no error   
  k8s-heartbeat                                                                     24s ago        never          0       no error   
  link-cache                                                                        10s ago        never          0       no error   
  resolve-identity-1192                                                             53s ago        never          0       no error   
  resolve-identity-1202                                                             55s ago        never          0       no error   
  resolve-identity-1301                                                             56s ago        never          0       no error   
  resolve-identity-1812                                                             55s ago        never          0       no error   
  resolve-identity-2033                                                             2m26s ago      never          0       no error   
  resolve-identity-2117                                                             55s ago        never          0       no error   
  resolve-identity-2507                                                             1m41s ago      never          0       no error   
  resolve-identity-2654                                                             2m25s ago      never          0       no error   
  resolve-identity-2722                                                             1m39s ago      never          0       no error   
  resolve-identity-2992                                                             2m26s ago      never          0       no error   
  resolve-identity-3073                                                             54s ago        never          0       no error   
  resolve-identity-3150                                                             57s ago        never          0       no error   
  resolve-identity-3677                                                             1m42s ago      never          0       no error   
  resolve-identity-3706                                                             55s ago        never          0       no error   
  resolve-identity-3811                                                             53s ago        never          0       no error   
  resolve-identity-3979                                                             33s ago        never          0       no error   
  resolve-identity-709                                                              55s ago        never          0       no error   
  resolve-identity-924                                                              52s ago        never          0       no error   
  resolve-labels-argocd/rke2-argocd-application-controller-654f4c59bd-m5tpw         3h5m56s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-dex-server-76bb6677d7-8rntq                     3h5m57s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm               3h5m55s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-redis-ha-server-0                               3h5m55s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-repo-server-7bf6499cb6-jh2wl                    3h5m54s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-repo-server-7bf6499cb6-lpnlc                    3h5m55s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-server-b55ff85f8-26zmv                          3h5m55s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-server-b55ff85f8-fmtn7                          3h5m55s ago    never          0       no error   
  resolve-labels-cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8                 3h5m53s ago    never          0       no error   
  resolve-labels-kube-system/hubble-relay-6f89c7f794-xdxwj                          3h11m42s ago   never          0       no error   
  resolve-labels-kube-system/hubble-ui-6969854c48-vkb2p                             3h11m39s ago   never          0       no error   
  resolve-labels-kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c   3h11m41s ago   never          0       no error   
  resolve-labels-kube-system/rke2-metrics-server-655477f655-khcbm                   3h5m53s ago    never          0       no error   
  resolve-labels-kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs              3h5m33s ago    never          0       no error   
  resolve-labels-kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c      3h5m52s ago    never          0       no error   
  sync-host-ips                                                                     26s ago        never          0       no error   
  sync-lb-maps-with-k8s-services                                                    3h12m26s ago   never          0       no error   
  sync-policymap-1192                                                               5m53s ago      never          0       no error   
  sync-policymap-1202                                                               5m55s ago      never          0       no error   
  sync-policymap-1301                                                               5m56s ago      never          0       no error   
  sync-policymap-1812                                                               5m55s ago      never          0       no error   
  sync-policymap-2117                                                               5m55s ago      never          0       no error   
  sync-policymap-2507                                                               11m41s ago     never          0       no error   
  sync-policymap-2654                                                               12m23s ago     never          0       no error   
  sync-policymap-2722                                                               11m39s ago     never          0       no error   
  sync-policymap-2992                                                               12m24s ago     never          0       no error   
  sync-policymap-3073                                                               5m54s ago      never          0       no error   
  sync-policymap-3150                                                               5m57s ago      never          0       no error   
  sync-policymap-3677                                                               11m42s ago     never          0       no error   
  sync-policymap-3706                                                               5m55s ago      never          0       no error   
  sync-policymap-3811                                                               5m53s ago      never          0       no error   
  sync-policymap-3979                                                               5m33s ago      never          0       no error   
  sync-policymap-709                                                                5m55s ago      never          0       no error   
  sync-policymap-924                                                                5m52s ago      never          0       no error   
  sync-to-k8s-ciliumendpoint (1192)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (1202)                                                 14s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (1301)                                                 15s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (1812)                                                 14s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (2117)                                                 14s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (2507)                                                 10s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (2722)                                                 18s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3073)                                                 13s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3150)                                                 16s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3677)                                                 11s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3706)                                                 15s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3811)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3979)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (709)                                                  14s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (924)                                                  11s ago        never          0       no error   
  sync-utime                                                                        26s ago        never          0       no error   
  template-dir-watcher                                                              never          never          0       no error   
  update-k8s-node-annotations                                                       3h12m27s ago   never          0       no error   
  write-cni-file                                                                    3h12m26s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.3.206, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 152.56   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                private   10.22.30.21 fe80::5054:ff:fe86:13c3 (Direct Routing), public   10.22.20.21 fe80::5054:ff:fea6:3e20
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
k8s-namespace:kube-system
agent-labels:
k8s-require-ipv6-pod-cidr:false
procfs:/host/proc
vtep-mask:
hubble-redact-kafka-apikey:false
enable-ipv4:true
fixed-identity-mapping:
devices:public private
k8s-client-qps:10
container-ip-local-reserved-ports:auto
enable-ipv4-fragment-tracking:true
enable-svc-source-range-check:true
hubble-monitor-events:
enable-tracing:false
local-router-ipv4:
bpf-ct-global-any-max:262144
service-no-backend-response:reject
preallocate-bpf-maps:false
endpoint-status:
enable-k8s-endpoint-slice:true
enable-srv6:false
ipv6-mcast-device:
kvstore-lease-ttl:15m0s
bpf-lb-external-clusterip:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
ipv6-native-routing-cidr:
enable-remote-node-identity:true
auto-create-cilium-node-resource:true
state-dir:/var/run/cilium
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
http-max-grpc-timeout:0
bpf-root:/sys/fs/bpf
kvstore:
mesh-auth-mutual-listener-port:0
use-cilium-internal-ip-for-ipsec:false
enable-ipv4-masquerade:true
dns-policy-unload-on-shutdown:false
cluster-id:0
proxy-connect-timeout:2
encrypt-interface:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipv6-pod-subnets:
endpoint-queue-size:25
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
allow-icmp-frag-needed:true
http-idle-timeout:0
hubble-export-file-max-backups:5
monitor-aggregation:medium
enable-k8s-api-discovery:false
datapath-mode:veth
tofqdns-enable-dns-compression:true
conntrack-gc-max-interval:0s
gateway-api-secrets-namespace:cilium-secrets
encryption-strict-mode-allow-remote-node-identities:false
bpf-ct-timeout-regular-tcp:2h13m20s
dnsproxy-concurrency-processing-grace-period:0s
cluster-name:hetzner
legacy-turn-off-k8s-event-handover:false
max-internal-timer-delay:0s
kvstore-periodic-sync:5m0s
enable-cilium-api-server-access:
enable-l2-announcements:false
enable-icmp-rules:true
bpf-ct-global-tcp-max:524288
dnsproxy-lock-timeout:500ms
bpf-node-map-max:16384
join-cluster:false
policy-trigger-interval:1s
cni-chaining-mode:portmap
dnsproxy-enable-transparent-mode:false
vtep-mac:
hubble-event-queue-size:0
enable-session-affinity:false
enable-well-known-identities:false
enable-l2-pod-announcements:false
enable-ipv6-masquerade:true
enable-local-redirect-policy:false
bpf-ct-timeout-service-tcp:2h13m20s
enable-runtime-device-detection:false
bpf-lb-sock:false
enable-encryption-strict-mode:false
proxy-prometheus-port:0
k8s-api-server:
kvstore-connectivity-timeout:2m0s
crd-wait-timeout:5m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-monitor:true
proxy-xff-num-trusted-hops-ingress:0
cni-exclusive:true
derive-masquerade-ip-addr-from-device:
k8s-sync-timeout:3m0s
socket-path:/var/run/cilium/cilium.sock
hubble-skip-unknown-cgroup-ids:true
bpf-neigh-global-max:524288
pprof:false
http-retry-timeout:0
prepend-iptables-chains:true
tofqdns-proxy-port:0
keep-config:false
enable-masquerade-to-route-source:false
config-dir:/tmp/cilium/config-map
proxy-gid:1337
auto-direct-node-routes:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-health-check-nodeport:true
tofqdns-pre-cache:
enable-xdp-prefilter:false
enable-ip-masq-agent:true
http-request-timeout:3600
bpf-lb-service-backend-map-max:0
enable-host-firewall:false
ipam-multi-pool-pre-allocation:
operator-api-serve-addr:127.0.0.1:9234
http-normalize-path:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
disable-endpoint-crd:false
local-router-ipv6:
vtep-cidr:
identity-gc-interval:15m0s
vlan-bpf-bypass:4000
enable-high-scale-ipcache:false
enable-host-port:false
direct-routing-device:private
kvstore-max-consecutive-quorum-errors:2
external-envoy-proxy:true
unmanaged-pod-watcher-interval:15
fqdn-regex-compile-lru-size:1024
mtu:0
mesh-auth-enabled:true
version:false
api-rate-limit:
bpf-lb-service-map-max:0
enable-wireguard:false
tofqdns-min-ttl:0
debug-verbose:
proxy-max-requests-per-connection:0
cluster-health-port:4240
enable-ipsec-key-watcher:true
enable-endpoint-routes:false
trace-payloadlen:128
metrics:
tofqdns-max-deferred-connection-deletes:10000
l2-announcements-renew-deadline:5s
hubble-redact-http-urlquery:false
routing-mode:native
enable-hubble:true
bpf-policy-map-full-reconciliation-interval:15m0s
pprof-address:localhost
enable-sctp:false
hubble-export-file-path:
conntrack-gc-interval:0s
bpf-auth-map-max:524288
policy-audit-mode:false
enable-k8s:true
bpf-lb-map-max:65536
ipv4-native-routing-cidr:10.22.30.0/24
hubble-export-file-compress:false
agent-liveness-update-interval:1s
enable-recorder:false
log-driver:
hubble-metrics:
bpf-map-dynamic-size-ratio:0.0025
config:
ipv4-pod-subnets:
bpf-lb-dsr-l4-xlate:frontend
enable-l2-neigh-discovery:true
policy-queue-size:100
ipsec-key-rotation-duration:5m0s
bpf-ct-timeout-regular-tcp-fin:10s
labels:
enable-endpoint-health-checking:true
lib-dir:/var/lib/cilium
encrypt-node:false
encryption-strict-mode-cidr:
hubble-prefer-ipv6:false
arping-refresh-period:30s
bpf-lb-dsr-dispatch:opt
k8s-heartbeat-timeout:30s
enable-node-port:false
enable-gateway-api:true
enable-ipv6-big-tcp:false
bpf-lb-sock-hostns-only:false
tofqdns-proxy-response-max-delay:100ms
enable-hubble-recorder-api:true
http-403-msg:
iptables-random-fully:false
enable-bandwidth-manager:true
enable-custom-calls:false
policy-cidr-match-mode:
hubble-recorder-storage-path:/var/run/cilium/pcaps
route-metric:0
node-port-bind-protection:true
hubble-export-allowlist:
bpf-lb-rss-ipv6-src-cidr:
enable-service-topology:false
mesh-auth-signal-backoff-duration:1s
bgp-announce-lb-ip:false
dns-max-ips-per-restored-rule:1000
enable-health-checking:true
allow-localhost:auto
tunnel-protocol:vxlan
enable-local-node-route:true
hubble-redact-http-headers-deny:
set-cilium-is-up-condition:true
enable-health-check-loadbalancer-ip:false
disable-iptables-feeder-rules:
bpf-ct-timeout-regular-any:1m0s
endpoint-gc-interval:5m0s
tofqdns-idle-connection-grace-period:0s
cflags:
bpf-lb-algorithm:random
prometheus-serve-addr::9962
log-opt:
enable-ipsec:false
nodeport-addresses:
hubble-metrics-server:
k8s-service-proxy-name:
enable-bpf-tproxy:false
srv6-encap-mode:reduced
bpf-ct-timeout-service-any:1m0s
ip-allocation-timeout:2m0s
k8s-client-burst:20
debug:false
clustermesh-ip-identities-sync-timeout:1m0s
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-nat46x64-gateway:false
mesh-auth-spire-admin-socket:
node-port-mode:snat
envoy-log:
hubble-export-fieldmask:
bypass-ip-availability-upon-restore:false
config-sources:config-map:kube-system/cilium-config
enable-gateway-api-secrets-sync:true
hubble-socket-path:/var/run/cilium/hubble.sock
ipv6-node:auto
max-connected-clusters:255
nodes-gc-interval:5m0s
dnsproxy-concurrency-limit:0
enable-cilium-endpoint-slice:true
enable-auto-protect-node-port-range:true
install-iptables-rules:true
cni-external-routing:false
enable-policy:default
mesh-auth-gc-interval:5m0s
bpf-ct-timeout-service-tcp-grace:1m0s
annotate-k8s-node:true
agent-health-port:9879
disable-envoy-version-check:false
bpf-sock-rev-map-max:262144
custom-cni-conf:false
enable-xt-socket-fallback:true
proxy-idle-timeout-seconds:60
wireguard-persistent-keepalive:0s
identity-allocation-mode:crd
enable-host-legacy-routing:false
node-port-range:
max-controller-interval:0
pprof-port:6060
enable-vtep:false
trace-sock:true
restore:true
hubble-redact-http-headers-allow:
install-no-conntrack-iptables-rules:false
enable-envoy-config:true
proxy-max-connection-duration-seconds:0
controller-group-metrics:write-cni-file sync-host-ips sync-lb-maps-with-k8s-services
enable-bbr:true
hubble-event-buffer-capacity:4095
ipv4-service-loopback-address:169.254.42.1
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipam:kubernetes
identity-heartbeat-timeout:30m0s
enable-mke:false
allocator-list-timeout:3m0s
k8s-service-cache-size:128
ipam-default-ip-pool:default
enable-bpf-clock-probe:false
enable-bgp-control-plane:false
bpf-fragments-map-max:8192
ipv4-node:auto
bpf-policy-map-max:16384
clustermesh-config:/var/lib/cilium/clustermesh/
envoy-config-timeout:2m0s
remove-cilium-node-taints:true
hubble-disable-tls:false
bpf-filter-priority:1
exclude-local-address:
certificates-directory:/var/run/cilium/certs
hubble-redact-http-userinfo:true
mesh-auth-mutual-connect-timeout:5s
hubble-flowlogs-config-path:
hubble-redact-enabled:false
enable-k8s-networkpolicy:true
bgp-announce-pod-cidr:false
cni-chaining-target:
gops-port:9890
enable-ipv6-ndp:false
hubble-recorder-sink-queue-size:1024
tofqdns-dns-reject-response-code:refused
identity-change-grace-period:5s
mke-cgroup-mount:
skip-cnp-status-startup-clean:false
egress-gateway-reconciliation-trigger-interval:1s
enable-unreachable-routes:false
local-max-addr-scope:252
bpf-nat-global-max:524288
ipv4-service-range:auto
bpf-lb-maglev-map-max:0
kube-proxy-replacement:strict
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-k8s-terminating-endpoint:true
enable-bpf-masquerade:true
node-port-algorithm:random
label-prefix-file:
endpoint-bpf-prog-watchdog-interval:30s
cmdref:
monitor-queue-size:0
ipv6-service-range:auto
enable-ipv6:false
dnsproxy-lock-count:131
egress-masquerade-interfaces:
l2-announcements-retry-period:2s
enable-pmtu-discovery:false
bpf-map-event-buffers:
bpf-lb-affinity-map-max:0
mesh-auth-rotated-identities-queue-size:1024
enable-ipv4-big-tcp:false
bpf-lb-maglev-table-size:16381
kvstore-opt:
mesh-auth-queue-size:1024
enable-cilium-health-api-server-access:
l2-pod-announcements-interface:
ipam-cilium-node-update-rate:15s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
ipsec-key-file:
monitor-aggregation-flags:all
ipv6-cluster-alloc-cidr:f00d::/64
tofqdns-endpoint-max-ip-per-hostname:50
enable-l7-proxy:true
egress-multi-home-ip-rule-compat:false
install-egress-gateway-routes:false
identity-restore-grace-period:10m0s
enable-ipv4-egress-gateway:false
egress-gateway-policy-map-max:16384
hubble-export-file-max-size-mb:10
read-cni-conf:
bpf-lb-rev-nat-map-max:0
http-retry-count:3
kube-proxy-replacement-healthz-bind-address:
enable-metrics:true
cilium-endpoint-gc-interval:5m0s
node-port-acceleration:disabled
k8s-kubeconfig-path:
enable-stale-cilium-endpoint-cleanup:true
cni-log-file:/var/run/cilium/cilium-cni.log
iptables-lock-timeout:5s
enable-identity-mark:true
proxy-xff-num-trusted-hops-egress:0
bpf-lb-rss-ipv4-src-cidr:
tunnel-port:0
bpf-lb-acceleration:disabled
bpf-lb-source-range-map-max:0
log-system-load:false
sidecar-istio-proxy-image:cilium/istio_proxy
hubble-listen-address::4244
k8s-require-ipv4-pod-cidr:false
hubble-export-denylist:
operator-prometheus-serve-addr::9963
enable-wireguard-userspace-fallback:false
vtep-endpoint:
l2-announcements-lease-duration:15s
ipv6-range:auto
cgroup-root:/run/cilium/cgroupv2
synchronize-k8s-nodes:true
bpf-lb-mode:snat
monitor-aggregation-interval:5s
enable-external-ips:false
ipv4-range:auto
```


#### Cilium version

```
1.15.5 8c7e442c 2024-05-10T16:33:07+02:00 go version go1.21.10 linux/amd64
```


#### Cilium memory map


```
00400000-02d9c000 r-xp 00000000 00:47 1323592                            /usr/bin/cilium-agent
02d9c000-05f5d000 r--p 0299c000 00:47 1323592                            /usr/bin/cilium-agent
05f5d000-060b2000 rw-p 05b5d000 00:47 1323592                            /usr/bin/cilium-agent
060b2000-06840000 rw-p 00000000 00:00 0 
c000000000-c005800000 rw-p 00000000 00:00 0 
c005800000-c008000000 ---p 00000000 00:00 0 
7fd6889fc000-7fd688d09000 rw-p 00000000 00:00 0 
7fd688d09000-7fd688d4a000 rw-s 00000000 00:0e 1053                       anon_inode:[perf_event]
7fd688d4a000-7fd688d8b000 rw-s 00000000 00:0e 1053                       anon_inode:[perf_event]
7fd688d8b000-7fd6891eb000 rw-p 00000000 00:00 0 
7fd6891eb000-7fd6892eb000 rw-p 00000000 00:00 0 
7fd6892eb000-7fd689400000 rw-p 00000000 00:00 0 
7fd689400000-7fd68b400000 rw-p 00000000 00:00 0 
7fd68b400000-7fd69b580000 ---p 00000000 00:00 0 
7fd69b580000-7fd69b581000 rw-p 00000000 00:00 0 
7fd69b581000-7fd6bb580000 ---p 00000000 00:00 0 
7fd6bb580000-7fd6bb581000 rw-p 00000000 00:00 0 
7fd6bb581000-7fd6cd430000 ---p 00000000 00:00 0 
7fd6cd430000-7fd6cd431000 rw-p 00000000 00:00 0 
7fd6cd431000-7fd6cf806000 ---p 00000000 00:00 0 
7fd6cf806000-7fd6cf807000 rw-p 00000000 00:00 0 
7fd6cf807000-7fd6cfc00000 ---p 00000000 00:00 0 
7fd6cfc03000-7fd6cfc05000 rw-s 00000000 00:0e 1053                       anon_inode:[perf_event]
7fd6cfc05000-7fd6cfc07000 rw-s 00000000 00:0e 1053                       anon_inode:[perf_event]
7fd6cfc07000-7fd6cfcfd000 rw-p 00000000 00:00 0 
7fd6cfcfd000-7fd6cfd7d000 ---p 00000000 00:00 0 
7fd6cfd7d000-7fd6cfd7e000 rw-p 00000000 00:00 0 
7fd6cfd7e000-7fd6cfdfd000 ---p 00000000 00:00 0 
7fd6cfdfd000-7fd6cfe5d000 rw-p 00000000 00:00 0 
7ffddda48000-7ffddda69000 rw-p 00000000 00:00 0                          [stack]
7ffdddb62000-7ffdddb66000 r--p 00000000 00:00 0                          [vvar]
7ffdddb66000-7ffdddb68000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc001bdc480)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc000df5e60,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=21) {
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc0008e3c30)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha: (*k8s.Service)(0xc0014968f0)(frontends:[]/ports=[tcp-server tcp-sentinel http-exporter-port]/selector=map[app:redis-ha release:rke2-argocd]),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.Service)(0xc0023480b0)(frontends:[10.65.148.50]/ports=[https http]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-server]),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.Service)(0xc00314d760)(frontends:[10.65.155.14]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.Service)(0xc00314da20)(frontends:[10.65.26.204]/ports=[http]/selector=map[name:echo-other-node]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.Service)(0xc001f1b080)(frontends:[10.65.178.184]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-0]),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.Service)(0xc00067fad0)(frontends:[10.65.51.64]/ports=[https]/selector=map[app.kubernetes.io/instance:rke2-snapshot-validation-webhook app.kubernetes.io/name:rke2-snapshot-validation-webhook]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.Service)(0xc0020018c0)(frontends:[10.65.213.42]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc0008e3ce0)(frontends:[10.65.253.13]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc0008e3d90)(frontends:[10.65.203.48]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.Service)(0xc0008e3ef0)(frontends:[10.65.0.10]/ports=[udp-53 tcp-53]/selector=map[app.kubernetes.io/instance:rke2-coredns app.kubernetes.io/name:rke2-coredns k8s-app:kube-dns]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.Service)(0xc001f1a8f0)(frontends:[10.65.180.197]/ports=[tcp-haproxy http-exporter-port]/selector=map[app:redis-ha-haproxy release:rke2-argocd]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.Service)(0xc001f1af20)(frontends:[10.65.70.170]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-2]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc0008e3e40)(frontends:[10.65.97.59]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.Service)(0xc002001a20)(frontends:[10.65.174.214]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.Service)(0xc002001340)(frontends:[10.65.48.249]/ports=[https]/selector=map[app:rke2-metrics-server app.kubernetes.io/instance:rke2-metrics-server app.kubernetes.io/name:rke2-metrics-server]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc0008e3b80)(frontends:[10.65.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.Service)(0xc001f1ab00)(frontends:[10.65.145.33]/ports=[http grpc]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-dex-server]),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.Service)(0xc001496fd0)(frontends:[10.65.115.248]/ports=[https-controller]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-application-controller]),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.Service)(0xc0014971e0)(frontends:[10.65.192.200]/ports=[https-repo-server]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-repo-server]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.Service)(0xc001497290)(frontends:[10.65.243.160]/ports=[tcp-sentinel http-exporter tcp-server]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-1])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.EndpointSlices)(0xc00144e618)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-2-8ts7n": (*k8s.Endpoints)(0xc0045fe270)(10.55.5.155:26379/TCP,10.55.5.155:6379/TCP,10.55.5.155:9121/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.EndpointSlices)(0xc00144e6b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-0-9lzv5": (*k8s.Endpoints)(0xc003c4ac30)(10.55.3.253:26379/TCP,10.55.3.253:6379/TCP,10.55.3.253:9121/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.EndpointSlices)(0xc0014c13d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=23) "rke2-cert-manager-qnhfm": (*k8s.Endpoints)(0xc003032b60)(10.55.4.152:9402/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc0001030c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc0015eedd0)(10.22.20.11:6443/TCP,10.22.20.12:6443/TCP,10.22.20.13:6443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.EndpointSlices)(0xc0016c2438)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "rke2-metrics-server-7sv6h": (*k8s.Endpoints)(0xc00412e0d0)(10.55.3.27:10250/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.EndpointSlices)(0xc00140a3a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=40) "rke2-argocd-application-controller-fz8wm": (*k8s.Endpoints)(0xc00333f2b0)(10.55.3.252:8082/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc0001030d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-9l8c5": (*k8s.Endpoints)(0xc00412ea90)(10.55.3.167:4245/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc0001030d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-7qjhj": (*k8s.Endpoints)(0xc004235860)(10.55.3.129:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.EndpointSlices)(0xc00144e508)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=34) "rke2-argocd-redis-ha-haproxy-vlh5w": (*k8s.Endpoints)(0xc0045fe410)(10.55.3.78:6379/TCP,10.55.3.78:9101/TCP,10.55.4.213:6379/TCP,10.55.4.213:9101/TCP,10.55.5.149:6379/TCP,10.55.5.149:9101/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.EndpointSlices)(0xc00140a380)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=28) "rke2-argocd-dex-server-sv4gw": (*k8s.Endpoints)(0xc0005a4f70)(10.55.3.19:5556/TCP,10.55.3.19:5557/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.EndpointSlices)(0xc00140a3b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-1-j6rjb": (*k8s.Endpoints)(0xc004235c70)(10.55.4.218:26379/TCP,10.55.4.218:6379/TCP,10.55.4.218:9121/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.EndpointSlices)(0xc00144fbf8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=38) "rke2-snapshot-validation-webhook-m6rrw": (*k8s.Endpoints)(0xc0042349c0)(10.55.3.210:8443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc0001030c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-dmr4p": (*k8s.Endpoints)(0xc001d09930)(10.22.30.11:4244/TCP,10.22.30.12:4244/TCP,10.22.30.13:4244/TCP,10.22.30.21:4244/TCP,10.22.30.22:4244/TCP,10.22.30.23:4244/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.EndpointSlices)(0xc00144e520)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=29) "rke2-argocd-repo-server-xmwsw": (*k8s.Endpoints)(0xc003c4a1a0)(10.55.3.23:8081/TCP,10.55.3.50:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.EndpointSlices)(0xc00144e610)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=24) "rke2-argocd-server-8r4gl": (*k8s.Endpoints)(0xc003c4a340)(10.55.3.60:8080/TCP,10.55.3.60:8080/TCP,10.55.3.90:8080/TCP,10.55.3.90:8080/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.EndpointSlices)(0xc000098e78)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-cert-manager-webhook-9smdc": (*k8s.Endpoints)(0xc00412fba0)(10.55.4.211:10250/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.EndpointSlices)(0xc001140d90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-dcdmx": (*k8s.Endpoints)(0xc003756820)(10.55.5.129:8080/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.EndpointSlices)(0xc001141540)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=21) "echo-other-node-zctcd": (*k8s.Endpoints)(0xc0036b4a90)(10.55.4.112:8080/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.EndpointSlices)(0xc0001030e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-coredns-rke2-coredns-kcjm5": (*k8s.Endpoints)(0xc0024f1450)(10.55.0.129:53/TCP,10.55.0.129:53/UDP,10.55.2.204:53/TCP,10.55.2.204:53/UDP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*tables.nodeAddressing)(0xc0012b0c90)({
  localNode: (*node.LocalNodeStore)(0xc000af8d80)({
   Observable: (stream.FuncObservable[github.com/cilium/cilium/pkg/node.LocalNode]) 0x1df7600,
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   value: (node.LocalNode) {
    Node: (types.Node) {
     Name: (string) (len=7) "worker1",
     Cluster: (string) (len=7) "hetzner",
     IPAddresses: ([]types.Address) (len=3 cap=4) {
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "InternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.30.21
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "ExternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.20.21
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=16) "CiliumInternalIP",
       IP: (net.IP) (len=16 cap=26) 10.55.3.206
      }
     },
     IPv4AllocCIDR: (*cidr.CIDR)(0xc0007382b8)(10.55.3.0/24),
     IPv4SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv6AllocCIDR: (*cidr.CIDR)(<nil>),
     IPv6SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv4HealthIP: (net.IP) (len=16 cap=26) 10.55.3.209,
     IPv6HealthIP: (net.IP) <nil>,
     IPv4IngressIP: (net.IP) (len=16 cap=26) 10.55.3.251,
     IPv6IngressIP: (net.IP) <nil>,
     ClusterID: (uint32) 0,
     Source: (source.Source) (len=5) "local",
     EncryptionKey: (uint8) 0,
     Labels: (map[string]string) (len=7) {
      (string) (len=23) "beta.kubernetes.io/arch": (string) (len=5) "amd64",
      (string) (len=32) "beta.kubernetes.io/instance-type": (string) (len=4) "rke2",
      (string) (len=21) "beta.kubernetes.io/os": (string) (len=5) "linux",
      (string) (len=18) "kubernetes.io/arch": (string) (len=5) "amd64",
      (string) (len=22) "kubernetes.io/hostname": (string) (len=7) "worker1",
      (string) (len=16) "kubernetes.io/os": (string) (len=5) "linux",
      (string) (len=32) "node.kubernetes.io/instance-type": (string) (len=4) "rke2"
     },
     Annotations: (map[string]string) (len=4) {
      (string) (len=33) "network.cilium.io/ipv4-Ingress-ip": (string) (len=11) "10.55.3.251",
      (string) (len=32) "network.cilium.io/ipv4-health-ip": (string) (len=11) "10.55.3.209",
      (string) (len=31) "network.cilium.io/ipv4-pod-cidr": (string) (len=12) "10.55.3.0/24",
      (string) (len=34) "network.cilium.io/ipv4-cilium-host": (string) (len=11) "10.55.3.206"
     },
     NodeIdentity: (uint32) 1,
     WireguardPubKey: (string) "",
     BootID: (string) (len=36) "6ebbde80-dc68-4364-b819-5e38c738f77e"
    },
    OptOutNodeEncryption: (bool) false,
    UID: (types.UID) (len=36) "822a884f-b68f-4716-8fc4-50cc1afb3caf",
    ProviderID: (string) (len=14) "rke2://worker1"
   },
   emit: (func(node.LocalNode)) 0x1df7ea0,
   complete: (func(error)) 0x1df7c60
  }),
  db: (*statedb.DB)(0xc0016bb7a0)({
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   tables: (map[string]statedb.TableMeta) (len=4) {
    (string) (len=7) "devices": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc000777a40)({
     table: (string) (len=7) "devices",
     smu: (*lock.sortableMutex)(0xc0011ef5a8)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 1,
      acquireDuration: (time.Duration) 26.455µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      },
      (string) (len=8) "selected": (statedb.anyIndexer) {
       name: (string) (len=8) "selected",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=6) "routes": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Route])(0xc000777a90)({
     table: (string) (len=6) "routes",
     smu: (*lock.sortableMutex)(0xc0011ef5c0)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 2,
      acquireDuration: (time.Duration) 3.486µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=9) "LinkIndex": (statedb.anyIndexer) {
       name: (string) (len=9) "LinkIndex",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=14) "node-addresses": (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc000777f90)({
     table: (string) (len=14) "node-addresses",
     smu: (*lock.sortableMutex)(0xc0011ef638)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 3,
      acquireDuration: (time.Duration) 5.524µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
       unique: (bool) false
      }
     }
    }),
    (string) (len=11) "l2-announce": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.L2AnnounceEntry])(0xc00014b9a0)({
     table: (string) (len=11) "l2-announce",
     smu: (*lock.sortableMutex)(0xc001b8b410)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 4,
      acquireDuration: (time.Duration) 130ns
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=6) "origin": (statedb.anyIndexer) {
       name: (string) (len=6) "origin",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    })
   },
   ctx: (*context.cancelCtx)(0xc0007a79f0)(context.Background.WithCancel),
   cancel: (context.CancelFunc) 0x4a18e0,
   root: (atomic.Pointer[github.com/hashicorp/go-immutable-radix/v2.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]]) {
    _: ([0]*iradix.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]) {
    },
    _: (atomic.noCopy) {
    },
    v: (unsafe.Pointer) 0xc0013e3870
   },
   gcTrigger: (chan struct {}) (cap=1) 0xc0018e3da0,
   gcExited: (chan struct {}) 0xc0018e3e00,
   gcRateLimitInterval: (time.Duration) 1s,
   metrics: (statedb.Metrics) {
    WriteTxnDuration: (*metric.histogramVec)(0xc000dd1600)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0010b4358)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62900)({
       metricMap: (*prometheus.metricMap)(0xc000d62930)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000da1ec0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0xc000dd1680)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0010b4360)({
      MetricVec: (*prometheus.MetricVec)(0xc000d629c0)({
       metricMap: (*prometheus.metricMap)(0xc000d629f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000da1f20)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0xc000dd1700)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4368)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62a50)({
       metricMap: (*prometheus.metricMap)(0xc000d62a80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000da1f80)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0xc000dd1780)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4370)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62ae0)({
       metricMap: (*prometheus.metricMap)(0xc000d62b10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df4000)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0xc000dd1800)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4378)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62ba0)({
       metricMap: (*prometheus.metricMap)(0xc000d62bd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df4060)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0xc000dd1880)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4380)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62c30)({
       metricMap: (*prometheus.metricMap)(0xc000d62c60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df40c0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0xc000dd1900)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4388)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62cc0)({
       metricMap: (*prometheus.metricMap)(0xc000d62cf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df4120)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0xc000dd1980)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0010b4390)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62d50)({
       metricMap: (*prometheus.metricMap)(0xc000d62d80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df4180)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0xc000dd1a00)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0010b4398)({
      MetricVec: (*prometheus.MetricVec)(0xc000d62e10)({
       metricMap: (*prometheus.metricMap)(0xc000d62e40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc000df41e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  }),
  nodeAddresses: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc000777f90)({
   table: (string) (len=14) "node-addresses",
   smu: (*lock.sortableMutex)(0xc0011ef638)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 3,
    acquireDuration: (time.Duration) 5.524µs
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
     unique: (bool) false
    }
   }
  }),
  devices: (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc000777a40)({
   table: (string) (len=7) "devices",
   smu: (*lock.sortableMutex)(0xc0011ef5a8)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 1,
    acquireDuration: (time.Duration) 26.455µs
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    },
    (string) (len=8) "selected": (statedb.anyIndexer) {
     name: (string) (len=8) "selected",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    }
   }
  })
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

