KEY             VALUE
AgentLiveness   11790115175563
UTimeOffset     3362276697265625
