REASON                                    DIRECTION   PACKETS   BYTES
Interface                                 INGRESS     1520097   1009606375
Success                                   EGRESS      3104391   393141952
Success                                   INGRESS     3209120   454505287
Unknown ICMPv4 code                       EGRESS      18        2010
Unsupported L3 protocol                   EGRESS      356       26712
Unsupported protocol for NAT masquerade   EGRESS      1         86
