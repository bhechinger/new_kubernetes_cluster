alloc: 68.17MB (71478200 bytes)
total-alloc: 8.67GB (9307045592 bytes)
sys: 98.86MB (103661243 bytes)
lookups: 0
mallocs: 171163832
frees: 170245042
heap-alloc: 68.17MB (71478200 bytes)
heap-sys: 82.56MB (86573056 bytes)
heap-idle: 8.98MB (9420800 bytes)
heap-in-use: 73.58MB (77152256 bytes)
heap-released: 2.56MB (2686976 bytes)
heap-objects: 918790
stack-in-use: 5.44MB (5701632 bytes)
stack-sys: 5.44MB (5701632 bytes)
stack-mspan-inuse: 1.32MB (1379784 bytes)
stack-mspan-sys: 1.41MB (1482936 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 767.96KB (786390 bytes)
gc-sys: 6.74MB (7070304 bytes)
next-gc: when heap-alloc >= 72.93MB (76476704 bytes)
last-gc: 2024-07-20 17:43:30.59134357 +0000 UTC
gc-pause-total: 39.564914ms
gc-pause: 98026
gc-pause-end: 1721497410591343570
num-gc: 264
num-forced-gc: 0
gc-cpu-fraction: 0.0001257198462042815
enable-gc: true
debug-gc: false
