Endpoint ID: 709
Path: /sys/fs/bpf/tc/globals/cilium_policy_00709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1495260    16647     0        
Allow    Ingress     1          ANY          NONE         disabled    3462408    39573     0        
Allow    Egress      0          ANY          NONE         disabled    46237623   628934    0        


Endpoint ID: 924
Path: /sys/fs/bpf/tc/globals/cilium_policy_00924

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    2228206   17694     0        
Allow    Egress      0          ANY          NONE         disabled    74982     850       0        


Endpoint ID: 1192
Path: /sys/fs/bpf/tc/globals/cilium_policy_01192

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1788534   20050     0        
Allow    Ingress     1          ANY          NONE         disabled    3056734   27283     0        
Allow    Egress      0          ANY          NONE         disabled    1684847   15976     0        


Endpoint ID: 1202
Path: /sys/fs/bpf/tc/globals/cilium_policy_01202

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    70294476   921473    0        
Allow    Ingress     1          ANY          NONE         disabled    1054090    13471     0        
Allow    Egress      0          ANY          NONE         disabled    16597311   195357    0        


Endpoint ID: 1301
Path: /sys/fs/bpf/tc/globals/cilium_policy_01301

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    820542   10363     0        
Allow    Ingress     1111       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     1344       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     2139       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     3394       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     3859       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     9426       8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     10448      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     11758      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     13815      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     14678      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     15581      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     16381      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     16822      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     21496      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     24197      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     29667      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     29762      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     30951      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     50180      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     50725      8082/TCP     NONE         disabled    0        0         24       
Allow    Ingress     53865      8082/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    577336   3738      0        


Endpoint ID: 1812
Path: /sys/fs/bpf/tc/globals/cilium_policy_01812

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    3336882   29525     0        
Allow    Egress      0          ANY          NONE         disabled    720565    9400      0        


Endpoint ID: 2117
Path: /sys/fs/bpf/tc/globals/cilium_policy_02117

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    3340158   29543     0        
Allow    Egress      0          ANY          NONE         disabled    725548    9389      0        


Endpoint ID: 2507
Path: /sys/fs/bpf/tc/globals/cilium_policy_02507

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    186636   2152      0        
Allow    Egress      0          ANY          NONE         disabled    535140   6215      0        


Endpoint ID: 2654
Path: /sys/fs/bpf/tc/globals/cilium_policy_02654

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    523256   6579      0        
Allow    Ingress     1          ANY          NONE         disabled    152996   1742      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2722
Path: /sys/fs/bpf/tc/globals/cilium_policy_02722

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1108090   13016     0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2992
Path: /sys/fs/bpf/tc/globals/cilium_policy_02992

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3073
Path: /sys/fs/bpf/tc/globals/cilium_policy_03073

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    588608   8656      0        
Allow    Ingress     30951      8081/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8081/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3150
Path: /sys/fs/bpf/tc/globals/cilium_policy_03150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Ingress     33708      5556/TCP     NONE         disabled    0       0         24       
Allow    Ingress     33708      5557/TCP     NONE         disabled    0       0         24       
Allow    Egress      0          ANY          NONE         disabled    84429   979       0        


Endpoint ID: 3677
Path: /sys/fs/bpf/tc/globals/cilium_policy_03677

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1960696   21609     0        
Allow    Egress      0          ANY          NONE         disabled    112432    1519      0        


Endpoint ID: 3706
Path: /sys/fs/bpf/tc/globals/cilium_policy_03706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    589152   8664      0        
Allow    Ingress     30951      8081/TCP     NONE         disabled    0        0         24       
Allow    Ingress     33708      8081/TCP     NONE         disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3811
Path: /sys/fs/bpf/tc/globals/cilium_policy_03811

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    77875   904       0        


Endpoint ID: 3979
Path: /sys/fs/bpf/tc/globals/cilium_policy_03979

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    2733440   12700     0        


