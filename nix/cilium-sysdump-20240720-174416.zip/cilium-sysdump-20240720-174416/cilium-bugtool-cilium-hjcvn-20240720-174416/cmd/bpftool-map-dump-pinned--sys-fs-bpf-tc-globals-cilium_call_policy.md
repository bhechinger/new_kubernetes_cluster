key: c5 02 00 00  value: 2c 05 00 00
key: 9c 03 00 00  value: d6 05 00 00
key: a8 04 00 00  value: 96 05 00 00
key: b2 04 00 00  value: 57 05 00 00
key: 15 05 00 00  value: 08 05 00 00
key: 14 07 00 00  value: 42 05 00 00
key: 45 08 00 00  value: 3d 05 00 00
key: cb 09 00 00  value: 5f 03 00 00
key: 5e 0a 00 00  value: d2 02 00 00
key: a2 0a 00 00  value: a7 03 00 00
key: 01 0c 00 00  value: 66 05 00 00
key: 4e 0c 00 00  value: fa 04 00 00
key: 5d 0e 00 00  value: 37 03 00 00
key: 7a 0e 00 00  value: 1f 05 00 00
key: e3 0e 00 00  value: a4 05 00 00
key: 8b 0f 00 00  value: 74 06 00 00
Found 16 elements
