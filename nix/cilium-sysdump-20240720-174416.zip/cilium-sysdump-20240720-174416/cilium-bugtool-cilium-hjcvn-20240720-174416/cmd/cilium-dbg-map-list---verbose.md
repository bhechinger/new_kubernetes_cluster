## Map: cilium_ipmasq_v4
Key           Value   State   Error
10.22.30.0            sync    
169.254.0.0           sync    

## Map: cilium_policy_03706
Cache is disabled


## Map: cilium_policy_01812
Cache is disabled


## Map: cilium_policy_01192
Cache is disabled


## Map: cilium_policy_03979
Cache is disabled


## Map: cilium_lb4_reverse_sk
Cache is disabled


## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
4     10.65.97.59:80        sync    
13    10.65.243.160:26379   sync    
14    10.65.243.160:9121    sync    
16    10.65.148.50:80       sync    
23    10.65.51.64:443       sync    
30    10.22.20.21:32495     sync    
32    0.0.0.0:32495         sync    
7     10.65.180.197:6379    sync    
22    10.65.178.184:6379    sync    
36    0.0.0.0:30568         sync    
3     10.65.203.48:80       sync    
5     10.65.0.10:53         sync    
15    10.65.148.50:443      sync    
17    10.65.70.170:9121     sync    
29    10.65.155.14:8080     sync    
31    10.22.30.21:32495     sync    
34    10.22.20.21:30568     sync    
1     10.65.0.1:443         sync    
6     10.65.180.197:9101    sync    
10    10.65.115.248:8082    sync    
12    10.65.243.160:6379    sync    
27    10.65.213.42:9402     sync    
28    10.65.174.214:443     sync    
2     10.65.253.13:443      sync    
19    10.65.70.170:26379    sync    
20    10.65.178.184:26379   sync    
21    10.65.178.184:9121    sync    
24    10.65.48.249:443      sync    
33    10.65.26.204:8080     sync    
8     10.65.145.33:5556     sync    
9     10.65.145.33:5557     sync    
11    10.65.192.200:8081    sync    
18    10.65.70.170:6379     sync    
35    10.22.30.21:30568     sync    

## Map: cilium_policy_03677
Cache is disabled


## Map: cilium_policy_01301
Cache is disabled


## Map: cilium_policy_00709
Cache is disabled


## Map: cilium_policy_00924
Cache is disabled


## Map: cilium_lxc
Key             Value                                                                                            State   Error
10.55.3.253:0   id=1202  sec_id=10448 flags=0x0000 ifindex=44  mac=0E:D3:A3:2B:79:E9 nodemac=92:59:79:19:51:2A   sync    
10.55.3.27:0    id=1192  sec_id=16822 flags=0x0000 ifindex=48  mac=BE:E9:CA:9A:59:A7 nodemac=EA:FF:4C:46:0E:5F   sync    
10.55.3.252:0   id=1301  sec_id=30951 flags=0x0000 ifindex=34  mac=BE:37:C0:63:F6:D3 nodemac=F6:44:AA:4B:9A:FD   sync    
10.55.3.209:0   id=2654  sec_id=4     flags=0x0000 ifindex=10  mac=BA:88:A8:D1:59:AC nodemac=FE:74:6F:D6:76:42   sync    
10.55.3.50:0    id=3706  sec_id=29762 flags=0x0000 ifindex=36  mac=9A:DA:50:3C:93:C4 nodemac=BA:B9:0D:49:20:50   sync    
10.55.3.60:0    id=1812  sec_id=33708 flags=0x0000 ifindex=40  mac=0E:F7:70:47:2A:A8 nodemac=A6:A9:84:59:1D:9B   sync    
10.55.3.210:0   id=924   sec_id=24197 flags=0x0000 ifindex=52  mac=A2:74:0C:79:19:9D nodemac=EA:E2:45:31:F3:1E   sync    
10.55.3.12:0    id=3979  sec_id=1111  flags=0x0000 ifindex=62  mac=9E:C2:06:8B:4B:C0 nodemac=CE:2C:8F:CE:A3:27   sync    
10.22.30.21:0   (localhost)                                                                                      sync    
10.55.3.167:0   id=3677  sec_id=2139  flags=0x0000 ifindex=14  mac=D6:1F:BC:9D:3A:35 nodemac=CA:1B:89:FE:06:BC   sync    
10.55.3.23:0    id=3073  sec_id=29762 flags=0x0000 ifindex=46  mac=D6:E1:74:B0:FC:05 nodemac=42:C9:BF:01:9C:27   sync    
10.55.3.129:0   id=2722  sec_id=16381 flags=0x0000 ifindex=28  mac=5A:DB:08:4B:FA:E4 nodemac=AE:8F:B6:3A:2C:90   sync    
10.22.20.21:0   (localhost)                                                                                      sync    
10.55.3.218:0   id=2507  sec_id=50180 flags=0x0000 ifindex=18  mac=02:64:8A:AD:4F:02 nodemac=8E:FC:C5:3B:EA:DD   sync    
10.55.3.19:0    id=3150  sec_id=14678 flags=0x0000 ifindex=32  mac=CE:9A:90:94:D3:13 nodemac=BE:F2:87:BA:AC:89   sync    
10.55.3.78:0    id=709   sec_id=11758 flags=0x0000 ifindex=38  mac=36:70:48:32:28:98 nodemac=A2:AF:3E:F9:68:FC   sync    
10.55.3.90:0    id=2117  sec_id=33708 flags=0x0000 ifindex=42  mac=A2:1D:BB:28:17:9C nodemac=3E:B6:F7:F3:F4:AE   sync    
10.55.3.164:0   id=3811  sec_id=1344  flags=0x0000 ifindex=50  mac=4A:A3:99:A6:77:10 nodemac=D2:CA:A3:A8:B3:9A   sync    
10.55.3.206:0   (localhost)                                                                                      sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_02654
Cache is disabled


## Map: cilium_policy_01202
Cache is disabled


## Map: cilium_lb4_affinity
Cache is disabled


## Map: cilium_lb4_backends_v3
Key   Value               State   Error
3     ANY://10.22.20.11   sync    
6     ANY://10.55.2.204   sync    
7     ANY://10.55.3.167   sync    
16    ANY://10.55.3.90    sync    
32    ANY://10.55.5.155   sync    
2     ANY://10.22.20.13   sync    
14    ANY://10.55.3.210   sync    
17    ANY://10.55.3.252   sync    
21    ANY://10.55.3.19    sync    
22    ANY://10.55.3.19    sync    
26    ANY://10.55.4.218   sync    
1     ANY://10.22.20.12   sync    
9     ANY://10.55.3.253   sync    
18    ANY://10.55.3.50    sync    
20    ANY://10.55.3.23    sync    
28    ANY://10.55.4.152   sync    
30    ANY://10.55.5.155   sync    
31    ANY://10.55.5.155   sync    
4     ANY://10.55.0.129   sync    
12    ANY://10.55.3.78    sync    
19    ANY://10.55.3.60    sync    
23    ANY://10.55.4.213   sync    
25    ANY://10.55.4.218   sync    
27    ANY://10.55.4.218   sync    
33    ANY://10.55.5.149   sync    
34    ANY://10.55.5.149   sync    
11    ANY://10.55.3.253   sync    
29    ANY://10.55.4.211   sync    
15    ANY://10.55.3.129   sync    
24    ANY://10.55.4.213   sync    
8     ANY://10.55.3.27    sync    
36    ANY://10.55.4.112   sync    
35    ANY://10.55.5.129   sync    
10    ANY://10.55.3.253   sync    
13    ANY://10.55.3.78    sync    
5     ANY://10.22.30.21   sync    

## Map: cilium_ipcache
Key              Value                                                    State   Error
10.55.3.12/32    identity=1111 encryptkey=0 tunnelendpoint=0.0.0.0        sync    
10.55.3.90/32    identity=33708 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.5.93/32    identity=6 encryptkey=0 tunnelendpoint=10.22.30.23       sync    
10.55.5.170/32   identity=21496 encryptkey=0 tunnelendpoint=10.22.30.23   sync    
10.55.1.165/32   identity=4 encryptkey=0 tunnelendpoint=10.22.30.12       sync    
10.22.20.21/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.164/32   identity=1344 encryptkey=0 tunnelendpoint=0.0.0.0        sync    
10.55.3.210/32   identity=24197 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.3.252/32   identity=30951 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.3.78/32    identity=11758 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.5.149/32   identity=11758 encryptkey=0 tunnelendpoint=10.22.30.23   sync    
10.55.1.178/32   identity=8 encryptkey=0 tunnelendpoint=10.22.30.12       sync    
10.55.3.19/32    identity=14678 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.0.16/32    identity=4 encryptkey=0 tunnelendpoint=10.22.30.11       sync    
10.55.1.36/32    identity=6 encryptkey=0 tunnelendpoint=10.22.30.12       sync    
10.55.3.50/32    identity=29762 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.22.20.22/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.4.218/32   identity=10448 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.55.5.82/32    identity=29667 encryptkey=0 tunnelendpoint=10.22.30.23   sync    
10.55.3.206/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.22.30.13/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
0.0.0.0/0        identity=2 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.253/32   identity=10448 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.5.155/32   identity=10448 encryptkey=0 tunnelendpoint=10.22.30.23   sync    
10.55.5.129/32   identity=3859 encryptkey=0 tunnelendpoint=10.22.30.23    sync    
10.55.0.129/32   identity=3394 encryptkey=0 tunnelendpoint=10.22.30.11    sync    
10.22.20.12/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.2.229/32   identity=6 encryptkey=0 tunnelendpoint=10.22.30.13       sync    
10.55.0.214/32   identity=8 encryptkey=0 tunnelendpoint=10.22.30.11       sync    
10.55.4.152/32   identity=53865 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.55.4.213/32   identity=11758 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.55.4.250/32   identity=15581 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.22.20.13/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.251/32   identity=8 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.23/32    identity=29762 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.4.84/32    identity=4 encryptkey=0 tunnelendpoint=10.22.30.22       sync    
10.55.3.129/32   identity=16381 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.22.20.23/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.22.30.12/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.167/32   identity=2139 encryptkey=0 tunnelendpoint=0.0.0.0        sync    
10.55.4.66/32    identity=6 encryptkey=0 tunnelendpoint=10.22.30.22       sync    
10.55.4.211/32   identity=13815 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.22.20.11/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.2.204/32   identity=3394 encryptkey=0 tunnelendpoint=10.22.30.13    sync    
10.55.5.68/32    identity=8 encryptkey=0 tunnelendpoint=10.22.30.23       sync    
10.55.2.220/32   identity=4 encryptkey=0 tunnelendpoint=10.22.30.13       sync    
10.22.30.11/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.3.27/32    identity=16822 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.0.64/32    identity=6 encryptkey=0 tunnelendpoint=10.22.30.11       sync    
10.55.3.218/32   identity=50180 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.22.30.22/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.4.187/32   identity=9426 encryptkey=0 tunnelendpoint=10.22.30.22    sync    
10.55.4.112/32   identity=50725 encryptkey=0 tunnelendpoint=10.22.30.22   sync    
10.22.30.23/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.55.4.77/32    identity=8 encryptkey=0 tunnelendpoint=10.22.30.22       sync    
10.55.2.122/32   identity=8 encryptkey=0 tunnelendpoint=10.22.30.13       sync    
10.55.3.60/32    identity=33708 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.55.5.109/32   identity=4 encryptkey=0 tunnelendpoint=10.22.30.23       sync    
10.55.3.209/32   identity=4 encryptkey=0 tunnelendpoint=0.0.0.0           sync    
10.22.30.21/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0           sync    

## Map: cilium_throttle
Cache is empty


## Map: cilium_lb4_services_v2
Key                       Value                 State   Error
10.65.243.160:26379 (0)   0 1 (13) [0x0 0x0]    sync    
10.65.148.50:80 (0)       0 2 (16) [0x0 0x0]    sync    
10.65.178.184:26379 (0)   0 1 (20) [0x0 0x0]    sync    
10.65.178.184:9121 (1)    11 0 (21) [0x0 0x0]   sync    
10.65.180.197:6379 (1)    13 0 (7) [0x0 0x0]    sync    
10.65.145.33:5557 (1)     22 0 (9) [0x0 0x0]    sync    
10.65.180.197:6379 (3)    34 0 (7) [0x0 0x0]    sync    
10.22.30.21:32495 (0)     0 1 (31) [0x42 0x0]   sync    
10.65.145.33:5557 (0)     0 1 (9) [0x0 0x0]     sync    
10.65.115.248:8082 (1)    17 0 (10) [0x0 0x0]   sync    
10.65.70.170:9121 (1)     30 0 (17) [0x0 0x0]   sync    
10.22.30.21:30568 (0)     0 1 (35) [0x42 0x0]   sync    
10.65.243.160:6379 (0)    0 1 (12) [0x0 0x0]    sync    
10.65.178.184:9121 (0)    0 1 (21) [0x0 0x0]    sync    
10.65.178.184:6379 (0)    0 1 (22) [0x0 0x0]    sync    
10.65.243.160:26379 (1)   26 0 (13) [0x0 0x0]   sync    
10.65.70.170:6379 (1)     31 0 (18) [0x0 0x0]   sync    
10.65.70.170:26379 (1)    32 0 (19) [0x0 0x0]   sync    
10.22.20.21:32495 (0)     0 1 (30) [0x42 0x0]   sync    
10.65.145.33:5556 (0)     0 1 (8) [0x0 0x0]     sync    
10.65.243.160:9121 (0)    0 1 (14) [0x0 0x0]    sync    
10.65.70.170:26379 (0)    0 1 (19) [0x0 0x0]    sync    
10.65.178.184:6379 (1)    9 0 (22) [0x0 0x0]    sync    
0.0.0.0:30568 (1)         36 0 (36) [0x0 0x0]   sync    
10.22.20.21:30568 (0)     0 1 (34) [0x42 0x0]   sync    
10.65.203.48:80 (0)       0 1 (3) [0x0 0x0]     sync    
10.65.97.59:80 (0)        0 1 (4) [0x0 0x0]     sync    
10.65.253.13:443 (1)      5 0 (2) [0x0 0x0]     sync    
10.65.180.197:6379 (0)    0 3 (7) [0x0 0x0]     sync    
10.65.192.200:8081 (1)    18 0 (11) [0x0 0x0]   sync    
10.65.203.48:80 (1)       7 0 (3) [0x0 0x0]     sync    
10.65.48.249:443 (1)      8 0 (24) [0x0 0x0]    sync    
10.22.20.21:32495 (1)     35 0 (30) [0x0 0x0]   sync    
10.65.180.197:9101 (0)    0 3 (6) [0x0 0x0]     sync    
10.65.192.200:8081 (0)    0 2 (11) [0x0 0x0]    sync    
10.65.148.50:443 (0)      0 2 (15) [0x0 0x0]    sync    
10.65.70.170:6379 (0)     0 1 (18) [0x0 0x0]    sync    
10.65.145.33:5556 (1)     21 0 (8) [0x0 0x0]    sync    
10.65.243.160:9121 (1)    27 0 (14) [0x0 0x0]   sync    
10.65.174.214:443 (1)     29 0 (28) [0x0 0x0]   sync    
10.65.0.10:53 (0)         0 2 (5) [0x0 0x0]     sync    
10.65.51.64:443 (0)       0 1 (23) [0x0 0x0]    sync    
10.65.51.64:443 (1)       14 0 (23) [0x0 0x0]   sync    
10.65.174.214:443 (0)     0 1 (28) [0x0 0x0]    sync    
10.65.148.50:443 (2)      19 0 (15) [0x0 0x0]   sync    
10.65.243.160:6379 (1)    25 0 (12) [0x0 0x0]   sync    
10.65.180.197:9101 (3)    33 0 (6) [0x0 0x0]    sync    
10.65.0.1:443 (2)         2 0 (1) [0x0 0x0]     sync    
10.65.0.1:443 (0)         0 3 (1) [0x0 0x0]     sync    
0.0.0.0:32495 (0)         0 1 (32) [0x2 0x0]    sync    
10.65.0.1:443 (1)         1 0 (1) [0x0 0x0]     sync    
10.65.0.10:53 (1)         4 0 (5) [0x0 0x0]     sync    
10.65.48.249:443 (0)      0 1 (24) [0x0 0x0]    sync    
10.65.213.42:9402 (0)     0 1 (27) [0x0 0x0]    sync    
0.0.0.0:30568 (0)         0 1 (36) [0x2 0x0]    sync    
10.65.155.14:8080 (1)     35 0 (29) [0x0 0x0]   sync    
10.65.70.170:9121 (0)     0 1 (17) [0x0 0x0]    sync    
10.65.97.59:80 (1)        15 0 (4) [0x0 0x0]    sync    
10.65.180.197:9101 (2)    23 0 (6) [0x0 0x0]    sync    
10.65.26.204:8080 (0)     0 1 (33) [0x0 0x0]    sync    
10.65.115.248:8082 (0)    0 1 (10) [0x0 0x0]    sync    
10.65.148.50:80 (2)       19 0 (16) [0x0 0x0]   sync    
0.0.0.0:32495 (1)         35 0 (32) [0x0 0x0]   sync    
10.22.30.21:30568 (1)     36 0 (35) [0x0 0x0]   sync    
10.65.0.1:443 (3)         3 0 (1) [0x0 0x0]     sync    
10.65.0.10:53 (2)         6 0 (5) [0x0 0x0]     sync    
10.65.192.200:8081 (2)    20 0 (11) [0x0 0x0]   sync    
10.65.213.42:9402 (1)     28 0 (27) [0x0 0x0]   sync    
10.65.155.14:8080 (0)     0 1 (29) [0x0 0x0]    sync    
10.22.20.21:30568 (1)     36 0 (34) [0x0 0x0]   sync    
10.65.148.50:80 (1)       16 0 (16) [0x0 0x0]   sync    
10.65.180.197:9101 (1)    12 0 (6) [0x0 0x0]    sync    
10.22.30.21:32495 (1)     35 0 (31) [0x0 0x0]   sync    
10.65.253.13:443 (0)      0 1 (2) [0x0 0x10]    sync    
10.65.180.197:6379 (2)    24 0 (7) [0x0 0x0]    sync    
10.65.178.184:26379 (1)   10 0 (20) [0x0 0x0]   sync    
10.65.148.50:443 (1)      16 0 (15) [0x0 0x0]   sync    
10.65.26.204:8080 (1)     36 0 (33) [0x0 0x0]   sync    

## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_policy_02117
Cache is disabled


## Map: cilium_runtime_config
Cache is disabled


## Map: cilium_policy_03811
Cache is disabled


## Map: cilium_policy_02722
Cache is disabled


## Map: cilium_policy_02507
Cache is disabled


## Map: cilium_policy_03150
Cache is disabled


## Map: cilium_policy_03073
Cache is disabled


## Map: cilium_policy_02992
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map
Cache is disabled


## Map: cilium_metrics
Cache is disabled


