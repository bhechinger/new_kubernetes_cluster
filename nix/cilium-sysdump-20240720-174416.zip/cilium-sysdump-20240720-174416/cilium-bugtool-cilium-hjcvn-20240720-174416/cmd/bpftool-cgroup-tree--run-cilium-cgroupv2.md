CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
55       cgroup_inet_ingress multi           sd_fw_ingress                  
54       cgroup_inet_egress multi           sd_fw_egress                   
654      cgroup_inet4_connect multi           cil_sock4_connect                
655      cgroup_inet6_connect multi           cil_sock6_connect                
649      cgroup_inet4_post_bind multi           cil_sock4_post_bind                
651      cgroup_inet6_post_bind multi           cil_sock6_post_bind                
656      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
652      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
648      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
650      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
657      cgroup_inet4_getpeername multi           cil_sock4_getpeername                
653      cgroup_inet6_getpeername multi           cil_sock6_getpeername                
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    57       cgroup_inet_ingress multi           sd_fw_ingress                  
    56       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-config.mount
    59       cgroup_inet_ingress multi           sd_fw_ingress                  
    58       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    26       cgroup_inet_ingress multi           sd_fw_ingress                  
    25       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/dev-mqueue.mount
    24       cgroup_inet_ingress multi           sd_fw_ingress                  
    23       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice
    1992     cgroup_inet_ingress multi           sd_fw_ingress                  
    1991     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-0.slice
    1990     cgroup_inet_ingress multi           sd_fw_ingress                  
    1989     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    1996     cgroup_inet_ingress multi           sd_fw_ingress                  
    1995     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/init.scope
    8        cgroup_inet_ingress multi           sd_fw_ingress                  
    7        cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice
    53       cgroup_inet_ingress multi           sd_fw_ingress                  
    52       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    18       cgroup_inet_ingress multi           sd_fw_ingress                  
    17       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    69       cgroup_inet_ingress multi           sd_fw_ingress                  
    68       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice
    16       cgroup_inet_ingress multi           sd_fw_ingress                  
    15       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice/serial-getty@hvc0.service
    140      cgroup_inet_ingress multi           sd_fw_ingress                  
    139      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/boot.mount
    79       cgroup_inet_ingress multi           sd_fw_ingress                  
    78       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/rke2-agent.service
    144      cgroup_inet_ingress multi           sd_fw_ingress                  
    143      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    14       cgroup_inet_ingress multi           sd_fw_ingress                  
    13       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    45       cgroup_inet_ingress multi           sd_fw_ingress                  
    44       cgroup_inet_egress multi           sd_fw_egress                   
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/mdmonitor.service
    73       cgroup_inet_ingress multi           sd_fw_ingress                  
    72       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/sshd.service
    134      cgroup_inet_ingress multi           sd_fw_ingress                  
    133      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dhcpcd.service
    97       cgroup_inet_ingress multi           sd_fw_ingress                  
    96       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/nscd.service
    142      cgroup_inet_ingress multi           sd_fw_ingress                  
    141      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    86       cgroup_inet_ingress multi           sd_fw_ingress                  
    85       cgroup_inet_egress multi           sd_fw_egress                   
    84       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/dbus.service
    107      cgroup_inet_ingress multi           sd_fw_ingress                  
    106      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    89       cgroup_inet_ingress multi           sd_fw_ingress                  
    88       cgroup_inet_egress multi           sd_fw_egress                   
    87       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/system-getty.slice
    12       cgroup_inet_ingress multi           sd_fw_ingress                  
    11       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-getty.slice/getty@tty1.service
    138      cgroup_inet_ingress multi           sd_fw_ingress                  
    137      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    110      cgroup_inet_ingress multi           sd_fw_ingress                  
    109      cgroup_inet_egress multi           sd_fw_egress                   
    108      cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/dev-hugepages.mount
    22       cgroup_inet_ingress multi           sd_fw_ingress                  
    21       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice
    192      cgroup_inet_ingress multi           sd_fw_ingress                  
    191      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice
    2730     cgroup_inet_ingress multi           sd_fw_ingress                  
    2729     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa92d1b_43ee_4455_b77a_e6383f018ca0.slice
    1529     cgroup_inet_ingress multi           sd_fw_ingress                  
    1528     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa92d1b_43ee_4455_b77a_e6383f018ca0.slice/cri-containerd-6d48740b76e79947aca3adbebdc64de3ec9b7267d73685c5cfbcf6dc44203a6a.scope
    1685     cgroup_inet_ingress multi           sd_fw_ingress                  
    1684     cgroup_inet_egress multi           sd_fw_egress                   
    1688     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa92d1b_43ee_4455_b77a_e6383f018ca0.slice/cri-containerd-7d4004af23744bfcc8bce4ad092039a2a19cee5e7c120e2daa3d8e1fbda21c73.scope
    1534     cgroup_inet_ingress multi           sd_fw_ingress                  
    1533     cgroup_inet_egress multi           sd_fw_egress                   
    1537     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e9a8f9a_96d9_4525_88dc_03c6e27f2274.slice
    968      cgroup_inet_ingress multi           sd_fw_ingress                  
    967      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e9a8f9a_96d9_4525_88dc_03c6e27f2274.slice/cri-containerd-72187057a8aac71a6b2a828454cfd39b8adc480b1ef2f2e3f18760996bfb2404.scope
    973      cgroup_inet_ingress multi           sd_fw_ingress                  
    972      cgroup_inet_egress multi           sd_fw_egress                   
    976      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e9a8f9a_96d9_4525_88dc_03c6e27f2274.slice/cri-containerd-c1a64216356a27a79089c5d2ac086ef927be84881c4a93385473e706b7fd1395.scope
    1049     cgroup_inet_ingress multi           sd_fw_ingress                  
    1048     cgroup_inet_egress multi           sd_fw_egress                   
    1052     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice
    196      cgroup_inet_ingress multi           sd_fw_ingress                  
    195      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice/cri-containerd-952edcc7065534514376a04b7178393d4629122d7dddbcb4e68ef971963ac747.scope
    662      cgroup_inet_ingress multi           sd_fw_ingress                  
    661      cgroup_inet_egress multi           sd_fw_egress                   
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice/cri-containerd-d561a8579b66c2d6c4d25806d0ad9c8d01867e52da55f8b189e79e50e0d9d9aa.scope
    298      cgroup_inet_ingress multi           sd_fw_ingress                  
    297      cgroup_inet_egress multi           sd_fw_egress                   
    301      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4aa39b8_a91b_4737_bbd6_6b899e1a5046.slice/cri-containerd-15c0db224a930557dee5eab47694931e090ae60d22ee88fa8cb65f5bd43c3801.scope
    201      cgroup_inet_ingress multi           sd_fw_ingress                  
    200      cgroup_inet_egress multi           sd_fw_egress                   
    204      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod3679cb86_735f_49bf_a560_3c5a7fc5ec0d.slice
    1539     cgroup_inet_ingress multi           sd_fw_ingress                  
    1538     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod3679cb86_735f_49bf_a560_3c5a7fc5ec0d.slice/cri-containerd-b2003f4fbeb8ca01a5b664cbd3c000ab184bb416437969edb1f40fd699cf3801.scope
    1548     cgroup_inet_ingress multi           sd_fw_ingress                  
    1547     cgroup_inet_egress multi           sd_fw_egress                   
    1553     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod3679cb86_735f_49bf_a560_3c5a7fc5ec0d.slice/cri-containerd-a3fe580a4939f6bb26f3d2514685c50a0d4a72b02393865e0da7d351e5574001.scope
    1775     cgroup_inet_ingress multi           sd_fw_ingress                  
    1774     cgroup_inet_egress multi           sd_fw_egress                   
    1778     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice
    2732     cgroup_inet_ingress multi           sd_fw_ingress                  
    2731     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod955f2bb5_ea0b_4cd2_9f0c_cc5debfccc08.slice
    1656     cgroup_inet_ingress multi           sd_fw_ingress                  
    1655     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod955f2bb5_ea0b_4cd2_9f0c_cc5debfccc08.slice/cri-containerd-62f384d55d1a29489cd62b7154fb13b3f275852d6b3cce6fbd65de4938bb3fb2.scope
    1661     cgroup_inet_ingress multi           sd_fw_ingress                  
    1660     cgroup_inet_egress multi           sd_fw_egress                   
    1664     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod955f2bb5_ea0b_4cd2_9f0c_cc5debfccc08.slice/cri-containerd-c6a922aaac0610c5bd31f3640f7be1b35b983ec92620122f017cb8fcf867fc87.scope
    1713     cgroup_inet_ingress multi           sd_fw_ingress                  
    1712     cgroup_inet_egress multi           sd_fw_egress                   
    1716     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91b2d7cf_e4ed_44dc_a705_da8bd9f77a41.slice
    1589     cgroup_inet_ingress multi           sd_fw_ingress                  
    1588     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91b2d7cf_e4ed_44dc_a705_da8bd9f77a41.slice/cri-containerd-0565943388e944d9cfcad4dae1faf1c26d6f1621b1ae44a28fb7e8f6127f23e9.scope
    1741     cgroup_inet_ingress multi           sd_fw_ingress                  
    1740     cgroup_inet_egress multi           sd_fw_egress                   
    1744     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91b2d7cf_e4ed_44dc_a705_da8bd9f77a41.slice/cri-containerd-7150a121ae388a896b76c394f7141bf6b156ffa47c2bea56d59c924b71ee01b4.scope
    1594     cgroup_inet_ingress multi           sd_fw_ingress                  
    1593     cgroup_inet_egress multi           sd_fw_egress                   
    1597     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5c5a9b3_fb4d_4d34_b491_c9af8de5e30b.slice
    1480     cgroup_inet_ingress multi           sd_fw_ingress                  
    1479     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5c5a9b3_fb4d_4d34_b491_c9af8de5e30b.slice/cri-containerd-e1e18caf4fc9ff180ef674bf56f301f032f96e8e06254ea7fc5cba292d86ee42.scope
    1923     cgroup_inet_ingress multi           sd_fw_ingress                  
    1922     cgroup_inet_egress multi           sd_fw_egress                   
    1926     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5c5a9b3_fb4d_4d34_b491_c9af8de5e30b.slice/cri-containerd-184d273eabf1c0a9b08baac80f0fe56a9e65084ecec8ef2617511af30b5910a2.scope
    1485     cgroup_inet_ingress multi           sd_fw_ingress                  
    1484     cgroup_inet_egress multi           sd_fw_egress                   
    1488     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57ea01af_2084_48cf_802b_3eb5ecb9912c.slice
    1414     cgroup_inet_ingress multi           sd_fw_ingress                  
    1413     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57ea01af_2084_48cf_802b_3eb5ecb9912c.slice/cri-containerd-6c6742e16d494dcf88362a1e94335021cd6ff3856160f1d27864fd6b81450f82.scope
    1419     cgroup_inet_ingress multi           sd_fw_ingress                  
    1418     cgroup_inet_egress multi           sd_fw_egress                   
    1422     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57ea01af_2084_48cf_802b_3eb5ecb9912c.slice/cri-containerd-dc6bd200a20a68ac0141b1fe135bed884a793ec8459abdfdc67a072c662b0c48.scope
    1729     cgroup_inet_ingress multi           sd_fw_ingress                  
    1728     cgroup_inet_egress multi           sd_fw_egress                   
    1732     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79bc45c7_45c5_460c_8da6_d6e832c83522.slice
    1404     cgroup_inet_ingress multi           sd_fw_ingress                  
    1403     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79bc45c7_45c5_460c_8da6_d6e832c83522.slice/cri-containerd-15167af9eff3b086853b69a92d854c8f446b2716c8c529c6753df6698e49b8ee.scope
    1899     cgroup_inet_ingress multi           sd_fw_ingress                  
    1898     cgroup_inet_egress multi           sd_fw_egress                   
    1902     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79bc45c7_45c5_460c_8da6_d6e832c83522.slice/cri-containerd-58085068c9ea31ac82a3f7de2daf5504877478e814ee833bd4582008b30ff571.scope
    1409     cgroup_inet_ingress multi           sd_fw_ingress                  
    1408     cgroup_inet_egress multi           sd_fw_egress                   
    1412     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcf029ae_9eec_4f02_82c7_9e1ee5d35f52.slice
    1394     cgroup_inet_ingress multi           sd_fw_ingress                  
    1393     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcf029ae_9eec_4f02_82c7_9e1ee5d35f52.slice/cri-containerd-2ec8d9d65c5051090c5173b5a793659c23324fbc7015399c84dbff32e44b5281.scope
    1863     cgroup_inet_ingress multi           sd_fw_ingress                  
    1862     cgroup_inet_egress multi           sd_fw_egress                   
    1866     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcf029ae_9eec_4f02_82c7_9e1ee5d35f52.slice/cri-containerd-6bf4ce8b9dadc24f43b62fe97df4918efad814075492ab92ea2d4edcf3675472.scope
    1399     cgroup_inet_ingress multi           sd_fw_ingress                  
    1398     cgroup_inet_egress multi           sd_fw_egress                   
    1402     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f500075_8c38_41d0_997c_7f43c053824b.slice
    208      cgroup_inet_ingress multi           sd_fw_ingress                  
    207      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f500075_8c38_41d0_997c_7f43c053824b.slice/cri-containerd-527bda372883ec8d2abf05d644d9c8ab9e1bdaf3a9c236977ec478abf03cc8fa.scope
    213      cgroup_inet_ingress multi           sd_fw_ingress                  
    212      cgroup_inet_egress multi           sd_fw_egress                   
    216      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f500075_8c38_41d0_997c_7f43c053824b.slice/cri-containerd-62a9ee524f961479faad83d2e8b3e66e829a0f573244b6b6c451efd23b2ea78a.scope
    225      cgroup_inet_ingress multi           sd_fw_ingress                  
    224      cgroup_inet_egress multi           sd_fw_egress                   
    228      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode73d0124_199c_4560_91f9_7c32ba302000.slice
    2334     cgroup_inet_ingress multi           sd_fw_ingress                  
    2333     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode73d0124_199c_4560_91f9_7c32ba302000.slice/cri-containerd-d501b576e1b3b7fba8760c85a5e46b04e90362f7703050c94a4fc29fe8333591.scope
    2339     cgroup_inet_ingress multi           sd_fw_ingress                  
    2338     cgroup_inet_egress multi           sd_fw_egress                   
    2342     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode73d0124_199c_4560_91f9_7c32ba302000.slice/cri-containerd-1e0d6ab256470a003cdf4a3265501004dc4596c9529f4522ea2c29e6e7ea8b4b.scope
    2347     cgroup_inet_ingress multi           sd_fw_ingress                  
    2346     cgroup_inet_egress multi           sd_fw_egress                   
    2350     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f0d762_5c6b_4672_8a24_711193064fc2.slice
    1371     cgroup_inet_ingress multi           sd_fw_ingress                  
    1370     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f0d762_5c6b_4672_8a24_711193064fc2.slice/cri-containerd-109dd775d98d9a19e1d98265269fff62709bfbe6bc2225c6bb1cccdd931f928a.scope
    1931     cgroup_inet_ingress multi           sd_fw_ingress                  
    1930     cgroup_inet_egress multi           sd_fw_egress                   
    1934     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f0d762_5c6b_4672_8a24_711193064fc2.slice/cri-containerd-0b4942bc7e6507ccd2f488a7f3cefefaaffe1a4e51d69907e1aaa6dbc39224c2.scope
    1376     cgroup_inet_ingress multi           sd_fw_ingress                  
    1375     cgroup_inet_egress multi           sd_fw_egress                   
    1379     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc13e077c_0db8_414e_9837_72b27fed4816.slice
    922      cgroup_inet_ingress multi           sd_fw_ingress                  
    921      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc13e077c_0db8_414e_9837_72b27fed4816.slice/cri-containerd-611adfd18427a7e18555b34c69216df249ccfdc48cc49035ef5e7cf34eb30f5b.scope
    1693     cgroup_inet_ingress multi           sd_fw_ingress                  
    1692     cgroup_inet_egress multi           sd_fw_egress                   
    1696     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc13e077c_0db8_414e_9837_72b27fed4816.slice/cri-containerd-b3b1d206b9baae51ea6e81e4d62d765070bb1fc0768544b155ac569424bdaf3b.scope
    927      cgroup_inet_ingress multi           sd_fw_ingress                  
    926      cgroup_inet_egress multi           sd_fw_egress                   
    930      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4553a32c_66c4_4de1_9f9f_49d5114d8f60.slice
    1460     cgroup_inet_ingress multi           sd_fw_ingress                  
    1459     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4553a32c_66c4_4de1_9f9f_49d5114d8f60.slice/cri-containerd-29ca3f463fb6dcc62e261fad54f9f08d5de34ede0c6230313b68055171b2ca2e.scope
    1465     cgroup_inet_ingress multi           sd_fw_ingress                  
    1464     cgroup_inet_egress multi           sd_fw_egress                   
    1468     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4553a32c_66c4_4de1_9f9f_49d5114d8f60.slice/cri-containerd-4bb69f8236d3ddacebd892350e5aaff7ca1fd54d58ff7136ee76e7ffed308512.scope
    1915     cgroup_inet_ingress multi           sd_fw_ingress                  
    1914     cgroup_inet_egress multi           sd_fw_egress                   
    1918     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode13f20a4_22d9_448a_aea9_da97a332c7e0.slice
    1447     cgroup_inet_ingress multi           sd_fw_ingress                  
    1446     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode13f20a4_22d9_448a_aea9_da97a332c7e0.slice/cri-containerd-828072d554f43bc6d6916479504418baf61aacae76ba095c5eb27222d1a1b5fc.scope
    1455     cgroup_inet_ingress multi           sd_fw_ingress                  
    1454     cgroup_inet_egress multi           sd_fw_egress                   
    1458     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode13f20a4_22d9_448a_aea9_da97a332c7e0.slice/cri-containerd-f453ba073e1c6c436fbdb6dae8ed96eae61e29efb01dae5a289beda39e18c3f2.scope
    1871     cgroup_inet_ingress multi           sd_fw_ingress                  
    1870     cgroup_inet_egress multi           sd_fw_egress                   
    1874     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice
    1028     cgroup_inet_ingress multi           sd_fw_ingress                  
    1027     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice/cri-containerd-f36a9d1e9466dd2a37c9719da11f13e6835655cec89e891b5dd51aac5f4b7ee3.scope
    1791     cgroup_inet_ingress multi           sd_fw_ingress                  
    1790     cgroup_inet_egress multi           sd_fw_egress                   
    1794     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice/cri-containerd-c27319099549875b891b534c5faf1562ae6288660a14f03511a3879567b422c2.scope
    1033     cgroup_inet_ingress multi           sd_fw_ingress                  
    1032     cgroup_inet_egress multi           sd_fw_egress                   
    1036     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3549abc9_80c2_490f_a8a6_0d4f3b01b4f4.slice/cri-containerd-8386611406a3294ed71a626960ada13109bdc79087941fd16ae70b3f13f1c74b.scope
    1673     cgroup_inet_ingress multi           sd_fw_ingress                  
    1672     cgroup_inet_egress multi           sd_fw_egress                   
    1676     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice
    1470     cgroup_inet_ingress multi           sd_fw_ingress                  
    1469     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-cf6cb019fe94c4b641a9251537a752a90855bebfab224b500dd28eabe7d2227c.scope
    1907     cgroup_inet_ingress multi           sd_fw_ingress                  
    1906     cgroup_inet_egress multi           sd_fw_egress                   
    1910     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-9df8b44d7d27ec373dff4568fd343b50f3d3db193ee7a82e4a6d0f4210fd5b6e.scope
    1475     cgroup_inet_ingress multi           sd_fw_ingress                  
    1474     cgroup_inet_egress multi           sd_fw_egress                   
    1478     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-a8cecb147bb6cf1a1447a09c8bcf9122e434575520321eef01852bc7d7608cc2.scope
    1759     cgroup_inet_ingress multi           sd_fw_ingress                  
    1758     cgroup_inet_egress multi           sd_fw_egress                   
    1762     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38131090_0da9_485b_9ffb_2c13fff3e444.slice/cri-containerd-532a1c89b8d72d54ba28381e4de677dc6e933b6cef306b9e4aae6f3b4292b9ed.scope
    1751     cgroup_inet_ingress multi           sd_fw_ingress                  
    1750     cgroup_inet_egress multi           sd_fw_egress                   
    1754     cgroup_device   multi                                          
