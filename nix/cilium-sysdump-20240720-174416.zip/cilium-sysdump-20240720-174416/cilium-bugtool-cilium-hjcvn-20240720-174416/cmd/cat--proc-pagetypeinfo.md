Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      0      0      0      0      0      0      0      1      0      0      0 
Node    0, zone      DMA, type      Movable      0      0      0      0      0      0      0      0      0      1      3 
Node    0, zone      DMA, type  Reclaimable      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type    Unmovable    258     64     68     88     28     13      7      1      1      1      0 
Node    0, zone    DMA32, type      Movable      3      3     26      1      0      0      1      0      0      1      6 
Node    0, zone    DMA32, type  Reclaimable    160     45     25     28     17      5      6      3      3      0      1 
Node    0, zone    DMA32, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      0     13     67     11      7      4      2      0      3      2      0 
Node    0, zone   Normal, type      Movable      1      1      0      1      1      0     21     27      8      3      9 
Node    0, zone   Normal, type  Reclaimable    200    100     21     58     66     34     13      1      2      2      0 
Node    0, zone   Normal, type   HighAtomic     67     93     79     58     30     12      3      0      2      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA            1            7            0            0            0            0 
Node 0, zone    DMA32           70          904           42            0            0            0 
Node 0, zone   Normal           52          902           60           10            0            0 
