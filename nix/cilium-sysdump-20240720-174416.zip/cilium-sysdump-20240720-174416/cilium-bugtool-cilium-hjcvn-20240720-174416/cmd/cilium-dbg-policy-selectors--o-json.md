[
  {
    "identities": [
      30951
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "source": "k8s",
        "value": "NetworkPolicy"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "source": "k8s",
        "value": "rke2-argocd-repo-server"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "source": "k8s",
        "value": "argocd"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "source": "k8s",
        "value": "44e84fdf-5ef5-4516-8cf8-2e5e1e3f3523"
      }
    ],
    "selector": "\u0026LabelSelector{MatchLabels:map[string]string{k8s.app.kubernetes.io/instance: rke2-argocd,k8s.app.kubernetes.io/name: argocd-application-controller,k8s.io.kubernetes.pod.namespace: argocd,},MatchExpressions:[]LabelSelectorRequirement{},}",
    "users": 1
  },
  {
    "identities": [
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      1111,
      1344,
      2139,
      3394,
      3859,
      9426,
      10448,
      11758,
      13815,
      14678,
      15581,
      16381,
      16822,
      21496,
      24197,
      29667,
      29762,
      30951,
      33708,
      50180,
      50725,
      53865
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "source": "k8s",
        "value": "NetworkPolicy"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "source": "k8s",
        "value": "rke2-argocd-server"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "source": "k8s",
        "value": "argocd"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "source": "k8s",
        "value": "d6baf548-03ff-49f8-93db-5f25fa513dc6"
      }
    ],
    "selector": "\u0026LabelSelector{MatchLabels:map[string]string{},MatchExpressions:[]LabelSelectorRequirement{},}",
    "users": 1
  },
  {
    "identities": [
      33708
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "source": "k8s",
        "value": "NetworkPolicy"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "source": "k8s",
        "value": "rke2-argocd-dex-server"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "source": "k8s",
        "value": "argocd"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "source": "k8s",
        "value": "0ca9b40f-9a3f-4ecd-bb56-154eebd0bf62"
      }
    ],
    "selector": "\u0026LabelSelector{MatchLabels:map[string]string{k8s.app.kubernetes.io/instance: rke2-argocd,k8s.app.kubernetes.io/name: argocd-server,k8s.io.kubernetes.pod.namespace: argocd,},MatchExpressions:[]LabelSelectorRequirement{},}",
    "users": 3
  },
  {
    "identities": [
      1111,
      1344,
      2139,
      3394,
      3859,
      9426,
      10448,
      11758,
      13815,
      14678,
      15581,
      16381,
      16822,
      21496,
      24197,
      29667,
      29762,
      30951,
      33708,
      50180,
      50725,
      53865
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "source": "k8s",
        "value": "NetworkPolicy"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "source": "k8s",
        "value": "rke2-argocd-application-controller"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "source": "k8s",
        "value": "argocd"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "source": "k8s",
        "value": "d14d3df5-1c32-43ce-9f4b-9fd13f1cacf6"
      }
    ],
    "selector": "\u0026LabelSelector{MatchLabels:map[string]string{},MatchExpressions:[]LabelSelectorRequirement{LabelSelectorRequirement{Key:k8s.io.kubernetes.pod.namespace,Operator:Exists,Values:[],},},}",
    "users": 1
  }
]

