KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [private   10.22.30.21 fe80::5054:ff:fe86:13c3 (Direct Routing), public   10.22.20.21 fe80::5054:ff:fea6:3e20]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 18/254 allocated from 10.55.3.0/24, 
Allocated addresses:
  10.55.3.12 (kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs)
  10.55.3.129 (kube-system/hubble-ui-6969854c48-vkb2p)
  10.55.3.164 (cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8)
  10.55.3.167 (kube-system/hubble-relay-6f89c7f794-xdxwj)
  10.55.3.19 (argocd/rke2-argocd-dex-server-76bb6677d7-8rntq)
  10.55.3.206 (router)
  10.55.3.209 (health)
  10.55.3.210 (kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c)
  10.55.3.218 (kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c)
  10.55.3.23 (argocd/rke2-argocd-repo-server-7bf6499cb6-jh2wl)
  10.55.3.251 (ingress)
  10.55.3.252 (argocd/rke2-argocd-application-controller-654f4c59bd-m5tpw)
  10.55.3.253 (argocd/rke2-argocd-redis-ha-server-0)
  10.55.3.27 (kube-system/rke2-metrics-server-655477f655-khcbm)
  10.55.3.50 (argocd/rke2-argocd-repo-server-7bf6499cb6-lpnlc)
  10.55.3.60 (argocd/rke2-argocd-server-b55ff85f8-26zmv)
  10.55.3.78 (argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm)
  10.55.3.90 (argocd/rke2-argocd-server-b55ff85f8-fmtn7)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [private, public]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [private, public]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      96/96 healthy
  Name                                                                              Last success   Last error     Count   Message
  cilium-health-ep                                                                  23s ago        never          0       no error   
  dns-garbage-collector-job                                                         25s ago        never          0       no error   
  endpoint-1192-regeneration-recovery                                               never          never          0       no error   
  endpoint-1202-regeneration-recovery                                               never          never          0       no error   
  endpoint-1301-regeneration-recovery                                               never          never          0       no error   
  endpoint-1812-regeneration-recovery                                               never          never          0       no error   
  endpoint-2033-regeneration-recovery                                               never          never          0       no error   
  endpoint-2117-regeneration-recovery                                               never          never          0       no error   
  endpoint-2507-regeneration-recovery                                               never          never          0       no error   
  endpoint-2654-regeneration-recovery                                               never          never          0       no error   
  endpoint-2722-regeneration-recovery                                               never          never          0       no error   
  endpoint-2992-regeneration-recovery                                               never          never          0       no error   
  endpoint-3073-regeneration-recovery                                               never          never          0       no error   
  endpoint-3150-regeneration-recovery                                               never          never          0       no error   
  endpoint-3677-regeneration-recovery                                               never          never          0       no error   
  endpoint-3706-regeneration-recovery                                               never          never          0       no error   
  endpoint-3811-regeneration-recovery                                               never          never          0       no error   
  endpoint-3979-regeneration-recovery                                               never          never          0       no error   
  endpoint-709-regeneration-recovery                                                never          never          0       no error   
  endpoint-924-regeneration-recovery                                                never          never          0       no error   
  endpoint-gc                                                                       2m26s ago      never          0       no error   
  ep-bpf-prog-watchdog                                                              23s ago        never          0       no error   
  ipcache-inject-labels                                                             24s ago        3h12m25s ago   0       no error   
  k8s-heartbeat                                                                     22s ago        never          0       no error   
  link-cache                                                                        8s ago         never          0       no error   
  resolve-identity-1192                                                             51s ago        never          0       no error   
  resolve-identity-1202                                                             53s ago        never          0       no error   
  resolve-identity-1301                                                             54s ago        never          0       no error   
  resolve-identity-1812                                                             53s ago        never          0       no error   
  resolve-identity-2033                                                             2m24s ago      never          0       no error   
  resolve-identity-2117                                                             53s ago        never          0       no error   
  resolve-identity-2507                                                             1m39s ago      never          0       no error   
  resolve-identity-2654                                                             2m23s ago      never          0       no error   
  resolve-identity-2722                                                             1m37s ago      never          0       no error   
  resolve-identity-2992                                                             2m24s ago      never          0       no error   
  resolve-identity-3073                                                             52s ago        never          0       no error   
  resolve-identity-3150                                                             55s ago        never          0       no error   
  resolve-identity-3677                                                             1m40s ago      never          0       no error   
  resolve-identity-3706                                                             53s ago        never          0       no error   
  resolve-identity-3811                                                             51s ago        never          0       no error   
  resolve-identity-3979                                                             31s ago        never          0       no error   
  resolve-identity-709                                                              53s ago        never          0       no error   
  resolve-identity-924                                                              50s ago        never          0       no error   
  resolve-labels-argocd/rke2-argocd-application-controller-654f4c59bd-m5tpw         3h5m54s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-dex-server-76bb6677d7-8rntq                     3h5m55s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm               3h5m53s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-redis-ha-server-0                               3h5m53s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-repo-server-7bf6499cb6-jh2wl                    3h5m52s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-repo-server-7bf6499cb6-lpnlc                    3h5m54s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-server-b55ff85f8-26zmv                          3h5m53s ago    never          0       no error   
  resolve-labels-argocd/rke2-argocd-server-b55ff85f8-fmtn7                          3h5m53s ago    never          0       no error   
  resolve-labels-cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8                 3h5m51s ago    never          0       no error   
  resolve-labels-kube-system/hubble-relay-6f89c7f794-xdxwj                          3h11m40s ago   never          0       no error   
  resolve-labels-kube-system/hubble-ui-6969854c48-vkb2p                             3h11m37s ago   never          0       no error   
  resolve-labels-kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c   3h11m39s ago   never          0       no error   
  resolve-labels-kube-system/rke2-metrics-server-655477f655-khcbm                   3h5m51s ago    never          0       no error   
  resolve-labels-kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs              3h5m31s ago    never          0       no error   
  resolve-labels-kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c      3h5m50s ago    never          0       no error   
  sync-host-ips                                                                     24s ago        never          0       no error   
  sync-lb-maps-with-k8s-services                                                    3h12m24s ago   never          0       no error   
  sync-policymap-1192                                                               5m51s ago      never          0       no error   
  sync-policymap-1202                                                               5m53s ago      never          0       no error   
  sync-policymap-1301                                                               5m54s ago      never          0       no error   
  sync-policymap-1812                                                               5m53s ago      never          0       no error   
  sync-policymap-2117                                                               5m53s ago      never          0       no error   
  sync-policymap-2507                                                               11m39s ago     never          0       no error   
  sync-policymap-2654                                                               12m21s ago     never          0       no error   
  sync-policymap-2722                                                               11m37s ago     never          0       no error   
  sync-policymap-2992                                                               12m22s ago     never          0       no error   
  sync-policymap-3073                                                               5m52s ago      never          0       no error   
  sync-policymap-3150                                                               5m55s ago      never          0       no error   
  sync-policymap-3677                                                               11m40s ago     never          0       no error   
  sync-policymap-3706                                                               5m53s ago      never          0       no error   
  sync-policymap-3811                                                               5m51s ago      never          0       no error   
  sync-policymap-3979                                                               5m31s ago      never          0       no error   
  sync-policymap-709                                                                5m53s ago      never          0       no error   
  sync-policymap-924                                                                5m50s ago      never          0       no error   
  sync-to-k8s-ciliumendpoint (1192)                                                 10s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (1202)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (1301)                                                 3s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (1812)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (2117)                                                 12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (2507)                                                 8s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (2722)                                                 6s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (3073)                                                 11s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3150)                                                 4s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (3677)                                                 9s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (3706)                                                 3s ago         never          0       no error   
  sync-to-k8s-ciliumendpoint (3811)                                                 10s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (3979)                                                 10s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (709)                                                  12s ago        never          0       no error   
  sync-to-k8s-ciliumendpoint (924)                                                  9s ago         never          0       no error   
  sync-utime                                                                        24s ago        never          0       no error   
  template-dir-watcher                                                              never          never          0       no error   
  update-k8s-node-annotations                                                       3h12m25s ago   never          0       no error   
  write-cni-file                                                                    3h12m24s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.3.206, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 152.57   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                private   10.22.30.21 fe80::5054:ff:fe86:13c3 (Direct Routing), public   10.22.20.21 fe80::5054:ff:fea6:3e20
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                     Disabled        
Cluster health:                 6/6 reachable   (2024-07-20T17:44:00Z)
  Name                          IP              Node        Endpoints
  hetzner/worker1 (localhost)   10.22.30.21     reachable   reachable
  hetzner/master1               10.22.30.11     reachable   reachable
  hetzner/master2               10.22.30.12     reachable   reachable
  hetzner/master3               10.22.30.13     reachable   reachable
  hetzner/worker2               10.22.30.22     reachable   reachable
  hetzner/worker3               10.22.30.23     reachable   reachable
Modules Health:
agent
├── controlplane
│   ├── node-manager
│   │   ├── background-sync                                 [OK] Node validation successful (3h12m, x101)
│   │   ├── nodes-add                                       [OK] Node adds successful (3h12m, x6)
│   │   └── nodes-update                                    [OK] Node updates successful (3h2m, x2)
│   ├── auth
│   │   ├── observer-job-auth request-authentication        [OK] Primed (3h12m, x1)
│   │   ├── observer-job-auth gc-identity-events            [OK] OK (1.964µs) [35] (3h12m, x1)
│   │   └── timer-job-auth gc-cleanup                       [OK] OK (17.503µs) (3h12m, x1)
│   ├── bgp-cp
│   │   └── job-diffstore-events                            [OK] Running (3h12m, x2)
│   ├── envoy-proxy
│   │   └── timer-job-version-check                         [OK] OK (3.253739ms) (3h12m, x1)
│   ├── stale-endpoint-cleanup                              [OK]  (3h12m, x1)
│   ├── endpoint-manager
│   │   ├── cilium-endpoint-3979 (kube-system/rke2-snapshot-controller-59cc9cd8f4-s4vrs)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3979) (3h5m, x1115)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x9)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3979 (3h5m, x13)
│   │   ├── cilium-endpoint-3677 (kube-system/hubble-relay-6f89c7f794-xdxwj)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3677) (3h11m, x1151)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h11m, x24)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3677 (3h11m, x13)
│   │   ├── endpoint-gc                                     [OK] endpoint-gc (3h12m, x39)
│   │   ├── cilium-endpoint-2507 (kube-system/rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2507) (3h11m, x1151)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h11m, x22)
│   │   │   └── policymap-sync                              [OK] sync-policymap-2507 (3h11m, x13)
│   │   ├── cilium-endpoint-2992 
│   │   │   ├── policymap-sync                              [OK] sync-policymap-2992 (3h12m, x13)
│   │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h12m, x26)
│   │   ├── cilium-endpoint-2722 (kube-system/hubble-ui-6969854c48-vkb2p)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2722) (3h11m, x1151)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h11m, x21)
│   │   │   └── policymap-sync                              [OK] sync-policymap-2722 (3h11m, x13)
│   │   ├── cilium-endpoint-3150 (argocd/rke2-argocd-dex-server-76bb6677d7-8rntq)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3150) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x17)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3150 (3h5m, x13)
│   │   ├── cilium-endpoint-1301 (argocd/rke2-argocd-application-controller-654f4c59bd-m5tpw)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1301) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-1301 (3h5m, x13)
│   │   ├── cilium-endpoint-2033 
│   │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h12m, x26)
│   │   ├── cilium-endpoint-3706 (argocd/rke2-argocd-repo-server-7bf6499cb6-lpnlc)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3706) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3706 (3h5m, x13)
│   │   ├── cilium-endpoint-709 (argocd/rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (709) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-709 (3h5m, x13)
│   │   ├── cilium-endpoint-1812 (argocd/rke2-argocd-server-b55ff85f8-26zmv)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1812) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-1812 (3h5m, x13)
│   │   ├── cilium-endpoint-2117 (argocd/rke2-argocd-server-b55ff85f8-fmtn7)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2117) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-2117 (3h5m, x13)
│   │   ├── cilium-endpoint-1202 (argocd/rke2-argocd-redis-ha-server-0)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1202) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x16)
│   │   │   └── policymap-sync                              [OK] sync-policymap-1202 (3h5m, x13)
│   │   ├── cilium-endpoint-3073 (argocd/rke2-argocd-repo-server-7bf6499cb6-jh2wl)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3073) (3h5m, x1117)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x15)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3073 (3h5m, x13)
│   │   ├── cilium-endpoint-1192 (kube-system/rke2-metrics-server-655477f655-khcbm)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1192) (3h5m, x1116)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x14)
│   │   │   └── policymap-sync                              [OK] sync-policymap-1192 (3h5m, x13)
│   │   ├── cilium-endpoint-3811 (cert-manager/rke2-origin-ca-issuer-7bd586658-pmrc8)
│   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3811) (3h5m, x1116)
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x14)
│   │   │   └── policymap-sync                              [OK] sync-policymap-3811 (3h5m, x13)
│   │   ├── cilium-endpoint-2654 
│   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h12m, x26)
│   │   │   └── policymap-sync                              [OK] sync-policymap-2654 (3h12m, x13)
│   │   └── cilium-endpoint-924 (kube-system/rke2-snapshot-validation-webhook-54c5989b65-v2s9c)
│   │       ├── policymap-sync                              [OK] sync-policymap-924 (3h5m, x13)
│   │       ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (924) (3h5m, x1116)
│   │       └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h5m, x13)
│   ├── daemon
│   │   └── ep-bpf-prog-watchdog                            [OK] ep-bpf-prog-watchdog (3h12m, x385)
│   └── l2-announcer
│       └── leader-election                                 [OK]  (3h12m, x1)
└── datapath
    ├── l2-responder
    │   └── job-l2-responder-reconciler                     [OK] Running (3h12m, x1)
    ├── agent-liveness-updater
    │   └── timer-job-agent-liveness-updater                [OK] OK (18.044µs) (3h12m, x1)
    └── node-address
        └── job-node-address-update                         [OK] 10.55.3.206 (cilium_host), fe80::e421:a4ff:fefc:b9c8 (cilium_host) (3h12m, x1)

