KEY             VALUE
AgentLiveness   12380831605843
UTimeOffset     3362275599609375
