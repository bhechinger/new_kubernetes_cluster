USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3997  0.0  0.0  11980  1940 ?        Rs   17:44   0:00 runc init
root        3984  0.0  0.1 721520  6292 ?        Rsl  17:44   0:00 runc init
root        3947  0.0  0.3 1241008 15488 ?       Ssl  17:44   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3985  0.0  0.0   7064  2816 ?        R    17:44   0:00  \_ ps auxfw
root        3996  0.0  0.0   1392   128 ?        R    17:44   0:00  \_ ip -4 r
root           1  1.2  3.8 1400628 154192 ?      Ssl  14:20   2:34 cilium-agent --config-dir=/tmp/cilium/config-map
root         132  0.0  0.1 1229772 7040 ?        Sl   14:20   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
