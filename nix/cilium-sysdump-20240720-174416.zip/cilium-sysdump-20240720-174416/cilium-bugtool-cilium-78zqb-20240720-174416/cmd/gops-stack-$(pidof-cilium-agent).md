goroutine 29 [running]:
runtime/pprof.writeGoroutineStacks({0x3f07700, 0xc000c74000})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x6a
runtime/pprof.writeGoroutine({0x3f07700?, 0xc000c74000?}, 0xc0023e0000?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x25
runtime/pprof.(*Profile).WriteTo(0x394e735?, {0x3f07700?, 0xc000c74000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x146
github.com/google/gops/agent.handle({0x7fb44e7c1910?, 0xc000c74000}, {0xc00117c000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xd2
github.com/google/gops/agent.listen({0x3f44240, 0xc00144a360})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1a5
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x379

goroutine 1 [select, 203 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc0001c7a40)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:232 +0x16e
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc0001c7a40)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:216 +0x112
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0xc000840300?, {0x3940fc9?, 0x4?, 0x3940e35?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:39 +0x17b
github.com/spf13/cobra.(*Command).execute(0xc0001ca300, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:987 +0xaa3
github.com/spf13/cobra.(*Command).ExecuteC(0xc0001ca300)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1115 +0x3ff
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1039
github.com/cilium/cilium/daemon/cmd.Execute(0xc0001c7a40?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:79 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x57

goroutine 220 [chan receive, 5 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0xc001742820, {0x3f59438?, 0xc000832ff0?}, 0xc000547a00?)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xae
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:106 +0x31
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:105 +0x2c5

goroutine 38 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000903c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 49 [select, 203 minutes]:
io.(*pipe).read(0xc0003b1260, {0xc001824000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x7fb44ea53318?, {0xc001824000?, 0x410ba5?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000091728)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc000886728, 0xc000e12200)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 50 [select, 203 minutes]:
io.(*pipe).read(0xc0003b12c0, {0xc000af0000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc000af0000?, 0x410ba5?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c0ff28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc000886738, 0xc000e12220)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 51 [select, 203 minutes]:
io.(*pipe).read(0xc0003b1320, {0xc000d96000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc000d96000?, 0x410ba5?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c11f28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc000886748, 0xc000e12240)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 52 [select, 203 minutes]:
io.(*pipe).read(0xc0003b1380, {0xc000e38000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0xc000092e20?, {0xc000e38000?, 0x410ba5?, 0x10000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000c12f28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc000886758, 0xc000e12260)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 172 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0006b3400, {{{0x395f226, 0xd}}, {0x0, 0x0}, 0xc000ad00e0, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 56 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x58
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x90

goroutine 30 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4fdb8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000670100?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000670100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000670100)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000ad0040)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000ad0040)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc00013a3c0, {0x3f44240, 0xc000ad0040})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc00013a3c0)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xa8
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xc5

goroutine 1186 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc001b76870, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x5c9
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1113
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x145

goroutine 167 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000dcedc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 169 [chan receive, 97 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:151 +0x71
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:145 +0x67

goroutine 170 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000dcee60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 171 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000dcef00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 179 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44ec4fcc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001f71e80?, 0xc001e8a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001f71e80, {0xc001e8a000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001f71e80, {0xc001e8a000?, 0x33ccd60?, 0xc00144a720?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015a06b8, {0xc001e8a000?, 0xc001e8a000?, 0x5?})
	/usr/local/go/src/net/net.go:179 +0x45
crypto/tls.(*atLeastReader).Read(0xc003b15698, {0xc001e8a000?, 0xc003b15698?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:805 +0x3b
bytes.(*Buffer).ReadFrom(0xc001a1a628, {0x3f0ca20, 0xc003b15698})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001a1a380, {0x7fb44e9dad10?, 0xc001523440}, 0xa000?)
	/usr/local/go/src/crypto/tls/conn.go:827 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc001a1a380, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:625 +0x250
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:587
crypto/tls.(*Conn).Read(0xc001a1a380, {0xc001b75000, 0x1000, 0xf983e9?})
	/usr/local/go/src/crypto/tls/conn.go:1369 +0x158
bufio.(*Reader).Read(0xc001f19f80, {0xc001a08580, 0x9, 0x31ee440?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc001f19f80}, {0xc001a08580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc001a08580, 0x9, 0x9a800?}, {0x3f07920?, 0xc001f19f80?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001a08540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc002075f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2275 +0x11f
golang.org/x/net/http2.(*ClientConn).readLoop(0xc0006b0d80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2170 +0x65
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 178
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:821 +0xcbe

goroutine 241 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 231
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 949 [select, 203 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0029405a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255f2c0, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0001cdbd0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 211 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 192
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 92743 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0027f4c00, 0xc002db4400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x224d7a7?, 0xc001eddce0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 273 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f9d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b99100?, 0x38801a0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b99100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b99100)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x1?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0xc000014300)
	/usr/local/go/src/net/unixsock.go:247 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:58 +0xaf
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:53 +0x136

goroutine 187 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0xc001b724f8, 0x56)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000e71c00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b724d0, 0xc000ca3f80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0000180a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0016c4990}, 0x1, 0xc001960540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00117c260?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0000180a0, 0xc001960540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00144a9c0, 0xc001960540)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 181
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 188 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 181
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 208 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 221
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 175 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 187
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1158 [select, 83 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc0024411e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1138 +0x225
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1156
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:328 +0x18c5

goroutine 193 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 187
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 194 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc001a9e4c0}, {0x7fb44e93c598, 0xc001b724d0}, {0x3f8d658?, 0x38fdc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ef8000, {0x0?, 0x0?}, 0xc001960540, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ef8000, 0xc001960540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001576280?, {0x3f0dec0, 0xc0000c8e60}, 0x1, 0xc001960540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ef8000, 0xc001960540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 187
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 190 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ef8000, 0xc001960540, 0xc00168c7e0, 0x2f73656974726570?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 194
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 94327 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003ee3080, 0xc002dee600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x6ea4a5?, 0xc002c32000?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 194
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 203 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001573260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 220
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 204 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001573380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 220
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 205 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0xc000cc2e90, 0xaa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001573260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc0000c9900}, 0xc001960d20, {0x3f6a9c8, 0xc001523b30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 220
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 192 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001b725a8, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000954640?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b72580, 0xc0013be380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0000181e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000d51740}, 0x1, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001096da0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0000181e0, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00144acc0, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 182
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 209 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 182
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 206 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 220
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 70370 [select, 55 minutes]:
net/http.(*persistConn).writeLoop(0xc001696000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 70352
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 213 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 192
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 214 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc003628740}, {0x7fb44e93c598, 0xc001b72580}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001a087e0, {0x0?, 0x0?}, 0xc00168cd80, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001a087e0, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001b51600?, {0x3f0dec0, 0xc000bea910}, 0x1, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001a087e0, 0xc00168cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 192
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 217 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001a087e0, 0xc00168cd80, 0xc00168d620, 0xc000092710?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 221 [select, 5 minutes]:
github.com/cilium/cilium/pkg/statedb.graveyardWorker(0xc0010c2a80, {0x3f59438, 0xc000beaf00}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/pkg/statedb/graveyard.go:28 +0x136
created by github.com/cilium/cilium/pkg/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/statedb/db.go:231 +0x152

goroutine 1092 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000dd3180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1075
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 223 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 224 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0xc000dce820, 0xc00168dc20, 0xc00168dce0, 0xc00168dd40)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:335 +0x286
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0xc000dce820, {0x3f59438?, 0xc000beb090?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:227 +0x305
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0xc000dce820, {0x3f59438, 0xc000beb090})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:169 +0x97
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:149 +0x156

goroutine 225 [chan receive, 203 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:350 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:349 +0x14f

goroutine 226 [syscall, 13 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc0028e5801?, 0x0?, 0xc001d2fca0?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fb44e7e26f8?, {0xc001d2fd70?, 0x58?, 0xc00009a400?}, 0xc0034bac00?, 0xc0034bac00?, 0x1400000058?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc0034bac00?, {0xc001d2fd70, 0x10000, 0x10000}, 0x6c62616c6c754e08?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc003af41e0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:366 +0x94
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:363 +0x35f

goroutine 227 [chan receive, 203 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1512 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1511 +0x14f

goroutine 228 [syscall, 177 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc00248eb01?, 0x0?, 0xc001d4f878?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fb44e9ca560?, {0xc001d4f948?, 0x3c?, 0xc0005c7400?}, 0xc001577780?, 0xc001577780?, 0x60000180000003c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc001577780?, {0xc001d4f948, 0x10000, 0x10000}, 0x2065636166726574?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x6?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1528 +0x9a
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1525 +0x35f

goroutine 229 [chan receive, 203 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2338 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2337 +0x13e

goroutine 230 [syscall, 203 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc002372501?, 0x0?, 0xc001da1dc8?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7fb44e9408f0?, {0xc001da1e98?, 0x5c4?, 0x60ce8a0?}, 0xc00237b200?, 0xc00237b200?, 0x10000005c4?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc00237b200?, {0xc001da1e98, 0x10000, 0x10000}, 0xc0100b4ff01?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc001db1ef8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2354 +0x7f
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 224
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2351 +0x34f

goroutine 231 [select, 13 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0xc000f62090, {0x3f59400, 0xc000c4f7d0}, {0x3f43ff0?, 0xc000cc30c0})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:260 +0x24b
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001369c80, {0x3f59400, 0xc000c4f7d0}, 0x0?, {0x3f445d0, 0xc0007cfff8}, {{{0x0, 0x0, 0x0}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 232 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4fbc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000c14ba0?, 0xc001d6feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000c14ba0, {0xc001d6feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0015a0f90, {0xc001d6feb0?, 0x3ef8148?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc00157fc00)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 233 [select, 203 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000289b80, {{{0x3963cb9, 0xe}}, {0x0, 0x0}, 0xc0015bede0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 234 [select, 203 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc0018c0000)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0x105
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x3ee

goroutine 274 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x2f
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:75 +0x199

goroutine 275 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f8e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b99280?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b99280)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b99280)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x447380?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc0000159b0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc0005bfa00, {0x3f44270?, 0xc0000159b0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0xa5
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x191

goroutine 269 [syscall, 203 minutes]:
syscall.Syscall6(0xc001ae5960?, 0xc001ae5948?, 0x4e4a5c?, 0xc001edc4b0?, 0x80000000000?, 0xc001ae5960?, 0x4e82e5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0x0?, {0xc000f031e8?, 0x0?, 0x0?}, 0x4e82c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc00046c320, {0xc000f031e8?, 0x2, 0x2}, {0xc001ae5ae8?, 0x73c0d8?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0017e3980, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(0xc00025e930?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328 +0x45
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x82
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x118

goroutine 239 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 238 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94e60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 237 [IO wait, 51 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4fad0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b98f00?, 0x2fd54c0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b98f00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b98f00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x40a19e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc000c7c6f0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc000be9ec0, {0x3f59438?, 0xc0005b7220}, 0xc001553f10?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xe2
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x192

goroutine 248 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 249 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000304000, {{{0x39565a6, 0xb}}, {0x3f43ff0, 0xc000cc3640}, 0xc0017dfb10, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 250 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x2?, 0x2?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c07640?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 251 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001aec200?, 0x247ec1e?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x3b9aca00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 252 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93940)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 253 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94980)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 254 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 463 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x3f94cc0?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 459 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc0001ce000, {0x3f99588, 0xc001065290}, 0xc0012c3900)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:112 +0x585
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:572 +0x51b

goroutine 1157 [select, 83 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000bebb30, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x113
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc00032d1f0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x86
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:325 +0xd2
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1156
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:322 +0x187e

goroutine 460 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit(0xc0001ce000, {0x3f59438, 0xc0009436d0}, 0xc0012c3900)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:79 +0x445
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1045 +0xc5

goroutine 454 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc0010647b8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001df4cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064790, 0xc001516140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ad9ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000ebd9e0}, 0x1, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d0600?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ad9ea0, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000815100, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x25b

goroutine 946 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027c0d20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 944 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 28199 [IO wait, 145 minutes]:
internal/poll.runtime_pollWait(0x7fb44e8efd18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00354cf00?, 0xc002bed000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00354cf00, {0xc002bed000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00354cf00, {0xc002bed000?, 0x703620?, 0xc0033cde00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0002a8068, {0xc002bed000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00257b440, {0xc002bed000?, 0xc0010fa720?, 0xc0033acd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c98900)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c98900, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00257b440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 28198
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1095 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001552fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002567380?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1075
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 264 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 265 [chan receive, 203 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc0007a8a00, {0x3f59438?, 0xc0007a8a50})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x5e
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14a

goroutine 266 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc000dcf0e0, {0x3f59438, 0xc0007a8a50})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:363 +0x31e
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x75
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 265
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4c

goroutine 267 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 237
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xa5

goroutine 270 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446e0, {0x3f59400, 0xc00081ea20?}, 0x0, {0x3f445d0?, 0xc0002a90f0}, {{{0xc00174b480, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 276 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 271 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446a0, {0x3f59400, 0xc00081eae0?}, 0x0, {0x3f445d0?, 0xc0002a90f0}, {{{0xc00174b480, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 272 [select, 5 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001a0e540, {0x3f59400, 0xc00081eb40}, 0x0?, {0x3f445d0, 0xc0002a90f0}, {{{0xc00174b480, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 289 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 671 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0xf4
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 670
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 278 [select, 203 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xd0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 270
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xcc

goroutine 290 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 293 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001aec600?, 0x100000000000000?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000ca1260?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 294 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001ad9180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 295 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc0007c2000)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:237 +0x89
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:207 +0x1b6

goroutine 296 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc0001ce000)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:691 +0xe5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:704 +0x4f

goroutine 297 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000305a40, {{{0x3990b5c, 0x19}}, {0x0, 0x0}, 0xc0015f2550, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 298 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000305b80, {{{0x398150a, 0x15}}, {0x0, 0x0}, 0xc0015f2590, 0x0, 0x3b61ab0, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 334 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018dbec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 332 [select, 97 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc0001ce000, 0xc0012c3910, 0xc001d83f78?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:40 +0x11d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:28 +0x168

goroutine 910 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89aed0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0017bf100?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0017bf100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0017bf100)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc001d80e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc000c24b70)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc002363590, {0x3f44270, 0xc000c24b70})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3f44270?, 0xc000c24b70?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:475 +0x78
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:473 +0x4f9

goroutine 302 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f500, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00016ff00?, 0x697461636f4c2b04?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc00016ff00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc00016ff00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000073c20)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000073c20)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
github.com/cilium/dns.(*Server).serveTCP(0xc000f91500, {0x3f44240?, 0xc000073c20})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x142
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000f91500)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x26c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000f91500)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 303 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44ec4f6f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000de8000?, 0xc000195200?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc000de8000, {0xc000195200, 0x200, 0x200}, {0xc00163ae70, 0x2c, 0x2c}, 0x7fb44e8fd7c8?, 0x5?)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x339
net.(*netFD).readMsgInet4(0xc000de8000, {0xc000195200?, 0x4100ef?, 0x7fb44e8e6d20?}, {0xc00163ae70?, 0xc001d817e8?, 0x44b5d3?}, 0xc0029d9800?, 0xc001d81818?)
	/usr/local/go/src/net/fd_posix.go:84 +0x31
net.(*UDPConn).readMsg(0x3b622b8?, {0xc000195200?, 0x419188?, 0x17f1?}, {0xc00163ae70?, 0x0?, 0xffffffffffffffff?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x15c
net.(*UDPConn).ReadMsgUDPAddrPort(0xc0015ca2f0, {0xc000195200?, 0x7fb44ec4f6f0?, 0x47e538?}, {0xc00163ae70?, 0xc001d81988?, 0x47e325?})
	/usr/local/go/src/net/udpsock.go:203 +0x3e
net.(*UDPConn).ReadMsgUDP(0xc000367500?, {0xc000195200?, 0xc00009a800?, 0xc000f3ca50?}, {0xc00163ae70?, 0xc001d819e8?, 0x410c25?})
	/usr/local/go/src/net/udpsock.go:191 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc0015ca2f0?, 0xc0015ca2f0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x58
github.com/cilium/dns.(*Server).readUDP(0xc000f91600, 0xc0015ca2f0, 0xc003c2e4b0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xeb
github.com/cilium/dns.defaultReader.ReadUDP({0xc000f91600?}, 0x3f07580?, 0xc003c2e4b0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0xc000f91600, {0x3f667c8?, 0xc0015ca2f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x29c
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000f91600)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x1c7
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000f91600)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 4792 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f03e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003192280?, 0xc00317d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003192280, {0xc00317d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003192280, {0xc00317d000?, 0xc002d57ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ee2d0, {0xc00317d000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002539b00, {0xc00317d000?, 0x450260?, 0xc002d57ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003186de0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003186de0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002539b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 4790
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 335 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001538060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 353 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 467 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002c5c140}, {0x7fb44e93c598, 0xc001064790}, {0x3f8d658?, 0x38fe380}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001554d20, {0x0?, 0x0?}, 0xc000ca1920, 0x419188?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001554d20, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000842100?, {0x3f0dec0, 0xc000817f90}, 0x1, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001554d20, 0xc000ca1920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 454
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 357 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001538120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 462 [chan receive, 97 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:53 +0x134
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:48 +0x3d8

goroutine 361 [select, 95 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:42 +0xec
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:40 +0x236

goroutine 363 [select, 45 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPolicyEventLoop(0xc0001ce000, 0xc0012c3950)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:41 +0x129
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NetworkPoliciesInit.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:28 +0x157

goroutine 365 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0015384e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 359 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc0015c3810, 0x93)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001538120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc0007ffa40}, 0xc000d63a40, {0x3f6a708, 0xc00169b098})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 371 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc0016b41d0, 0x29)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0015386c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc000810000}, 0xc000d63f80, {0x3f6aa20, 0xc00169b218})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 332
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 367 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 372 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 332
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 324 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018db380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 43846 [select, 109 minutes]:
net/http.(*persistConn).writeLoop(0xc002156ea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 43844
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 375 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 258
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 374 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc001b72d38, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000d3f9e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b72d10, 0xc0016b4340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000019220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000d43380}, 0x1, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0012c39f0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000019220, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00046dae0, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 258
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 336 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc0015c33d0, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0018dbec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77260, {0x3f59438, 0xc0007ff900}, 0xc000d63800, {0x3f6a8c0, 0xc00169af90})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 354 [select, 97 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:47 +0xc5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:45 +0x1ed

goroutine 466 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 454
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 358 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0015382a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 360 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 940 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001e08fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002566b40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 364 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001538360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 366 [sync.Cond.Wait, 45 minutes]:
sync.runtime_notifyListWait(0xc0015c3c90, 0x3e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001538360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f771e0, {0x3f59438, 0xc0007ffb80}, 0xc000d63c80, {0x3f6a868, 0xc00169b158})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 323 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018db260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 370 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001538840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 332
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 369 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0015386c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 332
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 325 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc0007fed70}, 0xc000d63140, {0x3f6a9c8, 0xc001523b30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:664 +0x5a6
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 326 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 378 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:125 +0x116
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1 in goroutine 355
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0xe5

goroutine 537 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001554d20, 0xc000ca1920, 0xc0019d71a0, 0xc00171f710?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 467
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 475 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc0010649c8, 0x34)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001341ea0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0010649a0, 0xc0015167c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ad9f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010a6660}, 0x1, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d07a0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ad9f40, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000815520, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 263
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 382 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc001b72de8, 0x49)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000814ea0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b72dc0, 0xc0016b43c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0000192c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000742540}, 0x1, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0012ef4b0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0000192c0, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00046db60, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 256
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 383 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 256
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1058 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 6132 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f0000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ef8b00?, 0xc001fae000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ef8b00, {0xc001fae000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ef8b00, {0xc001fae000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ef968, {0xc001fae000?, 0x0?, 0xc00165ed88?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc00165ed80, {0xc001fae000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002e80480)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e80480, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc002161560, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 387 [sync.Cond.Wait, 45 minutes]:
sync.runtime_notifyListWait(0xc001b72e98, 0x1e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00122b680?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b72e70, 0xc0016b4400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000019360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000742a50}, 0x1, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0012ef610?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000019360, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00046dbe0, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 259
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 388 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 259
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 455 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:93 +0x352
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:74 +0x13a

goroutine 391 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc001b72f48, 0x13)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000d3fe60?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b72f20, 0xc0016b4440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000019400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000743800}, 0x1, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0012efa40?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000019400, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00046dc60, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 255
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 392 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 255
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 4797 [select]:
net/http.(*persistConn).writeLoop(0xc00293e000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 4794
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 395 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 94789 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002158648, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc003654d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002158630, {0xc0012ab690, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0012ab690?}, {0xc0012ab690?, 0xc003654ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc002158600}, {0xc0012ab690, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003f2ceb8, {0xc001aff400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002be8a50, 0xc003259320?, {0x3f3b448, 0xc0039f1640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000e65280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000f552c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 398
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 397 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 398 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000f552c0}, {0x7fb44e93c598, 0xc001b72d10}, {0x3f8d658?, 0x38fdfc0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001a09340, {0x0?, 0x0?}, 0xc00157ade0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001a09340, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001655f80?, {0x3f0dec0, 0xc000810ff0}, 0x1, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001a09340, 0xc00157ade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 421 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001a09340, 0xc00157ade0, 0xc0010fbe60, 0x6e65747845726f64?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 398
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 41633 [select, 115 minutes]:
net/http.(*persistConn).writeLoop(0xc0023eb440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 41624
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 341 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00148fe00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 342 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00160c060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 343 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc0016d2110, 0x13)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x4?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00148fe00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f772e0, {0x3f59438, 0xc0007d1950}, 0xc0010fab40, {0x3f6a918, 0xc001b7f080})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 378
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 344 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 378
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 345 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 415 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 391
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 347 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 348 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00266bd80}, {0x7fb44e93c598, 0xc001b72dc0}, {0x3f8d658?, 0x38ffa00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ef8ee0, {0x0?, 0x0?}, 0xc0010facc0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ef8ee0, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00093f680?, {0x3f0dec0, 0xc0007d19f0}, 0x1, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ef8ee0, 0xc0010facc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 433 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ef8ee0, 0xc0010facc0, 0xc00157b260, 0xc0019bcf10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 348
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 351 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 387
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 409 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 405
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 401 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 387
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 402 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0012a2040}, {0x7fb44e93c598, 0xc001b72e70}, {0x3f8d658?, 0x38feec0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ef9260, {0x0?, 0x0?}, 0xc0010fafc0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ef9260, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00093fc40?, {0x3f0dec0, 0xc0007d1ae0}, 0x1, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ef9260, 0xc0010fafc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 387
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 436 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ef9260, 0xc0010fafc0, 0xc00157b800, 0xc001e05fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 93614 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002ca8180, 0xc002db5400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc00203a2a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 534
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 405 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc0001e3418, 0x9)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001600880?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0001e33f0, 0xc0016d2480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ad9540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000743290}, 0x1, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0012ef7c0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ad9540, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0002bd4c0, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 406 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 441 [sync.Cond.Wait, 177 minutes]:
sync.runtime_notifyListWait(0xc001b73208, 0xc)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0010a0500?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b731e0, 0xc0016d6200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000019680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010a6c60}, 0x1, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d0910?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000019680, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc00033abc0, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:110 +0x579

goroutine 411 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 405
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 412 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00302cf80}, {0x7fb44e93c598, 0xc0001e33f0}, {0x3f8d658?, 0x38fd0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ef96c0, {0x0?, 0x0?}, 0xc0010fb440, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ef96c0, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00093ffc0?, {0x3f0dec0, 0xc0007d1ea0}, 0x1, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ef96c0, 0xc0010fb440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 405
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 425 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ef96c0, 0xc0010fb440, 0xc0016bea20, 0xc001e81fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 412
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 37171 [IO wait, 125 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7962e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0033e5880?, 0xc002ebe000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0033e5880, {0xc002ebe000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0033e5880, {0xc002ebe000?, 0x703620?, 0xc00094b680?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001365c88, {0xc002ebe000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0023dd320, {0xc002ebe000?, 0xc002ab5860?, 0xc0028f6d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ecdce0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ecdce0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0023dd320)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 37170
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 28200 [select, 145 minutes]:
net/http.(*persistConn).writeLoop(0xc00257b440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 28198
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 417 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 391
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 418 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002869e80}, {0x7fb44e93c598, 0xc001b72f20}, {0x3f8d658?, 0x38fd480}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ef9a40, {0x0?, 0x0?}, 0xc0010fb860, 0xc0019bcd78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ef9a40, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00027f600?, {0x3f0dec0, 0xc0007d1f40}, 0x1, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ef9a40, 0xc0010fb860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 391
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 423 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ef9a40, 0xc0010fb860, 0xc0016be480, 0xc001df0fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 418
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 70369 [IO wait, 55 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd750, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002c64380?, 0xc0027f6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002c64380, {0xc0027f6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002c64380, {0xc0027f6000?, 0x703620?, 0xc0008fb180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f48f0, {0xc0027f6000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001696000, {0xc0027f6000?, 0xc0034471a0?, 0xc001ea4d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002e267e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e267e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001696000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 70352
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 11265 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7eaec0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0033c7500?, 0xc0033d7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0033c7500, {0xc0033d7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0033c7500, {0xc0033d7000?, 0xc002421ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00151fd70, {0xc0033d7000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0033b10e0, {0xc0033d7000?, 0x450260?, 0xc002421ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0033b7b60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0033b7b60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0033b10e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 11263
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 472 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0017994a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 471 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001799320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 10761 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7eafb8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002e30180?, 0xc000884000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002e30180, {0xc000884000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002e30180, {0xc000884000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6fdf0, {0xc000884000?, 0x0?, 0xc00111a2d8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc00111a2d0, {0xc000884000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0025c9e60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0025c9e60, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0025b6090, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 473 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc001516650, 0x6a)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001799320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76ee0, {0x3f59438, 0xc000848190}, 0xc0016bf980, {0x3f6a658, 0xc0005d1698})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 442 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc00171ff78?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 443 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001808120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 444 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 445 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0016d6510, 0x192)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001808120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77160, {0x3f59438, 0xc000811d10}, 0xc00157be00, {0x3f6a810, 0xc0005d1ce0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 446 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 447 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001808360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 448 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018084e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 481 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc0016d6910, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001808360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f770e0, {0x3f59438, 0xc0008320a0}, 0xc00157bec0, {0x3f6a7b8, 0xc0005d1ab8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 482 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 483 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001b73578, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002112c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b73550, 0xc0016d6a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000019720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010a7b00}, 0x1, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d0d50?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000019720, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00033ad00, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 262
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 484 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 262
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 474 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 7920 [IO wait, 189 minutes]:
internal/poll.runtime_pollWait(0x7fb44e8efe10, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002178080?, 0xc001ec1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002178080, {0xc001ec1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002178080, {0xc001ec1000?, 0x703620?, 0xc000452500?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00151e038, {0xc001ec1000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000ad3c20, {0xc001ec1000?, 0xc00272f260?, 0xc001704d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003040780)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003040780, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000ad3c20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 7919
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 476 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 263
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1062 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 938 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027c0b40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1064 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 5645 [IO wait, 195 minutes]:
internal/poll.runtime_pollWait(0x7fb44e8f01f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0030f3580?, 0xc003227000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0030f3580, {0xc003227000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0030f3580, {0xc003227000?, 0x703620?, 0xc0008fa280?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015e9f40, {0xc003227000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0015605a0, {0xc003227000?, 0xc0030e6f00?, 0xc003170d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003221b60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003221b60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0015605a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 5644
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 478 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0017995c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1175 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000288640, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc000d36240}, 0xc0008617c0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1134
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1065 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001a0f320, {0x3f59400, 0xc000022090}, 0xc002151fd0?, {0x3f445d0, 0xc0015a0080}, {{{0x0, 0x0, 0x0}}, {0x3f8bac0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 479 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001799740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 480 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001516a90, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0017995c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77060, {0x3f59438, 0xc000832190}, 0xc00157bf80, {0x3f6a760, 0xc00169bf68})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 497 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 455
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 499 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 475
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 506 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001064bd8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0020fbc80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064bb0, 0xc001516d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001a02000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010a7230}, 0x1, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d0a90?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001a02000, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000815920, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 261
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 501 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 475
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 502 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc001dd9000}, {0x7fb44e93c598, 0xc0010649a0}, {0x3f8d658?, 0x38c4ac0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001555180, {0x0?, 0x0?}, 0xc0016bfda0, 0x17cf244?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001555180, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000842240?, {0x3f0dec0, 0xc0008483c0}, 0x1, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001555180, 0xc0016bfda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 475
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 598 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001555180, 0xc0016bfda0, 0xc001f86540, 0xc002113fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 14843 [IO wait, 175 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea8f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003434a80?, 0xc0030bf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003434a80, {0xc0030bf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003434a80, {0xc0030bf000?, 0x703620?, 0xc000289180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000c559b8, {0xc0030bf000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00322d9e0, {0xc0030bf000?, 0xc00264f9e0?, 0xc002102d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00320c720)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00320c720, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00322d9e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 14842
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 507 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 261
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1112 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0xc0014a2f30)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1111
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:382 +0x78

goroutine 524 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 514
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 510 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 511 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00148d740}, {0x7fb44e93c598, 0xc001b731e0}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0015556c0, {0x0?, 0x0?}, 0xc00157bce0, 0x17cf244?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0015556c0, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000842280?, {0x3f0dec0, 0xc000848640}, 0x1, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0015556c0, 0xc00157bce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 600 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0015556c0, 0xc00157bce0, 0xc001f86840, 0xc001fdbfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 511
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 32659 [select, 135 minutes]:
net/http.(*persistConn).writeLoop(0xc002487b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 32657
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 514 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc001064c88, 0xc8)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0011d7260?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064c60, 0xc001516e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001a020a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010a7620}, 0x1, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d0bf0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001a020a0, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000815ca0, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 260
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 515 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 260
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 943 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255f180, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc0014a2318, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 518 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 506
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 935 [select, 25 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:166 +0x4bd
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:82 +0xa5

goroutine 520 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 506
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 521 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00319cf80}, {0x7fb44e93c598, 0xc001064bb0}, {0x3f8d658?, 0x38d6500}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001555a40, {0x0?, 0x0?}, 0xc0019d6720, 0x419101?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001555a40, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000842440?, {0x3f0dec0, 0xc000848d20}, 0x1, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001555a40, 0xc0019d6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 506
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 602 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001555a40, 0xc0019d6720, 0xc001f86c00, 0xc0020fdfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 521
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 11261 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7eadc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003402700?, 0xc0033c5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003402700, {0xc0033c5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003402700, {0xc0033c5000?, 0xc002d5cec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00151fcb0, {0xc0033c5000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003400900, {0xc0033c5000?, 0x450260?, 0xc002d5cec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0033b7920)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0033b7920, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003400900)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 11230
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 531 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 483
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 526 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 514
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 527 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0030ea100}, {0x7fb44e93c598, 0xc001064c60}, {0x3f8d658?, 0x38e2420}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001555ea0, {0x0?, 0x0?}, 0xc0019d6a20, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001555ea0, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000842ec0?, {0x3f0dec0, 0xc000848ff0}, 0x1, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001555ea0, 0xc0019d6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 514
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 614 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001555ea0, 0xc0019d6a20, 0xc001905da0, 0xc0019c0710?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 527
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 92744 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0027f4c48, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f375d0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0027f4c30, {0xc0024b2c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0024b2c01?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc00255e8c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00255e8c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc00255e8c0, {0x326cdc0, 0xc002a08108})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc003625710, {0xc001f3dc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003d2e7d0, 0xc002e914a0?, {0x3f3b448, 0xc000907480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000ed9460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001dd9000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 502
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 533 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 483
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 534 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002c8b080}, {0x7fb44e93c598, 0xc001b73550}, {0x3f8d658?, 0x38c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b7a2a0, {0x0?, 0x0?}, 0xc0019d6de0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b7a2a0, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000843180?, {0x3f0dec0, 0xc000849220}, 0x1, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b7a2a0, 0xc0019d6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 483
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 596 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b7a2a0, 0xc0019d6de0, 0xc001f86180, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 534
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 76039 [select, 45 minutes]:
net/http.(*persistConn).writeLoop(0xc003a178c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 76037
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 555 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 556 [select, 203 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:214 +0x1d5
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:204 +0x199

goroutine 1097 [select, 203 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbf040, {{{0x3963da7, 0xe}}, {0x0, 0x0}, 0xc0024322d0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1075
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 622 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:233 +0xf4
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:231 +0x2f8

goroutine 542 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001064d38, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001e03cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064d10, 0xc001517740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001a021e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0011db7a0}, 0x1, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0014d11e0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001a021e0, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc00084ed40, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit in goroutine 490
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x317

goroutine 1121 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255fe00, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001d1cd20, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1097
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 544 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc001064de8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00213bcc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064dc0, 0xc001517840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001a02320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0012870e0}, 0x1, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000c88e80?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001a02320, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc00084ede0, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit in goroutine 490
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:85 +0x4b4

goroutine 667 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b7aa80, 0xc001f87c80, 0xc00217f440, 0xc0013c4080?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 632 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000e36080}, {0x7fb44e93c598, 0xc001064e70}, {0x3f8d658?, 0x38c3780}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b7aa80, {0x0?, 0x0?}, 0xc001f87c80, 0x800?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b7aa80, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0013ac3c0?, {0x3f0dec0, 0xc001f0d540}, 0x1, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b7aa80, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 627
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 631 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 627
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 92635 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002f7a348, 0x8)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001e75d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002f7a330, {0xc00353771c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc003537712?}, {0xc00353771c?, 0xc001e75ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc002f7a300}, {0xc00353771c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001641de8, {0xc00292a000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003d36870, 0xc00300fda0?, {0x3f3b448, 0xc003b1bec0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000aa6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00302cf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 412
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 1069 [syscall, 203 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x29
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x1f

goroutine 627 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc001064e98, 0x2e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001341140?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001064e70, 0xc0015d9a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001a02fa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0011b8f90}, 0x1, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001738d10?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001a02fa0, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc0008b8d60, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc0011b8ba0, {0x0?, 0x0?}, {0x3f5aa90?, 0xc001f0f918}, 0xc001f87c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x556
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:243 +0x4c
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 649
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:242 +0x10f

goroutine 1159 [IO wait, 83 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89a710, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0023e6c80?, 0xc002d22000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0023e6c80, {0xc002d22000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0023e6c80, {0xc002d22000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015a0240, {0xc002d22000?, 0xc001e4ec10?, 0x3?})
	/usr/local/go/src/net/net.go:179 +0x45
bufio.(*Reader).Read(0xc001f189c0, {0xc001b7a120, 0x9, 0x7fb495962108?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc001f189c0}, {0xc001b7a120, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc001b7a120, 0x9, 0xc003217e48?}, {0x3f07920?, 0xc001f189c0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001b7a0e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc0024411e0, {0x3f59400, 0xc002d176e0}, 0x6628060?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:617 +0x15d
google.golang.org/grpc.(*Server).serveStreams(0xc0005bfa00, {0x3f592e8?, 0x6628060?}, {0x3f71660?, 0xc0024411e0}, {0x3f6a138?, 0xc0015a0240?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x3e2
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1156
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d8

goroutine 48295 [IO wait, 99 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795e10, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002689980?, 0xc001f38000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002689980, {0xc001f38000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002689980, {0xc001f38000?, 0x703620?, 0xc0006b3e00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0002a9f58, {0xc001f38000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00232cc60, {0xc001f38000?, 0xc002e91a40?, 0xc0035e7d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002dc22a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002dc22a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00232cc60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 48294
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 23731 [IO wait, 155 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea418, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0029b4300?, 0xc002e1e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0029b4300, {0xc002e1e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0029b4300, {0xc002e1e000?, 0x703620?, 0xc00094b040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6f1e8, {0xc002e1e000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002dbd440, {0xc002e1e000?, 0xc001ee0f00?, 0xc0016fbd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002cf4ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002cf4ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002dbd440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 23730
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 34914 [select, 129 minutes]:
net/http.(*persistConn).writeLoop(0xc000947320)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 34912
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94424 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002cb7e48, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f3a330?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002cb7e30, {0xc0024b3801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0024b3801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0036a0c80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0036a0c80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0036a0c80, {0x326cdc0, 0xc003ad7800})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc003605e60, {0xc0018b5400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003156b40, 0xc002ec3f80?, {0x3f3b448, 0xc003b049c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000f7ef80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0025725c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 611
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 939 [select, 203 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0027c3ea0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255f040, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000081c00, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1059 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbe8c0, {{{0x397c75e, 0x14}}, {0x3f43ff0, 0xc001f6e1c0}, 0xc00243d720, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1060 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1066 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1067 [select, 5 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc001f71a00, {0x3f59400, 0xc000022480}, 0x398a51c?, 0x0?, 0xc001ef0780)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:168 +0x25f
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc001f71a00, {0x3f59400, 0xc000022480}, {0x4a4b64?, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:113 +0x2db
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001a0f500, {0x3f59400, 0xc000022480}, 0x8f67a5?, {0x3f445d0, 0xc0015a0350}, {{{0xc0017db240, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1160 [select, 203 minutes]:
reflect.rselect({0xc000165320, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc002d07400?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001f039c8, {0x3f59400, 0xc002d17a10}, 0xc0002c1c00, {0x7fb44e8df598, 0xc000c531b0}, 0xc0000cbf20, {0x3a15de3?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001f039c8, {0x3f59400, 0xc002d17a10}, {0x7fb44e8df598?, 0xc000c531b0?}, {0x3a15de3, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc00210fa88?, {0x3f6d7f8, 0xc000c531b0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x6e
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x38335e0?, 0xc001f039c8}, {0x3f640d8?, 0xc0022e93b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc0005bfa00, {0x3f59400, 0xc002d17920}, {0x3f71660, 0xc0024411e0}, 0xc00235d680, 0xc000302630, 0x608ff20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc0005bfa00, {0x3f71660, 0xc0024411e0}, 0xc00235d680)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1159
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 12564 [select, 179 minutes]:
net/http.(*persistConn).writeLoop(0xc0016650e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 12562
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 3880 [select]:
net/http.(*persistConn).writeLoop(0xc002375b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 3877
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1277 [select, 203 minutes]:
reflect.rselect({0xc001664900, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc003a11200?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001f039c8, {0x3f59400, 0xc001f091a0}, 0xc000325b90, {0x7fb44e8f0e20, 0xc000c418f0}, 0xc000ca0960, {0x3a0d583?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001f039c8, {0x3f59400, 0xc001f091a0}, {0x7fb44e8f0e20?, 0xc000c418f0?}, {0x3a0d583, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc00213aa88?, {0x3f6d6f0, 0xc000c418f0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x6e
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x38335e0?, 0xc001f039c8}, {0x3f640d8?, 0xc002363860})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc0005bfa00, {0x3f59400, 0xc001f09050}, {0x3f71660, 0xc0024411e0}, 0xc00165d680, 0xc0004780c0, 0x608fe80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc0005bfa00, {0x3f71660, 0xc0024411e0}, 0xc00165d680)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1159
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 1063 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbea00, {{{0x395302a, 0xa}}, {0x0, 0x0}, 0xc000d14f70, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 672 [select, 5 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc001f0f860)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:889 +0x266
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 628
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:881 +0x5a

goroutine 911 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 904 [select, 203 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbe780, {{{0x39a7c52, 0x1e}}, {0x0, 0x0}, 0xc0014a3f38, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 937
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 932 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x105
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:409 +0xcf

goroutine 65893 [IO wait, 65 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795c20, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034e7980?, 0xc0029cc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034e7980, {0xc0029cc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034e7980, {0xc0029cc000?, 0x703620?, 0xc0033cdb80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0009ffb88, {0xc0029cc000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00162b200, {0xc0029cc000?, 0xc00264ec00?, 0xc001ea7d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003523560)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003523560, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00162b200)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 65892
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1096 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbef00, {{{0x3995728, 0x1a}}, {0x3f43ff0, 0xc001f6ea40}, 0xc0017bfc80, 0x0, 0xc000366ae0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1075
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1094 [select, 203 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc002432190})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000dbec80, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000ceb450, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1075
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 929 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255ef00, {{{0x395ed6d, 0xd}}, {0x0, 0x0}, 0xc001465c50, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 17058 [IO wait, 169 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea700, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00262fa00?, 0xc002337000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00262fa00, {0xc002337000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00262fa00, {0xc002337000?, 0x703620?, 0xc000dbfcc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013645f8, {0xc002337000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00235c5a0, {0xc002337000?, 0xc003259260?, 0xc0028f4d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002dc3aa0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002dc3aa0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00235c5a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 17057
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 591 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 542
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 592 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00157f880}, {0x7fb44e93c598, 0xc001064d10}, {0x3f8d658?, 0x38c4540}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b7a620, {0x0?, 0x0?}, 0xc000ca1bc0, 0xc0020eada0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b7a620, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000843840?, {0x3f0dec0, 0xc001f0c0f0}, 0x1, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b7a620, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 542
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 605 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b7a620, 0xc000ca1bc0, 0xc001f870e0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 592
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 94823 [select]:
net/http.(*persistConn).writeLoop(0xc002538900)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 94821
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 610 [chan receive, 203 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 544
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 611 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0025725c0}, {0x7fb44e93c598, 0xc001064dc0}, {0x3f8d658?, 0x38c4280}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001a09a40, {0x0?, 0x0?}, 0xc000ca1bc0, 0xc0019c05a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001a09a40, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00080dd00?, {0x3f0dec0, 0xc001d88190}, 0x1, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001a09a40, 0xc000ca1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 544
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 617 [select, 203 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001a09a40, 0xc000ca1bc0, 0xc001ee02a0, 0x2e95cf5?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 611
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 6661 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8eff08, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034c5280?, 0xc00349f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034c5280, {0xc00349f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034c5280, {0xc00349f000?, 0xc0019c8ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0002a98a0, {0xc00349f000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0023710e0, {0xc00349f000?, 0x450260?, 0xc0019c8ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0034c0ea0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0034c0ea0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0023710e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 6659
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 11266 [select]:
net/http.(*persistConn).writeLoop(0xc0033b10e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 11263
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 81135 [select, 35 minutes]:
net/http.(*persistConn).writeLoop(0xc001624120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 81133
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 59178 [IO wait, 79 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795a30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002816c00?, 0xc0022ec000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002816c00, {0xc0022ec000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002816c00, {0xc0022ec000?, 0x703620?, 0xc0004297c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001434bf0, {0xc0022ec000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003401680, {0xc0022ec000?, 0xc002e73c80?, 0xc002136d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0028d35c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0028d35c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003401680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 59177
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 49798 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795f08, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ef8080?, 0xc001f72000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ef8080, {0xc001f72000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ef8080, {0xc001f72000?, 0x703620?, 0xc000dbfa40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001364dd0, {0xc001f72000?, 0x0?, 0xc001f44000?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0029e5200, {0xc001f72000?, 0xc00217f260?, 0xc00351ad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002a98720)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002a98720, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0029e5200)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 49797
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 648 [select, 203 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000206140, {{{0x3999d77, 0x1b}}, {0x0, 0x0}, 0xc001358200, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1138 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89afc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0017bfc00?, 0xc002aff000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0017bfc00, {0xc002aff000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0017bfc00, {0xc002aff000?, 0x703620?, 0xc000305cc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f4100, {0xc002aff000?, 0x0?, 0xc00294a9c0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001685b00, {0xc002aff000?, 0xc0018fd3e0?, 0xc001d82d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002672d20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002672d20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001685b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1137
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 657 [select, 203 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc001d88fa0, {0x3f59438, 0xc001d89720})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:350 +0x209
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0002072c0, {{{0x397d38e, 0x14}}, {0x0, 0x0}, 0xc0013caa00, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 666 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f5f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ef08a0?, 0xc00230feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ef08a0, {0xc00230feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0015a14c8, {0xc00230feb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0013c4080)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 657
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 1061 [select, 5 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001a0f080, {0x3f59400, 0xc000c25ef0}, 0xc001e80fd0?, {0x3f445d0, 0xc000c55bf8}, {{{0xc000dcb920, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1161 [select, 203 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000bebd10, {0xc002d179c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000bebd10, {0xc002d179c0?, 0xc002c199f8?, 0xc002529550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc002d17860, {0xc002d179c0?, 0xc0025295c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc002d17860}, {0xc002d179c0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00235d680, {0xc002d179c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc002d179b0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc002529788?, 0xc00235d680, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc002d179b0, {0x7fb44e8df570, 0x6628060}, 0xc002529818?, {0x0, 0x0}, {0x37a56a0, 0xc0027c0e60}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0022e93b0, {0x37a56a0?, 0xc0027c0e60})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc000c531b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000dbec80?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1160
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 950 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0019c07d0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001ff99e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 46070 [select, 105 minutes]:
net/http.(*persistConn).writeLoop(0xc003534120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 46068
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 952 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255f400, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc0014a2498, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 953 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f120, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00293c840?, 0xc001927eb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00293c840, {0xc001927eb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0015cbbe0, {0xc001927eb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000eff080)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 1041 [syscall, 203 minutes]:
syscall.Syscall6(0xc000c64a74?, 0x0?, 0xc002927ce0?, 0x446db1?, 0x0?, 0xc002927d68?, 0xc00294a1a0?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
os.(*Process).blockUntilWaitable(0xc000f5f230)
	/usr/local/go/src/os/wait_waitid.go:32 +0x76
os.(*Process).wait(0xc000f5f230)
	/usr/local/go/src/os/exec_unix.go:22 +0x25
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0xc0029eb4a0)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 960
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4d9

goroutine 956 [select, 203 minutes]:
github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start.func1()
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:144 +0xc8
created by github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:142 +0x16d

goroutine 13977 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7ea9e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003613680?, 0xc0034b3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003613680, {0xc0034b3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003613680, {0xc0034b3000?, 0xc001803ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ee8b0, {0xc0034b3000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003535e60, {0xc0034b3000?, 0x450260?, 0xc001803ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00359de00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00359de00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003535e60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 13986
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 959 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x125
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc001a2cb10, 0x0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x5b1
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x21e

goroutine 960 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255f7c0, {{{0x395ed53, 0xd}}, {0x0, 0x0}, 0xc0005843c0, 0x0, 0xc0014a2f90, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 961 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 962 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 963 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 964 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 965 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 966 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 967 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 968 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 969 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 970 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 971 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 972 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 973 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 974 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 975 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 976 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44ec4f028, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002939980?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002939980)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002939980)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000584420)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000584420)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc0029485a0, {0x3f44240, 0xc000584420})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc000c73680, 0xe}, {0x3f44240, 0xc000584420})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xcf
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x67e

goroutine 1171 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89a808, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003547e80?, 0xc003a47000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003547e80, {0xc003a47000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003547e80, {0xc003a47000?, 0xc001f24ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f4ee0, {0xc003a47000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0015b8ea0, {0xc003a47000?, 0x450260?, 0xc001f24ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0003b03c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0003b03c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0015b8ea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1169
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1187 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:384 +0x8b
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1113
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:379 +0x5a

goroutine 980 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 981 [chan receive, 97 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc002ad4c20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001a0ec60, {0x3f59400, 0xc0029f4fc0}, 0x2be1c6b?, {0x3f445d0, 0xc0002a9da0}, {{{0xc0016d8b40, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 982 [chan receive, 95 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc002acac20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001a0ecc0, {0x3f59400, 0xc0029f5110}, 0x0?, {0x3f445d0, 0xc0002a9da0}, {{{0xc0016d8ec0, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 4796 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f02e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003192700?, 0xc003197000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003192700, {0xc003197000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003192700, {0xc003197000?, 0xc002adfec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ee318, {0xc003197000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00293e000, {0xc003197000?, 0x450260?, 0xc002adfec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003187020)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003187020, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00293e000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 4794
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 984 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc002a98ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 982
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 985 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002a98cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 982
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 986 [sync.Cond.Wait, 95 minutes]:
sync.runtime_notifyListWait(0xc000f85c10, 0x8f)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x6?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002a98ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc002aaaf00}, 0xc002ab4120, {0x3f6a708, 0xc00169b098})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 982
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 987 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 982
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1238 [chan receive]:
github.com/cilium/cilium/pkg/monitor/agent.(*listenerv1_2).drainQueue(0xc001d17200)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:54 +0x265
created by github.com/cilium/cilium/pkg/monitor/agent.newListenerv1_2 in goroutine 237
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:33 +0xd6

goroutine 83367 [IO wait, 29 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fcf90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002abf380?, 0xc001f59000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002abf380, {0xc001f59000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002abf380, {0xc001f59000?, 0x703620?, 0xc003e6e500?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015e8528, {0xc001f59000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00293f0e0, {0xc001f59000?, 0xc0035974a0?, 0xc001707d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00343c9c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00343c9c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00293f0e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 83366
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1140 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89abe8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001a6c380?, 0xc002b91000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001a6c380, {0xc002b91000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001a6c380, {0xc002b91000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f4118, {0xc002b91000?, 0x0?, 0xc002b8e0c8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc002b8e0c0, {0xc002b91000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002673200)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002673200, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc000e1b560, {0x3f59400, 0xc000c42270})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 910
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 6664 [select]:
net/http.(*persistConn).writeLoop(0xc00232d8c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 6637
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 37172 [select, 125 minutes]:
net/http.(*persistConn).writeLoop(0xc0023dd320)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 37170
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1623 [select]:
net/http.(*persistConn).writeLoop(0xc001604d80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1642
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1109 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255e780, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc0010f0180}, 0xc0002ff3e0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 940
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1113 [semacquire, 203 minutes]:
sync.runtime_Semacquire(0x339db00?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0xc00256aa00?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc00256aa00)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0x57
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc00256aa00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x105
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1111
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:386 +0xc7

goroutine 11262 [select]:
net/http.(*persistConn).writeLoop(0xc003400900)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 11230
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 83368 [select, 29 minutes]:
net/http.(*persistConn).writeLoop(0xc00293f0e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 83366
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 3879 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f06c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003095180?, 0xc0030a9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003095180, {0xc0030a9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003095180, {0xc0030a9000?, 0xc001e4fec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001790910, {0xc0030a9000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002375b00, {0xc0030a9000?, 0x450260?, 0xc001e4fec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00309ad80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00309ad80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002375b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 3877
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 5646 [select, 195 minutes]:
net/http.(*persistConn).writeLoop(0xc0015605a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 5644
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1172 [select]:
net/http.(*persistConn).writeLoop(0xc0015b8ea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1169
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1150 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc0015c2090, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00025eb60?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc0015c2040, {0x3f59438, 0xc000943b30}, {0xc002a92c40, 0x35}, 0x1, {0xc001fee6e5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1160
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 1173 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89ace0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003547f00?, 0xc003a4d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003547f00, {0xc003a4d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003547f00, {0xc003a4d000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f4ee8, {0xc003a4d000?, 0x0?, 0xc0039eade8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0039eade0, {0xc003a4d000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0003b1080)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0003b1080, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001b4ee10, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 4793 [select]:
net/http.(*persistConn).writeLoop(0xc002539b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 4790
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1111 [chan receive, 203 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc00256aa00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:391 +0xdc
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x66
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 959
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1ff

goroutine 1143 [IO wait, 177 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89a9f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001a6c800?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a6c800)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001a6c800)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc00105a7a0)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc00105a7a0)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc0029480f0, {0x3f44240, 0xc00105a7a0})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc0029480f0)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1112
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 1139 [select, 203 minutes]:
net/http.(*persistConn).writeLoop(0xc001685b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1137
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1136 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001c1a40, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001d1d668, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 960
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 94816 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f09b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00233c880?, 0xc0020d8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00233c880, {0xc0020d8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00233c880, {0xc0020d8000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ef900, {0xc0020d8000?, 0x0?, 0xc0016c14a8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0016c14a0, {0xc0020d8000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0035c2ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0035c2ba0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0010ac240, {0x3f59400, 0xc000c42270})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 910
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 1134 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 960
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1133 [select, 203 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc00253a460})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001c1900, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc000d4ff50, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 960
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1279 [sync.Cond.Wait, 203 minutes]:
sync.runtime_notifyListWait(0xc00157fd90, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc00025eb60?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00157fd40, {0x3f59438, 0xc0018b26e0}, {0xc0026774c0, 0x33}, 0x1, {0xc001effe25, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1277
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 1046 [select, 203 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x17c
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1033
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x226

goroutine 1025 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00255e140, {{{0x3952850, 0xa}}, {0x0, 0x0}, 0x3b623c8, 0x0, 0x3b61ab0, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 977
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1026 [select, 5 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0xe?, {0x3f59438, 0xc0009436d0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xfe
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:199 +0x19fc

goroutine 1027 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc00255e280)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x98
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:211 +0x1bdb

goroutine 1028 [runnable]:
syscall.Syscall6(0xc00127cec0?, 0xc000c64e30?, 0x409280?, 0xc001ecb380?, 0xc001a3f838?, 0x1000000004df2f0?, 0x3f07220?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0xffffffffffffff00?, {0xc00194f440?, 0x6069af0?, 0x3f07220?}, 0x227d925?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc000c79940, {0xc00194f440?, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0029f6fc0, 0xc000334af0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc001a26070, {0x3f59438, 0xc0026f9810})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x495
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 977
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 1029 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44ec4f310, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0001be400?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0001be400)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0001be400)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x447380?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc00203a690)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc00256b400, {0x3f44270?, 0xc00203a690})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:255 +0x4d
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:254 +0x286b

goroutine 1030 [chan receive, 203 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:260 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:259 +0x28dd

goroutine 1031 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44ec4f218, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0003b0720?, 0xc0020afeb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0003b0720, {0xc0020afeb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0015a01a8, {0xc0020afeb0?, 0x2d6574616c706d65?, 0x69746172656e6567?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000eb5bc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 977
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 1032 [select, 203 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc00203acc0)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xd1
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 977
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1e5

goroutine 1048 [chan receive, 203 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:326 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:325 +0x3479

goroutine 1047 [IO wait, 183 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89b0c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0001bfe80?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0001bfe80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0001bfe80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000c79c20)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000c79c20)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
google.golang.org/grpc.(*Server).Serve(0xc000f33400, {0x3f44240?, 0xc000c79c20})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:317 +0x56
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 977
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:316 +0x3405

goroutine 1036 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0003b1500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 981
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1037 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0003b1680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 981
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 1038 [sync.Cond.Wait, 97 minutes]:
sync.runtime_notifyListWait(0xc000eb5c90, 0x24)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0003b1500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc0026f9a40}, 0xc001363c80, {0x3f6aa20, 0xc00169b218})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 981
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1039 [select, 203 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 981
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1042 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027c0140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 960
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1188 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89a618, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003878980?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc003878980)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc003878980)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc002707e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc00397c450)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc002362c30, {0x3f44270, 0xc00397c450})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3f44270?, 0xc00397c450?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:358 +0x78
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1113
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:356 +0x4d9

goroutine 1189 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89a520, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003878b00?, 0xc003b0fc00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc003878b00, {0xc003b0fc00, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x285
net.(*netFD).readFrom(0xc003878b00, {0xc003b0fc00?, 0x50?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x25
net.(*IPConn).readFrom(0x53ff68?, {0xc003b0fc00, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0xc0015a0c98, {0xc003b0fc00?, 0xc00210fec0?, 0xc00210fe88?})
	/usr/local/go/src/net/iprawsock.go:129 +0x30
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc19f1bc3d319baca?, {0xc003b0fc00?, 0x60ccea0?, 0x60ccea0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x2f
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc001b76870, 0xc000cba9e0, 0xc001686ae0, 0xc000cbaa00, 0xc002e00450?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x139
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1186
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x377

goroutine 1195 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003b6140, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc001276f40}, 0xc000cbf5e0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1095
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 10284 [IO wait, 185 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7eb0b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00260f200?, 0xc002d61000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00260f200, {0xc002d61000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00260f200, {0xc002d61000?, 0x703620?, 0xc000452f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015cb920, {0xc002d61000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0016f2480, {0xc002d61000?, 0xc002e72c60?, 0xc003172d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ea02a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ea02a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0016f2480)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 10283
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1235 [IO wait, 203 minutes]:
internal/poll.runtime_pollWait(0x7fb44e8f0ba0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002938180?, 0xc0023c2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002938180, {0xc0023c2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002938180, {0xc0023c2000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015a08c8, {0xc0023c2000?, 0x0?, 0xc001d16668?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001d16660, {0xc0023c2000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001ef1aa0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001ef1aa0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00106f950, {0x3f59400, 0xc000c42270})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 910
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 72922 [select, 49 minutes]:
net/http.(*persistConn).writeLoop(0xc001697560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 72920
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1300 [select, 203 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0018b2550, {0xc001f09150, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0018b2550, {0xc001f09150?, 0xc00007b380?, 0xc001ed3550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc001f84db0, {0xc001f09150?, 0xc001ed35c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc001f84db0}, {0xc001f09150, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00165d680, {0xc001f09150, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc001f09140, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc001ed37a8?, 0xc00165d680, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc001f09140, {0x7fb44e8df570, 0x6628060}, 0xc001ed3818?, {0x0, 0x0}, {0x37a56a0, 0xc0022f0c80}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc002363860, {0x37a56a0?, 0xc0022f0c80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc000c418f0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000ca0360?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1277
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 1622 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f08b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002591600?, 0xc002657000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002591600, {0xc002657000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002591600, {0xc002657000?, 0xc002709ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015a1f48, {0xc002657000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001604d80, {0xc002657000?, 0x450260?, 0xc002709ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00263d9e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00263d9e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001604d80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1642
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 49799 [select, 49 minutes]:
net/http.(*persistConn).writeLoop(0xc0029e5200)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 49797
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 25972 [select, 149 minutes]:
net/http.(*persistConn).writeLoop(0xc001679d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 25970
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 14844 [select, 175 minutes]:
net/http.(*persistConn).writeLoop(0xc00322d9e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 14842
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 95194 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002f8a348, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002738d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002f8a330, {0xc001114ec8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001114eba?}, {0xc001114ec8?, 0xc002738ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc002f8a300}, {0xc001114ec8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00169a240, {0xc0018b4800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002be1ae0, 0xc002588060?, {0x3f3b448, 0xc00398de00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000dc3d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002c5c140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 467
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 3876 [select]:
net/http.(*persistConn).writeLoop(0xc0023de480)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 3864
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 41616 [IO wait, 115 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea320, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003082500?, 0xc002a71000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003082500, {0xc002a71000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003082500, {0xc002a71000?, 0x703620?, 0xc0002883c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6ea70, {0xc002a71000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0023eb440, {0xc002a71000?, 0xc002e732c0?, 0xc003515d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ecc8a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ecc8a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0023eb440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 41624
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 39383 [IO wait, 119 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7961f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0033ce880?, 0xc00215d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0033ce880, {0xc00215d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0033ce880, {0xc00215d000?, 0x703620?, 0xc0003b7680?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001364be0, {0xc00215d000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001a30c60, {0xc00215d000?, 0xc003259800?, 0xc0017fdd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c48660)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c48660, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001a30c60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 39382
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 43845 [IO wait, 109 minutes]:
internal/poll.runtime_pollWait(0x7fb44e796000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003751b80?, 0xc0020d6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003751b80, {0xc0020d6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003751b80, {0xc0020d6000?, 0x703620?, 0xc000289540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6e0c0, {0xc0020d6000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002156ea0, {0xc0020d6000?, 0xc003405740?, 0xc001e7fd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00258dc20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00258dc20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002156ea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 43844
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 63665 [IO wait, 69 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd940, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ec4c00?, 0xc002170000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ec4c00, {0xc002170000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ec4c00, {0xc002170000?, 0x703620?, 0xc000304280?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001790228, {0xc002170000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001ad58c0, {0xc002170000?, 0xc0010fbb00?, 0xc0017fcd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002723ce0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002723ce0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001ad58c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 63648
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 93282 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003586d80, 0xc000ab0700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0027fab00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 348
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 7953 [select, 189 minutes]:
net/http.(*persistConn).writeLoop(0xc000ad3c20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 7919
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 54066 [select, 89 minutes]:
net/http.(*persistConn).writeLoop(0xc001697440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 54048
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 25971 [IO wait, 149 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea608, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0023e6600?, 0xc002093000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0023e6600, {0xc002093000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0023e6600, {0xc002093000?, 0x703620?, 0xc0008fa3c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015cb150, {0xc002093000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001679d40, {0xc002093000?, 0xc002589e60?, 0xc002aefd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00254d5c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00254d5c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001679d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 25970
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 61402 [select, 75 minutes]:
net/http.(*persistConn).writeLoop(0xc0025385a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 61400
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 6662 [select]:
net/http.(*persistConn).writeLoop(0xc0023710e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 6659
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 95550 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7fd848, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003864b00?, 0xc00349e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003864b00, {0xc00349e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003864b00, {0xc00349e000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015a1408, {0xc00349e000?, 0x0?, 0xc0039eaed8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0039eaed0, {0xc00349e000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc00307d320)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00307d320, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00165a120, {0x3f59400, 0xc00397c5d0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1188
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 3394 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89add8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002552f00?, 0xc002560000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002552f00, {0xc002560000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002552f00, {0xc002560000?, 0x703620?, 0xc000429540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6f950, {0xc002560000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0015907e0, {0xc002560000?, 0xc0023e9b00?, 0xc002138d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00254d980)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00254d980, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0015907e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 3393
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 93500 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002c87380, 0xc002defe00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc0013517a0?, 0xc0013517b0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 6663 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f00f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00346e180?, 0xc0034d3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00346e180, {0xc0034d3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00346e180, {0xc0034d3000?, 0xc002d5dec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0002a98c8, {0xc0034d3000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00232d8c0, {0xc0034d3000?, 0x450260?, 0xc002d5dec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0034c0f60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0034c0f60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00232d8c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 6637
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 94412 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002cb7e00, 0xc0027a6c00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x6ea4a5?, 0xc0027eb5f0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 611
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 3395 [select, 199 minutes]:
net/http.(*persistConn).writeLoop(0xc0015907e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 3393
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 30435 [IO wait, 139 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea228, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002de6f80?, 0xc0022e1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002de6f80, {0xc0022e1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002de6f80, {0xc0022e1000?, 0x703620?, 0xc000206000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015cb930, {0xc0022e1000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000946000, {0xc0022e1000?, 0xc002cc3440?, 0xc001e4ad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00254c420)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00254c420, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000946000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 30434
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 17059 [select, 169 minutes]:
net/http.(*persistConn).writeLoop(0xc00235c5a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 17057
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94374 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc003b68780, 0xc002da1b00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc000eb9080?, 0xc000eb9090?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 13982 [select]:
net/http.(*persistConn).writeLoop(0xc00348b680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 13979
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 3120 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f07c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0026b9a00?, 0xc0027a2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0026b9a00, {0xc0027a2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0026b9a00, {0xc0027a2000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6e668, {0xc0027a2000?, 0x0?, 0xc001ef51d8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001ef51d0, {0xc0027a2000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc00279e9c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00279e9c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00166fe60, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 13365 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7eabd8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0020caf80?, 0xc001066000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0020caf80, {0xc001066000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0020caf80, {0xc001066000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f4888, {0xc001066000?, 0x0?, 0xc000024cc8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc000024cc0, {0xc001066000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0027220c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0027220c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0019ea120, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 49836 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795938, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002f84d00?, 0xc003226000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f84d00, {0xc003226000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002f84d00, {0xc003226000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2728, {0xc003226000?, 0x0?, 0xc0029e91a8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0029e91a0, {0xc003226000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0018db200)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0018db200, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001f80fc0, {0x3f59400, 0xc000c42270})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 910
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 59179 [select, 79 minutes]:
net/http.(*persistConn).writeLoop(0xc003401680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 59177
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 61401 [IO wait, 75 minutes]:
internal/poll.runtime_pollWait(0x7fb44e8f05d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002d8c980?, 0xc002828000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002d8c980, {0xc002828000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002d8c980, {0xc002828000?, 0x703620?, 0xc003904280?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014355c0, {0xc002828000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0025385a0, {0xc002828000?, 0xc003404e40?, 0xc002d59d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00359cae0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00359cae0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0025385a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 61400
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 21509 [IO wait, 159 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea510, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0026b8a80?, 0xc0020c1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0026b8a80, {0xc0020c1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0026b8a80, {0xc0020c1000?, 0x703620?, 0xc000453180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015d2f98, {0xc0020c1000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00235d7a0, {0xc0020c1000?, 0xc002e04cc0?, 0xc0033aad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002664a80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002664a80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00235d7a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 21508
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 19262 [select, 165 minutes]:
net/http.(*persistConn).writeLoop(0xc003535d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 19260
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 3875 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e89a428, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003103d00?, 0xc0030a3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003103d00, {0xc0030a3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003103d00, {0xc0030a3000?, 0xc000c0dec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017908d0, {0xc0030a3000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0023de480, {0xc0030a3000?, 0x450260?, 0xc000c0dec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00309ab40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00309ab40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0023de480)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 3864
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 39384 [select, 119 minutes]:
net/http.(*persistConn).writeLoop(0xc001a30c60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 39382
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 13978 [select]:
net/http.(*persistConn).writeLoop(0xc003535e60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 13986
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 4033 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e8f04d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001acf000?, 0xc00101b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001acf000, {0xc00101b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001acf000, {0xc00101b000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001790c98, {0xc00101b000?, 0x0?, 0xc0012ddd48?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0012ddd40, {0xc00101b000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0025bc240)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0025bc240, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001d11560, {0x3f59400, 0xc002bb0030})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1143
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 34913 [IO wait, 129 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7963e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003356080?, 0xc002491000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003356080, {0xc002491000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003356080, {0xc002491000?, 0x703620?, 0xc0033cc000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015cb028, {0xc002491000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000947320, {0xc002491000?, 0xc0019059e0?, 0xc003653d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0026647e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0026647e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000947320)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 34912
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 13981 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7eaae0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003313180?, 0xc0035bf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003313180, {0xc0035bf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003313180, {0xc0035bf000?, 0xc002704ec8?, 0xc001368c60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016ee8e8, {0xc0035bf000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00348b680, {0xc0035bf000?, 0x450260?, 0xc002704ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0035c2060)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0035c2060, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00348b680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 13979
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 94375 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc003b687c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002101d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003b687b0, {0xc0014748f8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0014748e0?}, {0xc0014748f8?, 0xc002101ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc003b68780}, {0xc0014748f8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0010ab038, {0xc003c7d400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0030707d0, 0xc0031124e0?, {0x3f3b448, 0xc003978fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010edca0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0012a2040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 90068 [select, 15 minutes]:
net/http.(*persistConn).writeLoop(0xc003400000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 90066
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 85601 [IO wait, 25 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd560, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034fbf00?, 0xc00354a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034fbf00, {0xc00354a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034fbf00, {0xc00354a000?, 0x703620?, 0xc000288780?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f59d8, {0xc00354a000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0016ceea0, {0xc00354a000?, 0xc002ab5620?, 0xc001708d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003151920)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003151920, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0016ceea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 85600
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 10285 [select, 185 minutes]:
net/http.(*persistConn).writeLoop(0xc0016f2480)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 10283
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 68146 [IO wait, 59 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89aaf0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0029d6880?, 0xc001f6a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0029d6880, {0xc001f6a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0029d6880, {0xc001f6a000?, 0x703620?, 0xc0006b3a40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014352e8, {0xc001f6a000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00169cb40, {0xc001f6a000?, 0xc002032060?, 0xc002708d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0018ae7e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0018ae7e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00169cb40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 68145
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 49840 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795b28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002f85100?, 0xc002afe000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f85100, {0xc002afe000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002f85100, {0xc002afe000?, 0x703620?, 0xc000dbfb80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2788, {0xc002afe000?, 0x0?, 0xc001f44000?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000bd4120, {0xc002afe000?, 0xc0028908a0?, 0xc00351fd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00343d0e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00343d0e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000bd4120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 49839
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 65894 [select, 65 minutes]:
net/http.(*persistConn).writeLoop(0xc00162b200)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 65892
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 48296 [select, 99 minutes]:
net/http.(*persistConn).writeLoop(0xc00232cc60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 48294
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 92993 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002427800, 0xc00284f200)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc001b76870?, 0xc002bb0000?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 592
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 30436 [select, 139 minutes]:
net/http.(*persistConn).writeLoop(0xc000946000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 30434
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 78910 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd468, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0025c0c00?, 0xc0020d9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0025c0c00, {0xc0020d9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0025c0c00, {0xc0020d9000?, 0x703620?, 0xc00094adc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013658b8, {0xc0020d9000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0015b8fc0, {0xc0020d9000?, 0xc000ca1440?, 0xc002adad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002172ae0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002172ae0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0015b8fc0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 78909
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 23732 [select, 155 minutes]:
net/http.(*persistConn).writeLoop(0xc002dbd440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 23730
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 78911 [select, 39 minutes]:
net/http.(*persistConn).writeLoop(0xc0015b8fc0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 78909
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94654 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0029b9680, 0xc002b53e00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc001dd9000?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 521
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 94702 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002ecef00, 0xc002ff7100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc00136cc40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 511
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 12563 [IO wait, 179 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7eacd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027f8500?, 0xc002545000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027f8500, {0xc002545000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027f8500, {0xc002545000?, 0x703620?, 0xc000288f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000c55810, {0xc002545000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0016650e0, {0xc002545000?, 0xc0018fde00?, 0xc002739d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b665a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b665a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0016650e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 12562
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 54065 [IO wait, 89 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795650, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00216d180?, 0xc002474000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00216d180, {0xc002474000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00216d180, {0xc002474000?, 0x703620?, 0xc0003b6780?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2260, {0xc002474000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001697440, {0xc002474000?, 0xc00348efc0?, 0xc002adbd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002665440)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002665440, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001697440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 54048
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 19261 [IO wait, 165 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7ea7f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00320b800?, 0xc00304c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00320b800, {0xc00304c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00320b800, {0xc00304c000?, 0x703620?, 0xc000dbf680?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f5e78, {0xc00304c000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003535d40, {0xc00304c000?, 0xc002891ec0?, 0xc0036b4d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0034cfbc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0034cfbc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003535d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 19260
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 49841 [select, 49 minutes]:
net/http.(*persistConn).writeLoop(0xc000bd4120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 49839
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 50932 [IO wait, 95 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795d18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00429f580?, 0xc00428b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00429f580, {0xc00428b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00429f580, {0xc00428b000?, 0x703620?, 0xc003e6f540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014347f8, {0xc00428b000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc004287680, {0xc00428b000?, 0xc00417d8c0?, 0xc0035f4d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0042ac5a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0042ac5a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc004287680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 50931
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 92994 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002427848, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f3a380?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002427830, {0xc002694001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002694001?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc000305040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000305040)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc000305040, {0x326cdc0, 0xc002912b70})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc003ab0d20, {0xc00292ac00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00253bd60, 0xc003259980?, {0x3f3b448, 0xc0039dcc40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0007bc340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00157f880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 592
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 93263 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc003586dc8, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0016fdd40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003586db0, {0xc003a80440, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc003a80440?}, {0xc003a80440?, 0xc0016fdce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc003586d80}, {0xc003a80440, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003997038, {0xc00292bc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002ce6000, 0xc0030e6480?, {0x3f3b448, 0xc00146dd00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0016d9500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00266bd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 348
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 95555 [select]:
net/http.(*persistConn).writeLoop(0xc0015eb440)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 95553
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 21510 [select, 159 minutes]:
net/http.(*persistConn).writeLoop(0xc00235d7a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 21508
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 92282 [select, 9 minutes]:
net/http.(*persistConn).writeLoop(0xc003534360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 92280
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 87834 [IO wait, 19 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd370, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003ab7680?, 0xc001b0d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003ab7680, {0xc001b0d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003ab7680, {0xc001b0d000?, 0x703620?, 0xc003905e00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015ca530, {0xc001b0d000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002174120, {0xc001b0d000?, 0xc003183860?, 0xc001eb1d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00343d2c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00343d2c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002174120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 87833
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 32658 [IO wait, 135 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7964d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0025c0d80?, 0xc002c84000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0025c0d80, {0xc002c84000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0025c0d80, {0xc002c84000?, 0x703620?, 0xc000304780?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00151e4c8, {0xc002c84000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002487b00, {0xc002c84000?, 0xc00356f2c0?, 0xc0016fad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c98d20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c98d20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002487b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 32657
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 49842 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795840, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002f85380?, 0xc002336000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f85380, {0xc002336000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002f85380, {0xc002336000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2790, {0xc002336000?, 0x0?, 0xc002c46908?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc002c46900, {0xc002336000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc00343d1a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00343d1a0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00166e000, {0x3f59400, 0xc00397c5d0})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1188
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 87835 [select, 19 minutes]:
net/http.(*persistConn).writeLoop(0xc002174120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 87833
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94822 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7fda38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002552680?, 0xc002d60000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002552680, {0xc002d60000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002552680, {0xc002d60000?, 0x703620?, 0xc00255f540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017905e0, {0xc002d60000?, 0x0?, 0xc00275fba0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002538900, {0xc002d60000?, 0xc003447200?, 0xc003390d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003f8ff80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003f8ff80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002538900)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 94821
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 92634 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002f7a300, 0xc002defa00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0015c2f80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 412
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 56946 [IO wait, 85 minutes]:
internal/poll.runtime_pollWait(0x7fb44e795748, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001acef00?, 0xc002c3c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001acef00, {0xc002c3c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001acef00, {0xc002c3c000?, 0x703620?, 0xc000288c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015f5318, {0xc002c3c000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc002aa1d40, {0xc002c3c000?, 0xc00403baa0?, 0xc001df3d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c992c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c992c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc002aa1d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 56945
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 46069 [IO wait, 105 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7960f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ab6980?, 0xc002851000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ab6980, {0xc002851000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ab6980, {0xc002851000?, 0x703620?, 0xc0033cc140?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6e6d0, {0xc002851000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003534120, {0xc002851000?, 0xc002946960?, 0xc003659d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0031adbc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0031adbc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003534120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 46068
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 92281 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fcda0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00260ed80?, 0xc0024b5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00260ed80, {0xc0024b5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00260ed80, {0xc0024b5000?, 0x703620?, 0xc0036a0f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017901d8, {0xc0024b5000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003534360, {0xc0024b5000?, 0xc001f87980?, 0xc0036b6d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00337f980)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00337f980, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003534360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 92280
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 93864 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002d73800, 0xc001204000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc002cd9b40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 418
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 68147 [select, 59 minutes]:
net/http.(*persistConn).writeLoop(0xc00169cb40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 68145
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94326 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00334d0c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37be8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00334d0b0, {0xc00232f801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc00232f801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0036a0780)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0036a0780)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0036a0780, {0x326cdc0, 0xc0028ea708})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0034a7050, {0xc00292a400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0035e2640, 0xc003182600?, {0x3f3b448, 0xc00392f900})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013539e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0030ea100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 527
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 94706 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002ecef48, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f38020?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002ecef30, {0xc00248d201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc00248d201?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0036a08c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0036a08c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0036a08c0, {0x326cdc0, 0xc00311b1a0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0036f7dd0, {0xc001afe400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000810eb0, 0xc002ab57a0?, {0x3f3b448, 0xc0035adb40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000eb2500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00148d740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 511
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 90067 [IO wait, 15 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fce98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003252a80?, 0xc0027f0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003252a80, {0xc0027f0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003252a80, {0xc0027f0000?, 0x703620?, 0xc0039057c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2218, {0xc0027f0000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003400000, {0xc0027f0000?, 0xc003405bc0?, 0xc0035e8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0033005a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0033005a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003400000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 90066
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 50933 [select, 95 minutes]:
net/http.(*persistConn).writeLoop(0xc004287680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 50931
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 63666 [select, 69 minutes]:
net/http.(*persistConn).writeLoop(0xc001ad58c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 63648
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94343 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00334d080, 0xc002da0600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x6ea4a5?, 0xc0027eb5f0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 527
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 81134 [IO wait, 35 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd658, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0034cbd00?, 0xc0027f2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0034cbd00, {0xc0027f2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0034cbd00, {0xc0027f2000?, 0x703620?, 0xc0036a03c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0015e83f0, {0xc0027f2000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001624120, {0xc0027f2000?, 0xc0030e60c0?, 0xc0019a9d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002e4f380)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e4f380, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001624120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 81133
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 93865 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002d73848, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002153d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002d73830, {0xc0011c8cb0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0011c8cb0?}, {0xc0011c8cb0?, 0xc002153ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc002d73800}, {0xc0011c8cb0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003f2c378, {0xc0027b1400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0035bc050, 0xc0039e5d40?, {0x3f3b448, 0xc00392ee40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00105a060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002869e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 418
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 93514 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002c873c8, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f38020?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002c873b0, {0xc00237a601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc00237a601?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc003e6e140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc003e6e140)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc003e6e140, {0x326cdc0, 0xc003ad79b0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00341ecc0, {0xc003c7c000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003157220, 0xc0018fd080?, {0x3f3b448, 0xc003b04ac0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000d003a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc003628740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 56947 [select, 85 minutes]:
net/http.(*persistConn).writeLoop(0xc002aa1d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 56945
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 95179 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002f8a300, 0xc002852500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc002165500?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 467
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 93615 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002ca81c8, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37a08?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002ca81b0, {0xc00237b801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc00237b801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0033cc640)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0033cc640)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0033cc640, {0x326cdc0, 0xc002e398d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0030a4d20, {0xc0027b0c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003f42e10, 0xc00348e420?, {0x3f3b448, 0xc003af3f80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013b87a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002c8b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 534
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 72921 [IO wait, 49 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd088, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002786c80?, 0xc002e2d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002786c80, {0xc002e2d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002786c80, {0xc002e2d000?, 0x703620?, 0xc0033cd040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000f6f360, {0xc002e2d000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001697560, {0xc002e2d000?, 0xc002890b40?, 0xc0035f9d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002378e40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002378e40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001697560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 72920
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 94328 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc003ee30c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0016fed40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc003ee30b0, {0xc003674cf8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc003674cec?}, {0xc003674cf8?, 0xc0016fece0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7fb44e93c4c0, 0xc003ee3080}, {0xc003674cf8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00392a240, {0xc0018b4000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00291b9f0, 0xc003182cc0?, {0x3f3b448, 0xc00392f940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000fc60e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001a9e4c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 194
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 94788 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002158600, 0xc000a4f500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc003b5b1c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 398
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 93202 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0020dbb48, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37dc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0020dbb30, {0xc002bb4c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002bb4c01?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0003b77c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0003b77c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0003b77c0, {0x326cdc0, 0xc0011e8ff0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc003b6b020, {0xc00292b800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002907810, 0xc001f866c0?, {0x3f3b448, 0xc003b5a580})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001283f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000e36080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 85602 [select, 25 minutes]:
net/http.(*persistConn).writeLoop(0xc0016ceea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 85600
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 94670 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0029b96c8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37af8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0029b96b0, {0xc002430601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002430601?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc003904b40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc003904b40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc003904b40, {0x326cdc0, 0xc002c1be18})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0035cade0, {0xc003c7cc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003704cd0, 0xc002eb23c0?, {0x3f3b448, 0xc001f6e5c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001010f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00319cf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 521
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 93201 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0020dbb00, 0xc002f99e00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc000f27380?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 94518 [select, 5 minutes]:
net/http.(*persistConn).writeLoop(0xc001f32fc0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 94516
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 76038 [IO wait, 45 minutes]:
internal/poll.runtime_pollWait(0x7fb44e7fd278, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003969700?, 0xc003a66000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003969700, {0xc003a66000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003969700, {0xc003a66000?, 0x703620?, 0xc0036a1400?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013c2a50, {0xc003a66000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003a178c0, {0xc003a66000?, 0xc003abcd20?, 0xc001e4bd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003a5ac00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003a5ac00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003a178c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 76037
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 94517 [IO wait, 5 minutes]:
internal/poll.runtime_pollWait(0x7fb44e89a900, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003102780?, 0xc0028ee000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003102780, {0xc0028ee000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003102780, {0xc0028ee000?, 0x703620?, 0xc003905040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001435fe0, {0xc0028ee000?, 0x0?, 0xc001f0fa00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001f32fc0, {0xc0028ee000?, 0xc0016be420?, 0xc0019add38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002cf70e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002cf70e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001f32fc0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 94516
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 95554 [IO wait]:
internal/poll.runtime_pollWait(0x7fb44e7fd180, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0025c5a00?, 0xc0030a2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0025c5a00, {0xc0030a2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0025c5a00, {0xc0030a2000?, 0x703620?, 0xc00255f680?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001435c28, {0xc0030a2000?, 0x0?, 0xc00294a9c0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0015eb440, {0xc0030a2000?, 0xc003404360?, 0xc001f22d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ea1260)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ea1260, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0015eb440)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 95553
	/usr/local/go/src/net/http/transport.go:1776 +0x169f
