REASON                    DIRECTION   PACKETS   BYTES
Interface                 INGRESS     2074063   402118215
Success                   EGRESS      1972776   535954495
Success                   INGRESS     84708     7672606
Unsupported L3 protocol   EGRESS      12        840
