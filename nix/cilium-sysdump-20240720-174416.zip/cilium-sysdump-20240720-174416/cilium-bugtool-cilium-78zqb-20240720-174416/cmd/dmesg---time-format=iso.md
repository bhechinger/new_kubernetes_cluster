2024-07-20T14:18:27,000000+00:00 Linux version 6.8.12 (nixbld@localhost) (gcc (GCC) 13.3.0, GNU ld (GNU Binutils) 2.42) #1-NixOS SMP PREEMPT_DYNAMIC Thu May 30 07:49:53 UTC 2024
2024-07-20T14:18:27,000000+00:00 Command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/vsq52zk5ykskh3cindr7ijlfqpcyp17c-nixos-system-master1-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:18:27,000000+00:00 BIOS-provided physical RAM map:
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x000000007ffdbfff] usable
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x000000007ffdc000-0x000000007fffffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x00000000b0000000-0x00000000bfffffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x00000000fed1c000-0x00000000fed1ffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2024-07-20T14:18:27,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000017fffffff] usable
2024-07-20T14:18:27,000000+00:00 NX (Execute Disable) protection: active
2024-07-20T14:18:27,000000+00:00 APIC: Static calls initialized
2024-07-20T14:18:27,000000+00:00 SMBIOS 2.8 present.
2024-07-20T14:18:27,000000+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 1.15.0-1 04/01/2014
2024-07-20T14:18:27,000000+00:00 Hypervisor detected: KVM
2024-07-20T14:18:27,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2024-07-20T14:18:27,000000+00:00 kvm-clock: using sched offset of 300968954798 cycles
2024-07-20T14:18:27,000001+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2024-07-20T14:18:27,000003+00:00 tsc: Detected 3593.200 MHz processor
2024-07-20T14:18:27,000816+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2024-07-20T14:18:27,000819+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2024-07-20T14:18:27,000823+00:00 last_pfn = 0x180000 max_arch_pfn = 0x400000000
2024-07-20T14:18:27,000845+00:00 MTRR map: 4 entries (3 fixed + 1 variable; max 19), built from 8 variable MTRRs
2024-07-20T14:18:27,000847+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2024-07-20T14:18:27,000878+00:00 last_pfn = 0x7ffdc max_arch_pfn = 0x400000000
2024-07-20T14:18:27,002862+00:00 found SMP MP-table at [mem 0x000f5b80-0x000f5b8f]
2024-07-20T14:18:27,002999+00:00 RAMDISK: [mem 0x3693b000-0x37494fff]
2024-07-20T14:18:27,003003+00:00 ACPI: Early table checksum verification disabled
2024-07-20T14:18:27,003005+00:00 ACPI: RSDP 0x00000000000F5970 000014 (v00 BOCHS )
2024-07-20T14:18:27,003011+00:00 ACPI: RSDT 0x000000007FFE2842 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003014+00:00 ACPI: FACP 0x000000007FFE2632 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003018+00:00 ACPI: DSDT 0x000000007FFE0040 0025F2 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003020+00:00 ACPI: FACS 0x000000007FFE0000 000040
2024-07-20T14:18:27,003022+00:00 ACPI: APIC 0x000000007FFE2726 000080 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003024+00:00 ACPI: HPET 0x000000007FFE27A6 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003026+00:00 ACPI: MCFG 0x000000007FFE27DE 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003028+00:00 ACPI: WAET 0x000000007FFE281A 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:18:27,003030+00:00 ACPI: Reserving FACP table memory at [mem 0x7ffe2632-0x7ffe2725]
2024-07-20T14:18:27,003031+00:00 ACPI: Reserving DSDT table memory at [mem 0x7ffe0040-0x7ffe2631]
2024-07-20T14:18:27,003031+00:00 ACPI: Reserving FACS table memory at [mem 0x7ffe0000-0x7ffe003f]
2024-07-20T14:18:27,003032+00:00 ACPI: Reserving APIC table memory at [mem 0x7ffe2726-0x7ffe27a5]
2024-07-20T14:18:27,003033+00:00 ACPI: Reserving HPET table memory at [mem 0x7ffe27a6-0x7ffe27dd]
2024-07-20T14:18:27,003033+00:00 ACPI: Reserving MCFG table memory at [mem 0x7ffe27de-0x7ffe2819]
2024-07-20T14:18:27,003034+00:00 ACPI: Reserving WAET table memory at [mem 0x7ffe281a-0x7ffe2841]
2024-07-20T14:18:27,003179+00:00 No NUMA configuration found
2024-07-20T14:18:27,003179+00:00 Faking a node at [mem 0x0000000000000000-0x000000017fffffff]
2024-07-20T14:18:27,003181+00:00 NODE_DATA(0) allocated [mem 0x17fff9000-0x17fffefff]
2024-07-20T14:18:27,003196+00:00 Zone ranges:
2024-07-20T14:18:27,003197+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2024-07-20T14:18:27,003198+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2024-07-20T14:18:27,003199+00:00   Normal   [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:18:27,003200+00:00   Device   empty
2024-07-20T14:18:27,003201+00:00 Movable zone start for each node
2024-07-20T14:18:27,003202+00:00 Early memory node ranges
2024-07-20T14:18:27,003202+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2024-07-20T14:18:27,003203+00:00   node   0: [mem 0x0000000000100000-0x000000007ffdbfff]
2024-07-20T14:18:27,003204+00:00   node   0: [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:18:27,003205+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000017fffffff]
2024-07-20T14:18:27,003212+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2024-07-20T14:18:27,003232+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2024-07-20T14:18:27,008910+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2024-07-20T14:18:27,009490+00:00 ACPI: PM-Timer IO Port: 0x608
2024-07-20T14:18:27,009499+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2024-07-20T14:18:27,009522+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2024-07-20T14:18:27,009524+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2024-07-20T14:18:27,009526+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2024-07-20T14:18:27,009527+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2024-07-20T14:18:27,009528+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2024-07-20T14:18:27,009529+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2024-07-20T14:18:27,009531+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2024-07-20T14:18:27,009532+00:00 ACPI: HPET id: 0x8086a201 base: 0xfed00000
2024-07-20T14:18:27,009536+00:00 smpboot: Allowing 2 CPUs, 0 hotplug CPUs
2024-07-20T14:18:27,009550+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2024-07-20T14:18:27,009567+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2024-07-20T14:18:27,009569+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2024-07-20T14:18:27,009570+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2024-07-20T14:18:27,009570+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2024-07-20T14:18:27,009571+00:00 PM: hibernation: Registered nosave memory: [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:18:27,009572+00:00 PM: hibernation: Registered nosave memory: [mem 0x80000000-0xafffffff]
2024-07-20T14:18:27,009572+00:00 PM: hibernation: Registered nosave memory: [mem 0xb0000000-0xbfffffff]
2024-07-20T14:18:27,009573+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfed1bfff]
2024-07-20T14:18:27,009574+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed1c000-0xfed1ffff]
2024-07-20T14:18:27,009574+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed20000-0xfeffbfff]
2024-07-20T14:18:27,009575+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2024-07-20T14:18:27,009575+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2024-07-20T14:18:27,009576+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2024-07-20T14:18:27,009577+00:00 [mem 0xc0000000-0xfed1bfff] available for PCI devices
2024-07-20T14:18:27,009578+00:00 Booting paravirtualized kernel on KVM
2024-07-20T14:18:27,009580+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2024-07-20T14:18:27,013618+00:00 setup_percpu: NR_CPUS:384 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2024-07-20T14:18:27,013850+00:00 percpu: Embedded 84 pages/cpu s221184 r8192 d114688 u1048576
2024-07-20T14:18:27,013854+00:00 pcpu-alloc: s221184 r8192 d114688 u1048576 alloc=1*2097152
2024-07-20T14:18:27,013856+00:00 pcpu-alloc: [0] 0 1 
2024-07-20T14:18:27,013872+00:00 kvm-guest: PV spinlocks disabled, no host support
2024-07-20T14:18:27,013873+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/vsq52zk5ykskh3cindr7ijlfqpcyp17c-nixos-system-master1-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:18:27,013916+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage", will be passed to user space.
2024-07-20T14:18:27,014255+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-07-20T14:18:27,014439+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-07-20T14:18:27,014463+00:00 Fallback order for Node 0: 0 
2024-07-20T14:18:27,014466+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1031900
2024-07-20T14:18:27,014466+00:00 Policy zone: Normal
2024-07-20T14:18:27,014670+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2024-07-20T14:18:27,014675+00:00 software IO TLB: area num 2.
2024-07-20T14:18:27,033524+00:00 Memory: 3997088K/4193768K available (16384K kernel code, 2371K rwdata, 11016K rodata, 3164K init, 4396K bss, 196420K reserved, 0K cma-reserved)
2024-07-20T14:18:27,054960+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-07-20T14:18:27,055065+00:00 ftrace: allocating 43348 entries in 170 pages
2024-07-20T14:18:27,061060+00:00 ftrace: allocated 170 pages with 4 groups
2024-07-20T14:18:27,061621+00:00 Dynamic Preempt: voluntary
2024-07-20T14:18:27,061724+00:00 rcu: Preemptible hierarchical RCU implementation.
2024-07-20T14:18:27,061725+00:00 rcu: 	RCU event tracing is enabled.
2024-07-20T14:18:27,061725+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=384 to nr_cpu_ids=2.
2024-07-20T14:18:27,061726+00:00 	Trampoline variant of Tasks RCU enabled.
2024-07-20T14:18:27,061727+00:00 	Rude variant of Tasks RCU enabled.
2024-07-20T14:18:27,061727+00:00 	Tracing variant of Tasks RCU enabled.
2024-07-20T14:18:27,061728+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2024-07-20T14:18:27,061728+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-07-20T14:18:27,063991+00:00 NR_IRQS: 24832, nr_irqs: 440, preallocated irqs: 16
2024-07-20T14:18:27,064187+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-07-20T14:18:27,064251+00:00 kfence: initialized - using 2097152 bytes for 255 objects at 0x(____ptrval____)-0x(____ptrval____)
2024-07-20T14:18:27,068852+00:00 Console: colour VGA+ 80x25
2024-07-20T14:18:27,068854+00:00 printk: legacy console [tty0] enabled
2024-07-20T14:18:27,069080+00:00 ACPI: Core revision 20230628
2024-07-20T14:18:27,069217+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604467 ns
2024-07-20T14:18:27,069283+00:00 APIC: Switch to symmetric I/O mode setup
2024-07-20T14:18:27,069398+00:00 x2apic enabled
2024-07-20T14:18:27,069561+00:00 APIC: Switched APIC routing to: physical x2apic
2024-07-20T14:18:27,070244+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2024-07-20T14:18:27,070258+00:00 tsc: Marking TSC unstable due to TSCs unsynchronized
2024-07-20T14:18:27,070261+00:00 Calibrating delay loop (skipped) preset value.. 7186.40 BogoMIPS (lpj=3593200)
2024-07-20T14:18:27,071334+00:00 process: using AMD E400 aware idle routine
2024-07-20T14:18:27,071337+00:00 Last level iTLB entries: 4KB 512, 2MB 255, 4MB 127
2024-07-20T14:18:27,071338+00:00 Last level dTLB entries: 4KB 512, 2MB 255, 4MB 127, 1GB 0
2024-07-20T14:18:27,071343+00:00 x86/fpu: x87 FPU will use FXSAVE
2024-07-20T14:18:27,087414+00:00 Freeing SMP alternatives memory: 36K
2024-07-20T14:18:27,087417+00:00 pid_max: default: 32768 minimum: 301
2024-07-20T14:18:27,087835+00:00 LSM: initializing lsm=capability,landlock,yama,selinux,bpf,integrity
2024-07-20T14:18:27,088009+00:00 landlock: Up and running.
2024-07-20T14:18:27,088010+00:00 Yama: becoming mindful.
2024-07-20T14:18:27,088012+00:00 SELinux:  Initializing.
2024-07-20T14:18:27,088186+00:00 LSM support for eBPF active
2024-07-20T14:18:27,088334+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:18:27,088339+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:18:27,190832+00:00 smpboot: CPU0: AMD QEMU Virtual CPU version 2.5+ (family: 0xf, model: 0x6b, stepping: 0x1)
2024-07-20T14:18:27,190992+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:18:27,191000+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:18:27,191015+00:00 RCU Tasks Trace: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:18:27,191027+00:00 Performance Events: AMD PMU driver.
2024-07-20T14:18:27,191036+00:00 ... version:                0
2024-07-20T14:18:27,191037+00:00 ... bit width:              48
2024-07-20T14:18:27,191037+00:00 ... generic registers:      4
2024-07-20T14:18:27,191038+00:00 ... value mask:             0000ffffffffffff
2024-07-20T14:18:27,191039+00:00 ... max period:             00007fffffffffff
2024-07-20T14:18:27,191039+00:00 ... fixed-purpose events:   0
2024-07-20T14:18:27,191040+00:00 ... event mask:             000000000000000f
2024-07-20T14:18:27,191093+00:00 signal: max sigframe size: 1440
2024-07-20T14:18:27,191118+00:00 rcu: Hierarchical SRCU implementation.
2024-07-20T14:18:27,191118+00:00 rcu: 	Max phase no-delay instances is 400.
2024-07-20T14:18:27,191259+00:00 smp: Bringing up secondary CPUs ...
2024-07-20T14:18:27,191259+00:00 smpboot: x86: Booting SMP configuration:
2024-07-20T14:18:27,191259+00:00 .... node  #0, CPUs:      #1
2024-07-20T14:18:27,191285+00:00 smp: Brought up 1 node, 2 CPUs
2024-07-20T14:18:27,191285+00:00 smpboot: Max logical packages: 2
2024-07-20T14:18:27,191285+00:00 smpboot: Total of 2 processors activated (14372.80 BogoMIPS)
2024-07-20T14:18:27,191458+00:00 devtmpfs: initialized
2024-07-20T14:18:27,191458+00:00 x86/mm: Memory block size: 128MB
2024-07-20T14:18:27,191633+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2024-07-20T14:18:27,191633+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-07-20T14:18:27,192297+00:00 pinctrl core: initialized pinctrl subsystem
2024-07-20T14:18:27,192372+00:00 PM: RTC time: 14:18:27, date: 2024-07-20
2024-07-20T14:18:27,192862+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-07-20T14:18:27,192963+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-07-20T14:18:27,193200+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-07-20T14:18:27,193435+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-07-20T14:18:27,193445+00:00 audit: initializing netlink subsys (disabled)
2024-07-20T14:18:27,193471+00:00 audit: type=2000 audit(1721485107.790:1): state=initialized audit_enabled=0 res=1
2024-07-20T14:18:27,193536+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2024-07-20T14:18:27,193537+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-07-20T14:18:27,193537+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-07-20T14:18:27,193544+00:00 cpuidle: using governor menu
2024-07-20T14:18:27,193625+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-07-20T14:18:27,193740+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] (base 0xb0000000) for domain 0000 [bus 00-ff]
2024-07-20T14:18:27,193743+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] reserved as E820 entry
2024-07-20T14:18:27,193751+00:00 PCI: Using configuration type 1 for base access
2024-07-20T14:18:27,193834+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2024-07-20T14:18:27,193849+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-07-20T14:18:27,193849+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2024-07-20T14:18:27,194313+00:00 ACPI: Added _OSI(Module Device)
2024-07-20T14:18:27,194314+00:00 ACPI: Added _OSI(Processor Device)
2024-07-20T14:18:27,194314+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-07-20T14:18:27,194315+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-07-20T14:18:27,194939+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-07-20T14:18:27,228321+00:00 ACPI: _OSC evaluation for CPUs failed, trying _PDC
2024-07-20T14:18:27,228360+00:00 ACPI: Interpreter enabled
2024-07-20T14:18:27,228368+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2024-07-20T14:18:27,228369+00:00 ACPI: Using IOAPIC for interrupt routing
2024-07-20T14:18:27,228386+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2024-07-20T14:18:27,228387+00:00 PCI: Using E820 reservations for host bridge windows
2024-07-20T14:18:27,228443+00:00 ACPI: Enabled 2 GPEs in block 00 to 3F
2024-07-20T14:18:27,229869+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2024-07-20T14:18:27,229873+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-07-20T14:18:27,229893+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR]
2024-07-20T14:18:27,229920+00:00 acpi PNP0A08:00: _OSC: OS now controls [PME PCIeCapability]
2024-07-20T14:18:27,230024+00:00 PCI host bridge to bus 0000:00
2024-07-20T14:18:27,230025+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2024-07-20T14:18:27,230026+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2024-07-20T14:18:27,230027+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2024-07-20T14:18:27,230028+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xafffffff window]
2024-07-20T14:18:27,230029+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:18:27,230030+00:00 pci_bus 0000:00: root bus resource [mem 0x180000000-0x97fffffff window]
2024-07-20T14:18:27,230031+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2024-07-20T14:18:27,230063+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2024-07-20T14:18:27,230300+00:00 pci 0000:00:01.0: [1013:00b8] type 00 class 0x030000 conventional PCI endpoint
2024-07-20T14:18:27,232260+00:00 pci 0000:00:01.0: BAR 0 [mem 0xfa000000-0xfbffffff pref]
2024-07-20T14:18:27,233260+00:00 pci 0000:00:01.0: BAR 1 [mem 0xfea10000-0xfea10fff]
2024-07-20T14:18:27,239260+00:00 pci 0000:00:01.0: ROM [mem 0xfea00000-0xfea0ffff pref]
2024-07-20T14:18:27,239298+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2024-07-20T14:18:27,239452+00:00 pci 0000:00:02.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,240789+00:00 pci 0000:00:02.0: BAR 0 [mem 0xfea11000-0xfea11fff]
2024-07-20T14:18:27,244930+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:18:27,244952+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:18:27,245675+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:18:27,246056+00:00 pci 0000:00:02.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,247148+00:00 pci 0000:00:02.1: BAR 0 [mem 0xfea12000-0xfea12fff]
2024-07-20T14:18:27,248264+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:18:27,248284+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:18:27,248703+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:18:27,249401+00:00 pci 0000:00:02.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,250260+00:00 pci 0000:00:02.2: BAR 0 [mem 0xfea13000-0xfea13fff]
2024-07-20T14:18:27,252109+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:18:27,252129+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:18:27,252461+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:18:27,252820+00:00 pci 0000:00:02.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,254261+00:00 pci 0000:00:02.3: BAR 0 [mem 0xfea14000-0xfea14fff]
2024-07-20T14:18:27,257930+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:18:27,257951+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:18:27,258453+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:18:27,258828+00:00 pci 0000:00:02.4: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,260028+00:00 pci 0000:00:02.4: BAR 0 [mem 0xfea15000-0xfea15fff]
2024-07-20T14:18:27,261627+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:18:27,261647+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:18:27,262068+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:18:27,262463+00:00 pci 0000:00:02.5: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,263607+00:00 pci 0000:00:02.5: BAR 0 [mem 0xfea16000-0xfea16fff]
2024-07-20T14:18:27,264983+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:18:27,265003+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:18:27,265275+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:18:27,265642+00:00 pci 0000:00:02.6: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,267260+00:00 pci 0000:00:02.6: BAR 0 [mem 0xfea17000-0xfea17fff]
2024-07-20T14:18:27,270951+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:18:27,270971+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:18:27,271451+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:18:27,271827+00:00 pci 0000:00:02.7: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,272932+00:00 pci 0000:00:02.7: BAR 0 [mem 0xfea18000-0xfea18fff]
2024-07-20T14:18:27,274264+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:18:27,274284+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:18:27,274674+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:18:27,275039+00:00 pci 0000:00:03.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:18:27,276142+00:00 pci 0000:00:03.0: BAR 0 [mem 0xfea19000-0xfea19fff]
2024-07-20T14:18:27,277265+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:18:27,277287+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:18:27,277669+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:18:27,278403+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2024-07-20T14:18:27,278628+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2024-07-20T14:18:27,278751+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2024-07-20T14:18:27,283592+00:00 pci 0000:00:1f.2: BAR 4 [io  0xc040-0xc05f]
2024-07-20T14:18:27,284260+00:00 pci 0000:00:1f.2: BAR 5 [mem 0xfea1a000-0xfea1afff]
2024-07-20T14:18:27,285096+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2024-07-20T14:18:27,286928+00:00 pci 0000:00:1f.3: BAR 4 [io  0x0700-0x073f]
2024-07-20T14:18:27,288010+00:00 acpiphp: Slot [0] registered
2024-07-20T14:18:27,288115+00:00 pci 0000:01:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:18:27,289260+00:00 pci 0000:01:00.0: BAR 1 [mem 0xfe880000-0xfe880fff]
2024-07-20T14:18:27,293644+00:00 pci 0000:01:00.0: BAR 4 [mem 0xfd000000-0xfd003fff 64bit pref]
2024-07-20T14:18:27,294604+00:00 pci 0000:01:00.0: ROM [mem 0xfe800000-0xfe87ffff pref]
2024-07-20T14:18:27,295498+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:18:27,296012+00:00 acpiphp: Slot [0-1] registered
2024-07-20T14:18:27,296091+00:00 pci 0000:02:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:18:27,297260+00:00 pci 0000:02:00.0: BAR 1 [mem 0xfe680000-0xfe680fff]
2024-07-20T14:18:27,299260+00:00 pci 0000:02:00.0: BAR 4 [mem 0xfce00000-0xfce03fff 64bit pref]
2024-07-20T14:18:27,299909+00:00 pci 0000:02:00.0: ROM [mem 0xfe600000-0xfe67ffff pref]
2024-07-20T14:18:27,300702+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:18:27,301235+00:00 acpiphp: Slot [0-2] registered
2024-07-20T14:18:27,301304+00:00 pci 0000:03:00.0: [1b36:000d] type 00 class 0x0c0330 PCIe Endpoint
2024-07-20T14:18:27,301686+00:00 pci 0000:03:00.0: BAR 0 [mem 0xfe400000-0xfe403fff 64bit]
2024-07-20T14:18:27,305743+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:18:27,306553+00:00 acpiphp: Slot [0-3] registered
2024-07-20T14:18:27,306631+00:00 pci 0000:04:00.0: [1af4:1043] type 00 class 0x078000 PCIe Endpoint
2024-07-20T14:18:27,307906+00:00 pci 0000:04:00.0: BAR 1 [mem 0xfe200000-0xfe200fff]
2024-07-20T14:18:27,309934+00:00 pci 0000:04:00.0: BAR 4 [mem 0xfca00000-0xfca03fff 64bit pref]
2024-07-20T14:18:27,311517+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:18:27,312130+00:00 acpiphp: Slot [0-4] registered
2024-07-20T14:18:27,312213+00:00 pci 0000:05:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:18:27,313622+00:00 pci 0000:05:00.0: BAR 1 [mem 0xfe000000-0xfe000fff]
2024-07-20T14:18:27,315629+00:00 pci 0000:05:00.0: BAR 4 [mem 0xfc800000-0xfc803fff 64bit pref]
2024-07-20T14:18:27,318775+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:18:27,319307+00:00 acpiphp: Slot [0-5] registered
2024-07-20T14:18:27,319390+00:00 pci 0000:06:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:18:27,320598+00:00 pci 0000:06:00.0: BAR 1 [mem 0xfde00000-0xfde00fff]
2024-07-20T14:18:27,322622+00:00 pci 0000:06:00.0: BAR 4 [mem 0xfc600000-0xfc603fff 64bit pref]
2024-07-20T14:18:27,323952+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:18:27,324544+00:00 acpiphp: Slot [0-6] registered
2024-07-20T14:18:27,324620+00:00 pci 0000:07:00.0: [1af4:1045] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:18:27,326260+00:00 pci 0000:07:00.0: BAR 4 [mem 0xfc400000-0xfc403fff 64bit pref]
2024-07-20T14:18:27,327395+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:18:27,329342+00:00 acpiphp: Slot [0-7] registered
2024-07-20T14:18:27,329417+00:00 pci 0000:08:00.0: [1af4:1044] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:18:27,331782+00:00 pci 0000:08:00.0: BAR 4 [mem 0xfc200000-0xfc203fff 64bit pref]
2024-07-20T14:18:27,332893+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:18:27,333349+00:00 acpiphp: Slot [0-8] registered
2024-07-20T14:18:27,333359+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:18:27,337039+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2024-07-20T14:18:27,337081+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2024-07-20T14:18:27,337284+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2024-07-20T14:18:27,337319+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2024-07-20T14:18:27,337353+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2024-07-20T14:18:27,337387+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2024-07-20T14:18:27,337422+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2024-07-20T14:18:27,337456+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2024-07-20T14:18:27,337472+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2024-07-20T14:18:27,337476+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2024-07-20T14:18:27,337480+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2024-07-20T14:18:27,337484+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2024-07-20T14:18:27,337488+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2024-07-20T14:18:27,337492+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2024-07-20T14:18:27,337495+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2024-07-20T14:18:27,337499+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2024-07-20T14:18:27,337636+00:00 iommu: Default domain type: Translated
2024-07-20T14:18:27,337637+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2024-07-20T14:18:27,337664+00:00 ACPI: bus type USB registered
2024-07-20T14:18:27,337672+00:00 usbcore: registered new interface driver usbfs
2024-07-20T14:18:27,337677+00:00 usbcore: registered new interface driver hub
2024-07-20T14:18:27,337680+00:00 usbcore: registered new device driver usb
2024-07-20T14:18:27,337755+00:00 NetLabel: Initializing
2024-07-20T14:18:27,337755+00:00 NetLabel:  domain hash size = 128
2024-07-20T14:18:27,337755+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-07-20T14:18:27,337755+00:00 NetLabel:  unlabeled traffic allowed by default
2024-07-20T14:18:27,337755+00:00 PCI: Using ACPI for IRQ routing
2024-07-20T14:18:27,367856+00:00 PCI: pci_cache_line_size set to 64 bytes
2024-07-20T14:18:27,368032+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2024-07-20T14:18:27,368034+00:00 e820: reserve RAM buffer [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:18:27,368050+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2024-07-20T14:18:27,368050+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2024-07-20T14:18:27,368050+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2024-07-20T14:18:27,368050+00:00 vgaarb: loaded
2024-07-20T14:18:27,368050+00:00 hpet: 3 channels of 0 reserved for per-cpu timers
2024-07-20T14:18:27,368050+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2024-07-20T14:18:27,368050+00:00 hpet0: 3 comparators, 64-bit 100.000000 MHz counter
2024-07-20T14:18:27,371286+00:00 clocksource: Switched to clocksource kvm-clock
2024-07-20T14:18:27,372080+00:00 VFS: Disk quotas dquot_6.6.0
2024-07-20T14:18:27,372103+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-07-20T14:18:27,372158+00:00 pnp: PnP ACPI init
2024-07-20T14:18:27,372255+00:00 system 00:04: [mem 0xb0000000-0xbfffffff window] has been reserved
2024-07-20T14:18:27,372411+00:00 pnp: PnP ACPI: found 5 devices
2024-07-20T14:18:27,378747+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2024-07-20T14:18:27,378873+00:00 NET: Registered PF_INET protocol family
2024-07-20T14:18:27,378932+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-07-20T14:18:27,387326+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-07-20T14:18:27,387342+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-07-20T14:18:27,387356+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-07-20T14:18:27,387436+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-07-20T14:18:27,387680+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-07-20T14:18:27,387754+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-07-20T14:18:27,387780+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:18:27,387808+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:18:27,387875+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-07-20T14:18:27,387881+00:00 NET: Registered PF_XDP protocol family
2024-07-20T14:18:27,387886+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2024-07-20T14:18:27,387888+00:00 pci 0000:00:02.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2024-07-20T14:18:27,387889+00:00 pci 0000:00:02.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2024-07-20T14:18:27,387891+00:00 pci 0000:00:02.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2024-07-20T14:18:27,387892+00:00 pci 0000:00:02.4: bridge window [io  0x1000-0x0fff] to [bus 05] add_size 1000
2024-07-20T14:18:27,387893+00:00 pci 0000:00:02.5: bridge window [io  0x1000-0x0fff] to [bus 06] add_size 1000
2024-07-20T14:18:27,387894+00:00 pci 0000:00:02.6: bridge window [io  0x1000-0x0fff] to [bus 07] add_size 1000
2024-07-20T14:18:27,387895+00:00 pci 0000:00:02.7: bridge window [io  0x1000-0x0fff] to [bus 08] add_size 1000
2024-07-20T14:18:27,387896+00:00 pci 0000:00:03.0: bridge window [io  0x1000-0x0fff] to [bus 09] add_size 1000
2024-07-20T14:18:27,387902+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x1fff]: assigned
2024-07-20T14:18:27,387903+00:00 pci 0000:00:02.1: bridge window [io  0x2000-0x2fff]: assigned
2024-07-20T14:18:27,387904+00:00 pci 0000:00:02.2: bridge window [io  0x3000-0x3fff]: assigned
2024-07-20T14:18:27,387905+00:00 pci 0000:00:02.3: bridge window [io  0x4000-0x4fff]: assigned
2024-07-20T14:18:27,387906+00:00 pci 0000:00:02.4: bridge window [io  0x5000-0x5fff]: assigned
2024-07-20T14:18:27,387907+00:00 pci 0000:00:02.5: bridge window [io  0x6000-0x6fff]: assigned
2024-07-20T14:18:27,387908+00:00 pci 0000:00:02.6: bridge window [io  0x7000-0x7fff]: assigned
2024-07-20T14:18:27,387909+00:00 pci 0000:00:02.7: bridge window [io  0x8000-0x8fff]: assigned
2024-07-20T14:18:27,387910+00:00 pci 0000:00:03.0: bridge window [io  0x9000-0x9fff]: assigned
2024-07-20T14:18:27,387913+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:18:27,387922+00:00 pci 0000:00:02.0:   bridge window [io  0x1000-0x1fff]
2024-07-20T14:18:27,388921+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:18:27,389495+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:18:27,390610+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:18:27,390616+00:00 pci 0000:00:02.1:   bridge window [io  0x2000-0x2fff]
2024-07-20T14:18:27,391442+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:18:27,392000+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:18:27,393108+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:18:27,393115+00:00 pci 0000:00:02.2:   bridge window [io  0x3000-0x3fff]
2024-07-20T14:18:27,393941+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:18:27,394495+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:18:27,395617+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:18:27,395623+00:00 pci 0000:00:02.3:   bridge window [io  0x4000-0x4fff]
2024-07-20T14:18:27,396454+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:18:27,396999+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:18:27,398127+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:18:27,398134+00:00 pci 0000:00:02.4:   bridge window [io  0x5000-0x5fff]
2024-07-20T14:18:27,400287+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:18:27,401900+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:18:27,402683+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:18:27,402689+00:00 pci 0000:00:02.5:   bridge window [io  0x6000-0x6fff]
2024-07-20T14:18:27,403284+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:18:27,403663+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:18:27,404430+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:18:27,404436+00:00 pci 0000:00:02.6:   bridge window [io  0x7000-0x7fff]
2024-07-20T14:18:27,405017+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:18:27,405401+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:18:27,406147+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:18:27,406153+00:00 pci 0000:00:02.7:   bridge window [io  0x8000-0x8fff]
2024-07-20T14:18:27,406742+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:18:27,407123+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:18:27,407931+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:18:27,407937+00:00 pci 0000:00:03.0:   bridge window [io  0x9000-0x9fff]
2024-07-20T14:18:27,408566+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:18:27,409168+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:18:27,410287+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2024-07-20T14:18:27,410289+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2024-07-20T14:18:27,410290+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2024-07-20T14:18:27,410291+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xafffffff window]
2024-07-20T14:18:27,410292+00:00 pci_bus 0000:00: resource 8 [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:18:27,410293+00:00 pci_bus 0000:00: resource 9 [mem 0x180000000-0x97fffffff window]
2024-07-20T14:18:27,410294+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2024-07-20T14:18:27,410295+00:00 pci_bus 0000:01: resource 1 [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:18:27,410296+00:00 pci_bus 0000:01: resource 2 [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:18:27,410298+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2024-07-20T14:18:27,410298+00:00 pci_bus 0000:02: resource 1 [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:18:27,410299+00:00 pci_bus 0000:02: resource 2 [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:18:27,410300+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2024-07-20T14:18:27,410301+00:00 pci_bus 0000:03: resource 1 [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:18:27,410302+00:00 pci_bus 0000:03: resource 2 [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:18:27,410303+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2024-07-20T14:18:27,410304+00:00 pci_bus 0000:04: resource 1 [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:18:27,410305+00:00 pci_bus 0000:04: resource 2 [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:18:27,410307+00:00 pci_bus 0000:05: resource 0 [io  0x5000-0x5fff]
2024-07-20T14:18:27,410307+00:00 pci_bus 0000:05: resource 1 [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:18:27,410308+00:00 pci_bus 0000:05: resource 2 [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:18:27,410309+00:00 pci_bus 0000:06: resource 0 [io  0x6000-0x6fff]
2024-07-20T14:18:27,410310+00:00 pci_bus 0000:06: resource 1 [mem 0xfde00000-0xfdffffff]
2024-07-20T14:18:27,410311+00:00 pci_bus 0000:06: resource 2 [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:18:27,410312+00:00 pci_bus 0000:07: resource 0 [io  0x7000-0x7fff]
2024-07-20T14:18:27,410313+00:00 pci_bus 0000:07: resource 1 [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:18:27,410314+00:00 pci_bus 0000:07: resource 2 [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:18:27,410315+00:00 pci_bus 0000:08: resource 0 [io  0x8000-0x8fff]
2024-07-20T14:18:27,410316+00:00 pci_bus 0000:08: resource 1 [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:18:27,410316+00:00 pci_bus 0000:08: resource 2 [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:18:27,410317+00:00 pci_bus 0000:09: resource 0 [io  0x9000-0x9fff]
2024-07-20T14:18:27,410318+00:00 pci_bus 0000:09: resource 1 [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:18:27,410319+00:00 pci_bus 0000:09: resource 2 [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:18:27,410596+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2024-07-20T14:18:27,415096+00:00 PCI: CLS 0 bytes, default 64
2024-07-20T14:18:27,415110+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2024-07-20T14:18:27,415111+00:00 software IO TLB: mapped [mem 0x000000007bfdc000-0x000000007ffdc000] (64MB)
2024-07-20T14:18:27,415288+00:00 Trying to unpack rootfs image as initramfs...
2024-07-20T14:18:27,416240+00:00 Initialise system trusted keyrings
2024-07-20T14:18:27,416298+00:00 workingset: timestamp_bits=40 max_order=20 bucket_order=0
2024-07-20T14:18:27,433107+00:00 Key type asymmetric registered
2024-07-20T14:18:27,433113+00:00 Asymmetric key parser 'x509' registered
2024-07-20T14:18:27,433163+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 251)
2024-07-20T14:18:27,433248+00:00 io scheduler mq-deadline registered
2024-07-20T14:18:27,433249+00:00 io scheduler kyber registered
2024-07-20T14:18:27,435879+00:00 pcieport 0000:00:02.0: PME: Signaling with IRQ 24
2024-07-20T14:18:27,438264+00:00 pcieport 0000:00:02.1: PME: Signaling with IRQ 25
2024-07-20T14:18:27,439394+00:00 pcieport 0000:00:02.2: PME: Signaling with IRQ 26
2024-07-20T14:18:27,441731+00:00 pcieport 0000:00:02.3: PME: Signaling with IRQ 27
2024-07-20T14:18:27,444093+00:00 pcieport 0000:00:02.4: PME: Signaling with IRQ 28
2024-07-20T14:18:27,446900+00:00 pcieport 0000:00:02.5: PME: Signaling with IRQ 29
2024-07-20T14:18:27,448765+00:00 pcieport 0000:00:02.6: PME: Signaling with IRQ 30
2024-07-20T14:18:27,450684+00:00 pcieport 0000:00:02.7: PME: Signaling with IRQ 31
2024-07-20T14:18:27,451222+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2024-07-20T14:18:27,453044+00:00 pcieport 0000:00:03.0: PME: Signaling with IRQ 32
2024-07-20T14:18:27,453630+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2024-07-20T14:18:27,453811+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2024-07-20T14:18:27,454363+00:00 Linux agpgart interface v0.103
2024-07-20T14:18:27,454375+00:00 ACPI: bus type drm_connector registered
2024-07-20T14:18:27,454843+00:00 usbcore: registered new interface driver usbserial_generic
2024-07-20T14:18:27,454849+00:00 usbserial: USB Serial support registered for generic
2024-07-20T14:18:27,454852+00:00 amd_pstate: the _CPC object is not present in SBIOS or ACPI disabled
2024-07-20T14:18:27,454920+00:00 drop_monitor: Initializing network drop monitor service
2024-07-20T14:18:27,455241+00:00 NET: Registered PF_INET6 protocol family
2024-07-20T14:18:27,472714+00:00 Freeing initrd memory: 11624K
2024-07-20T14:18:27,473041+00:00 Segment Routing with IPv6
2024-07-20T14:18:27,473066+00:00 In-situ OAM (IOAM) with IPv6
2024-07-20T14:18:27,473343+00:00 IPI shorthand broadcast: enabled
2024-07-20T14:18:27,475350+00:00 sched_clock: Marking stable (470006166, 5067360)->(486683471, -11609945)
2024-07-20T14:18:27,475481+00:00 registered taskstats version 1
2024-07-20T14:18:27,475575+00:00 Loading compiled-in X.509 certificates
2024-07-20T14:18:27,480259+00:00 Key type .fscrypt registered
2024-07-20T14:18:27,480262+00:00 Key type fscrypt-provisioning registered
2024-07-20T14:18:27,480406+00:00 PM:   Magic number: 0:266:334
2024-07-20T14:18:27,480418+00:00 tty tty55: hash matches
2024-07-20T14:18:27,483886+00:00 RAS: Correctable Errors collector initialized.
2024-07-20T14:18:27,483949+00:00 clk: Disabling unused clocks
2024-07-20T14:18:27,485717+00:00 Freeing unused decrypted memory: 2028K
2024-07-20T14:18:27,486216+00:00 Freeing unused kernel image (initmem) memory: 3164K
2024-07-20T14:18:27,486218+00:00 Write protecting the kernel read-only data: 28672k
2024-07-20T14:18:27,486585+00:00 Freeing unused kernel image (rodata/data gap) memory: 1272K
2024-07-20T14:18:27,509305+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2024-07-20T14:18:27,509327+00:00 Run /init as init process
2024-07-20T14:18:27,509329+00:00   with arguments:
2024-07-20T14:18:27,509331+00:00     /init
2024-07-20T14:18:27,509332+00:00   with environment:
2024-07-20T14:18:27,509333+00:00     HOME=/
2024-07-20T14:18:27,509334+00:00     TERM=linux
2024-07-20T14:18:27,509334+00:00     BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage
2024-07-20T14:18:27,526109+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] loading module virtio_balloon...
2024-07-20T14:18:27,529676+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] loading module virtio_console...
2024-07-20T14:18:27,535096+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] loading module virtio_rng...
2024-07-20T14:18:27,538116+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] loading module virtio_gpu...
2024-07-20T14:18:27,543607+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] loading module dm_mod...
2024-07-20T14:18:27,560092+00:00 device-mapper: ioctl: 4.48.0-ioctl (2023-03-01) initialised: dm-devel@redhat.com
2024-07-20T14:18:27,561368+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] running udev...
2024-07-20T14:18:27,572623+00:00 stage-1-init: [Sat Jul 20 14:18:28 UTC 2024] Starting systemd-udevd version 255.6
2024-07-20T14:18:27,622382+00:00 rtc_cmos 00:03: RTC can wake from S4
2024-07-20T14:18:27,629923+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2024-07-20T14:18:27,635419+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2024-07-20T14:18:27,635577+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2024-07-20T14:18:27,637354+00:00 rtc_cmos 00:03: registered as rtc0
2024-07-20T14:18:27,637396+00:00 rtc_cmos 00:03: setting system clock to 2024-07-20T14:18:27 UTC (1721485107)
2024-07-20T14:18:27,637433+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram, hpet irqs
2024-07-20T14:18:27,658200+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:18:27,658208+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 1
2024-07-20T14:18:27,658362+00:00 xhci_hcd 0000:03:00.0: hcc params 0x00087001 hci version 0x100 quirks 0x0000000000000010
2024-07-20T14:18:27,658683+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:18:27,658685+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 2
2024-07-20T14:18:27,658687+00:00 xhci_hcd 0000:03:00.0: Host supports USB 3.0 SuperSpeed
2024-07-20T14:18:27,658731+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.08
2024-07-20T14:18:27,658733+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:18:27,658734+00:00 usb usb1: Product: xHCI Host Controller
2024-07-20T14:18:27,658735+00:00 usb usb1: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:18:27,658736+00:00 usb usb1: SerialNumber: 0000:03:00.0
2024-07-20T14:18:27,659157+00:00 hub 1-0:1.0: USB hub found
2024-07-20T14:18:27,659173+00:00 hub 1-0:1.0: 4 ports detected
2024-07-20T14:18:27,659306+00:00 usb usb2: We don't know the algorithms for LPM for this host, disabling LPM.
2024-07-20T14:18:27,659319+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.08
2024-07-20T14:18:27,659320+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:18:27,659321+00:00 usb usb2: Product: xHCI Host Controller
2024-07-20T14:18:27,659322+00:00 usb usb2: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:18:27,659323+00:00 usb usb2: SerialNumber: 0000:03:00.0
2024-07-20T14:18:27,659420+00:00 hub 2-0:1.0: USB hub found
2024-07-20T14:18:27,659434+00:00 hub 2-0:1.0: 4 ports detected
2024-07-20T14:18:27,666486+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input0
2024-07-20T14:18:27,668305+00:00 random: crng init done
2024-07-20T14:18:27,678377+00:00 virtio_blk virtio3: 2/0/0 default/read/poll queues
2024-07-20T14:18:27,678800+00:00 virtio_blk virtio3: [vda] 83886080 512-byte logical blocks (42.9 GB/40.0 GiB)
2024-07-20T14:18:27,679896+00:00 virtio_net virtio1 enp2s0: renamed from eth1
2024-07-20T14:18:27,681892+00:00 SCSI subsystem initialized
2024-07-20T14:18:27,682184+00:00  vda: vda1 vda2 vda3
2024-07-20T14:18:27,683180+00:00 virtio_blk virtio4: 2/0/0 default/read/poll queues
2024-07-20T14:18:27,683556+00:00 virtio_blk virtio4: [vdb] 83886080 512-byte logical blocks (42.9 GB/40.0 GiB)
2024-07-20T14:18:27,685032+00:00 virtio_net virtio0 enp1s0: renamed from eth0
2024-07-20T14:18:27,696940+00:00 libata version 3.00 loaded.
2024-07-20T14:18:27,700143+00:00 ahci 0000:00:1f.2: version 3.0
2024-07-20T14:18:27,700291+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2024-07-20T14:18:27,700650+00:00 ahci 0000:00:1f.2: AHCI 0001.0000 32 slots 6 ports 1.5 Gbps 0x3f impl SATA mode
2024-07-20T14:18:27,700652+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2024-07-20T14:18:27,701333+00:00 scsi host0: ahci
2024-07-20T14:18:27,701464+00:00 scsi host1: ahci
2024-07-20T14:18:27,701554+00:00 scsi host2: ahci
2024-07-20T14:18:27,701644+00:00 scsi host3: ahci
2024-07-20T14:18:27,701736+00:00 scsi host4: ahci
2024-07-20T14:18:27,701808+00:00 scsi host5: ahci
2024-07-20T14:18:27,701838+00:00 ata1: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a100 irq 50 lpm-pol 0
2024-07-20T14:18:27,701843+00:00 ata2: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a180 irq 50 lpm-pol 0
2024-07-20T14:18:27,701847+00:00 ata3: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a200 irq 50 lpm-pol 0
2024-07-20T14:18:27,701850+00:00 ata4: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a280 irq 50 lpm-pol 0
2024-07-20T14:18:27,701854+00:00 ata5: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a300 irq 50 lpm-pol 0
2024-07-20T14:18:27,701857+00:00 ata6: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a380 irq 50 lpm-pol 0
2024-07-20T14:18:28,011878+00:00 ata2: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:18:28,012017+00:00 ata1: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:18:28,012152+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:18:28,012276+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:18:28,012408+00:00 ata4: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2024-07-20T14:18:28,012584+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:18:28,012628+00:00 ata4.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2024-07-20T14:18:28,012633+00:00 ata4.00: applying bridge limits
2024-07-20T14:18:28,012731+00:00 ata4.00: configured for UDMA/100
2024-07-20T14:18:28,012930+00:00 scsi 3:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2024-07-20T14:18:28,021438+00:00 sr 3:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2024-07-20T14:18:28,021443+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2024-07-20T14:18:28,022320+00:00 sr 3:0:0:0: Attached scsi CD-ROM sr0
2024-07-20T14:18:28,051835+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] starting device mapper and LVM...
2024-07-20T14:18:28,066539+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] 1 logical volume(s) in volume group "pool" now active
2024-07-20T14:18:28,088946+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] checking /dev/pool/root...
2024-07-20T14:18:28,089847+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] fsck (busybox 1.36.1)
2024-07-20T14:18:28,090833+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] [fsck.ext4 (1) -- /mnt-root/] fsck.ext4 -a /dev/pool/root
2024-07-20T14:18:28,091784+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] /dev/pool/root: clean, 128916/2591792 files, 763842/10356736 blocks
2024-07-20T14:18:28,101506+00:00 stage-1-init: [Sat Jul 20 14:18:27 UTC 2024] mounting /dev/pool/root on /...
2024-07-20T14:18:28,205914+00:00 EXT4-fs (dm-0): mounted filesystem 7ab5c3a1-1012-44b8-8a42-1a0c6404bf11 r/w with ordered data mode. Quota mode: none.
2024-07-20T14:18:28,212096+00:00 EXT4-fs (dm-0): re-mounted 7ab5c3a1-1012-44b8-8a42-1a0c6404bf11 r/w. Quota mode: none.
2024-07-20T14:18:28,326086+00:00 EXT4-fs (dm-0): re-mounted 7ab5c3a1-1012-44b8-8a42-1a0c6404bf11 r/w. Quota mode: none.
2024-07-20T14:18:28,326354+00:00 booting system configuration /nix/store/vsq52zk5ykskh3cindr7ijlfqpcyp17c-nixos-system-master1-24.11.20240716.ad0b5ee
2024-07-20T14:18:28,337886+00:00 stage-2-init: running activation script...
2024-07-20T14:18:28,421687+00:00 stage-2-init: setting up /etc...
2024-07-20T14:18:28,515984+00:00 systemd[1]: Inserted module 'autofs4'
2024-07-20T14:18:28,530854+00:00 systemd[1]: systemd 255.6 running in system mode (+PAM +AUDIT -SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -BPF_FRAMEWORK -XKBCOMMON +UTMP -SYSVINIT default-hierarchy=unified)
2024-07-20T14:18:28,530859+00:00 systemd[1]: Detected virtualization kvm.
2024-07-20T14:18:28,530869+00:00 systemd[1]: Detected architecture x86-64.
2024-07-20T14:18:28,532175+00:00 systemd[1]: Hostname set to <master1>.
2024-07-20T14:18:28,532402+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-07-20T14:18:28,664431+00:00 systemd[1]: Queued start job for default target Multi-User System.
2024-07-20T14:18:28,674407+00:00 systemd[1]: Created slice Slice /system/getty.
2024-07-20T14:18:28,674931+00:00 systemd[1]: Created slice Slice /system/modprobe.
2024-07-20T14:18:28,675419+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2024-07-20T14:18:28,675897+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2024-07-20T14:18:28,676363+00:00 systemd[1]: Created slice User and Session Slice.
2024-07-20T14:18:28,676609+00:00 systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
2024-07-20T14:18:28,676868+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2024-07-20T14:18:28,677121+00:00 systemd[1]: Expecting device /dev/disk/by-partlabel/disk-disk1-ESP...
2024-07-20T14:18:28,677354+00:00 systemd[1]: Expecting device /dev/hvc0...
2024-07-20T14:18:28,677542+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp1s0...
2024-07-20T14:18:28,677762+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp2s0...
2024-07-20T14:18:28,677987+00:00 systemd[1]: Reached target Local Encrypted Volumes.
2024-07-20T14:18:28,678207+00:00 systemd[1]: Reached target Containers.
2024-07-20T14:18:28,678407+00:00 systemd[1]: Reached target Path Units.
2024-07-20T14:18:28,678598+00:00 systemd[1]: Reached target Remote File Systems.
2024-07-20T14:18:28,678796+00:00 systemd[1]: Reached target Slice Units.
2024-07-20T14:18:28,678990+00:00 systemd[1]: Reached target Swaps.
2024-07-20T14:18:28,680047+00:00 systemd[1]: Listening on Process Core Dump Socket.
2024-07-20T14:18:28,680345+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2024-07-20T14:18:28,680619+00:00 systemd[1]: Listening on Journal Socket.
2024-07-20T14:18:28,680894+00:00 systemd[1]: Listening on Userspace Out-Of-Memory (OOM) Killer Socket.
2024-07-20T14:18:28,681412+00:00 systemd[1]: Listening on udev Control Socket.
2024-07-20T14:18:28,681674+00:00 systemd[1]: Listening on udev Kernel Socket.
2024-07-20T14:18:28,682574+00:00 systemd[1]: Mounting Huge Pages File System...
2024-07-20T14:18:28,684121+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2024-07-20T14:18:28,687435+00:00 systemd[1]: Mounting Kernel Debug File System...
2024-07-20T14:18:28,690998+00:00 systemd[1]: Starting domainname.service...
2024-07-20T14:18:28,692183+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2024-07-20T14:18:28,695497+00:00 systemd[1]: Starting Load Kernel Module configfs...
2024-07-20T14:18:28,698150+00:00 systemd[1]: Starting Load Kernel Module drm...
2024-07-20T14:18:28,699984+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2024-07-20T14:18:28,701164+00:00 systemd[1]: Starting Load Kernel Module fuse...
2024-07-20T14:18:28,702134+00:00 systemd[1]: Starting mount-pstore.service...
2024-07-20T14:18:28,703208+00:00 systemd[1]: Starting Create SUID/SGID Wrappers...
2024-07-20T14:18:28,705115+00:00 systemd[1]: File System Check on Root Device was skipped because of an unmet condition check (ConditionPathIsReadWrite=!/).
2024-07-20T14:18:28,705955+00:00 systemd[1]: Starting Journal Service...
2024-07-20T14:18:28,714168+00:00 systemd[1]: Starting Load Kernel Modules...
2024-07-20T14:18:28,716152+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2024-07-20T14:18:28,718226+00:00 systemd[1]: Starting Coldplug All udev Devices...
2024-07-20T14:18:28,719566+00:00 systemd[1]: Mounted Huge Pages File System.
2024-07-20T14:18:28,721339+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2024-07-20T14:18:28,721814+00:00 systemd[1]: Mounted Kernel Debug File System.
2024-07-20T14:18:28,723206+00:00 systemd[1]: domainname.service: Deactivated successfully.
2024-07-20T14:18:28,723305+00:00 systemd[1]: Finished domainname.service.
2024-07-20T14:18:28,723709+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2024-07-20T14:18:28,724838+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-07-20T14:18:28,724918+00:00 systemd[1]: Finished Load Kernel Module configfs.
2024-07-20T14:18:28,725586+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-07-20T14:18:28,725660+00:00 systemd[1]: Finished Load Kernel Module drm.
2024-07-20T14:18:28,731156+00:00 systemd[1]: Mounting Kernel Configuration File System...
2024-07-20T14:18:28,732261+00:00 systemd[1]: Starting Create Static Device Nodes in /dev gracefully...
2024-07-20T14:18:28,733203+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-07-20T14:18:28,733296+00:00 systemd[1]: Finished Load Kernel Module efi_pstore.
2024-07-20T14:18:28,739023+00:00 NET: Registered PF_ALG protocol family
2024-07-20T14:18:28,741624+00:00 systemd[1]: Mounted Kernel Configuration File System.
2024-07-20T14:18:28,750478+00:00 systemd-journald[401]: Collecting audit messages is disabled.
2024-07-20T14:18:28,755928+00:00 EXT4-fs (dm-0): re-mounted 7ab5c3a1-1012-44b8-8a42-1a0c6404bf11 r/w. Quota mode: none.
2024-07-20T14:18:28,756720+00:00 fuse: init (API version 7.39)
2024-07-20T14:18:28,759154+00:00 systemd[1]: Finished Remount Root and Kernel File Systems.
2024-07-20T14:18:28,765184+00:00 systemd[1]: Starting Load/Save OS Random Seed...
2024-07-20T14:18:28,765559+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-07-20T14:18:28,765658+00:00 systemd[1]: Finished Load Kernel Module fuse.
2024-07-20T14:18:28,768210+00:00 systemd[1]: Mounting FUSE Control File System...
2024-07-20T14:18:28,771126+00:00 systemd[1]: Finished Create Static Device Nodes in /dev gracefully.
2024-07-20T14:18:28,773693+00:00 systemd[1]: Starting Create Static Device Nodes in /dev...
2024-07-20T14:18:28,774358+00:00 systemd[1]: Mounted FUSE Control File System.
2024-07-20T14:18:28,783501+00:00 systemd[1]: Finished Load/Save OS Random Seed.
2024-07-20T14:18:28,788951+00:00 systemd[1]: Finished Create Static Device Nodes in /dev.
2024-07-20T14:18:28,789334+00:00 systemd[1]: Reached target Preparation for Local File Systems.
2024-07-20T14:18:28,794267+00:00 systemd[1]: Starting Rule-based Manager for Device Events and Files...
2024-07-20T14:18:28,808473+00:00 systemd[1]: Started Journal Service.
2024-07-20T14:18:28,821235+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2024-07-20T14:18:28,831622+00:00 systemd-journald[401]: Received client request to flush runtime journal.
2024-07-20T14:18:28,833045+00:00 tun: Universal TUN/TAP device driver, 1.6
2024-07-20T14:18:28,845853+00:00 loop: module loaded
2024-07-20T14:18:28,931223+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input2
2024-07-20T14:18:28,934593+00:00 cirrus 0000:00:01.0: vgaarb: deactivate vga console
2024-07-20T14:18:28,935766+00:00 ACPI: button: Power Button [PWRF]
2024-07-20T14:18:28,938308+00:00 Console: switching to colour dummy device 80x25
2024-07-20T14:18:28,938788+00:00 [drm] Initialized cirrus 2.0.0 2019 for 0000:00:01.0 on minor 0
2024-07-20T14:18:28,941583+00:00 fbcon: cirrusdrmfb (fb0) is primary device
2024-07-20T14:18:28,962432+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2024-07-20T14:18:28,973100+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2024-07-20T14:18:28,974120+00:00 i2c i2c-0: 1/1 memory slots populated (from DMI)
2024-07-20T14:18:28,974122+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2024-07-20T14:18:28,984964+00:00 Console: switching to colour frame buffer device 128x48
2024-07-20T14:18:28,992097+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2024-07-20T14:18:28,992270+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2024-07-20T14:18:29,018490+00:00 mousedev: PS/2 mouse device common for all mice
2024-07-20T14:18:29,084207+00:00 iTCO_wdt iTCO_wdt.1.auto: Found a ICH9 TCO device (Version=2, TCOBASE=0x0660)
2024-07-20T14:18:29,085011+00:00 cirrus 0000:00:01.0: [drm] fb0: cirrusdrmfb frame buffer device
2024-07-20T14:18:29,119131+00:00 iTCO_wdt iTCO_wdt.1.auto: initialized. heartbeat=30 sec (nowayout=0)
2024-07-20T14:18:29,136081+00:00 kvm_amd: Nested Virtualization enabled
2024-07-20T14:18:29,136085+00:00 kvm_amd: Nested Paging disabled
2024-07-20T14:18:29,150986+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:18:29,150995+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:18:29,155585+00:00 EDAC MC: Ver: 3.0.0
2024-07-20T14:18:30,397156+00:00 8021q: 802.1Q VLAN Support v1.8
2024-07-20T14:18:30,543279+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2024-07-20T14:18:30,544654+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2024-07-20T14:18:30,544762+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2024-07-20T14:18:30,611294+00:00 8021q: adding VLAN 0 to HW filter on device enp1s0
2024-07-20T14:18:30,611457+00:00 8021q: adding VLAN 0 to HW filter on device enp2s0
2024-07-20T14:18:30,655695+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:18:30,655702+00:00 public: port 1(enp1s0) entered disabled state
2024-07-20T14:18:30,655714+00:00 virtio_net virtio0 enp1s0: entered allmulticast mode
2024-07-20T14:18:30,655779+00:00 virtio_net virtio0 enp1s0: entered promiscuous mode
2024-07-20T14:18:30,667303+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:18:30,667306+00:00 public: port 1(enp1s0) entered forwarding state
2024-07-20T14:18:30,688693+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:18:30,688697+00:00 private: port 1(vlan4000) entered disabled state
2024-07-20T14:18:30,688862+00:00 vlan4000: entered allmulticast mode
2024-07-20T14:18:30,688866+00:00 virtio_net virtio1 enp2s0: entered allmulticast mode
2024-07-20T14:18:30,688952+00:00 vlan4000: entered promiscuous mode
2024-07-20T14:18:30,688953+00:00 virtio_net virtio1 enp2s0: entered promiscuous mode
2024-07-20T14:18:30,694355+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:18:30,694358+00:00 private: port 1(vlan4000) entered forwarding state
2024-07-20T14:18:32,309163+00:00 NET: Registered PF_PACKET protocol family
2024-07-20T14:18:37,519546+00:00 Bridge firewalling registered
2024-07-20T14:20:54,882623+00:00 Initializing XFRM netlink socket
2024-07-20T14:20:55,955483+00:00 eth0: renamed from tmpce3f5
