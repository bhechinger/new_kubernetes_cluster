ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
92         Disabled           Disabled          3394       k8s:app.kubernetes.io/instance=rke2-coredns                                         10.55.0.129   ready   
                                                           k8s:app.kubernetes.io/name=rke2-coredns                                                                   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
351        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                    ready   
                                                           k8s:node-role.kubernetes.io/etcd=true                                                                     
                                                           k8s:node-role.kubernetes.io/master=true                                                                   
                                                           k8s:node.kubernetes.io/instance-type=rke2                                                                 
                                                           reserved:host                                                                                             
764        Disabled           Disabled          8          reserved:ingress                                                                    10.55.0.214   ready   
3424       Disabled           Disabled          4          reserved:health                                                                     10.55.0.16    ready   
