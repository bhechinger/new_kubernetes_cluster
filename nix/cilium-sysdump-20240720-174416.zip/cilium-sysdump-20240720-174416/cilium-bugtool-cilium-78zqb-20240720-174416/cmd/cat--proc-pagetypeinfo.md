Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      0      0      0      0      0      0      0      1      0      0      0 
Node    0, zone      DMA, type      Movable      0      0      0      0      0      0      0      0      0      1      3 
Node    0, zone      DMA, type  Reclaimable      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type    Unmovable     23     15      2     71     34     39      9      4      1      1      1 
Node    0, zone    DMA32, type      Movable    323    245    240     91     40     16      5      4      2      0      8 
Node    0, zone    DMA32, type  Reclaimable    277     38     20     17      3      2      2      2      1      0      0 
Node    0, zone    DMA32, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      1      1      1      0      1      1      0      0      1      2      0 
Node    0, zone   Normal, type      Movable      0      1      0      1      0     93     26      6      1      1      4 
Node    0, zone   Normal, type  Reclaimable      1      0      0     35     45     21     11      9      3      0      0 
Node    0, zone   Normal, type   HighAtomic     34     50     23     27     20      9      3      2      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA            1            7            0            0            0            0 
Node 0, zone    DMA32           22          964           30            0            0            0 
Node 0, zone   Normal           89          890           40            5            0            0 
