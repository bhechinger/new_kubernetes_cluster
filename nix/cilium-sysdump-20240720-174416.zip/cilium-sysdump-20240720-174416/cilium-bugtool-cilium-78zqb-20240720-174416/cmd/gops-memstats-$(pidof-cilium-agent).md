alloc: 54.15MB (56780264 bytes)
total-alloc: 1.87GB (2009811144 bytes)
sys: 81.89MB (85868219 bytes)
lookups: 0
mallocs: 40779794
frees: 40279941
heap-alloc: 54.15MB (56780264 bytes)
heap-sys: 67.47MB (70746112 bytes)
heap-idle: 6.36MB (6668288 bytes)
heap-in-use: 61.11MB (64077824 bytes)
heap-released: 6.24MB (6545408 bytes)
heap-objects: 499853
stack-in-use: 4.53MB (4751360 bytes)
stack-sys: 4.53MB (4751360 bytes)
stack-mspan-inuse: 966.16KB (989352 bytes)
stack-mspan-sys: 1.03MB (1075536 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 581.72KB (595678 bytes)
gc-sys: 6.47MB (6787320 bytes)
next-gc: when heap-alloc >= 66.24MB (69455344 bytes)
last-gc: 2024-07-20 17:43:03.235162341 +0000 UTC
gc-pause-total: 11.084549ms
gc-pause: 53491
gc-pause-end: 1721497383235162341
num-gc: 129
num-forced-gc: 0
gc-cpu-fraction: 5.4974387305141333e-05
enable-gc: true
debug-gc: false
