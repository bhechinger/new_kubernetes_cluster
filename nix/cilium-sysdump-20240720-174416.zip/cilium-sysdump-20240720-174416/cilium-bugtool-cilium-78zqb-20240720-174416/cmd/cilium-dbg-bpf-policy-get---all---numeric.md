Endpoint ID: 92
Path: /sys/fs/bpf/tc/globals/cilium_policy_00092

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1457199   17426     0        
Allow    Ingress     1          ANY          NONE         disabled    1185865   13666     0        
Allow    Egress      0          ANY          NONE         disabled    229051    2973      0        


Endpoint ID: 351
Path: /sys/fs/bpf/tc/globals/cilium_policy_00351

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3424
Path: /sys/fs/bpf/tc/globals/cilium_policy_03424

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    532633   6707      0        
Allow    Ingress     1          ANY          NONE         disabled    160686   1835      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


