Module                  Size  Used by
udp_diag               12288  0
tcp_diag               12288  0
inet_diag              28672  2 tcp_diag,udp_diag
ip_set                 65536  0
nft_chain_nat          12288  3
veth                   45056  0
tcp_bbr                20480  188
xfrm_user              61440  1
xfrm_algo              16384  1 xfrm_user
xt_conntrack           12288  1
xt_comment             12288  27
nft_compat             24576  38
nf_tables             372736  124 nft_compat,nft_chain_nat
iptable_filter         12288  0
iptable_nat            12288  0
nf_nat                 61440  2 nft_chain_nat,iptable_nat
overlay               229376  19
br_netfilter           36864  0
af_packet              65536  2
cfg80211             1359872  0
rfkill                 40960  2 cfg80211
8021q                  49152  0
edac_core             110592  0
kvm_amd               208896  0
nls_iso8859_1          12288  1
nls_cp437              16384  1
vfat                   20480  1
fat                   102400  1 vfat
ccp                   159744  1 kvm_amd
iTCO_wdt               16384  0
intel_pmc_bxt          16384  1 iTCO_wdt
joydev                 24576  0
kvm                  1351680  1 kvm_amd
mousedev               24576  0
watchdog               49152  1 iTCO_wdt
psmouse               221184  0
irqbypass              12288  1 kvm
i2c_i801               40960  0
i2c_smbus              20480  1 i2c_i801
lpc_ich                28672  0
evdev                  28672  2
intel_agp              24576  0
tiny_power_button      12288  0
cirrus                 20480  0
intel_gtt              24576  1 intel_agp
input_leds             12288  0
button                 28672  0
led_class              20480  1 input_leds
mac_hid                12288  0
serio_raw              16384  0
sch_fq_codel           20480  2
loop                   40960  0
tun                    69632  0
tap                    32768  0
macvlan                36864  0
bridge                401408  1 br_netfilter
stp                    12288  1 bridge
llc                    16384  2 bridge,stp
sch_fq                 24576  3
xt_socket              16384  1
nf_socket_ipv4         12288  1 xt_socket
nf_socket_ipv6         16384  1 xt_socket
xt_mark                12288  2
xt_CT                  12288  5
nf_conntrack          204800  3 xt_conntrack,nf_nat,xt_CT
libcrc32c              12288  3 nf_conntrack,nf_nat,nf_tables
fuse                  192512  1
xt_TPROXY              12288  2
nf_tproxy_ipv6         16384  1 xt_TPROXY
nf_tproxy_ipv4         16384  1 xt_TPROXY
nf_defrag_ipv6         24576  3 nf_conntrack,xt_socket,xt_TPROXY
nf_defrag_ipv4         12288  3 nf_conntrack,xt_socket,xt_TPROXY
algif_hash             12288  0
af_alg                 32768  1 algif_hash
sch_ingress            20480  6
efi_pstore             12288  0
cls_bpf                20480  9
configfs               69632  1
nfnetlink              20480  5 nft_compat,nf_tables,ip_set
dmi_sysfs              24576  0
qemu_fw_cfg            20480  0
ip_tables              28672  2 iptable_filter,iptable_nat
x_tables               53248  10 xt_conntrack,iptable_filter,nft_compat,xt_socket,xt_comment,xt_TPROXY,xt_CT,ip_tables,iptable_nat,xt_mark
autofs4                61440  0
ext4                 1142784  1
crc32c_generic         12288  3
crc16                  12288  1 ext4
mbcache                16384  1 ext4
jbd2                  204800  1 ext4
sr_mod                 28672  0
cdrom                  81920  1 sr_mod
ahci                   57344  0
libahci                61440  1 ahci
libata                479232  2 libahci,ahci
scsi_mod              327680  2 libata,sr_mod
virtio_blk             36864  2
virtio_net             90112  0
net_failover           24576  1 virtio_net
failover               12288  1 net_failover
atkbd                  40960  0
xhci_pci               24576  0
xhci_pci_renesas       24576  1 xhci_pci
firmware_class         61440  3 ccp,xhci_pci_renesas,cfg80211
libps2                 24576  2 atkbd,psmouse
vivaldi_fmap           12288  1 atkbd
xhci_hcd              393216  1 xhci_pci
scsi_common            16384  3 scsi_mod,libata,sr_mod
virtio_pci             40960  0
virtio_pci_legacy_dev    16384  1 virtio_pci
virtio_pci_modern_dev    28672  1 virtio_pci
rtc_cmos               28672  1
i8042                  57344  0
serio                  28672  6 serio_raw,atkbd,psmouse,i8042
dm_mod                221184  3
dax                    53248  1 dm_mod
virtio_gpu            102400  0
virtio_dma_buf         12288  1 virtio_gpu
virtio_rng             12288  0
rng_core               20480  2 virtio_rng,ccp
virtio_console         45056  0
virtio_balloon         32768  0
virtio                 16384  7 virtio_rng,virtio_console,virtio_balloon,virtio_gpu,virtio_pci,virtio_blk,virtio_net
virtio_ring            57344  7 virtio_rng,virtio_console,virtio_balloon,virtio_gpu,virtio_pci,virtio_blk,virtio_net
