markdown output at /tmp/cilium-bugtool-20240720-174417.139+0000-UTC-3127766646/cmd/cilium-debuginfo-20240720-174447.749+0000-UTC.md
json output at /tmp/cilium-bugtool-20240720-174417.139+0000-UTC-3127766646/cmd/cilium-debuginfo-20240720-174447.749+0000-UTC.json
