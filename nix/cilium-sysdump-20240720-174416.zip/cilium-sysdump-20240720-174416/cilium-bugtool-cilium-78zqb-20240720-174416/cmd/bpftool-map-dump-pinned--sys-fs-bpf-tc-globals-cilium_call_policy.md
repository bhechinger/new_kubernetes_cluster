key: 5c 00 00 00  value: 0e 04 00 00
key: 60 0d 00 00  value: 08 04 00 00
Found 2 elements
