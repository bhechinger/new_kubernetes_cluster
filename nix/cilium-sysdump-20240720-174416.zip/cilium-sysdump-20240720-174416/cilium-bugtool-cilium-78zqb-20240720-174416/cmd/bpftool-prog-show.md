2: tracing  name hid_tail_call  tag 7cc47bbf07148bfe  gpl
	loaded_at 2024-07-20T14:18:28+0000  uid 0
	xlated 56B  jited 129B  memlock 4096B  map_ids 2
	btf_id 2
7: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 6
8: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 5
11: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 10
12: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 9
13: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 12
14: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 11
15: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 14
16: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 13
17: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 16
18: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 15
21: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 20
22: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 19
23: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 22
24: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 21
25: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 24
26: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 23
27: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 26
28: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 25
29: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 28
30: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 27
31: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 30
32: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 29
33: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 32
34: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 31
35: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 34
36: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 33
37: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 36
38: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 35
39: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 38
40: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 37
41: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 40
42: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 39
43: cgroup_device  name sd_devices  tag 3a32ccd9e03ea87a  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 504B  jited 318B  memlock 4096B
44: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 42
45: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 41
46: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 44
47: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 43
48: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 46
49: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 45
50: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 48
51: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 47
52: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 8
53: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 7
54: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 4
55: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 3
56: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 50
57: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 49
58: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 52
59: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 51
60: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 54
61: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 53
62: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 56
63: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 55
64: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 58
65: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 57
66: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 60
67: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 59
68: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 62
69: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 61
72: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 66
73: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 65
74: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 68
75: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 67
78: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 72
79: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 71
80: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 70
81: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 69
82: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 74
83: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 73
84: cgroup_device  name sd_devices  tag 63878b01a3de7bae  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 464B  jited 297B  memlock 4096B
85: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 76
86: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 75
87: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 416B  jited 264B  memlock 4096B
88: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 78
89: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 77
90: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 80
91: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 79
92: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 82
93: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 81
94: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 84
95: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 83
96: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 86
97: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 85
98: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 88
99: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 87
102: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 92
103: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:30+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 91
104: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 94
105: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 93
106: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 96
107: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 95
108: cgroup_device  name sd_devices  tag 03e2cf74d47166f5  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 744B  jited 456B  memlock 4096B
109: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 98
110: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 97
113: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 100
114: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 99
115: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 102
116: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 101
117: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 104
118: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 103
119: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 106
120: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 105
121: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 108
122: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 107
123: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 110
124: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 109
125: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 112
126: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 111
127: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 114
128: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 113
129: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 116
130: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 115
131: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 118
132: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 117
133: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 120
134: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 119
135: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 122
136: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 121
137: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 124
138: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 123
139: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 126
140: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:31+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 125
141: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 90
142: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 89
143: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 128
144: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:18:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 127
205: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 144
206: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 143
209: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 150
210: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 149
213: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
214: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 152
215: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 151
218: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
221: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
222: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 155
223: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 154
226: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:24+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
235: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 158
236: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 157
239: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
240: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 160
241: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 159
244: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
247: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
248: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 163
249: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 162
252: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:49+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
269: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 168
270: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 167
273: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 166
274: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 165
277: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
278: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 170
279: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 169
282: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
283: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
284: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 172
285: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 171
288: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
293: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
294: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 176
295: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 175
298: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
299: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
300: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 178
301: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 177
304: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:54+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
313: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 182
314: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 181
317: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
318: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 184
319: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 183
322: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
325: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
326: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 187
327: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 186
330: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:19:55+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
495: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 222
496: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 221
501: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 224
502: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 223
505: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
506: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 228
507: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 227
510: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
511: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
512: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 230
513: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 229
516: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
517: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 226
518: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 225
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
522: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 234
523: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 233
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:25+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:32+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
538: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:32+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 240
539: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:32+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 239
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:32+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:34+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
546: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:34+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 243
547: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:34+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 242
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:34+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
575: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 64
576: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 63
602: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:53+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
603: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:53+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 264
604: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:53+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 263
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:53+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:54+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
611: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 268
612: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:54+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 267
615: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:54+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
970: cgroup_sock_addr  name cil_sock4_getpeername  tag 87271573c2abff4f  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 2672B  jited 1491B  memlock 4096B  map_ids 308,313,314,311,312
	btf_id 141
971: cgroup_sock_addr  name cil_sock4_connect  tag 4ac7567395eca7cf  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 5240B  jited 2826B  memlock 8192B  map_ids 314,311,308,326,325,315,312,313
	btf_id 142
972: cgroup_sock_addr  name cil_sock4_recvmsg  tag 87271573c2abff4f  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 2672B  jited 1491B  memlock 4096B  map_ids 308,313,314,311,312
	btf_id 143
973: cgroup_sock_addr  name cil_sock6_getpeername  tag 42037bd653c99049  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 2904B  jited 1621B  memlock 4096B  map_ids 308,313,314,311,312
	btf_id 144
974: cgroup_sock  name cil_sock6_post_bind  tag 8dc07c20ddb00d87  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 1224B  jited 730B  memlock 4096B  map_ids 311,314
	btf_id 145
975: cgroup_sock_addr  name cil_sock6_sendmsg  tag 9c45a193655af861  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 5464B  jited 2933B  memlock 8192B  map_ids 314,311,308,326,325,315,312,313
	btf_id 146
976: cgroup_sock_addr  name cil_sock4_sendmsg  tag 381b569805c952fd  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 5192B  jited 2792B  memlock 8192B  map_ids 314,311,308,326,325,315,312,313
	btf_id 147
977: cgroup_sock_addr  name cil_sock6_recvmsg  tag 42037bd653c99049  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 2904B  jited 1621B  memlock 4096B  map_ids 308,313,314,311,312
	btf_id 148
978: cgroup_sock  name cil_sock4_post_bind  tag 80bc39b2ffc68395  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 824B  jited 483B  memlock 4096B  map_ids 314,311
	btf_id 149
979: cgroup_sock_addr  name cil_sock6_connect  tag 068d472a70505afe  gpl
	loaded_at 2024-07-20T14:20:56+0000  uid 0
	xlated 5496B  jited 2987B  memlock 8192B  map_ids 314,311,308,326,325,315,312,313
	btf_id 150
980: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 323,312,321,336,319,320,316
	btf_id 155
981: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,336
	btf_id 156
982: sched_cls  name tail_handle_ipv4_from_host  tag 25b5f6d85a1964c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 310,312,311,317,336
	btf_id 157
983: sched_cls  name tail_handle_snat_fwd_ipv4  tag 16ca0bc2cb43ff24  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 32184B  jited 22534B  memlock 32768B  map_ids 323,310,311,312,319,320,324,321,306,308,336
	btf_id 158
984: sched_cls  name __send_drop_notify  tag 08748ec384ab55d9  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 308
	btf_id 159
985: sched_cls  name tail_nodeport_nat_egress_ipv4  tag add5fd2fce53f51b  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 323,312,321,306,336
	btf_id 160
988: sched_cls  name cil_to_host  tag fd128c0c744c0771  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 384B  jited 224B  memlock 4096B  map_ids 312
	btf_id 163
989: sched_cls  name tail_handle_ipv4_from_netdev  tag 104257f8a07e3916  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 323,312,314,336,310,327,319,320,317,326,325,315,306,322
	btf_id 164
990: sched_cls  name cil_from_host  tag d4910d449c1a5496  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2768B  jited 1799B  memlock 4096B  map_ids 312,318,336,311
	btf_id 165
991: sched_cls  name cil_to_host  tag fd128c0c744c0771  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 384B  jited 224B  memlock 4096B  map_ids 312
	btf_id 167
994: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 323,312,321,338,319,320,316
	btf_id 170
995: sched_cls  name tail_handle_snat_fwd_ipv4  tag 63467cb7fbd56f2b  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 32184B  jited 22540B  memlock 32768B  map_ids 323,310,311,312,319,320,324,321,306,308,338
	btf_id 171
996: sched_cls  name tail_handle_ipv4_from_netdev  tag 775cbf86f3cacb8c  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 323,312,314,338,310,327,319,320,317,326,325,315,306,322
	btf_id 172
997: sched_cls  name tail_nodeport_nat_egress_ipv4  tag add5fd2fce53f51b  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 323,312,321,306,338
	btf_id 173
999: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,338
	btf_id 175
1000: sched_cls  name __send_drop_notify  tag 08748ec384ab55d9  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 308
	btf_id 176
1001: sched_cls  name tail_handle_ipv4_from_host  tag 25b5f6d85a1964c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 310,312,311,317,338
	btf_id 177
1002: sched_cls  name __send_drop_notify  tag 08748ec384ab55d9  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 308
	btf_id 179
1003: sched_cls  name tail_handle_ipv4_from_netdev  tag 8c376336df74ccbd  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 323,312,314,341,310,327,319,320,317,326,325,315,306,322
	btf_id 180
1005: sched_cls  name cil_from_netdev  tag 72a26bdb155998c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2160B  jited 1459B  memlock 4096B  map_ids 312,341,311
	btf_id 182
1006: sched_cls  name tail_nodeport_nat_egress_ipv4  tag add5fd2fce53f51b  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 323,312,321,306,341
	btf_id 183
1007: sched_cls  name tail_handle_ipv4_from_host  tag 25b5f6d85a1964c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 310,312,311,317,341
	btf_id 184
1009: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,341
	btf_id 186
1010: sched_cls  name cil_to_netdev  tag 02053ddb1f852816  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 7976B  jited 5080B  memlock 8192B  map_ids 312,318,309,341,323,319,320,316,308
	btf_id 187
1011: sched_cls  name tail_handle_snat_fwd_ipv4  tag 02041ab69a4e96c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 32184B  jited 22549B  memlock 32768B  map_ids 323,310,311,312,319,320,324,321,306,308,341
	btf_id 188
1012: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 323,312,321,341,319,320,316
	btf_id 189
1014: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,343
	btf_id 192
1015: sched_cls  name tail_handle_snat_fwd_ipv4  tag e281c8ce12c6b171  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 32232B  jited 22578B  memlock 32768B  map_ids 323,310,311,312,319,320,324,321,306,308,343
	btf_id 193
1016: sched_cls  name cil_to_netdev  tag 5257d1cb72e274a0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 7976B  jited 5080B  memlock 8192B  map_ids 312,318,309,343,323,319,320,316,308
	btf_id 194
1017: sched_cls  name tail_nodeport_nat_egress_ipv4  tag add5fd2fce53f51b  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 323,312,321,306,343
	btf_id 195
1019: sched_cls  name tail_handle_ipv4_from_netdev  tag 1c8b0450a592d6b7  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 323,312,314,343,310,327,319,320,317,326,325,315,306,322
	btf_id 197
1020: sched_cls  name __send_drop_notify  tag 08748ec384ab55d9  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 308
	btf_id 198
1021: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 323,312,321,343,319,320,316
	btf_id 199
1022: sched_cls  name cil_from_netdev  tag 72a26bdb155998c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2160B  jited 1459B  memlock 4096B  map_ids 312,343,311
	btf_id 200
1023: sched_cls  name tail_handle_ipv4_from_host  tag 25b5f6d85a1964c0  gpl
	loaded_at 2024-07-20T14:20:58+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 310,312,311,317,343
	btf_id 201
1024: sched_cls  name tail_handle_arp  tag 55c8d66b8e89591b  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 1488B  jited 919B  memlock 4096B  map_ids 312,346
	btf_id 203
1025: sched_cls  name cil_from_container  tag 790dedaa66e7c7e4  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 736B  jited 568B  memlock 4096B  map_ids 346,312
	btf_id 204
1026: sched_cls  name tail_handle_ipv4_cont  tag ab8bd0c5ef885485  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 11448B  jited 6900B  memlock 12288B  map_ids 311,345,308,335,307,304,305,306,319,320,312,316,346,310,317
	btf_id 205
1028: sched_cls  name tail_nodeport_rev_dnat_ingress_ipv4  tag 761d8b1ff7fe424c  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 5648B  jited 3558B  memlock 8192B  map_ids 323,312,319,320,347,316
	btf_id 208
1029: sched_cls  name tail_handle_ipv4  tag 9c8c8bf3ed2c79d1  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 8512B  jited 5171B  memlock 12288B  map_ids 323,312,314,319,320,326,325,315,346,306
	btf_id 209
1030: sched_cls  name tail_ipv4_ct_egress  tag 0aa97d2bf01d8fe8  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 6080B  jited 3713B  memlock 8192B  map_ids 312,346,319,320,323,345
	btf_id 211
1031: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,346
	btf_id 212
1032: sched_cls  name handle_policy  tag 2fa7b3c8cb4808f8  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 15168B  jited 9123B  memlock 16384B  map_ids 312,319,320,323,347,348,308,316,344,311,307,304,305,306
	btf_id 210
1033: sched_cls  name tail_nodeport_rev_dnat_ingress_ipv4  tag 761d8b1ff7fe424c  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 5648B  jited 3558B  memlock 8192B  map_ids 323,312,319,320,346,316
	btf_id 213
1034: sched_cls  name __send_drop_notify  tag da065315ef1bc816  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 400B  jited 230B  memlock 4096B  map_ids 308
	btf_id 215
1035: sched_cls  name handle_policy_egress  tag 2c29b898c763aaeb  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 640B  jited 446B  memlock 4096B  map_ids 346,312
	btf_id 216
1036: sched_cls  name tail_ipv4_ct_egress  tag 6d3ee1bfb78860d6  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 6080B  jited 3713B  memlock 8192B  map_ids 312,347,319,320,323,348
	btf_id 214
1037: sched_cls  name tail_ipv4_to_endpoint  tag a3bf32ff01e65583  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 10576B  jited 6121B  memlock 12288B  map_ids 311,312,323,319,320,315,348,308,316,344,307,304,305,306,347
	btf_id 218
1038: sched_cls  name handle_policy  tag 4b75318ad3c10e4a  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 15168B  jited 9123B  memlock 16384B  map_ids 312,319,320,323,346,345,308,316,335,311,307,304,305,306
	btf_id 217
1039: sched_cls  name tail_handle_ipv4  tag d8361c6a964252ab  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 8512B  jited 5171B  memlock 12288B  map_ids 323,312,314,319,320,326,325,315,347,306
	btf_id 219
1041: sched_cls  name tail_ipv4_to_endpoint  tag d70601955f993cf2  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 10576B  jited 6121B  memlock 12288B  map_ids 311,312,323,319,320,315,345,308,316,335,307,304,305,306,346
	btf_id 220
1042: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 312,347
	btf_id 222
1043: sched_cls  name tail_ipv4_ct_ingress  tag edc419242c41ce71  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 6184B  jited 3765B  memlock 8192B  map_ids 312,346,319,320,323,345
	btf_id 223
1044: sched_cls  name tail_handle_ipv4_cont  tag 68d9d41d798bd101  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 11448B  jited 6900B  memlock 12288B  map_ids 311,348,308,344,307,304,305,306,319,320,312,316,347,310,317
	btf_id 224
1045: sched_cls  name __send_drop_notify  tag e9796420fafa5a07  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 400B  jited 230B  memlock 4096B  map_ids 308
	btf_id 225
1046: sched_cls  name tail_ipv4_ct_ingress  tag 539fe38442130aec  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 6184B  jited 3765B  memlock 8192B  map_ids 312,347,319,320,323,348
	btf_id 226
1047: sched_cls  name handle_policy_egress  tag 38a07aab5728ee33  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 640B  jited 446B  memlock 4096B  map_ids 347,312
	btf_id 227
1048: sched_cls  name tail_handle_arp  tag 3bdee5a03af65bbf  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 1488B  jited 919B  memlock 4096B  map_ids 312,347
	btf_id 228
1049: sched_cls  name cil_from_container  tag 7ba42dfc588c1fc9  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 736B  jited 568B  memlock 4096B  map_ids 347,312
	btf_id 229
1050: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 329
1051: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 328
1054: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
1055: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 350
1056: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 349
1059: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:20:59+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
1062: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:21:04+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
1063: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:21:04+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 353
1064: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:21:04+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 352
1067: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:21:04+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
1120: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:33:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 356
1121: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:33:29+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 355
1702: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 364
1703: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 363
1704: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 18
1705: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 17
1708: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 130
1709: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T16:42:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 129
1782: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:00:03+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 384
1783: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:00:03+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 383
1956: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 146
1957: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 145
1958: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 148
1959: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:21+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 147
