CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
55       cgroup_inet_ingress multi           sd_fw_ingress                  
54       cgroup_inet_egress multi           sd_fw_egress                   
971      cgroup_inet4_connect multi           cil_sock4_connect                
979      cgroup_inet6_connect multi           cil_sock6_connect                
978      cgroup_inet4_post_bind multi           cil_sock4_post_bind                
974      cgroup_inet6_post_bind multi           cil_sock6_post_bind                
976      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
975      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
972      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
977      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
970      cgroup_inet4_getpeername multi           cil_sock4_getpeername                
973      cgroup_inet6_getpeername multi           cil_sock6_getpeername                
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    63       cgroup_inet_ingress multi           sd_fw_ingress                  
    62       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-config.mount
    57       cgroup_inet_ingress multi           sd_fw_ingress                  
    56       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    26       cgroup_inet_ingress multi           sd_fw_ingress                  
    25       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/dev-mqueue.mount
    24       cgroup_inet_ingress multi           sd_fw_ingress                  
    23       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice
    1705     cgroup_inet_ingress multi           sd_fw_ingress                  
    1704     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-0.slice
    1709     cgroup_inet_ingress multi           sd_fw_ingress                  
    1708     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    1703     cgroup_inet_ingress multi           sd_fw_ingress                  
    1702     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/init.scope
    8        cgroup_inet_ingress multi           sd_fw_ingress                  
    7        cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice
    53       cgroup_inet_ingress multi           sd_fw_ingress                  
    52       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    18       cgroup_inet_ingress multi           sd_fw_ingress                  
    17       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    67       cgroup_inet_ingress multi           sd_fw_ingress                  
    66       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice
    16       cgroup_inet_ingress multi           sd_fw_ingress                  
    15       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice/serial-getty@hvc0.service
    140      cgroup_inet_ingress multi           sd_fw_ingress                  
    139      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/boot.mount
    75       cgroup_inet_ingress multi           sd_fw_ingress                  
    74       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    14       cgroup_inet_ingress multi           sd_fw_ingress                  
    13       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    45       cgroup_inet_ingress multi           sd_fw_ingress                  
    44       cgroup_inet_egress multi           sd_fw_egress                   
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/sshd.service
    134      cgroup_inet_ingress multi           sd_fw_ingress                  
    133      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/rke2.service
    144      cgroup_inet_ingress multi           sd_fw_ingress                  
    143      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dhcpcd.service
    97       cgroup_inet_ingress multi           sd_fw_ingress                  
    96       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/nscd.service
    142      cgroup_inet_ingress multi           sd_fw_ingress                  
    141      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    86       cgroup_inet_ingress multi           sd_fw_ingress                  
    85       cgroup_inet_egress multi           sd_fw_egress                   
    84       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/dbus.service
    107      cgroup_inet_ingress multi           sd_fw_ingress                  
    106      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    89       cgroup_inet_ingress multi           sd_fw_ingress                  
    88       cgroup_inet_egress multi           sd_fw_egress                   
    87       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/system-getty.slice
    12       cgroup_inet_ingress multi           sd_fw_ingress                  
    11       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-getty.slice/getty@tty1.service
    138      cgroup_inet_ingress multi           sd_fw_ingress                  
    137      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    110      cgroup_inet_ingress multi           sd_fw_ingress                  
    109      cgroup_inet_egress multi           sd_fw_egress                   
    108      cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/dev-hugepages.mount
    22       cgroup_inet_ingress multi           sd_fw_ingress                  
    21       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice
    206      cgroup_inet_ingress multi           sd_fw_ingress                  
    205      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod1d9d7008_b854_47e1_bc3e_c243cc663e35.slice
    1051     cgroup_inet_ingress multi           sd_fw_ingress                  
    1050     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod1d9d7008_b854_47e1_bc3e_c243cc663e35.slice/cri-containerd-12f5e92de9806d9ea1e0d13550125cff18eac40eaa23185c573ed52d66f1e58e.scope
    1064     cgroup_inet_ingress multi           sd_fw_ingress                  
    1063     cgroup_inet_egress multi           sd_fw_egress                   
    1067     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-pod1d9d7008_b854_47e1_bc3e_c243cc663e35.slice/cri-containerd-ce3f50548c3741723343f12ef92567cf668cd6852bd20421ab6f618b64c569ef.scope
    1056     cgroup_inet_ingress multi           sd_fw_ingress                  
    1055     cgroup_inet_egress multi           sd_fw_egress                   
    1059     cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice
    1961     cgroup_inet_ingress multi           sd_fw_ingress                  
    1960     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc709f39330d6b9b1bfbc26c3e77da4b.slice
    210      cgroup_inet_ingress multi           sd_fw_ingress                  
    209      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc709f39330d6b9b1bfbc26c3e77da4b.slice/cri-containerd-4fa7ebcbdaccaa7a5ffb623f22cfb2f1f51f5fd78c40ca3fed55c13a7994e8a9.scope
    223      cgroup_inet_ingress multi           sd_fw_ingress                  
    222      cgroup_inet_egress multi           sd_fw_egress                   
    226      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc709f39330d6b9b1bfbc26c3e77da4b.slice/cri-containerd-d92f6221adabab08bd51a4d03074e7518939cb351e41b08ebea2ea41b34bd59d.scope
    215      cgroup_inet_ingress multi           sd_fw_ingress                  
    214      cgroup_inet_egress multi           sd_fw_egress                   
    218      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63869d3da4e43e9dd71175c83053e16.slice
    236      cgroup_inet_ingress multi           sd_fw_ingress                  
    235      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63869d3da4e43e9dd71175c83053e16.slice/cri-containerd-a576a7139f31f893550b282372a85a0fe77d7d342984052aebc4096ad31ce0ef.scope
    249      cgroup_inet_ingress multi           sd_fw_ingress                  
    248      cgroup_inet_egress multi           sd_fw_egress                   
    252      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63869d3da4e43e9dd71175c83053e16.slice/cri-containerd-eb71fdcdde0dede4529e62a43bab6450434e9de7e038c74e61379ba273c9df02.scope
    241      cgroup_inet_ingress multi           sd_fw_ingress                  
    240      cgroup_inet_egress multi           sd_fw_egress                   
    244      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f590e8a404bedf1dcc5e636ca60f177.slice
    274      cgroup_inet_ingress multi           sd_fw_ingress                  
    273      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f590e8a404bedf1dcc5e636ca60f177.slice/cri-containerd-7fa938b0aa8586fc4942ca042b64d2ca437c8a879949f98ee59e564b0c075073.scope
    301      cgroup_inet_ingress multi           sd_fw_ingress                  
    300      cgroup_inet_egress multi           sd_fw_egress                   
    304      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f590e8a404bedf1dcc5e636ca60f177.slice/cri-containerd-1dad8e8b72b537b0da6558b44e4794b886f54765076070b101922d79b9a96d7b.scope
    285      cgroup_inet_ingress multi           sd_fw_ingress                  
    284      cgroup_inet_egress multi           sd_fw_egress                   
    288      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod97c7bb75d2246e62ea6f13bf47b989af.slice
    314      cgroup_inet_ingress multi           sd_fw_ingress                  
    313      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod97c7bb75d2246e62ea6f13bf47b989af.slice/cri-containerd-5faae5ba01bf8adb89efdc1c36a9d17277554a9965aea9830e211f7e689ee262.scope
    327      cgroup_inet_ingress multi           sd_fw_ingress                  
    326      cgroup_inet_egress multi           sd_fw_egress                   
    330      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod97c7bb75d2246e62ea6f13bf47b989af.slice/cri-containerd-a88ea2dd624ae8ddf8fde0e80597a56fb46d324ae6258af1d9df3b46acfd6686.scope
    319      cgroup_inet_ingress multi           sd_fw_ingress                  
    318      cgroup_inet_egress multi           sd_fw_egress                   
    322      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17aeb561aaba310b5149fc1e5bc019b3.slice
    270      cgroup_inet_ingress multi           sd_fw_ingress                  
    269      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17aeb561aaba310b5149fc1e5bc019b3.slice/cri-containerd-7726252e0316068087991f6db4a3fa36c67dddceda5ed04899fb6757218aaece.scope
    295      cgroup_inet_ingress multi           sd_fw_ingress                  
    294      cgroup_inet_egress multi           sd_fw_egress                   
    298      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17aeb561aaba310b5149fc1e5bc019b3.slice/cri-containerd-9f8233d381a94d81bfefec65ae8831bd7f510c16b9694fb6dd68940cb81c5ffb.scope
    279      cgroup_inet_ingress multi           sd_fw_ingress                  
    278      cgroup_inet_egress multi           sd_fw_egress                   
    282      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice
    496      cgroup_inet_ingress multi           sd_fw_ingress                  
    495      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice/cri-containerd-bb0d3f6248b42fa65f96842288631f481d47de1e1500a494b2dd597918ba043c.scope
    604      cgroup_inet_ingress multi           sd_fw_ingress                  
    603      cgroup_inet_egress multi           sd_fw_egress                   
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice/cri-containerd-01d049435c4554758c1553fea759fa72794a645ce008ade5a1b7f7e6f1456618.scope
    507      cgroup_inet_ingress multi           sd_fw_ingress                  
    506      cgroup_inet_egress multi           sd_fw_egress                   
    510      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice/cri-containerd-0adc94fdc466e2eb187171e193ef38798cfc3bfab86e4ec9a1297b1a2320f642.scope
    612      cgroup_inet_ingress multi           sd_fw_ingress                  
    611      cgroup_inet_egress multi           sd_fw_egress                   
    615      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice
    1963     cgroup_inet_ingress multi           sd_fw_ingress                  
    1962     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807200f7_b336_49da_8dd9_7d59fbdb25b2.slice
    518      cgroup_inet_ingress multi           sd_fw_ingress                  
    517      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807200f7_b336_49da_8dd9_7d59fbdb25b2.slice/cri-containerd-e8085532cd843658dace57a3d7cf88d76029a61aabdb4124f90f993ad7a91ed8.scope
    539      cgroup_inet_ingress multi           sd_fw_ingress                  
    538      cgroup_inet_egress multi           sd_fw_egress                   
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807200f7_b336_49da_8dd9_7d59fbdb25b2.slice/cri-containerd-44ea28e314c2067c94d7ec717293d6109955003e8da5ddf4796e36792e145fdc.scope
    523      cgroup_inet_ingress multi           sd_fw_ingress                  
    522      cgroup_inet_egress multi           sd_fw_egress                   
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7bc0721_1d2a_4ab7_9dc1_de94826ddecd.slice
    502      cgroup_inet_ingress multi           sd_fw_ingress                  
    501      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7bc0721_1d2a_4ab7_9dc1_de94826ddecd.slice/cri-containerd-0f2e71705cccbb1bb382b6f0a77b3ba65975f04ffc67faa29823f206a13281b0.scope
    547      cgroup_inet_ingress multi           sd_fw_ingress                  
    546      cgroup_inet_egress multi           sd_fw_egress                   
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7bc0721_1d2a_4ab7_9dc1_de94826ddecd.slice/cri-containerd-5cdc83d98fade91b61f322b62b9a77b7a54d86b57dfae58317707b72891245d3.scope
    513      cgroup_inet_ingress multi           sd_fw_ingress                  
    512      cgroup_inet_egress multi           sd_fw_egress                   
    516      cgroup_device   multi                                          
