KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [public   10.22.20.11 fe80::5054:ff:fe92:19da, private   10.22.30.11 fe80::5054:ff:fed6:4c0f (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 4/254 allocated from 10.55.0.0/24, 
Allocated addresses:
  10.55.0.129 (kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp)
  10.55.0.16 (health)
  10.55.0.214 (ingress)
  10.55.0.64 (router)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [public, private]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [public, private]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      26/26 healthy
  Name                                                                    Last success   Last error     Count   Message
  cilium-health-ep                                                        52s ago        never          0       no error   
  dns-garbage-collector-job                                               54s ago        never          0       no error   
  endpoint-3424-regeneration-recovery                                     never          never          0       no error   
  endpoint-351-regeneration-recovery                                      never          never          0       no error   
  endpoint-764-regeneration-recovery                                      never          never          0       no error   
  endpoint-92-regeneration-recovery                                       never          never          0       no error   
  endpoint-gc                                                             3m54s ago      never          0       no error   
  ep-bpf-prog-watchdog                                                    23s ago        never          0       no error   
  ipcache-inject-labels                                                   53s ago        3h23m54s ago   0       no error   
  k8s-heartbeat                                                           22s ago        never          0       no error   
  link-cache                                                              8s ago         never          0       no error   
  resolve-identity-3424                                                   3m52s ago      never          0       no error   
  resolve-identity-351                                                    3m53s ago      never          0       no error   
  resolve-identity-764                                                    3m53s ago      never          0       no error   
  resolve-identity-92                                                     3m52s ago      never          0       no error   
  resolve-labels-kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp   3h23m52s ago   never          0       no error   
  sync-host-ips                                                           53s ago        never          0       no error   
  sync-lb-maps-with-k8s-services                                          3h23m53s ago   never          0       no error   
  sync-policymap-3424                                                     8m50s ago      never          0       no error   
  sync-policymap-351                                                      8m51s ago      never          0       no error   
  sync-policymap-92                                                       8m50s ago      never          0       no error   
  sync-to-k8s-ciliumendpoint (92)                                         11s ago        never          0       no error   
  sync-utime                                                              53s ago        never          0       no error   
  template-dir-watcher                                                    never          never          0       no error   
  update-k8s-node-annotations                                             3h23m54s ago   never          0       no error   
  write-cni-file                                                          3h23m54s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.0.64, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 15.33   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                public   10.22.20.11 fe80::5054:ff:fe92:19da, private   10.22.30.11 fe80::5054:ff:fed6:4c0f (Direct Routing)
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                     Disabled        
Cluster health:                 6/6 reachable   (2024-07-20T17:43:59Z)
  Name                          IP              Node        Endpoints
  hetzner/master1 (localhost)   10.22.30.11     reachable   reachable
  hetzner/master2               10.22.30.12     reachable   reachable
  hetzner/master3               10.22.30.13     reachable   reachable
  hetzner/worker1               10.22.30.21     reachable   reachable
  hetzner/worker2               10.22.30.22     reachable   reachable
  hetzner/worker3               10.22.30.23     reachable   reachable
Modules Health:
agent
├── datapath
│   ├── node-address
│   │   └── job-node-address-update                         [OK] 10.55.0.64 (cilium_host), fe80::886b:c6ff:fee4:c936 (cilium_host) (3h23m, x1)
│   ├── l2-responder
│   │   └── job-l2-responder-reconciler                     [OK] Running (3h23m, x1)
│   └── agent-liveness-updater
│       └── timer-job-agent-liveness-updater                [OK] OK (29.034µs) (3h23m, x1)
└── controlplane
    ├── bgp-cp
    │   └── job-diffstore-events                            [OK] Running (3h23m, x2)
    ├── stale-endpoint-cleanup                              [OK]  (3h23m, x1)
    ├── endpoint-manager
    │   ├── cilium-endpoint-3424 
    │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h23m, x25)
    │   │   └── policymap-sync                              [OK] sync-policymap-3424 (3h23m, x14)
    │   ├── endpoint-gc                                     [OK] endpoint-gc (3h23m, x41)
    │   ├── cilium-endpoint-351 
    │   │   ├── policymap-sync                              [OK] sync-policymap-351 (3h23m, x14)
    │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h23m, x25)
    │   ├── cilium-endpoint-764 
    │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h23m, x26)
    │   └── cilium-endpoint-92 (kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp)
    │       ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (92) (3h23m, x1225)
    │       ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h23m, x25)
    │       └── policymap-sync                              [OK] sync-policymap-92 (3h23m, x14)
    ├── l2-announcer
    │   └── leader-election                                 [OK]  (3h23m, x1)
    ├── envoy-proxy
    │   └── timer-job-version-check                         [OK] OK (2.67845ms) (3h23m, x1)
    ├── auth
    │   ├── observer-job-auth gc-identity-events            [OK] OK (2.244µs) [35] (3h23m, x1)
    │   ├── observer-job-auth request-authentication        [OK] Primed (3h23m, x1)
    │   └── timer-job-auth gc-cleanup                       [OK] OK (16.691µs) (3h23m, x1)
    ├── node-manager
    │   ├── background-sync                                 [OK] Node validation successful (3h23m, x112)
    │   ├── nodes-add                                       [OK] Node adds successful (3h23m, x6)
    │   └── nodes-update                                    [OK] Node updates successful (3h19m, x5)
    └── daemon
        └── ep-bpf-prog-watchdog                            [OK] ep-bpf-prog-watchdog (3h23m, x408)

