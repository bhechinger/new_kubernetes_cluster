[
  {
    "containers": [
      {
        "cgroup-id": 8156,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice/cri-containerd-bb0d3f6248b42fa65f96842288631f481d47de1e1500a494b2dd597918ba043c.scope"
      },
      {
        "cgroup-id": 8230,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95aadda2_29bc_4b65_90a0_93477170e298.slice/cri-containerd-0adc94fdc466e2eb187171e193ef38798cfc3bfab86e4ec9a1297b1a2320f642.scope"
      }
    ],
    "ips": [
      "10.22.30.11"
    ],
    "name": "cilium-78zqb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7502,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807200f7_b336_49da_8dd9_7d59fbdb25b2.slice/cri-containerd-e8085532cd843658dace57a3d7cf88d76029a61aabdb4124f90f993ad7a91ed8.scope"
      }
    ],
    "ips": [
      "10.22.30.11"
    ],
    "name": "cilium-envoy-r2l2w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8452,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-pod1d9d7008_b854_47e1_bc3e_c243cc663e35.slice/cri-containerd-12f5e92de9806d9ea1e0d13550125cff18eac40eaa23185c573ed52d66f1e58e.scope"
      }
    ],
    "ips": [
      "10.55.0.129"
    ],
    "name": "rke2-coredns-rke2-coredns-84b9cb946c-7tvkp",
    "namespace": "kube-system"
  }
]

