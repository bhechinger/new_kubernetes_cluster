[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.22.20.11/32",
    "identity": 1
  },
  {
    "cidr": "10.22.20.12/32",
    "identity": 7
  },
  {
    "cidr": "10.22.20.13/32",
    "identity": 7
  },
  {
    "cidr": "10.22.20.21/32",
    "identity": 6
  },
  {
    "cidr": "10.22.20.22/32",
    "identity": 6
  },
  {
    "cidr": "10.22.20.23/32",
    "identity": 6
  },
  {
    "cidr": "10.22.30.11/32",
    "identity": 1
  },
  {
    "cidr": "10.22.30.12/32",
    "identity": 6
  },
  {
    "cidr": "10.22.30.13/32",
    "identity": 6
  },
  {
    "cidr": "10.22.30.21/32",
    "identity": 6
  },
  {
    "cidr": "10.22.30.22/32",
    "identity": 6
  },
  {
    "cidr": "10.22.30.23/32",
    "identity": 6
  },
  {
    "cidr": "10.55.0.16/32",
    "hostIP": "10.22.30.11",
    "identity": 4
  },
  {
    "cidr": "10.55.0.64/32",
    "hostIP": "10.22.30.11",
    "identity": 1
  },
  {
    "cidr": "10.55.0.129/32",
    "hostIP": "10.22.30.11",
    "identity": 3394,
    "metadata": {
      "name": "rke2-coredns-rke2-coredns-84b9cb946c-7tvkp",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.0.214/32",
    "hostIP": "10.22.30.11",
    "identity": 8
  },
  {
    "cidr": "10.55.1.36/32",
    "hostIP": "10.22.30.12",
    "identity": 6
  },
  {
    "cidr": "10.55.1.165/32",
    "hostIP": "10.22.30.12",
    "identity": 4
  },
  {
    "cidr": "10.55.1.178/32",
    "hostIP": "10.22.30.12",
    "identity": 8
  },
  {
    "cidr": "10.55.2.122/32",
    "hostIP": "10.22.30.13",
    "identity": 8
  },
  {
    "cidr": "10.55.2.204/32",
    "hostIP": "10.22.30.13",
    "identity": 3394,
    "metadata": {
      "name": "rke2-coredns-rke2-coredns-84b9cb946c-rg8k7",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.2.220/32",
    "hostIP": "10.22.30.13",
    "identity": 4
  },
  {
    "cidr": "10.55.2.229/32",
    "hostIP": "10.22.30.13",
    "identity": 6
  },
  {
    "cidr": "10.55.3.12/32",
    "hostIP": "10.22.30.21",
    "identity": 1111,
    "metadata": {
      "name": "rke2-snapshot-controller-59cc9cd8f4-s4vrs",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.19/32",
    "hostIP": "10.22.30.21",
    "identity": 14678,
    "metadata": {
      "name": "rke2-argocd-dex-server-76bb6677d7-8rntq",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.23/32",
    "hostIP": "10.22.30.21",
    "identity": 29762,
    "metadata": {
      "name": "rke2-argocd-repo-server-7bf6499cb6-jh2wl",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.27/32",
    "hostIP": "10.22.30.21",
    "identity": 16822,
    "metadata": {
      "name": "rke2-metrics-server-655477f655-khcbm",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.50/32",
    "hostIP": "10.22.30.21",
    "identity": 29762,
    "metadata": {
      "name": "rke2-argocd-repo-server-7bf6499cb6-lpnlc",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.60/32",
    "hostIP": "10.22.30.21",
    "identity": 33708,
    "metadata": {
      "name": "rke2-argocd-server-b55ff85f8-26zmv",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.78/32",
    "hostIP": "10.22.30.21",
    "identity": 11758,
    "metadata": {
      "name": "rke2-argocd-redis-ha-haproxy-7548cbd54c-9r7vm",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.90/32",
    "hostIP": "10.22.30.21",
    "identity": 33708,
    "metadata": {
      "name": "rke2-argocd-server-b55ff85f8-fmtn7",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.129/32",
    "hostIP": "10.22.30.21",
    "identity": 16381,
    "metadata": {
      "name": "hubble-ui-6969854c48-vkb2p",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.164/32",
    "hostIP": "10.22.30.21",
    "identity": 1344,
    "metadata": {
      "name": "rke2-origin-ca-issuer-7bd586658-pmrc8",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.167/32",
    "hostIP": "10.22.30.21",
    "identity": 2139,
    "metadata": {
      "name": "hubble-relay-6f89c7f794-xdxwj",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.206/32",
    "hostIP": "10.22.30.21",
    "identity": 6
  },
  {
    "cidr": "10.55.3.209/32",
    "hostIP": "10.22.30.21",
    "identity": 4
  },
  {
    "cidr": "10.55.3.210/32",
    "hostIP": "10.22.30.21",
    "identity": 24197,
    "metadata": {
      "name": "rke2-snapshot-validation-webhook-54c5989b65-v2s9c",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.218/32",
    "hostIP": "10.22.30.21",
    "identity": 50180,
    "metadata": {
      "name": "rke2-coredns-rke2-coredns-autoscaler-b49765765-cxr2c",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.251/32",
    "hostIP": "10.22.30.21",
    "identity": 8
  },
  {
    "cidr": "10.55.3.252/32",
    "hostIP": "10.22.30.21",
    "identity": 30951,
    "metadata": {
      "name": "rke2-argocd-application-controller-654f4c59bd-m5tpw",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.3.253/32",
    "hostIP": "10.22.30.21",
    "identity": 10448,
    "metadata": {
      "name": "rke2-argocd-redis-ha-server-0",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.66/32",
    "hostIP": "10.22.30.22",
    "identity": 6
  },
  {
    "cidr": "10.55.4.77/32",
    "hostIP": "10.22.30.22",
    "identity": 8
  },
  {
    "cidr": "10.55.4.84/32",
    "hostIP": "10.22.30.22",
    "identity": 4
  },
  {
    "cidr": "10.55.4.112/32",
    "hostIP": "10.22.30.22",
    "identity": 50725,
    "metadata": {
      "name": "echo-other-node-6bb6657c95-szfjd",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.152/32",
    "hostIP": "10.22.30.22",
    "identity": 53865,
    "metadata": {
      "name": "rke2-cert-manager-8464c59bc9-bm6bq",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.187/32",
    "hostIP": "10.22.30.22",
    "identity": 9426,
    "metadata": {
      "name": "rke2-cert-manager-cainjector-ff5f7fd4d-8hhwr",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.211/32",
    "hostIP": "10.22.30.22",
    "identity": 13815,
    "metadata": {
      "name": "rke2-cert-manager-webhook-6547766fdb-jwpp8",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.213/32",
    "hostIP": "10.22.30.22",
    "identity": 11758,
    "metadata": {
      "name": "rke2-argocd-redis-ha-haproxy-7548cbd54c-jzccr",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.218/32",
    "hostIP": "10.22.30.22",
    "identity": 10448,
    "metadata": {
      "name": "rke2-argocd-redis-ha-server-1",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.4.250/32",
    "hostIP": "10.22.30.22",
    "identity": 15581,
    "metadata": {
      "name": "client3-6d89d47f9c-7t8z5",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.5.68/32",
    "hostIP": "10.22.30.23",
    "identity": 8
  },
  {
    "cidr": "10.55.5.82/32",
    "hostIP": "10.22.30.23",
    "identity": 29667,
    "metadata": {
      "name": "client-d48766cfd-l52hz",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.5.93/32",
    "hostIP": "10.22.30.23",
    "identity": 6
  },
  {
    "cidr": "10.55.5.109/32",
    "hostIP": "10.22.30.23",
    "identity": 4
  },
  {
    "cidr": "10.55.5.129/32",
    "hostIP": "10.22.30.23",
    "identity": 3859,
    "metadata": {
      "name": "echo-same-node-c74f867d5-2bzpm",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.5.149/32",
    "hostIP": "10.22.30.23",
    "identity": 11758,
    "metadata": {
      "name": "rke2-argocd-redis-ha-haproxy-7548cbd54c-q6kt2",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.5.155/32",
    "hostIP": "10.22.30.23",
    "identity": 10448,
    "metadata": {
      "name": "rke2-argocd-redis-ha-server-2",
      "namespace": "argocd",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.55.5.170/32",
    "hostIP": "10.22.30.23",
    "identity": 21496,
    "metadata": {
      "name": "client2-7b7957dc98-6fpqf",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  }
]

