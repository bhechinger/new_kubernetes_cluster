top - 17:44:17 up  3:25,  0 users,  load average: 0.35, 0.34, 0.29
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 24.1 sy,  0.0 ni, 51.7 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3921.4 total,    272.7 free,   1165.9 used,   2482.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2477.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1400628 154320  77312 S   0.0   3.8   2:34.64 cilium-+
    132 root      20   0 1229772   7040   3968 S   0.0   0.2   0:00.35 cilium-+
   3947 root      20   0 1241008  15744  11008 S   0.0   0.4   0:00.03 cilium-+
   3997 root      20   0 1229568   4224   3712 S   0.0   0.1   0:00.01 gops
   4017 root      20   0    7184   3072   2688 R   0.0   0.1   0:00.00 top
   4040 root      20   0 1229568   4480   3968 S   0.0   0.1   0:00.00 gops
