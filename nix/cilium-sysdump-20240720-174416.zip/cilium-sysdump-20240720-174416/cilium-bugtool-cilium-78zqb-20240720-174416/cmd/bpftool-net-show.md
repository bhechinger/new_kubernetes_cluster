xdp:

tc:
public(5) clsact/ingress cil_from_netdev-public id 1005
public(5) clsact/egress cil_to_netdev-public id 1010
private(6) clsact/ingress cil_from_netdev-private id 1022
private(6) clsact/egress cil_to_netdev-private id 1016
cilium_net(7) clsact/ingress cil_to_host-cilium_net id 991
cilium_host(8) clsact/ingress cil_to_host-cilium_host id 988
cilium_host(8) clsact/egress cil_from_host-cilium_host id 990
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 1049
lxc57b410517745(12) clsact/ingress cil_from_container-lxc57b410517745 id 1025

flow_dissector:

netfilter:

