# Cilium debug information

#### Cilium encryption



#### Cilium version

```
1.15.5 8c7e442c 2024-05-10T16:33:07+02:00 go version go1.21.10 linux/amd64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
92         Disabled           Disabled          3394       k8s:app.kubernetes.io/instance=rke2-coredns                                         10.55.0.129   ready   
                                                           k8s:app.kubernetes.io/name=rke2-coredns                                                                   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=hetzner                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
351        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                    ready   
                                                           k8s:node-role.kubernetes.io/etcd=true                                                                     
                                                           k8s:node-role.kubernetes.io/master=true                                                                   
                                                           k8s:node.kubernetes.io/instance-type=rke2                                                                 
                                                           reserved:host                                                                                             
764        Disabled           Disabled          8          reserved:ingress                                                                    10.55.0.214   ready   
3424       Disabled           Disabled          4          reserved:health                                                                     10.55.0.16    ready   
```

#### BPF Policy Get 92

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1456453   17417     0        
Allow    Ingress     1          ANY          NONE         disabled    1185865   13666     0        
Allow    Egress      0          ANY          NONE         disabled    228985    2972      0        

```


#### BPF CT List 92

```
Invalid argument: unknown type 92
```


#### Endpoint Get 92

```
[
  {
    "id": 92,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-92-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d8b6a9e6-92d6-49a8-8704-0679b2e09e8f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-92",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:57.376Z",
            "success-count": 41
          },
          "uuid": "fb4515af-593e-49ff-bc6e-a55d34b1ee2a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T14:20:57.348Z",
            "success-count": 1
          },
          "uuid": "6fff3417-ee92-46fb-83be-e6eef4957e3e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-92",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:35:59.759Z",
            "success-count": 14
          },
          "uuid": "923da0fa-9500-4356-8ad2-4b9925456354"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (92)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:44:38.369Z",
            "success-count": 1224
          },
          "uuid": "2dfca26d-06d1-4afa-9c22-f4e119bfe3a1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ce3f50548c3741723343f12ef92567cf668cd6852bd20421ab6f618b64c569ef:eth0",
        "container-id": "ce3f50548c3741723343f12ef92567cf668cd6852bd20421ab6f618b64c569ef",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "rke2-coredns-rke2-coredns-84b9cb946c-7tvkp",
        "pod-name": "kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3394,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:app.kubernetes.io/instance=rke2-coredns",
          "k8s:app.kubernetes.io/name=rke2-coredns",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=84b9cb946c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=rke2-coredns",
          "k8s:app.kubernetes.io/name=rke2-coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=hetzner",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "tcp-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "tcp-9153",
          "port": 9153,
          "protocol": "TCP"
        },
        {
          "name": "udp-53",
          "port": 53,
          "protocol": "UDP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.129",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "42:2e:90:77:52:98",
        "interface-index": 12,
        "interface-name": "lxc57b410517745",
        "mac": "f2:32:ff:33:52:a3"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3394,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3394,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 92

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 92

```
Timestamp              Status    State                   Message
2024-07-20T16:08:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK        regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:20:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:20:59Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:20:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:57Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:20:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:20:57Z   OK        ready                   Set identity for this endpoint
2024-07-20T14:20:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:56Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3394

```
ID     LABELS
3394   k8s:app.kubernetes.io/instance=rke2-coredns
       k8s:app.kubernetes.io/name=rke2-coredns
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=hetzner
       k8s:io.cilium.k8s.policy.serviceaccount=coredns
       k8s:io.kubernetes.pod.namespace=kube-system
       k8s:k8s-app=kube-dns

```


#### BPF Policy Get 351

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 351

```
Invalid argument: unknown type 351
```


#### Endpoint Get 351

```
[
  {
    "id": 351,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-351-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0e80aaa2-28fe-44ef-b07d-7264a315d827"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-351",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:56.433Z",
            "success-count": 41
          },
          "uuid": "c76d2a0f-ba56-4886-89bd-23319a88f6b1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-351",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:35:58.304Z",
            "success-count": 14
          },
          "uuid": "6adb96bd-8355-496b-8af5-f8fcaa0ba148"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=rke2",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/control-plane=true"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "8a:6b:c6:e4:c9:36",
        "interface-name": "cilium_host",
        "mac": "8a:6b:c6:e4:c9:36"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 351

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 351

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:20:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:20:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-07-20T14:20:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:20:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:20:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:20:56Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:20:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host
     reserved:kube-apiserver

```


#### BPF Policy Get 764

```
Error: Failed to open map: loading pinned map /sys/fs/bpf/tc/globals/cilium_policy_00764: no such file or directory


```


#### BPF CT List 764

```
Invalid argument: unknown type 764
```


#### Endpoint Get 764

```
[
  {
    "id": 764,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-764-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "079f5c3c-ed08-4d46-8332-a1c0e438a9e1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-764",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:56.433Z",
            "success-count": 41
          },
          "uuid": "b6825cdd-9d21-470d-ad96-5a729cde292e"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 8,
        "labels": [
          "reserved:ingress"
        ]
      },
      "labels": {
        "derived": [
          "reserved:ingress"
        ],
        "realized": {},
        "security-relevant": [
          "reserved:ingress"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.214"
          }
        ]
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 764

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 764

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:20:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:20:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:20:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:20:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:20:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:20:56Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:20:56Z   OK       waiting-for-identity    Ingress Endpoint creation

```


#### Identity get 8

```
ID   LABELS
8    reserved:ingress

```


#### BPF Policy Get 3424

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    532567   6706      0        
Allow    Ingress     1          ANY          NONE         disabled    160686   1835      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3424

```
Invalid argument: unknown type 3424
```


#### Endpoint Get 3424

```
[
  {
    "id": 3424,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3424-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "619ab279-c568-422d-828e-a1c7877cb60a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3424",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:57.450Z",
            "success-count": 41
          },
          "uuid": "7171bbbc-8c7f-409c-a575-ab390a81ce05"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3424",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:35:59.759Z",
            "success-count": 14
          },
          "uuid": "4105d80e-2925-4c71-bced-141486843a84"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.16",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "42:04:b1:89:a2:af",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "76:b0:48:7b:0e:68"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3424

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3424

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:20:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:20:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:20:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:20:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:20:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:20:57Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:20:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                           
1    10.65.0.1:443         ClusterIP      1 => 10.22.20.11:6443 (active)    
                                          2 => 10.22.20.12:6443 (active)    
                                          3 => 10.22.20.13:6443 (active)    
2    10.65.253.13:443      ClusterIP      1 => 10.22.30.11:4244 (active)    
3    10.65.203.48:80       ClusterIP      1 => 10.55.3.167:4245 (active)    
4    10.65.97.59:80        ClusterIP      1 => 10.55.3.129:8081 (active)    
5    10.65.0.10:53         ClusterIP      1 => 10.55.0.129:53 (active)      
                                          2 => 10.55.2.204:53 (active)      
6    10.65.180.197:9101    ClusterIP      1 => 10.55.3.78:9101 (active)     
                                          2 => 10.55.4.213:9101 (active)    
                                          3 => 10.55.5.149:9101 (active)    
7    10.65.180.197:6379    ClusterIP      1 => 10.55.3.78:6379 (active)     
                                          2 => 10.55.4.213:6379 (active)    
                                          3 => 10.55.5.149:6379 (active)    
8    10.65.145.33:5556     ClusterIP      1 => 10.55.3.19:5556 (active)     
9    10.65.145.33:5557     ClusterIP      1 => 10.55.3.19:5557 (active)     
10   10.65.115.248:8082    ClusterIP      1 => 10.55.3.252:8082 (active)    
11   10.65.192.200:8081    ClusterIP      1 => 10.55.3.50:8081 (active)     
                                          2 => 10.55.3.23:8081 (active)     
12   10.65.243.160:6379    ClusterIP      1 => 10.55.4.218:6379 (active)    
13   10.65.243.160:26379   ClusterIP      1 => 10.55.4.218:26379 (active)   
14   10.65.243.160:9121    ClusterIP      1 => 10.55.4.218:9121 (active)    
15   10.65.148.50:443      ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
16   10.65.148.50:80       ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
17   10.65.70.170:6379     ClusterIP      1 => 10.55.5.155:6379 (active)    
18   10.65.70.170:26379    ClusterIP      1 => 10.55.5.155:26379 (active)   
19   10.65.70.170:9121     ClusterIP      1 => 10.55.5.155:9121 (active)    
20   10.65.178.184:6379    ClusterIP      1 => 10.55.3.253:6379 (active)    
21   10.65.178.184:26379   ClusterIP      1 => 10.55.3.253:26379 (active)   
22   10.65.178.184:9121    ClusterIP      1 => 10.55.3.253:9121 (active)    
23   10.65.51.64:443       ClusterIP      1 => 10.55.3.210:8443 (active)    
24   10.65.48.249:443      ClusterIP      1 => 10.55.3.27:10250 (active)    
27   10.65.213.42:9402     ClusterIP      1 => 10.55.4.152:9402 (active)    
28   10.65.174.214:443     ClusterIP      1 => 10.55.4.211:10250 (active)   
29   10.65.155.14:8080     ClusterIP      1 => 10.55.5.129:8080 (active)    
30   0.0.0.0:32495         NodePort       1 => 10.55.5.129:8080 (active)    
31   10.22.20.11:32495     NodePort       1 => 10.55.5.129:8080 (active)    
32   10.22.30.11:32495     NodePort       1 => 10.55.5.129:8080 (active)    
33   10.65.26.204:8080     ClusterIP      1 => 10.55.4.112:8080 (active)    
34   10.22.20.11:30568     NodePort       1 => 10.55.4.112:8080 (active)    
35   10.22.30.11:30568     NodePort       1 => 10.55.4.112:8080 (active)    
36   0.0.0.0:30568         NodePort       1 => 10.55.4.112:8080 (active)    
```

#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc001f70f80)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc001a0e060,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=21) {
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha: (*k8s.Service)(0xc001065ad0)(frontends:[]/ports=[http-exporter-port tcp-server tcp-sentinel]/selector=map[app:redis-ha release:rke2-argocd]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.Service)(0xc001065b80)(frontends:[10.65.180.197]/ports=[tcp-haproxy http-exporter-port]/selector=map[app:redis-ha-haproxy release:rke2-argocd]),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.Service)(0xc002603600)(frontends:[10.65.26.204]/ports=[http]/selector=map[name:echo-other-node]),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.Service)(0xc002ccc8f0)(frontends:[10.65.148.50]/ports=[http https]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-server]),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.Service)(0xc000910000)(frontends:[10.65.51.64]/ports=[https]/selector=map[app.kubernetes.io/instance:rke2-snapshot-validation-webhook app.kubernetes.io/name:rke2-snapshot-validation-webhook]),
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.Service)(0xc000911970)(frontends:[10.65.48.249]/ports=[https]/selector=map[app:rke2-metrics-server app.kubernetes.io/instance:rke2-metrics-server app.kubernetes.io/name:rke2-metrics-server]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc001b72fd0)(frontends:[10.65.203.48]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc001b73080)(frontends:[10.65.97.59]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.Service)(0xc002ccc630)(frontends:[10.65.145.33]/ports=[http grpc]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-dex-server]),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.Service)(0xc001b73130)(frontends:[10.65.0.10]/ports=[udp-53 tcp-53]/selector=map[app.kubernetes.io/instance:rke2-coredns app.kubernetes.io/name:rke2-coredns k8s-app:kube-dns]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.Service)(0xc0030696b0)(frontends:[10.65.213.42]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc001064420)(frontends:[10.65.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc0010644d0)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc001064580)(frontends:[10.65.253.13]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.Service)(0xc002ccca50)(frontends:[10.65.70.170]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-2]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.Service)(0xc001b72210)(frontends:[10.65.178.184]/ports=[http-exporter tcp-server tcp-sentinel]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-0]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.Service)(0xc003069b80)(frontends:[10.65.174.214]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.Service)(0xc003069550)(frontends:[10.65.155.14]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.Service)(0xc002522370)(frontends:[10.65.115.248]/ports=[https-controller]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-application-controller]),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.Service)(0xc002522e70)(frontends:[10.65.192.200]/ports=[https-repo-server]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-repo-server]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.Service)(0xc002523080)(frontends:[10.65.243.160]/ports=[http-exporter tcp-server tcp-sentinel]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-1])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.EndpointSlices)(0xc0017911d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=34) "rke2-argocd-redis-ha-haproxy-vlh5w": (*k8s.Endpoints)(0xc001ff2ea0)(10.55.3.78:6379/TCP,10.55.3.78:9101/TCP,10.55.4.213:6379/TCP,10.55.4.213:9101/TCP,10.55.5.149:6379/TCP,10.55.5.149:9101/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.EndpointSlices)(0xc001791330)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-1-j6rjb": (*k8s.Endpoints)(0xc001ffdba0)(10.55.4.218:26379/TCP,10.55.4.218:6379/TCP,10.55.4.218:9121/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.EndpointSlices)(0xc0017913b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=24) "rke2-argocd-server-8r4gl": (*k8s.Endpoints)(0xc002d780d0)(10.55.3.60:8080/TCP,10.55.3.60:8080/TCP,10.55.3.90:8080/TCP,10.55.3.90:8080/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.EndpointSlices)(0xc0016ef810)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-dcdmx": (*k8s.Endpoints)(0xc0031e4270)(10.55.5.129:8080/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.EndpointSlices)(0xc00151f808)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=21) "echo-other-node-zctcd": (*k8s.Endpoints)(0xc00307a8f0)(10.55.4.112:8080/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc0015a12a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-9l8c5": (*k8s.Endpoints)(0xc002bba5b0)(10.55.3.167:4245/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.EndpointSlices)(0xc0015a12b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-coredns-rke2-coredns-kcjm5": (*k8s.Endpoints)(0xc002478410)(10.55.0.129:53/TCP,10.55.0.129:53/UDP,10.55.2.204:53/TCP,10.55.2.204:53/UDP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.EndpointSlices)(0xc0015cb290)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=28) "rke2-argocd-dex-server-sv4gw": (*k8s.Endpoints)(0xc0024ad860)(10.55.3.19:5556/TCP,10.55.3.19:5557/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.EndpointSlices)(0xc001791310)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=40) "rke2-argocd-application-controller-fz8wm": (*k8s.Endpoints)(0xc0034eec30)(10.55.3.252:8082/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.EndpointSlices)(0xc00151e908)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "rke2-metrics-server-7sv6h": (*k8s.Endpoints)(0xc0034eeea0)(10.55.3.27:10250/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.EndpointSlices)(0xc000c55b58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=23) "rke2-cert-manager-qnhfm": (*k8s.Endpoints)(0xc0030ee820)(10.55.4.152:9402/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.EndpointSlices)(0xc000c55dc8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-cert-manager-webhook-9smdc": (*k8s.Endpoints)(0xc0030efee0)(10.55.4.211:10250/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc0015a1290)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc0028c4f70)(10.22.20.11:6443/TCP,10.22.20.12:6443/TCP,10.22.20.13:6443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc0015a12a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-7qjhj": (*k8s.Endpoints)(0xc0030ef040)(10.55.3.129:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.EndpointSlices)(0xc0015cb3d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=29) "rke2-argocd-repo-server-xmwsw": (*k8s.Endpoints)(0xc0024ac8f0)(10.55.3.23:8081/TCP,10.55.3.50:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.EndpointSlices)(0xc0017913c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-2-8ts7n": (*k8s.Endpoints)(0xc002d78340)(10.55.5.155:26379/TCP,10.55.5.155:6379/TCP,10.55.5.155:9121/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.EndpointSlices)(0xc001791470)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-0-9lzv5": (*k8s.Endpoints)(0xc001fa4270)(10.55.3.253:26379/TCP,10.55.3.253:6379/TCP,10.55.3.253:9121/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.EndpointSlices)(0xc0002a8ba0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=38) "rke2-snapshot-validation-webhook-m6rrw": (*k8s.Endpoints)(0xc0023fc1a0)(10.55.3.210:8443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc0015a1298)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-dmr4p": (*k8s.Endpoints)(0xc0031eeb60)(10.22.30.11:4244/TCP,10.22.30.12:4244/TCP,10.22.30.13:4244/TCP,10.22.30.21:4244/TCP,10.22.30.22:4244/TCP,10.22.30.23:4244/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*tables.nodeAddressing)(0xc0018aa1e0)({
  localNode: (*node.LocalNodeStore)(0xc0006b0f00)({
   Observable: (stream.FuncObservable[github.com/cilium/cilium/pkg/node.LocalNode]) 0x1df7600,
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   value: (node.LocalNode) {
    Node: (types.Node) {
     Name: (string) (len=7) "master1",
     Cluster: (string) (len=7) "hetzner",
     IPAddresses: ([]types.Address) (len=3 cap=4) {
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "InternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.30.11
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "ExternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.20.11
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=16) "CiliumInternalIP",
       IP: (net.IP) (len=16 cap=26) 10.55.0.64
      }
     },
     IPv4AllocCIDR: (*cidr.CIDR)(0xc0015a1100)(10.55.0.0/24),
     IPv4SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv6AllocCIDR: (*cidr.CIDR)(<nil>),
     IPv6SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv4HealthIP: (net.IP) (len=16 cap=26) 10.55.0.16,
     IPv6HealthIP: (net.IP) <nil>,
     IPv4IngressIP: (net.IP) (len=16 cap=26) 10.55.0.214,
     IPv6IngressIP: (net.IP) <nil>,
     ClusterID: (uint32) 0,
     Source: (source.Source) (len=5) "local",
     EncryptionKey: (uint8) 0,
     Labels: (map[string]string) (len=10) {
      (string) (len=23) "beta.kubernetes.io/arch": (string) (len=5) "amd64",
      (string) (len=32) "beta.kubernetes.io/instance-type": (string) (len=4) "rke2",
      (string) (len=32) "node.kubernetes.io/instance-type": (string) (len=4) "rke2",
      (string) (len=22) "kubernetes.io/hostname": (string) (len=7) "master1",
      (string) (len=30) "node-role.kubernetes.io/master": (string) (len=4) "true",
      (string) (len=28) "node-role.kubernetes.io/etcd": (string) (len=4) "true",
      (string) (len=18) "kubernetes.io/arch": (string) (len=5) "amd64",
      (string) (len=37) "node-role.kubernetes.io/control-plane": (string) (len=4) "true",
      (string) (len=21) "beta.kubernetes.io/os": (string) (len=5) "linux",
      (string) (len=16) "kubernetes.io/os": (string) (len=5) "linux"
     },
     Annotations: (map[string]string) (len=4) {
      (string) (len=34) "network.cilium.io/ipv4-cilium-host": (string) (len=10) "10.55.0.64",
      (string) (len=33) "network.cilium.io/ipv4-Ingress-ip": (string) (len=11) "10.55.0.214",
      (string) (len=31) "network.cilium.io/ipv4-pod-cidr": (string) (len=12) "10.55.0.0/24",
      (string) (len=32) "network.cilium.io/ipv4-health-ip": (string) (len=10) "10.55.0.16"
     },
     NodeIdentity: (uint32) 1,
     WireguardPubKey: (string) "",
     BootID: (string) (len=36) "4d30e4a8-ffd9-4ba0-8558-2648afacb05f"
    },
    OptOutNodeEncryption: (bool) false,
    UID: (types.UID) (len=36) "968dda0e-666e-41ef-86e9-479aea590ce8",
    ProviderID: (string) (len=14) "rke2://master1"
   },
   emit: (func(node.LocalNode)) 0x1df7ea0,
   complete: (func(error)) 0x1df7c60
  }),
  db: (*statedb.DB)(0xc0010c2a80)({
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   tables: (map[string]statedb.TableMeta) (len=4) {
    (string) (len=11) "l2-announce": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.L2AnnounceEntry])(0xc0005b73b0)({
     table: (string) (len=11) "l2-announce",
     smu: (*lock.sortableMutex)(0xc00194f908)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 4,
      acquireDuration: (time.Duration) 150ns
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=6) "origin": (statedb.anyIndexer) {
       name: (string) (len=6) "origin",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=7) "devices": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc000833310)({
     table: (string) (len=7) "devices",
     smu: (*lock.sortableMutex)(0xc0017d5710)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 1,
      acquireDuration: (time.Duration) 4.127µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      },
      (string) (len=8) "selected": (statedb.anyIndexer) {
       name: (string) (len=8) "selected",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=6) "routes": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Route])(0xc000833360)({
     table: (string) (len=6) "routes",
     smu: (*lock.sortableMutex)(0xc0017d5728)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 2,
      acquireDuration: (time.Duration) 893ns
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=9) "LinkIndex": (statedb.anyIndexer) {
       name: (string) (len=9) "LinkIndex",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=14) "node-addresses": (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc000833770)({
     table: (string) (len=14) "node-addresses",
     smu: (*lock.sortableMutex)(0xc0017d5770)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 3,
      acquireDuration: (time.Duration) 1.066µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
       unique: (bool) false
      }
     }
    })
   },
   ctx: (*context.cancelCtx)(0xc000beaf00)(context.Background.WithCancel),
   cancel: (context.CancelFunc) 0x4a18e0,
   root: (atomic.Pointer[github.com/hashicorp/go-immutable-radix/v2.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]]) {
    _: ([0]*iradix.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]) {
    },
    _: (atomic.noCopy) {
    },
    v: (unsafe.Pointer) 0xc000df6d50
   },
   gcTrigger: (chan struct {}) (cap=1) 0xc00168db00,
   gcExited: (chan struct {}) 0xc00168db60,
   gcRateLimitInterval: (time.Duration) 1s,
   metrics: (statedb.Metrics) {
    WriteTxnDuration: (*metric.histogramVec)(0xc00142d700)({
     ObserverVec: (*prometheus.HistogramVec)(0xc00128f3b0)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0270)({
       metricMap: (*prometheus.metricMap)(0xc000cc02a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001423e60)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0xc00142d780)({
     ObserverVec: (*prometheus.HistogramVec)(0xc00128f3b8)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0300)({
       metricMap: (*prometheus.metricMap)(0xc000cc0330)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001423ec0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0xc00142d800)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3c0)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0390)({
       metricMap: (*prometheus.metricMap)(0xc000cc03c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001423f20)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0xc00142d880)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3c8)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0450)({
       metricMap: (*prometheus.metricMap)(0xc000cc0480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001423f80)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0xc00142d900)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3d0)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc04e0)({
       metricMap: (*prometheus.metricMap)(0xc000cc0510)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001444000)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0xc00142d980)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3d8)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0570)({
       metricMap: (*prometheus.metricMap)(0xc000cc05d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001444060)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0xc00142da00)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3e0)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0630)({
       metricMap: (*prometheus.metricMap)(0xc000cc0660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0014440c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0xc00142da80)({
     GaugeVec: (*prometheus.GaugeVec)(0xc00128f3e8)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc06c0)({
       metricMap: (*prometheus.metricMap)(0xc000cc06f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001444120)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0xc00142db00)({
     ObserverVec: (*prometheus.HistogramVec)(0xc00128f3f0)({
      MetricVec: (*prometheus.MetricVec)(0xc000cc0780)({
       metricMap: (*prometheus.metricMap)(0xc000cc07b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001444180)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  }),
  nodeAddresses: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc000833770)({
   table: (string) (len=14) "node-addresses",
   smu: (*lock.sortableMutex)(0xc0017d5770)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 3,
    acquireDuration: (time.Duration) 1.066µs
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
     unique: (bool) false
    }
   }
  }),
  devices: (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc000833310)({
   table: (string) (len=7) "devices",
   smu: (*lock.sortableMutex)(0xc0017d5710)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 1,
    acquireDuration: (time.Duration) 4.127µs
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    },
    (string) (len=8) "selected": (statedb.anyIndexer) {
     name: (string) (len=8) "selected",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    }
   }
  })
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium memory map


```
00400000-02d9c000 r-xp 00000000 00:b4 1592714                            /usr/bin/cilium-agent
02d9c000-05f5d000 r--p 0299c000 00:b4 1592714                            /usr/bin/cilium-agent
05f5d000-060b2000 rw-p 05b5d000 00:b4 1592714                            /usr/bin/cilium-agent
060b2000-06840000 rw-p 00000000 00:00 0 
c000000000-c004800000 rw-p 00000000 00:00 0 
c004800000-c008000000 ---p 00000000 00:00 0 
7fb44e634000-7fb44e809000 rw-p 00000000 00:00 0 
7fb44e809000-7fb44e84a000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7fb44e84a000-7fb44e88b000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7fb44e88b000-7fb44edeb000 rw-p 00000000 00:00 0 
7fb44edeb000-7fb44eeeb000 rw-p 00000000 00:00 0 
7fb44eeeb000-7fb44f000000 rw-p 00000000 00:00 0 
7fb44f000000-7fb451000000 rw-p 00000000 00:00 0 
7fb451000000-7fb461180000 ---p 00000000 00:00 0 
7fb461180000-7fb461181000 rw-p 00000000 00:00 0 
7fb461181000-7fb481180000 ---p 00000000 00:00 0 
7fb481180000-7fb481181000 rw-p 00000000 00:00 0 
7fb481181000-7fb493030000 ---p 00000000 00:00 0 
7fb493030000-7fb493031000 rw-p 00000000 00:00 0 
7fb493031000-7fb495406000 ---p 00000000 00:00 0 
7fb495406000-7fb495407000 rw-p 00000000 00:00 0 
7fb495407000-7fb495800000 ---p 00000000 00:00 0 
7fb495808000-7fb49580a000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7fb49580a000-7fb49580c000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7fb49580c000-7fb495842000 rw-p 00000000 00:00 0 
7fb495842000-7fb4958c2000 ---p 00000000 00:00 0 
7fb4958c2000-7fb4958c3000 rw-p 00000000 00:00 0 
7fb4958c3000-7fb495942000 ---p 00000000 00:00 0 
7fb495942000-7fb4959a2000 rw-p 00000000 00:00 0 
7ffd857fe000-7ffd8581f000 rw-p 00000000 00:00 0                          [stack]
7ffd859a0000-7ffd859a4000 r--p 00000000 00:00 0                          [vvar]
7ffd859a4000-7ffd859a6000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### Kernel version

```
6.8.12
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [public   10.22.20.11 fe80::5054:ff:fe92:19da, private   10.22.30.11 fe80::5054:ff:fed6:4c0f (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 4/254 allocated from 10.55.0.0/24, 
Allocated addresses:
  10.55.0.129 (kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp)
  10.55.0.16 (health)
  10.55.0.214 (ingress)
  10.55.0.64 (router)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [public, private]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [public, private]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      26/26 healthy
  Name                                                                    Last success   Last error     Count   Message
  cilium-health-ep                                                        51s ago        never          0       no error   
  dns-garbage-collector-job                                               53s ago        never          0       no error   
  endpoint-3424-regeneration-recovery                                     never          never          0       no error   
  endpoint-351-regeneration-recovery                                      never          never          0       no error   
  endpoint-764-regeneration-recovery                                      never          never          0       no error   
  endpoint-92-regeneration-recovery                                       never          never          0       no error   
  endpoint-gc                                                             3m53s ago      never          0       no error   
  ep-bpf-prog-watchdog                                                    22s ago        never          0       no error   
  ipcache-inject-labels                                                   52s ago        3h23m53s ago   0       no error   
  k8s-heartbeat                                                           21s ago        never          0       no error   
  link-cache                                                              7s ago         never          0       no error   
  resolve-identity-3424                                                   3m51s ago      never          0       no error   
  resolve-identity-351                                                    3m52s ago      never          0       no error   
  resolve-identity-764                                                    3m52s ago      never          0       no error   
  resolve-identity-92                                                     3m51s ago      never          0       no error   
  resolve-labels-kube-system/rke2-coredns-rke2-coredns-84b9cb946c-7tvkp   3h23m51s ago   never          0       no error   
  sync-host-ips                                                           52s ago        never          0       no error   
  sync-lb-maps-with-k8s-services                                          3h23m52s ago   never          0       no error   
  sync-policymap-3424                                                     8m49s ago      never          0       no error   
  sync-policymap-351                                                      8m51s ago      never          0       no error   
  sync-policymap-92                                                       8m49s ago      never          0       no error   
  sync-to-k8s-ciliumendpoint (92)                                         10s ago        never          0       no error   
  sync-utime                                                              52s ago        never          0       no error   
  template-dir-watcher                                                    never          never          0       no error   
  update-k8s-node-annotations                                             3h23m53s ago   never          0       no error   
  write-cni-file                                                          3h23m53s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.0.64, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 15.32   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                public   10.22.20.11 fe80::5054:ff:fe92:19da, private   10.22.30.11 fe80::5054:ff:fed6:4c0f (Direct Routing)
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
clustermesh-ip-identities-sync-timeout:1m0s
label-prefix-file:
enable-health-check-nodeport:true
disable-envoy-version-check:false
enable-l2-neigh-discovery:true
enable-cilium-health-api-server-access:
enable-icmp-rules:true
identity-restore-grace-period:10m0s
tofqdns-idle-connection-grace-period:0s
hubble-monitor-events:
hubble-export-file-path:
bpf-sock-rev-map-max:262144
enable-bpf-masquerade:true
enable-xt-socket-fallback:true
ipv4-service-loopback-address:169.254.42.1
enable-ipv4-fragment-tracking:true
bpf-lb-mode:snat
api-rate-limit:
container-ip-local-reserved-ports:auto
envoy-config-timeout:2m0s
enable-bbr:true
bpf-fragments-map-max:8192
iptables-random-fully:false
fixed-identity-mapping:
cluster-health-port:4240
k8s-client-qps:10
crd-wait-timeout:5m0s
enable-l2-pod-announcements:false
enable-k8s-endpoint-slice:true
enable-unreachable-routes:false
service-no-backend-response:reject
enable-node-port:false
bpf-lb-sock-hostns-only:false
kube-proxy-replacement-healthz-bind-address:
enable-runtime-device-detection:false
enable-policy:default
enable-hubble-recorder-api:true
dns-max-ips-per-restored-rule:1000
mesh-auth-mutual-listener-port:0
proxy-idle-timeout-seconds:60
annotate-k8s-node:true
kvstore:
l2-pod-announcements-interface:
derive-masquerade-ip-addr-from-device:
mesh-auth-rotated-identities-queue-size:1024
node-port-acceleration:disabled
cflags:
bpf-neigh-global-max:524288
http-max-grpc-timeout:0
ip-masq-agent-config-path:/etc/config/ip-masq-agent
node-port-range:
bpf-ct-timeout-regular-tcp:2h13m20s
http-normalize-path:true
enable-sctp:false
auto-direct-node-routes:true
hubble-prefer-ipv6:false
hubble-export-file-max-size-mb:10
k8s-api-server:
mesh-auth-queue-size:1024
proxy-max-requests-per-connection:0
enable-encryption-strict-mode:false
enable-bpf-clock-probe:false
nodes-gc-interval:5m0s
sidecar-istio-proxy-image:cilium/istio_proxy
procfs:/host/proc
enable-stale-cilium-endpoint-cleanup:true
pprof-port:6060
hubble-export-file-compress:false
cluster-name:hetzner
enable-k8s-terminating-endpoint:true
bpf-lb-maglev-map-max:0
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
hubble-metrics:
prometheus-serve-addr::9962
monitor-aggregation-flags:all
kube-proxy-replacement:strict
vtep-mac:
disable-endpoint-crd:false
tofqdns-max-deferred-connection-deletes:10000
encryption-strict-mode-allow-remote-node-identities:false
pprof-address:localhost
ipv6-service-range:auto
k8s-client-burst:20
bpf-auth-map-max:524288
ipv6-mcast-device:
ip-allocation-timeout:2m0s
ipv6-native-routing-cidr:
enable-k8s-networkpolicy:true
ipv4-pod-subnets:
mesh-auth-spire-admin-socket:
restore:true
bpf-lb-dsr-l4-xlate:frontend
vtep-endpoint:
dnsproxy-enable-transparent-mode:false
devices:public private
hubble-event-queue-size:0
mesh-auth-gc-interval:5m0s
bpf-lb-map-max:65536
egress-gateway-policy-map-max:16384
tofqdns-endpoint-max-ip-per-hostname:50
tunnel-protocol:vxlan
trace-sock:true
k8s-service-cache-size:128
bpf-ct-timeout-regular-tcp-fin:10s
srv6-encap-mode:reduced
max-controller-interval:0
bpf-lb-rev-nat-map-max:0
egress-gateway-reconciliation-trigger-interval:1s
hubble-flowlogs-config-path:
install-no-conntrack-iptables-rules:false
ipsec-key-file:
agent-health-port:9879
proxy-max-connection-duration-seconds:0
policy-audit-mode:false
http-request-timeout:3600
bpf-ct-timeout-service-any:1m0s
gateway-api-secrets-namespace:cilium-secrets
enable-wireguard-userspace-fallback:false
enable-ipv4-big-tcp:false
http-403-msg:
bpf-policy-map-full-reconciliation-interval:15m0s
mke-cgroup-mount:
mesh-auth-enabled:true
dns-policy-unload-on-shutdown:false
fqdn-regex-compile-lru-size:1024
bpf-ct-timeout-service-tcp-grace:1m0s
http-idle-timeout:0
auto-create-cilium-node-resource:true
enable-external-ips:false
mesh-auth-mutual-connect-timeout:5s
legacy-turn-off-k8s-event-handover:false
cni-exclusive:true
enable-ipv6-ndp:false
ipv6-node:auto
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ip-masq-agent:true
identity-change-grace-period:5s
encrypt-node:false
tunnel-port:0
metrics:
l2-announcements-renew-deadline:5s
bpf-lb-source-range-map-max:0
proxy-xff-num-trusted-hops-ingress:0
enable-monitor:true
kvstore-periodic-sync:5m0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-ct-timeout-regular-tcp-syn:1m0s
ipv6-pod-subnets:
vlan-bpf-bypass:4000
conntrack-gc-max-interval:0s
enable-gateway-api:true
cni-external-routing:false
monitor-aggregation-interval:5s
enable-cilium-endpoint-slice:true
debug:false
ipv4-native-routing-cidr:10.22.30.0/24
enable-wireguard:false
enable-local-redirect-policy:false
install-egress-gateway-routes:false
preallocate-bpf-maps:false
cluster-id:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-metrics:true
envoy-log:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-ct-global-any-max:262144
enable-mke:false
hubble-recorder-sink-queue-size:1024
enable-tracing:false
enable-high-scale-ipcache:false
custom-cni-conf:false
debug-verbose:
hubble-disable-tls:false
enable-recorder:false
ipam-cilium-node-update-rate:15s
set-cilium-is-up-condition:true
egress-masquerade-interfaces:
enable-l7-proxy:true
enable-endpoint-routes:false
encryption-strict-mode-cidr:
trace-payloadlen:128
ipv4-service-range:auto
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-bpf-tproxy:false
enable-k8s-api-discovery:false
routing-mode:native
mesh-auth-signal-backoff-duration:1s
enable-ipv6-masquerade:true
hubble-export-denylist:
enable-health-checking:true
bpf-lb-service-map-max:0
dnsproxy-concurrency-processing-grace-period:0s
enable-session-affinity:false
direct-routing-device:private
bpf-nat-global-max:524288
datapath-mode:veth
prepend-iptables-chains:true
monitor-aggregation:medium
enable-ipv6:false
allow-localhost:auto
enable-bgp-control-plane:false
ipv4-node:auto
hubble-redact-http-headers-deny:
route-metric:0
ipam-default-ip-pool:default
enable-pmtu-discovery:false
hubble-skip-unknown-cgroup-ids:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
disable-iptables-feeder-rules:
log-opt:
enable-xdp-prefilter:false
enable-k8s:true
k8s-heartbeat-timeout:30s
join-cluster:false
enable-well-known-identities:false
dnsproxy-lock-timeout:500ms
tofqdns-proxy-port:0
cni-chaining-mode:portmap
ipv6-range:auto
ipam:kubernetes
enable-nat46x64-gateway:false
tofqdns-proxy-response-max-delay:100ms
cgroup-root:/run/cilium/cgroupv2
hubble-metrics-server:
controller-group-metrics:write-cni-file sync-host-ips sync-lb-maps-with-k8s-services
conntrack-gc-interval:0s
enable-hubble:true
node-port-bind-protection:true
bpf-lb-service-backend-map-max:0
enable-service-topology:false
identity-heartbeat-timeout:30m0s
enable-ipv6-big-tcp:false
hubble-export-fieldmask:
ipsec-key-rotation-duration:5m0s
bpf-node-map-max:16384
proxy-gid:1337
enable-svc-source-range-check:true
enable-custom-calls:false
lib-dir:/var/lib/cilium
hubble-export-file-max-backups:5
hubble-export-allowlist:
bpf-lb-acceleration:disabled
enable-local-node-route:true
bpf-root:/sys/fs/bpf
bpf-ct-timeout-service-tcp:2h13m20s
enable-ipsec-key-watcher:true
nodeport-addresses:
enable-srv6:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
arping-refresh-period:30s
bpf-lb-rss-ipv6-src-cidr:
endpoint-status:
kvstore-max-consecutive-quorum-errors:2
dnsproxy-lock-count:131
kvstore-lease-ttl:15m0s
ipam-multi-pool-pre-allocation:
bpf-ct-timeout-regular-any:1m0s
tofqdns-pre-cache:
synchronize-k8s-nodes:true
keep-config:false
k8s-kubeconfig-path:
config-dir:/tmp/cilium/config-map
gops-port:9890
operator-api-serve-addr:127.0.0.1:9234
enable-bandwidth-manager:true
egress-multi-home-ip-rule-compat:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
local-router-ipv4:
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-auto-protect-node-port-range:true
install-iptables-rules:true
bpf-lb-maglev-table-size:16381
bypass-ip-availability-upon-restore:false
use-cilium-internal-ip-for-ipsec:false
remove-cilium-node-taints:true
ipv4-range:auto
certificates-directory:/var/run/cilium/certs
bpf-lb-dsr-dispatch:opt
iptables-lock-timeout:5s
node-port-mode:snat
hubble-redact-http-urlquery:false
endpoint-gc-interval:5m0s
kvstore-opt:
k8s-sync-timeout:3m0s
k8s-service-proxy-name:
enable-ipv4-masquerade:true
cni-chaining-target:
skip-cnp-status-startup-clean:false
config-sources:config-map:kube-system/cilium-config
mtu:0
bpf-lb-rss-ipv4-src-cidr:
clustermesh-config:/var/lib/cilium/clustermesh/
enable-host-firewall:false
read-cni-conf:
enable-ipv4-egress-gateway:false
allow-icmp-frag-needed:true
cmdref:
enable-endpoint-health-checking:true
hubble-listen-address::4244
max-connected-clusters:255
monitor-queue-size:0
bpf-lb-affinity-map-max:0
enable-masquerade-to-route-source:false
config:
hubble-redact-kafka-apikey:false
enable-remote-node-identity:true
k8s-namespace:kube-system
ipv6-cluster-alloc-cidr:f00d::/64
enable-host-port:false
bpf-policy-map-max:16384
endpoint-bpf-prog-watchdog-interval:30s
http-retry-count:3
tofqdns-enable-dns-compression:true
hubble-redact-enabled:false
k8s-require-ipv4-pod-cidr:false
version:false
policy-queue-size:100
operator-prometheus-serve-addr::9963
kvstore-connectivity-timeout:2m0s
allocator-list-timeout:3m0s
pprof:false
enable-ipsec:false
identity-gc-interval:15m0s
exclude-local-address:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
unmanaged-pod-watcher-interval:15
log-driver:
enable-host-legacy-routing:false
bgp-announce-pod-cidr:false
endpoint-queue-size:25
vtep-cidr:
enable-identity-mark:true
socket-path:/var/run/cilium/cilium.sock
vtep-mask:
bpf-map-dynamic-size-ratio:0.0025
policy-cidr-match-mode:
bpf-lb-algorithm:random
l2-announcements-retry-period:2s
k8s-require-ipv6-pod-cidr:false
bpf-lb-external-clusterip:false
enable-cilium-api-server-access:
enable-vtep:false
local-router-ipv6:
wireguard-persistent-keepalive:0s
tofqdns-dns-reject-response-code:refused
max-internal-timer-delay:0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-gateway-api-secrets-sync:true
proxy-prometheus-port:0
node-port-algorithm:random
state-dir:/var/run/cilium
external-envoy-proxy:true
l2-announcements-lease-duration:15s
labels:
bgp-announce-lb-ip:false
hubble-redact-http-userinfo:true
hubble-socket-path:/var/run/cilium/hubble.sock
policy-trigger-interval:1s
tofqdns-min-ttl:0
http-retry-timeout:0
hubble-redact-http-headers-allow:
bpf-filter-priority:1
enable-health-check-loadbalancer-ip:false
dnsproxy-concurrency-limit:0
enable-l2-announcements:false
proxy-xff-num-trusted-hops-egress:0
agent-labels:
hubble-event-buffer-capacity:4095
bpf-map-event-buffers:
encrypt-interface:
bpf-lb-sock:false
proxy-connect-timeout:2
identity-allocation-mode:crd
enable-ipv4:true
bpf-ct-global-tcp-max:524288
local-max-addr-scope:252
log-system-load:false
agent-liveness-update-interval:1s
cilium-endpoint-gc-interval:5m0s
enable-envoy-config:true
```


#### Policy get

```
:
 [
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-dex-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "http",
                "protocol": "TCP"
              }
            ]
          },
          {
            "ports": [
              {
                "port": "grpc",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-dex-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "0ca9b40f-9a3f-4ecd-bb56-154eebd0bf62",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-repo-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      },
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-application-controller",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-repo-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "44e84fdf-5ef5-4516-8cf8-2e5e1e3f3523",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-application-controller",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchExpressions": [
              {
                "key": "k8s:io.kubernetes.pod.namespace",
                "operator": "Exists"
              }
            ]
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "controller",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-application-controller",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d14d3df5-1c32-43ce-9f4b-9fd13f1cacf6",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {}
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d6baf548-03ff-49f8-93db-5f25fa513dc6",
        "source": "k8s"
      }
    ]
  }
]
Revision: 233

```

