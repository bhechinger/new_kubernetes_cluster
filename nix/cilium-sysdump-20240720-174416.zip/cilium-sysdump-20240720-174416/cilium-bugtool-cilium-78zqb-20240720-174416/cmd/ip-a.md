1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: enp1s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel master public state UP group default qlen 1000
    link/ether 52:54:00:92:19:da brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fe92:19da/64 scope link 
       valid_lft forever preferred_lft forever
3: enp2s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 52:54:00:d6:4c:0f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fed6:4c0f/64 scope link 
       valid_lft forever preferred_lft forever
4: vlan4000@enp2s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master private state UP group default qlen 1000
    link/ether 52:54:00:d6:4c:0f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fed6:4c0f/64 scope link 
       valid_lft forever preferred_lft forever
5: public: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq state UP group default qlen 1000
    link/ether 52:54:00:92:19:da brd ff:ff:ff:ff:ff:ff
    inet 10.22.20.11/24 brd 10.22.20.255 scope global dynamic noprefixroute public
       valid_lft 2852sec preferred_lft 2210sec
    inet6 fe80::5054:ff:fe92:19da/64 scope link 
       valid_lft forever preferred_lft forever
6: private: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq state UP group default qlen 1000
    link/ether 52:54:00:d6:4c:0f brd ff:ff:ff:ff:ff:ff
    inet 10.22.30.11/24 scope global private
       valid_lft forever preferred_lft forever
    inet6 fe80::5054:ff:fed6:4c0f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 16:84:f3:ac:40:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1484:f3ff:feac:408a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:6b:c6:e4:c9:36 brd ff:ff:ff:ff:ff:ff
    inet 10.55.0.64/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::886b:c6ff:fee4:c936/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:04:b1:89:a2:af brd ff:ff:ff:ff:ff:ff link-netns cilium-health
    inet6 fe80::4004:b1ff:fe89:a2af/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc57b410517745@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:2e:90:77:52:98 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::402e:90ff:fe77:5298/64 scope link 
       valid_lft forever preferred_lft forever
