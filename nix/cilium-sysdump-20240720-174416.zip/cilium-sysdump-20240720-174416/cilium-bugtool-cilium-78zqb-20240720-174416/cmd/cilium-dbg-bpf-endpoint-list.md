IP ADDRESS      LOCAL ENDPOINT INFO
10.55.0.129:0   id=92    sec_id=3394  flags=0x0000 ifindex=12  mac=F2:32:FF:33:52:A3 nodemac=42:2E:90:77:52:98   
10.22.30.11:0   (localhost)                                                                                      
10.55.0.64:0    (localhost)                                                                                      
10.55.0.16:0    id=3424  sec_id=4     flags=0x0000 ifindex=10  mac=76:B0:48:7B:0E:68 nodemac=42:04:B1:89:A2:AF   
10.22.20.11:0   (localhost)                                                                                      
