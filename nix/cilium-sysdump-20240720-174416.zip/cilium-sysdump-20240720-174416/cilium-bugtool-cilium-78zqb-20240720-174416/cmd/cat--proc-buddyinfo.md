Node 0, zone      DMA      0      0      0      0      0      0      0      1      0      1      3 
Node 0, zone    DMA32    623    298    262    179     77     57     16     10      4      1      9 
Node 0, zone   Normal     36     52     24     63     66    124     40     17      5      3      4 
