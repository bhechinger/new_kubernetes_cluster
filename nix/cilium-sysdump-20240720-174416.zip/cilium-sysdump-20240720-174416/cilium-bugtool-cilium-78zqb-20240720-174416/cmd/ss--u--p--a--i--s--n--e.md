Total: 694
TCP:   481 (estab 352, closed 98, orphaned 0, timewait 86)

Transport Total     IP        IPv6
RAW	  6         3         3        
UDP	  3         2         1        
TCP	  383       308       75       
INET	  392       313       79       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q Local Address:Port  Peer Address:PortProcess                                                                           
UNCONN 0      0            0.0.0.0:68         0.0.0.0:*    ino:4237 sk:3439 cgroup:unreachable:9d8 <->                                      
UNCONN 0      0          127.0.0.1:39031      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:15608 sk:16145 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  *:546              *:*    ino:4239 sk:16146 cgroup:unreachable:9d8 v6only:0 <->                            
