[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.3.209"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.3.251"
      },
      "ipv6": {}
    },
    "name": "hetzner/worker1",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.3.0/24",
        "enabled": true,
        "ip": "10.22.30.21"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.21"
      },
      {
        "ip": "10.55.3.206"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.4.84"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.4.77"
      },
      "ipv6": {}
    },
    "name": "hetzner/worker2",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.4.0/24",
        "enabled": true,
        "ip": "10.22.30.22"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.22"
      },
      {
        "ip": "10.55.4.66"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.5.109"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.5.68"
      },
      "ipv6": {}
    },
    "name": "hetzner/worker3",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.5.0/24",
        "enabled": true,
        "ip": "10.22.30.23"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.23"
      },
      {
        "ip": "10.55.5.93"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.0.16"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.0.214"
      },
      "ipv6": {}
    },
    "name": "hetzner/master1",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.0.0/24",
        "enabled": true,
        "ip": "10.22.30.11"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.11"
      },
      {
        "ip": "10.55.0.64"
      }
    ],
    "source": "local"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.1.165"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.1.178"
      },
      "ipv6": {}
    },
    "name": "hetzner/master2",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.1.0/24",
        "enabled": true,
        "ip": "10.22.30.12"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.12"
      },
      {
        "ip": "10.55.1.36"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.2.220"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.2.122"
      },
      "ipv6": {}
    },
    "name": "hetzner/master3",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.2.0/24",
        "enabled": true,
        "ip": "10.22.30.13"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.20.13"
      },
      {
        "ip": "10.55.2.229"
      }
    ],
    "source": "custom-resource"
  }
]

