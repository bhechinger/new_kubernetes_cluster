 17:44:17 up  3:25,  0 users,  load average: 0.35, 0.34, 0.29
