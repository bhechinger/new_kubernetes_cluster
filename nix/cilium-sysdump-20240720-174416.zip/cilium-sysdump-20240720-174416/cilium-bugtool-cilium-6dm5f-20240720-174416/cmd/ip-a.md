1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: enp1s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel master public state UP group default qlen 1000
    link/ether 52:54:00:86:ce:9b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fe86:ce9b/64 scope link 
       valid_lft forever preferred_lft forever
3: enp2s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 52:54:00:6e:9a:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fe6e:9aac/64 scope link 
       valid_lft forever preferred_lft forever
4: vlan4000@enp2s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master private state UP group default qlen 1000
    link/ether 52:54:00:6e:9a:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5054:ff:fe6e:9aac/64 scope link 
       valid_lft forever preferred_lft forever
5: public: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq state UP group default qlen 1000
    link/ether 52:54:00:86:ce:9b brd ff:ff:ff:ff:ff:ff
    inet 10.22.20.12/24 brd 10.22.20.255 scope global dynamic noprefixroute public
       valid_lft 3020sec preferred_lft 2353sec
    inet6 fe80::5054:ff:fe86:ce9b/64 scope link 
       valid_lft forever preferred_lft forever
6: private: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq state UP group default qlen 1000
    link/ether 52:54:00:6e:9a:ac brd ff:ff:ff:ff:ff:ff
    inet 10.22.30.12/24 scope global private
       valid_lft forever preferred_lft forever
    inet6 fe80::5054:ff:fe6e:9aac/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:e9:82:00:2b:f9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9ce9:82ff:fe00:2bf9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether be:d8:9d:37:3d:a7 brd ff:ff:ff:ff:ff:ff
    inet 10.55.1.36/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bcd8:9dff:fe37:3da7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:65:c5:64:e9:f6 brd ff:ff:ff:ff:ff:ff link-netns cilium-health
    inet6 fe80::4865:c5ff:fe64:e9f6/64 scope link 
       valid_lft forever preferred_lft forever
