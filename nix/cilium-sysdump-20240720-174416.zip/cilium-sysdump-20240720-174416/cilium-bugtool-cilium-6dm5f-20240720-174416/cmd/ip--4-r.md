default via 10.22.20.1 dev public proto dhcp src 10.22.20.12 metric 1005 
10.22.20.0/24 dev public proto dhcp scope link src 10.22.20.12 metric 1005 
10.22.30.0/24 dev private proto kernel scope link src 10.22.30.12 
10.55.0.0/24 via 10.22.30.11 dev private proto kernel 
10.55.1.0/24 via 10.55.1.36 dev cilium_host proto kernel src 10.55.1.36 
10.55.1.36 dev cilium_host proto kernel scope link 
10.55.2.0/24 via 10.22.30.13 dev private proto kernel 
10.55.3.0/24 via 10.22.30.21 dev private proto kernel 
10.55.4.0/24 via 10.22.30.22 dev private proto kernel 
10.55.5.0/24 via 10.22.30.23 dev private proto kernel 
