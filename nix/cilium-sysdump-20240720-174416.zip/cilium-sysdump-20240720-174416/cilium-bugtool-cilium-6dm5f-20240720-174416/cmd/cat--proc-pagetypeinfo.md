Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      0      0      0      0      0      0      0      1      0      0      0 
Node    0, zone      DMA, type      Movable      0      0      0      0      0      0      0      0      0      1      3 
Node    0, zone      DMA, type  Reclaimable      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type    Unmovable    116     92     34     31      4      1      1      3      1      0      1 
Node    0, zone    DMA32, type      Movable   1212    221    108      1      1      2      2      1      0      2      8 
Node    0, zone    DMA32, type  Reclaimable      3      4      7      6      5      4      1      1      0      2      1 
Node    0, zone    DMA32, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable    110     79     48     61     12      8      3      5      2      1      0 
Node    0, zone   Normal, type      Movable      1      0      1      0      0     22     32     18     14      9      6 
Node    0, zone   Normal, type  Reclaimable      1      0      1      0      1      0      1      0      1      0      0 
Node    0, zone   Normal, type   HighAtomic      1      0      2      1      0      1      0      1      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA            1            7            0            0            0            0 
Node 0, zone    DMA32           20          960           36            0            0            0 
Node 0, zone   Normal           88          901           34            1            0            0 
