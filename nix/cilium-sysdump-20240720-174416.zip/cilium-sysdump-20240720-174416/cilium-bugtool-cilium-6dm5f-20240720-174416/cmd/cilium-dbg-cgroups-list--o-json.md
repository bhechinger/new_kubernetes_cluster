[
  {
    "containers": [
      {
        "cgroup-id": 6689,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice/cri-containerd-d418631439f23b226ceef06ef9c8423b4b16fafde100299f43ab160dae252fe6.scope"
      },
      {
        "cgroup-id": 6615,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice/cri-containerd-5d7a4f01caf3d2a01d8e0ab150b714646904cda68c9806fd7547623674c32e20.scope"
      }
    ],
    "ips": [
      "10.22.30.12"
    ],
    "name": "cilium-6dm5f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 5961,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4eb2286_6713_4da7_9d36_c71f9daf12ff.slice/cri-containerd-b0040c1471ca448011290e11015071548db0d5d89a58788b13506b44793341c7.scope"
      }
    ],
    "ips": [
      "10.22.30.12"
    ],
    "name": "cilium-envoy-b9lsm",
    "namespace": "kube-system"
  }
]

