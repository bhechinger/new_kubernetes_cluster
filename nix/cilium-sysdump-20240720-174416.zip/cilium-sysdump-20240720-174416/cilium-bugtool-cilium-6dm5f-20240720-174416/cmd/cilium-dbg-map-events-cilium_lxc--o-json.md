{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.20.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:25:17.734Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.30.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:25:17.735Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:25:17.735Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:25:20.915Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:39.010Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:40.829Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:41.830Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:42.831Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:43.831Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:44.833Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:32:45.833Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:26.102Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:27.538Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:28.539Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:29.540Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:30.540Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:31.541Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:32.541Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:33.542Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T14:38:50.414Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:39.506Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:40.505Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:35:41.506Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T15:50:39.604Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:48.091Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:49.091Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.1.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-07-20T16:08:50.092Z",
  "value": "id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6"
}

