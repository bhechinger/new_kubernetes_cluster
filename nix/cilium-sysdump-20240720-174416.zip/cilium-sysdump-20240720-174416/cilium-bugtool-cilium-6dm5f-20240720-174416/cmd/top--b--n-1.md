top - 17:44:17 up  3:21,  0 users,  load average: 0.05, 0.18, 0.17
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 24.1 sy,  0.0 ni, 55.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3921.4 total,    156.3 free,    951.3 used,   2813.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2689.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3741 root      20   0 1229568   4352   3712 S   6.7   0.1   0:00.01 gops
   3745 root      20   0 1229568   4352   3712 S   6.7   0.1   0:00.01 gops
      1 root      20   0 1333984 146664  75520 S   0.0   3.7   2:01.63 cilium-+
    133 root      20   0 1229772   6912   3968 S   0.0   0.2   0:00.36 cilium-+
   3705 root      20   0 1241264  16256  11520 S   0.0   0.4   0:00.04 cilium-+
   3742 root      20   0    7184   3200   2816 R   0.0   0.1   0:00.00 top
   3776 root      20   0 1229568   4480   3968 S   0.0   0.1   0:00.00 gops
