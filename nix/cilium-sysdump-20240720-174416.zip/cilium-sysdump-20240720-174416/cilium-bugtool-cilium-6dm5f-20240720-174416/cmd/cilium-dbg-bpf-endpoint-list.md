IP ADDRESS      LOCAL ENDPOINT INFO
10.22.20.12:0   (localhost)                                                                                      
10.22.30.12:0   (localhost)                                                                                      
10.55.1.165:0   id=2406  sec_id=4     flags=0x0000 ifindex=10  mac=76:2D:B1:30:2B:E8 nodemac=4A:65:C5:64:E9:F6   
10.55.1.36:0    (localhost)                                                                                      
