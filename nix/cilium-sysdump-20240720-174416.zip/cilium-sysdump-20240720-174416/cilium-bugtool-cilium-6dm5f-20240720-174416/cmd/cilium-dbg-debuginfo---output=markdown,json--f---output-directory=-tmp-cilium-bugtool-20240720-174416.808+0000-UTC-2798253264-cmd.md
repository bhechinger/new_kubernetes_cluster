markdown output at /tmp/cilium-bugtool-20240720-174416.808+0000-UTC-2798253264/cmd/cilium-debuginfo-20240720-174447.546+0000-UTC.md
json output at /tmp/cilium-bugtool-20240720-174416.808+0000-UTC-2798253264/cmd/cilium-debuginfo-20240720-174447.546+0000-UTC.json
