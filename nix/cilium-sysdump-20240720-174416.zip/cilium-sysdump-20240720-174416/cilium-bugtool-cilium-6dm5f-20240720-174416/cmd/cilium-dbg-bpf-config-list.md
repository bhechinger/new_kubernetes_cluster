KEY             VALUE
AgentLiveness   12133957688397
UTimeOffset     3362276082031250
