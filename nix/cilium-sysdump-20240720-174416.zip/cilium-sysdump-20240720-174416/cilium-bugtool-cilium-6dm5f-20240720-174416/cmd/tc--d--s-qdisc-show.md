qdisc noqueue 0: dev lo root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq_codel 0: dev enp1s0 root refcnt 2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 38728681 bytes 139350 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 3028 drop_overlimit 0 new_flow_count 21 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc fq_codel 0: dev enp2s0 root refcnt 2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 165315085 bytes 929808 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 256 drop_overlimit 0 new_flow_count 20 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc noqueue 0: dev vlan4000 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq 8003: dev public root refcnt 2 limit 10000p flow_limit 100p buckets 32768 orphan_mask 1023 quantum 3028b initial_quantum 15140b low_rate_threshold 550Kbit refill_delay 40ms timer_slack 10us horizon 2s horizon_cap 
 Sent 33209193 bytes 82196 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  flows 1 (inactive 1 throttled 0)
  gc 0 highprio 0 throttled 33 latency 15.2us
qdisc clsact ffff: dev public parent ffff:fff1 
 Sent 48390600 bytes 187186 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq 8006: dev private root refcnt 2 limit 10000p flow_limit 100p buckets 32768 orphan_mask 1023 quantum 3028b initial_quantum 15140b low_rate_threshold 550Kbit refill_delay 40ms timer_slack 10us horizon 2s horizon_cap 
 Sent 163767649 bytes 922001 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  flows 4 (inactive 4 throttled 0)
  gc 0 highprio 0 throttled 155 latency 17.3us
qdisc clsact ffff: dev private parent ffff:fff1 
 Sent 309339310 bytes 1793266 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_net root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
 Sent 13984 bytes 268 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_host root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
 Sent 175420 bytes 2068 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc_health root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
 Sent 462396 bytes 7111 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
