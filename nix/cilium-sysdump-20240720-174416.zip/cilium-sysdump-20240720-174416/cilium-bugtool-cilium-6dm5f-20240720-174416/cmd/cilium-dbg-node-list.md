Name              IPv4 Address   Endpoint CIDR   IPv6 Address   Endpoint CIDR   Source
hetzner/master1   10.22.30.11    10.55.0.0/24                                   custom-resource
hetzner/master2   10.22.30.12    10.55.1.0/24                                   local
hetzner/master3   10.22.30.13    10.55.2.0/24                                   custom-resource
hetzner/worker1   10.22.30.21    10.55.3.0/24                                   custom-resource
hetzner/worker2   10.22.30.22    10.55.4.0/24                                   custom-resource
hetzner/worker3   10.22.30.23    10.55.5.0/24                                   custom-resource
