2024-07-20T14:22:34,000000+00:00 Linux version 6.8.12 (nixbld@localhost) (gcc (GCC) 13.3.0, GNU ld (GNU Binutils) 2.42) #1-NixOS SMP PREEMPT_DYNAMIC Thu May 30 07:49:53 UTC 2024
2024-07-20T14:22:34,000000+00:00 Command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/1f0bkfb0n227ifpvzjyzzgmh710wd402-nixos-system-master2-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:22:34,000000+00:00 BIOS-provided physical RAM map:
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x000000007ffdbfff] usable
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x000000007ffdc000-0x000000007fffffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x00000000b0000000-0x00000000bfffffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x00000000fed1c000-0x00000000fed1ffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2024-07-20T14:22:34,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000017fffffff] usable
2024-07-20T14:22:34,000000+00:00 NX (Execute Disable) protection: active
2024-07-20T14:22:34,000000+00:00 APIC: Static calls initialized
2024-07-20T14:22:34,000000+00:00 SMBIOS 2.8 present.
2024-07-20T14:22:34,000000+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 1.15.0-1 04/01/2014
2024-07-20T14:22:34,000000+00:00 Hypervisor detected: KVM
2024-07-20T14:22:34,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2024-07-20T14:22:34,000000+00:00 kvm-clock: using sched offset of 550046579657 cycles
2024-07-20T14:22:34,000002+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2024-07-20T14:22:34,000003+00:00 tsc: Detected 3593.200 MHz processor
2024-07-20T14:22:34,000815+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2024-07-20T14:22:34,000817+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2024-07-20T14:22:34,000821+00:00 last_pfn = 0x180000 max_arch_pfn = 0x400000000
2024-07-20T14:22:34,000844+00:00 MTRR map: 4 entries (3 fixed + 1 variable; max 19), built from 8 variable MTRRs
2024-07-20T14:22:34,000846+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2024-07-20T14:22:34,000877+00:00 last_pfn = 0x7ffdc max_arch_pfn = 0x400000000
2024-07-20T14:22:34,002827+00:00 found SMP MP-table at [mem 0x000f5b80-0x000f5b8f]
2024-07-20T14:22:34,002931+00:00 RAMDISK: [mem 0x3693b000-0x37494fff]
2024-07-20T14:22:34,002936+00:00 ACPI: Early table checksum verification disabled
2024-07-20T14:22:34,002939+00:00 ACPI: RSDP 0x00000000000F5970 000014 (v00 BOCHS )
2024-07-20T14:22:34,002945+00:00 ACPI: RSDT 0x000000007FFE2842 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002950+00:00 ACPI: FACP 0x000000007FFE2632 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002954+00:00 ACPI: DSDT 0x000000007FFE0040 0025F2 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002956+00:00 ACPI: FACS 0x000000007FFE0000 000040
2024-07-20T14:22:34,002958+00:00 ACPI: APIC 0x000000007FFE2726 000080 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002960+00:00 ACPI: HPET 0x000000007FFE27A6 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002962+00:00 ACPI: MCFG 0x000000007FFE27DE 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002963+00:00 ACPI: WAET 0x000000007FFE281A 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2024-07-20T14:22:34,002965+00:00 ACPI: Reserving FACP table memory at [mem 0x7ffe2632-0x7ffe2725]
2024-07-20T14:22:34,002966+00:00 ACPI: Reserving DSDT table memory at [mem 0x7ffe0040-0x7ffe2631]
2024-07-20T14:22:34,002967+00:00 ACPI: Reserving FACS table memory at [mem 0x7ffe0000-0x7ffe003f]
2024-07-20T14:22:34,002968+00:00 ACPI: Reserving APIC table memory at [mem 0x7ffe2726-0x7ffe27a5]
2024-07-20T14:22:34,002968+00:00 ACPI: Reserving HPET table memory at [mem 0x7ffe27a6-0x7ffe27dd]
2024-07-20T14:22:34,002969+00:00 ACPI: Reserving MCFG table memory at [mem 0x7ffe27de-0x7ffe2819]
2024-07-20T14:22:34,002969+00:00 ACPI: Reserving WAET table memory at [mem 0x7ffe281a-0x7ffe2841]
2024-07-20T14:22:34,003113+00:00 No NUMA configuration found
2024-07-20T14:22:34,003113+00:00 Faking a node at [mem 0x0000000000000000-0x000000017fffffff]
2024-07-20T14:22:34,003115+00:00 NODE_DATA(0) allocated [mem 0x17fffa000-0x17fffffff]
2024-07-20T14:22:34,003133+00:00 Zone ranges:
2024-07-20T14:22:34,003134+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2024-07-20T14:22:34,003135+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2024-07-20T14:22:34,003136+00:00   Normal   [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:22:34,003137+00:00   Device   empty
2024-07-20T14:22:34,003138+00:00 Movable zone start for each node
2024-07-20T14:22:34,003139+00:00 Early memory node ranges
2024-07-20T14:22:34,003139+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2024-07-20T14:22:34,003140+00:00   node   0: [mem 0x0000000000100000-0x000000007ffdbfff]
2024-07-20T14:22:34,003141+00:00   node   0: [mem 0x0000000100000000-0x000000017fffffff]
2024-07-20T14:22:34,003142+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000017fffffff]
2024-07-20T14:22:34,003148+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2024-07-20T14:22:34,003167+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2024-07-20T14:22:34,008709+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2024-07-20T14:22:34,009328+00:00 ACPI: PM-Timer IO Port: 0x608
2024-07-20T14:22:34,009340+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2024-07-20T14:22:34,009365+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2024-07-20T14:22:34,009368+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2024-07-20T14:22:34,009369+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2024-07-20T14:22:34,009370+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2024-07-20T14:22:34,009371+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2024-07-20T14:22:34,009372+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2024-07-20T14:22:34,009375+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2024-07-20T14:22:34,009375+00:00 ACPI: HPET id: 0x8086a201 base: 0xfed00000
2024-07-20T14:22:34,009380+00:00 smpboot: Allowing 2 CPUs, 0 hotplug CPUs
2024-07-20T14:22:34,009395+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2024-07-20T14:22:34,009422+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2024-07-20T14:22:34,009424+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2024-07-20T14:22:34,009425+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2024-07-20T14:22:34,009425+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2024-07-20T14:22:34,009426+00:00 PM: hibernation: Registered nosave memory: [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:22:34,009427+00:00 PM: hibernation: Registered nosave memory: [mem 0x80000000-0xafffffff]
2024-07-20T14:22:34,009427+00:00 PM: hibernation: Registered nosave memory: [mem 0xb0000000-0xbfffffff]
2024-07-20T14:22:34,009428+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfed1bfff]
2024-07-20T14:22:34,009429+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed1c000-0xfed1ffff]
2024-07-20T14:22:34,009429+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed20000-0xfeffbfff]
2024-07-20T14:22:34,009430+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2024-07-20T14:22:34,009431+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2024-07-20T14:22:34,009431+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2024-07-20T14:22:34,009433+00:00 [mem 0xc0000000-0xfed1bfff] available for PCI devices
2024-07-20T14:22:34,009434+00:00 Booting paravirtualized kernel on KVM
2024-07-20T14:22:34,009436+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2024-07-20T14:22:34,013479+00:00 setup_percpu: NR_CPUS:384 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2024-07-20T14:22:34,013707+00:00 percpu: Embedded 84 pages/cpu s221184 r8192 d114688 u1048576
2024-07-20T14:22:34,013711+00:00 pcpu-alloc: s221184 r8192 d114688 u1048576 alloc=1*2097152
2024-07-20T14:22:34,013713+00:00 pcpu-alloc: [0] 0 1 
2024-07-20T14:22:34,013728+00:00 kvm-guest: PV spinlocks disabled, no host support
2024-07-20T14:22:34,013729+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage init=/nix/store/1f0bkfb0n227ifpvzjyzzgmh710wd402-nixos-system-master2-24.11.20240716.ad0b5ee/init mitigations=off loglevel=4
2024-07-20T14:22:34,013774+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage", will be passed to user space.
2024-07-20T14:22:34,014146+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-07-20T14:22:34,014356+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-07-20T14:22:34,014380+00:00 Fallback order for Node 0: 0 
2024-07-20T14:22:34,014383+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1031900
2024-07-20T14:22:34,014383+00:00 Policy zone: Normal
2024-07-20T14:22:34,014586+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2024-07-20T14:22:34,014591+00:00 software IO TLB: area num 2.
2024-07-20T14:22:34,033491+00:00 Memory: 3997092K/4193768K available (16384K kernel code, 2371K rwdata, 11016K rodata, 3164K init, 4396K bss, 196416K reserved, 0K cma-reserved)
2024-07-20T14:22:34,056211+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-07-20T14:22:34,056319+00:00 ftrace: allocating 43348 entries in 170 pages
2024-07-20T14:22:34,062299+00:00 ftrace: allocated 170 pages with 4 groups
2024-07-20T14:22:34,062858+00:00 Dynamic Preempt: voluntary
2024-07-20T14:22:34,062967+00:00 rcu: Preemptible hierarchical RCU implementation.
2024-07-20T14:22:34,062968+00:00 rcu: 	RCU event tracing is enabled.
2024-07-20T14:22:34,062968+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=384 to nr_cpu_ids=2.
2024-07-20T14:22:34,062969+00:00 	Trampoline variant of Tasks RCU enabled.
2024-07-20T14:22:34,062970+00:00 	Rude variant of Tasks RCU enabled.
2024-07-20T14:22:34,062970+00:00 	Tracing variant of Tasks RCU enabled.
2024-07-20T14:22:34,062971+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2024-07-20T14:22:34,062971+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-07-20T14:22:34,065227+00:00 NR_IRQS: 24832, nr_irqs: 440, preallocated irqs: 16
2024-07-20T14:22:34,065429+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-07-20T14:22:34,065495+00:00 kfence: initialized - using 2097152 bytes for 255 objects at 0x(____ptrval____)-0x(____ptrval____)
2024-07-20T14:22:34,070120+00:00 Console: colour VGA+ 80x25
2024-07-20T14:22:34,070122+00:00 printk: legacy console [tty0] enabled
2024-07-20T14:22:34,070359+00:00 ACPI: Core revision 20230628
2024-07-20T14:22:34,070508+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604467 ns
2024-07-20T14:22:34,070574+00:00 APIC: Switch to symmetric I/O mode setup
2024-07-20T14:22:34,070691+00:00 x2apic enabled
2024-07-20T14:22:34,070855+00:00 APIC: Switched APIC routing to: physical x2apic
2024-07-20T14:22:34,071537+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2024-07-20T14:22:34,071552+00:00 tsc: Marking TSC unstable due to TSCs unsynchronized
2024-07-20T14:22:34,071555+00:00 Calibrating delay loop (skipped) preset value.. 7186.40 BogoMIPS (lpj=3593200)
2024-07-20T14:22:34,072634+00:00 process: using AMD E400 aware idle routine
2024-07-20T14:22:34,072637+00:00 Last level iTLB entries: 4KB 512, 2MB 255, 4MB 127
2024-07-20T14:22:34,072638+00:00 Last level dTLB entries: 4KB 512, 2MB 255, 4MB 127, 1GB 0
2024-07-20T14:22:34,072643+00:00 x86/fpu: x87 FPU will use FXSAVE
2024-07-20T14:22:34,088994+00:00 Freeing SMP alternatives memory: 36K
2024-07-20T14:22:34,088998+00:00 pid_max: default: 32768 minimum: 301
2024-07-20T14:22:34,089449+00:00 LSM: initializing lsm=capability,landlock,yama,selinux,bpf,integrity
2024-07-20T14:22:34,089639+00:00 landlock: Up and running.
2024-07-20T14:22:34,089640+00:00 Yama: becoming mindful.
2024-07-20T14:22:34,089643+00:00 SELinux:  Initializing.
2024-07-20T14:22:34,089824+00:00 LSM support for eBPF active
2024-07-20T14:22:34,089976+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:22:34,089981+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-07-20T14:22:34,192520+00:00 smpboot: CPU0: AMD QEMU Virtual CPU version 2.5+ (family: 0xf, model: 0x6b, stepping: 0x1)
2024-07-20T14:22:34,192553+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:22:34,192553+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:22:34,192553+00:00 RCU Tasks Trace: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1.
2024-07-20T14:22:34,192553+00:00 Performance Events: AMD PMU driver.
2024-07-20T14:22:34,192553+00:00 ... version:                0
2024-07-20T14:22:34,192553+00:00 ... bit width:              48
2024-07-20T14:22:34,192553+00:00 ... generic registers:      4
2024-07-20T14:22:34,192553+00:00 ... value mask:             0000ffffffffffff
2024-07-20T14:22:34,192553+00:00 ... max period:             00007fffffffffff
2024-07-20T14:22:34,192553+00:00 ... fixed-purpose events:   0
2024-07-20T14:22:34,192553+00:00 ... event mask:             000000000000000f
2024-07-20T14:22:34,192553+00:00 signal: max sigframe size: 1440
2024-07-20T14:22:34,192553+00:00 rcu: Hierarchical SRCU implementation.
2024-07-20T14:22:34,192553+00:00 rcu: 	Max phase no-delay instances is 400.
2024-07-20T14:22:34,192553+00:00 smp: Bringing up secondary CPUs ...
2024-07-20T14:22:34,192553+00:00 smpboot: x86: Booting SMP configuration:
2024-07-20T14:22:34,192553+00:00 .... node  #0, CPUs:      #1
2024-07-20T14:22:34,192601+00:00 smp: Brought up 1 node, 2 CPUs
2024-07-20T14:22:34,192601+00:00 smpboot: Max logical packages: 2
2024-07-20T14:22:34,192601+00:00 smpboot: Total of 2 processors activated (14372.80 BogoMIPS)
2024-07-20T14:22:34,192774+00:00 devtmpfs: initialized
2024-07-20T14:22:34,192774+00:00 x86/mm: Memory block size: 128MB
2024-07-20T14:22:34,193814+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2024-07-20T14:22:34,193814+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-07-20T14:22:34,193814+00:00 pinctrl core: initialized pinctrl subsystem
2024-07-20T14:22:34,193814+00:00 PM: RTC time: 14:22:35, date: 2024-07-20
2024-07-20T14:22:34,194249+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-07-20T14:22:34,194623+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-07-20T14:22:34,194868+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-07-20T14:22:34,194904+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-07-20T14:22:34,194916+00:00 audit: initializing netlink subsys (disabled)
2024-07-20T14:22:34,194926+00:00 audit: type=2000 audit(1721485355.370:1): state=initialized audit_enabled=0 res=1
2024-07-20T14:22:34,194926+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2024-07-20T14:22:34,194926+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-07-20T14:22:34,194926+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-07-20T14:22:34,194926+00:00 cpuidle: using governor menu
2024-07-20T14:22:34,194926+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-07-20T14:22:34,194926+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] (base 0xb0000000) for domain 0000 [bus 00-ff]
2024-07-20T14:22:34,194926+00:00 PCI: ECAM [mem 0xb0000000-0xbfffffff] reserved as E820 entry
2024-07-20T14:22:34,194926+00:00 PCI: Using configuration type 1 for base access
2024-07-20T14:22:34,194963+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2024-07-20T14:22:34,212636+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-07-20T14:22:34,212636+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2024-07-20T14:22:34,212695+00:00 ACPI: Added _OSI(Module Device)
2024-07-20T14:22:34,212695+00:00 ACPI: Added _OSI(Processor Device)
2024-07-20T14:22:34,212695+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-07-20T14:22:34,212695+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-07-20T14:22:34,213888+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-07-20T14:22:34,214082+00:00 ACPI: _OSC evaluation for CPUs failed, trying _PDC
2024-07-20T14:22:34,214082+00:00 ACPI: Interpreter enabled
2024-07-20T14:22:34,214082+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2024-07-20T14:22:34,214082+00:00 ACPI: Using IOAPIC for interrupt routing
2024-07-20T14:22:34,214082+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2024-07-20T14:22:34,214082+00:00 PCI: Using E820 reservations for host bridge windows
2024-07-20T14:22:34,214082+00:00 ACPI: Enabled 2 GPEs in block 00 to 3F
2024-07-20T14:22:34,215638+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2024-07-20T14:22:34,215643+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-07-20T14:22:34,215664+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR]
2024-07-20T14:22:34,215691+00:00 acpi PNP0A08:00: _OSC: OS now controls [PME PCIeCapability]
2024-07-20T14:22:34,215800+00:00 PCI host bridge to bus 0000:00
2024-07-20T14:22:34,215801+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2024-07-20T14:22:34,215802+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2024-07-20T14:22:34,215803+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2024-07-20T14:22:34,215804+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xafffffff window]
2024-07-20T14:22:34,215805+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:22:34,215806+00:00 pci_bus 0000:00: root bus resource [mem 0x180000000-0x97fffffff window]
2024-07-20T14:22:34,215807+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2024-07-20T14:22:34,215839+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2024-07-20T14:22:34,216076+00:00 pci 0000:00:01.0: [1013:00b8] type 00 class 0x030000 conventional PCI endpoint
2024-07-20T14:22:34,217555+00:00 pci 0000:00:01.0: BAR 0 [mem 0xfa000000-0xfbffffff pref]
2024-07-20T14:22:34,218555+00:00 pci 0000:00:01.0: BAR 1 [mem 0xfea10000-0xfea10fff]
2024-07-20T14:22:34,225162+00:00 pci 0000:00:01.0: ROM [mem 0xfea00000-0xfea0ffff pref]
2024-07-20T14:22:34,225200+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2024-07-20T14:22:34,225364+00:00 pci 0000:00:02.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,227178+00:00 pci 0000:00:02.0: BAR 0 [mem 0xfea11000-0xfea11fff]
2024-07-20T14:22:34,230559+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:22:34,230580+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:22:34,231071+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:22:34,231614+00:00 pci 0000:00:02.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,233019+00:00 pci 0000:00:02.1: BAR 0 [mem 0xfea12000-0xfea12fff]
2024-07-20T14:22:34,234559+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:22:34,234580+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:22:34,235084+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:22:34,235758+00:00 pci 0000:00:02.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,236997+00:00 pci 0000:00:02.2: BAR 0 [mem 0xfea13000-0xfea13fff]
2024-07-20T14:22:34,239110+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:22:34,240565+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:22:34,241570+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:22:34,241938+00:00 pci 0000:00:02.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,242971+00:00 pci 0000:00:02.3: BAR 0 [mem 0xfea14000-0xfea14fff]
2024-07-20T14:22:34,244992+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:22:34,245012+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:22:34,245496+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:22:34,245914+00:00 pci 0000:00:02.4: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,247012+00:00 pci 0000:00:02.4: BAR 0 [mem 0xfea15000-0xfea15fff]
2024-07-20T14:22:34,249010+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:22:34,249030+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:22:34,249570+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:22:34,249936+00:00 pci 0000:00:02.5: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,251018+00:00 pci 0000:00:02.5: BAR 0 [mem 0xfea16000-0xfea16fff]
2024-07-20T14:22:34,253986+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:22:34,254007+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:22:34,254570+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:22:34,254931+00:00 pci 0000:00:02.6: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,255986+00:00 pci 0000:00:02.6: BAR 0 [mem 0xfea17000-0xfea17fff]
2024-07-20T14:22:34,257977+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:22:34,257997+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:22:34,258468+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:22:34,258856+00:00 pci 0000:00:02.7: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,259988+00:00 pci 0000:00:02.7: BAR 0 [mem 0xfea18000-0xfea18fff]
2024-07-20T14:22:34,261560+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:22:34,261583+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:22:34,262149+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:22:34,264593+00:00 pci 0000:00:03.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2024-07-20T14:22:34,266391+00:00 pci 0000:00:03.0: BAR 0 [mem 0xfea19000-0xfea19fff]
2024-07-20T14:22:34,267985+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:22:34,268005+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:22:34,268571+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:22:34,269015+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2024-07-20T14:22:34,269240+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2024-07-20T14:22:34,269364+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2024-07-20T14:22:34,273554+00:00 pci 0000:00:1f.2: BAR 4 [io  0xc040-0xc05f]
2024-07-20T14:22:34,274369+00:00 pci 0000:00:1f.2: BAR 5 [mem 0xfea1a000-0xfea1afff]
2024-07-20T14:22:34,275722+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2024-07-20T14:22:34,278175+00:00 pci 0000:00:1f.3: BAR 4 [io  0x0700-0x073f]
2024-07-20T14:22:34,279441+00:00 acpiphp: Slot [0] registered
2024-07-20T14:22:34,279613+00:00 pci 0000:01:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:22:34,280949+00:00 pci 0000:01:00.0: BAR 1 [mem 0xfe880000-0xfe880fff]
2024-07-20T14:22:34,283554+00:00 pci 0000:01:00.0: BAR 4 [mem 0xfd000000-0xfd003fff 64bit pref]
2024-07-20T14:22:34,284365+00:00 pci 0000:01:00.0: ROM [mem 0xfe800000-0xfe87ffff pref]
2024-07-20T14:22:34,285184+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:22:34,286569+00:00 acpiphp: Slot [0-1] registered
2024-07-20T14:22:34,287629+00:00 pci 0000:02:00.0: [1af4:1041] type 00 class 0x020000 PCIe Endpoint
2024-07-20T14:22:34,289961+00:00 pci 0000:02:00.0: BAR 1 [mem 0xfe680000-0xfe680fff]
2024-07-20T14:22:34,292365+00:00 pci 0000:02:00.0: BAR 4 [mem 0xfce00000-0xfce03fff 64bit pref]
2024-07-20T14:22:34,292944+00:00 pci 0000:02:00.0: ROM [mem 0xfe600000-0xfe67ffff pref]
2024-07-20T14:22:34,293916+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:22:34,294506+00:00 acpiphp: Slot [0-2] registered
2024-07-20T14:22:34,294581+00:00 pci 0000:03:00.0: [1b36:000d] type 00 class 0x0c0330 PCIe Endpoint
2024-07-20T14:22:34,295042+00:00 pci 0000:03:00.0: BAR 0 [mem 0xfe400000-0xfe403fff 64bit]
2024-07-20T14:22:34,297462+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:22:34,298122+00:00 acpiphp: Slot [0-3] registered
2024-07-20T14:22:34,298194+00:00 pci 0000:04:00.0: [1af4:1043] type 00 class 0x078000 PCIe Endpoint
2024-07-20T14:22:34,300974+00:00 pci 0000:04:00.0: BAR 1 [mem 0xfe200000-0xfe200fff]
2024-07-20T14:22:34,303347+00:00 pci 0000:04:00.0: BAR 4 [mem 0xfca00000-0xfca03fff 64bit pref]
2024-07-20T14:22:34,304948+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:22:34,305573+00:00 acpiphp: Slot [0-4] registered
2024-07-20T14:22:34,305646+00:00 pci 0000:05:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:22:34,306983+00:00 pci 0000:05:00.0: BAR 1 [mem 0xfe000000-0xfe000fff]
2024-07-20T14:22:34,309555+00:00 pci 0000:05:00.0: BAR 4 [mem 0xfc800000-0xfc803fff 64bit pref]
2024-07-20T14:22:34,313197+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:22:34,313644+00:00 acpiphp: Slot [0-5] registered
2024-07-20T14:22:34,313719+00:00 pci 0000:06:00.0: [1af4:1042] type 00 class 0x010000 PCIe Endpoint
2024-07-20T14:22:34,315339+00:00 pci 0000:06:00.0: BAR 1 [mem 0xfde00000-0xfde00fff]
2024-07-20T14:22:34,317957+00:00 pci 0000:06:00.0: BAR 4 [mem 0xfc600000-0xfc603fff 64bit pref]
2024-07-20T14:22:34,319251+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:22:34,319892+00:00 acpiphp: Slot [0-6] registered
2024-07-20T14:22:34,319973+00:00 pci 0000:07:00.0: [1af4:1045] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:22:34,324754+00:00 pci 0000:07:00.0: BAR 4 [mem 0xfc400000-0xfc403fff 64bit pref]
2024-07-20T14:22:34,325829+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:22:34,326415+00:00 acpiphp: Slot [0-7] registered
2024-07-20T14:22:34,326491+00:00 pci 0000:08:00.0: [1af4:1044] type 00 class 0x00ff00 PCIe Endpoint
2024-07-20T14:22:34,328554+00:00 pci 0000:08:00.0: BAR 4 [mem 0xfc200000-0xfc203fff 64bit pref]
2024-07-20T14:22:34,329695+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:22:34,330277+00:00 acpiphp: Slot [0-8] registered
2024-07-20T14:22:34,330286+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:22:34,336775+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2024-07-20T14:22:34,336816+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2024-07-20T14:22:34,336850+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2024-07-20T14:22:34,336885+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2024-07-20T14:22:34,336921+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2024-07-20T14:22:34,336960+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2024-07-20T14:22:34,336993+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2024-07-20T14:22:34,337027+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2024-07-20T14:22:34,337042+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2024-07-20T14:22:34,337046+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2024-07-20T14:22:34,337050+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2024-07-20T14:22:34,337053+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2024-07-20T14:22:34,337057+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2024-07-20T14:22:34,337061+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2024-07-20T14:22:34,337065+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2024-07-20T14:22:34,337068+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2024-07-20T14:22:34,337205+00:00 iommu: Default domain type: Translated
2024-07-20T14:22:34,337206+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2024-07-20T14:22:34,337233+00:00 ACPI: bus type USB registered
2024-07-20T14:22:34,337241+00:00 usbcore: registered new interface driver usbfs
2024-07-20T14:22:34,337246+00:00 usbcore: registered new interface driver hub
2024-07-20T14:22:34,337250+00:00 usbcore: registered new device driver usb
2024-07-20T14:22:34,337782+00:00 NetLabel: Initializing
2024-07-20T14:22:34,337783+00:00 NetLabel:  domain hash size = 128
2024-07-20T14:22:34,337783+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-07-20T14:22:34,337796+00:00 NetLabel:  unlabeled traffic allowed by default
2024-07-20T14:22:34,337797+00:00 PCI: Using ACPI for IRQ routing
2024-07-20T14:22:34,366197+00:00 PCI: pci_cache_line_size set to 64 bytes
2024-07-20T14:22:34,366374+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2024-07-20T14:22:34,366375+00:00 e820: reserve RAM buffer [mem 0x7ffdc000-0x7fffffff]
2024-07-20T14:22:34,366394+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2024-07-20T14:22:34,366394+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2024-07-20T14:22:34,366394+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2024-07-20T14:22:34,366394+00:00 vgaarb: loaded
2024-07-20T14:22:34,366394+00:00 hpet: 3 channels of 0 reserved for per-cpu timers
2024-07-20T14:22:34,366394+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2024-07-20T14:22:34,366394+00:00 hpet0: 3 comparators, 64-bit 100.000000 MHz counter
2024-07-20T14:22:34,370595+00:00 clocksource: Switched to clocksource kvm-clock
2024-07-20T14:22:34,371412+00:00 VFS: Disk quotas dquot_6.6.0
2024-07-20T14:22:34,371416+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-07-20T14:22:34,371460+00:00 pnp: PnP ACPI init
2024-07-20T14:22:34,371559+00:00 system 00:04: [mem 0xb0000000-0xbfffffff window] has been reserved
2024-07-20T14:22:34,371671+00:00 pnp: PnP ACPI: found 5 devices
2024-07-20T14:22:34,378285+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2024-07-20T14:22:34,378421+00:00 NET: Registered PF_INET protocol family
2024-07-20T14:22:34,378480+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-07-20T14:22:34,386833+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-07-20T14:22:34,386846+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-07-20T14:22:34,386858+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-07-20T14:22:34,386989+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-07-20T14:22:34,387238+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-07-20T14:22:34,387308+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-07-20T14:22:34,387335+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:22:34,387363+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-07-20T14:22:34,387430+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-07-20T14:22:34,387436+00:00 NET: Registered PF_XDP protocol family
2024-07-20T14:22:34,387441+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2024-07-20T14:22:34,387444+00:00 pci 0000:00:02.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2024-07-20T14:22:34,387446+00:00 pci 0000:00:02.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2024-07-20T14:22:34,387447+00:00 pci 0000:00:02.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2024-07-20T14:22:34,387448+00:00 pci 0000:00:02.4: bridge window [io  0x1000-0x0fff] to [bus 05] add_size 1000
2024-07-20T14:22:34,387449+00:00 pci 0000:00:02.5: bridge window [io  0x1000-0x0fff] to [bus 06] add_size 1000
2024-07-20T14:22:34,387451+00:00 pci 0000:00:02.6: bridge window [io  0x1000-0x0fff] to [bus 07] add_size 1000
2024-07-20T14:22:34,387452+00:00 pci 0000:00:02.7: bridge window [io  0x1000-0x0fff] to [bus 08] add_size 1000
2024-07-20T14:22:34,387453+00:00 pci 0000:00:03.0: bridge window [io  0x1000-0x0fff] to [bus 09] add_size 1000
2024-07-20T14:22:34,387459+00:00 pci 0000:00:02.0: bridge window [io  0x1000-0x1fff]: assigned
2024-07-20T14:22:34,387461+00:00 pci 0000:00:02.1: bridge window [io  0x2000-0x2fff]: assigned
2024-07-20T14:22:34,387462+00:00 pci 0000:00:02.2: bridge window [io  0x3000-0x3fff]: assigned
2024-07-20T14:22:34,387463+00:00 pci 0000:00:02.3: bridge window [io  0x4000-0x4fff]: assigned
2024-07-20T14:22:34,387464+00:00 pci 0000:00:02.4: bridge window [io  0x5000-0x5fff]: assigned
2024-07-20T14:22:34,387465+00:00 pci 0000:00:02.5: bridge window [io  0x6000-0x6fff]: assigned
2024-07-20T14:22:34,387466+00:00 pci 0000:00:02.6: bridge window [io  0x7000-0x7fff]: assigned
2024-07-20T14:22:34,387467+00:00 pci 0000:00:02.7: bridge window [io  0x8000-0x8fff]: assigned
2024-07-20T14:22:34,387468+00:00 pci 0000:00:03.0: bridge window [io  0x9000-0x9fff]: assigned
2024-07-20T14:22:34,387471+00:00 pci 0000:00:02.0: PCI bridge to [bus 01]
2024-07-20T14:22:34,387481+00:00 pci 0000:00:02.0:   bridge window [io  0x1000-0x1fff]
2024-07-20T14:22:34,388233+00:00 pci 0000:00:02.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:22:34,388645+00:00 pci 0000:00:02.0:   bridge window [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:22:34,389475+00:00 pci 0000:00:02.1: PCI bridge to [bus 02]
2024-07-20T14:22:34,389481+00:00 pci 0000:00:02.1:   bridge window [io  0x2000-0x2fff]
2024-07-20T14:22:34,390096+00:00 pci 0000:00:02.1:   bridge window [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:22:34,390545+00:00 pci 0000:00:02.1:   bridge window [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:22:34,391352+00:00 pci 0000:00:02.2: PCI bridge to [bus 03]
2024-07-20T14:22:34,391358+00:00 pci 0000:00:02.2:   bridge window [io  0x3000-0x3fff]
2024-07-20T14:22:34,391975+00:00 pci 0000:00:02.2:   bridge window [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:22:34,392394+00:00 pci 0000:00:02.2:   bridge window [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:22:34,393190+00:00 pci 0000:00:02.3: PCI bridge to [bus 04]
2024-07-20T14:22:34,393196+00:00 pci 0000:00:02.3:   bridge window [io  0x4000-0x4fff]
2024-07-20T14:22:34,393811+00:00 pci 0000:00:02.3:   bridge window [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:22:34,394217+00:00 pci 0000:00:02.3:   bridge window [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:22:34,395008+00:00 pci 0000:00:02.4: PCI bridge to [bus 05]
2024-07-20T14:22:34,395014+00:00 pci 0000:00:02.4:   bridge window [io  0x5000-0x5fff]
2024-07-20T14:22:34,395621+00:00 pci 0000:00:02.4:   bridge window [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:22:34,399323+00:00 pci 0000:00:02.4:   bridge window [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:22:34,400240+00:00 pci 0000:00:02.5: PCI bridge to [bus 06]
2024-07-20T14:22:34,400246+00:00 pci 0000:00:02.5:   bridge window [io  0x6000-0x6fff]
2024-07-20T14:22:34,400902+00:00 pci 0000:00:02.5:   bridge window [mem 0xfde00000-0xfdffffff]
2024-07-20T14:22:34,401343+00:00 pci 0000:00:02.5:   bridge window [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:22:34,402203+00:00 pci 0000:00:02.6: PCI bridge to [bus 07]
2024-07-20T14:22:34,402209+00:00 pci 0000:00:02.6:   bridge window [io  0x7000-0x7fff]
2024-07-20T14:22:34,402862+00:00 pci 0000:00:02.6:   bridge window [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:22:34,403292+00:00 pci 0000:00:02.6:   bridge window [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:22:34,404142+00:00 pci 0000:00:02.7: PCI bridge to [bus 08]
2024-07-20T14:22:34,404148+00:00 pci 0000:00:02.7:   bridge window [io  0x8000-0x8fff]
2024-07-20T14:22:34,404825+00:00 pci 0000:00:02.7:   bridge window [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:22:34,405273+00:00 pci 0000:00:02.7:   bridge window [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:22:34,406146+00:00 pci 0000:00:03.0: PCI bridge to [bus 09]
2024-07-20T14:22:34,406152+00:00 pci 0000:00:03.0:   bridge window [io  0x9000-0x9fff]
2024-07-20T14:22:34,406793+00:00 pci 0000:00:03.0:   bridge window [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:22:34,407219+00:00 pci 0000:00:03.0:   bridge window [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:22:34,408028+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2024-07-20T14:22:34,408030+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2024-07-20T14:22:34,408031+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2024-07-20T14:22:34,408032+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xafffffff window]
2024-07-20T14:22:34,408033+00:00 pci_bus 0000:00: resource 8 [mem 0xc0000000-0xfebfffff window]
2024-07-20T14:22:34,408034+00:00 pci_bus 0000:00: resource 9 [mem 0x180000000-0x97fffffff window]
2024-07-20T14:22:34,408036+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2024-07-20T14:22:34,408037+00:00 pci_bus 0000:01: resource 1 [mem 0xfe800000-0xfe9fffff]
2024-07-20T14:22:34,408037+00:00 pci_bus 0000:01: resource 2 [mem 0xfd000000-0xfd1fffff 64bit pref]
2024-07-20T14:22:34,408039+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2024-07-20T14:22:34,408040+00:00 pci_bus 0000:02: resource 1 [mem 0xfe600000-0xfe7fffff]
2024-07-20T14:22:34,408041+00:00 pci_bus 0000:02: resource 2 [mem 0xfce00000-0xfcffffff 64bit pref]
2024-07-20T14:22:34,408042+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2024-07-20T14:22:34,408043+00:00 pci_bus 0000:03: resource 1 [mem 0xfe400000-0xfe5fffff]
2024-07-20T14:22:34,408043+00:00 pci_bus 0000:03: resource 2 [mem 0xfcc00000-0xfcdfffff 64bit pref]
2024-07-20T14:22:34,408045+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2024-07-20T14:22:34,408046+00:00 pci_bus 0000:04: resource 1 [mem 0xfe200000-0xfe3fffff]
2024-07-20T14:22:34,408046+00:00 pci_bus 0000:04: resource 2 [mem 0xfca00000-0xfcbfffff 64bit pref]
2024-07-20T14:22:34,408048+00:00 pci_bus 0000:05: resource 0 [io  0x5000-0x5fff]
2024-07-20T14:22:34,408048+00:00 pci_bus 0000:05: resource 1 [mem 0xfe000000-0xfe1fffff]
2024-07-20T14:22:34,408049+00:00 pci_bus 0000:05: resource 2 [mem 0xfc800000-0xfc9fffff 64bit pref]
2024-07-20T14:22:34,408050+00:00 pci_bus 0000:06: resource 0 [io  0x6000-0x6fff]
2024-07-20T14:22:34,408051+00:00 pci_bus 0000:06: resource 1 [mem 0xfde00000-0xfdffffff]
2024-07-20T14:22:34,408052+00:00 pci_bus 0000:06: resource 2 [mem 0xfc600000-0xfc7fffff 64bit pref]
2024-07-20T14:22:34,408053+00:00 pci_bus 0000:07: resource 0 [io  0x7000-0x7fff]
2024-07-20T14:22:34,408054+00:00 pci_bus 0000:07: resource 1 [mem 0xfdc00000-0xfddfffff]
2024-07-20T14:22:34,408055+00:00 pci_bus 0000:07: resource 2 [mem 0xfc400000-0xfc5fffff 64bit pref]
2024-07-20T14:22:34,408056+00:00 pci_bus 0000:08: resource 0 [io  0x8000-0x8fff]
2024-07-20T14:22:34,408057+00:00 pci_bus 0000:08: resource 1 [mem 0xfda00000-0xfdbfffff]
2024-07-20T14:22:34,408058+00:00 pci_bus 0000:08: resource 2 [mem 0xfc200000-0xfc3fffff 64bit pref]
2024-07-20T14:22:34,408059+00:00 pci_bus 0000:09: resource 0 [io  0x9000-0x9fff]
2024-07-20T14:22:34,408060+00:00 pci_bus 0000:09: resource 1 [mem 0xfd800000-0xfd9fffff]
2024-07-20T14:22:34,408060+00:00 pci_bus 0000:09: resource 2 [mem 0xfc000000-0xfc1fffff 64bit pref]
2024-07-20T14:22:34,408342+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2024-07-20T14:22:34,412622+00:00 PCI: CLS 0 bytes, default 64
2024-07-20T14:22:34,412634+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2024-07-20T14:22:34,412634+00:00 software IO TLB: mapped [mem 0x000000007bfdc000-0x000000007ffdc000] (64MB)
2024-07-20T14:22:34,412795+00:00 Trying to unpack rootfs image as initramfs...
2024-07-20T14:22:34,415298+00:00 Initialise system trusted keyrings
2024-07-20T14:22:34,415369+00:00 workingset: timestamp_bits=40 max_order=20 bucket_order=0
2024-07-20T14:22:34,425023+00:00 Key type asymmetric registered
2024-07-20T14:22:34,425024+00:00 Asymmetric key parser 'x509' registered
2024-07-20T14:22:34,425038+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 251)
2024-07-20T14:22:34,425095+00:00 io scheduler mq-deadline registered
2024-07-20T14:22:34,425096+00:00 io scheduler kyber registered
2024-07-20T14:22:34,428422+00:00 pcieport 0000:00:02.0: PME: Signaling with IRQ 24
2024-07-20T14:22:34,429468+00:00 pcieport 0000:00:02.1: PME: Signaling with IRQ 25
2024-07-20T14:22:34,429977+00:00 pcieport 0000:00:02.2: PME: Signaling with IRQ 26
2024-07-20T14:22:34,431002+00:00 pcieport 0000:00:02.3: PME: Signaling with IRQ 27
2024-07-20T14:22:34,432011+00:00 pcieport 0000:00:02.4: PME: Signaling with IRQ 28
2024-07-20T14:22:34,433832+00:00 pcieport 0000:00:02.5: PME: Signaling with IRQ 29
2024-07-20T14:22:34,434879+00:00 pcieport 0000:00:02.6: PME: Signaling with IRQ 30
2024-07-20T14:22:34,435904+00:00 pcieport 0000:00:02.7: PME: Signaling with IRQ 31
2024-07-20T14:22:34,436183+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2024-07-20T14:22:34,436946+00:00 pcieport 0000:00:03.0: PME: Signaling with IRQ 32
2024-07-20T14:22:34,438165+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2024-07-20T14:22:34,438261+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2024-07-20T14:22:34,438535+00:00 Linux agpgart interface v0.103
2024-07-20T14:22:34,438540+00:00 ACPI: bus type drm_connector registered
2024-07-20T14:22:34,438884+00:00 usbcore: registered new interface driver usbserial_generic
2024-07-20T14:22:34,438887+00:00 usbserial: USB Serial support registered for generic
2024-07-20T14:22:34,438889+00:00 amd_pstate: the _CPC object is not present in SBIOS or ACPI disabled
2024-07-20T14:22:34,438928+00:00 drop_monitor: Initializing network drop monitor service
2024-07-20T14:22:34,439074+00:00 NET: Registered PF_INET6 protocol family
2024-07-20T14:22:34,499093+00:00 Freeing initrd memory: 11624K
2024-07-20T14:22:34,499434+00:00 Segment Routing with IPv6
2024-07-20T14:22:34,499453+00:00 In-situ OAM (IOAM) with IPv6
2024-07-20T14:22:34,499730+00:00 IPI shorthand broadcast: enabled
2024-07-20T14:22:34,501632+00:00 sched_clock: Marking stable (496006143, 5119539)->(517272580, -16146898)
2024-07-20T14:22:34,501775+00:00 registered taskstats version 1
2024-07-20T14:22:34,501844+00:00 Loading compiled-in X.509 certificates
2024-07-20T14:22:34,506440+00:00 Key type .fscrypt registered
2024-07-20T14:22:34,506443+00:00 Key type fscrypt-provisioning registered
2024-07-20T14:22:34,506599+00:00 PM:   Magic number: 0:816:384
2024-07-20T14:22:34,506627+00:00 container PNP0A06:02: hash matches
2024-07-20T14:22:34,506640+00:00 acpi PNP0A06:02: hash matches
2024-07-20T14:22:34,510104+00:00 RAS: Correctable Errors collector initialized.
2024-07-20T14:22:34,510184+00:00 clk: Disabling unused clocks
2024-07-20T14:22:34,511855+00:00 Freeing unused decrypted memory: 2028K
2024-07-20T14:22:34,512335+00:00 Freeing unused kernel image (initmem) memory: 3164K
2024-07-20T14:22:34,512338+00:00 Write protecting the kernel read-only data: 28672k
2024-07-20T14:22:34,512694+00:00 Freeing unused kernel image (rodata/data gap) memory: 1272K
2024-07-20T14:22:34,533772+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2024-07-20T14:22:34,533779+00:00 Run /init as init process
2024-07-20T14:22:34,533781+00:00   with arguments:
2024-07-20T14:22:34,533782+00:00     /init
2024-07-20T14:22:34,533783+00:00   with environment:
2024-07-20T14:22:34,533784+00:00     HOME=/
2024-07-20T14:22:34,533785+00:00     TERM=linux
2024-07-20T14:22:34,533786+00:00     BOOT_IMAGE=(hd0,gpt2)//kernels/4fx883ps9xv311wkackj2r7r9vik2gwa-linux-6.8.12-bzImage
2024-07-20T14:22:34,551505+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] loading module virtio_balloon...
2024-07-20T14:22:34,557860+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] loading module virtio_console...
2024-07-20T14:22:34,561716+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] loading module virtio_rng...
2024-07-20T14:22:34,565055+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] loading module virtio_gpu...
2024-07-20T14:22:34,572400+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] loading module dm_mod...
2024-07-20T14:22:34,587796+00:00 device-mapper: ioctl: 4.48.0-ioctl (2023-03-01) initialised: dm-devel@redhat.com
2024-07-20T14:22:34,589235+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] running udev...
2024-07-20T14:22:34,606943+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] Starting systemd-udevd version 255.6
2024-07-20T14:22:34,659639+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2024-07-20T14:22:34,660140+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2024-07-20T14:22:34,660145+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2024-07-20T14:22:34,662974+00:00 rtc_cmos 00:03: RTC can wake from S4
2024-07-20T14:22:34,665174+00:00 rtc_cmos 00:03: registered as rtc0
2024-07-20T14:22:34,665253+00:00 rtc_cmos 00:03: setting system clock to 2024-07-20T14:22:35 UTC (1721485355)
2024-07-20T14:22:34,665332+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram, hpet irqs
2024-07-20T14:22:34,670817+00:00 random: crng init done
2024-07-20T14:22:34,685338+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:22:34,685344+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 1
2024-07-20T14:22:34,685488+00:00 xhci_hcd 0000:03:00.0: hcc params 0x00087001 hci version 0x100 quirks 0x0000000000000010
2024-07-20T14:22:34,685794+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2024-07-20T14:22:34,685796+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 2
2024-07-20T14:22:34,685798+00:00 xhci_hcd 0000:03:00.0: Host supports USB 3.0 SuperSpeed
2024-07-20T14:22:34,685840+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.08
2024-07-20T14:22:34,685843+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:22:34,685844+00:00 usb usb1: Product: xHCI Host Controller
2024-07-20T14:22:34,685845+00:00 usb usb1: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:22:34,685846+00:00 usb usb1: SerialNumber: 0000:03:00.0
2024-07-20T14:22:34,686182+00:00 hub 1-0:1.0: USB hub found
2024-07-20T14:22:34,686204+00:00 hub 1-0:1.0: 4 ports detected
2024-07-20T14:22:34,686504+00:00 usb usb2: We don't know the algorithms for LPM for this host, disabling LPM.
2024-07-20T14:22:34,686517+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.08
2024-07-20T14:22:34,686519+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-07-20T14:22:34,686520+00:00 usb usb2: Product: xHCI Host Controller
2024-07-20T14:22:34,686521+00:00 usb usb2: Manufacturer: Linux 6.8.12 xhci-hcd
2024-07-20T14:22:34,686521+00:00 usb usb2: SerialNumber: 0000:03:00.0
2024-07-20T14:22:34,686589+00:00 hub 2-0:1.0: USB hub found
2024-07-20T14:22:34,686900+00:00 hub 2-0:1.0: 4 ports detected
2024-07-20T14:22:34,693813+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input0
2024-07-20T14:22:34,699665+00:00 SCSI subsystem initialized
2024-07-20T14:22:34,701152+00:00 virtio_blk virtio3: 2/0/0 default/read/poll queues
2024-07-20T14:22:34,701613+00:00 virtio_blk virtio3: [vda] 83886080 512-byte logical blocks (42.9 GB/40.0 GiB)
2024-07-20T14:22:34,702868+00:00  vda: vda1 vda2 vda3
2024-07-20T14:22:34,703496+00:00 virtio_blk virtio4: 2/0/0 default/read/poll queues
2024-07-20T14:22:34,704298+00:00 virtio_blk virtio4: [vdb] 83886080 512-byte logical blocks (42.9 GB/40.0 GiB)
2024-07-20T14:22:34,720337+00:00 libata version 3.00 loaded.
2024-07-20T14:22:34,720888+00:00 virtio_net virtio0 enp1s0: renamed from eth0
2024-07-20T14:22:34,723474+00:00 ahci 0000:00:1f.2: version 3.0
2024-07-20T14:22:34,723630+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2024-07-20T14:22:34,723986+00:00 ahci 0000:00:1f.2: AHCI 0001.0000 32 slots 6 ports 1.5 Gbps 0x3f impl SATA mode
2024-07-20T14:22:34,723989+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2024-07-20T14:22:34,724265+00:00 virtio_net virtio1 enp2s0: renamed from eth1
2024-07-20T14:22:34,724564+00:00 scsi host0: ahci
2024-07-20T14:22:34,724645+00:00 scsi host1: ahci
2024-07-20T14:22:34,724702+00:00 scsi host2: ahci
2024-07-20T14:22:34,724862+00:00 scsi host3: ahci
2024-07-20T14:22:34,725058+00:00 scsi host4: ahci
2024-07-20T14:22:34,725233+00:00 scsi host5: ahci
2024-07-20T14:22:34,725271+00:00 ata1: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a100 irq 50 lpm-pol 0
2024-07-20T14:22:34,725275+00:00 ata2: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a180 irq 50 lpm-pol 0
2024-07-20T14:22:34,725278+00:00 ata3: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a200 irq 50 lpm-pol 0
2024-07-20T14:22:34,725282+00:00 ata4: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a280 irq 50 lpm-pol 0
2024-07-20T14:22:34,725285+00:00 ata5: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a300 irq 50 lpm-pol 0
2024-07-20T14:22:34,725288+00:00 ata6: SATA max UDMA/133 abar m4096@0xfea1a000 port 0xfea1a380 irq 50 lpm-pol 0
2024-07-20T14:22:35,035843+00:00 ata4: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2024-07-20T14:22:35,036013+00:00 ata1: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:22:35,036149+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:22:35,036271+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:22:35,036324+00:00 ata4.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2024-07-20T14:22:35,036328+00:00 ata4.00: applying bridge limits
2024-07-20T14:22:35,036458+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:22:35,036575+00:00 ata2: SATA link down (SStatus 0 SControl 300)
2024-07-20T14:22:35,036686+00:00 ata4.00: configured for UDMA/100
2024-07-20T14:22:35,036911+00:00 scsi 3:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2024-07-20T14:22:35,045107+00:00 sr 3:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2024-07-20T14:22:35,045111+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2024-07-20T14:22:35,046058+00:00 sr 3:0:0:0: Attached scsi CD-ROM sr0
2024-07-20T14:22:35,077322+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] starting device mapper and LVM...
2024-07-20T14:22:35,091669+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] 1 logical volume(s) in volume group "pool" now active
2024-07-20T14:22:35,114468+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] checking /dev/pool/root...
2024-07-20T14:22:35,115494+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] fsck (busybox 1.36.1)
2024-07-20T14:22:35,116935+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] [fsck.ext4 (1) -- /mnt-root/] fsck.ext4 -a /dev/pool/root
2024-07-20T14:22:35,117888+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] /dev/pool/root: clean, 128916/2591792 files, 763852/10356736 blocks
2024-07-20T14:22:35,124569+00:00 stage-1-init: [Sat Jul 20 14:22:35 UTC 2024] mounting /dev/pool/root on /...
2024-07-20T14:22:35,227815+00:00 EXT4-fs (dm-0): mounted filesystem f67ea5fa-6f44-4a0e-b615-a043a7582837 r/w with ordered data mode. Quota mode: none.
2024-07-20T14:22:35,230159+00:00 EXT4-fs (dm-0): re-mounted f67ea5fa-6f44-4a0e-b615-a043a7582837 r/w. Quota mode: none.
2024-07-20T14:22:35,336137+00:00 EXT4-fs (dm-0): re-mounted f67ea5fa-6f44-4a0e-b615-a043a7582837 r/w. Quota mode: none.
2024-07-20T14:22:35,336350+00:00 booting system configuration /nix/store/1f0bkfb0n227ifpvzjyzzgmh710wd402-nixos-system-master2-24.11.20240716.ad0b5ee
2024-07-20T14:22:35,346513+00:00 stage-2-init: running activation script...
2024-07-20T14:22:35,446176+00:00 stage-2-init: setting up /etc...
2024-07-20T14:22:35,574368+00:00 systemd[1]: Inserted module 'autofs4'
2024-07-20T14:22:35,584346+00:00 systemd[1]: systemd 255.6 running in system mode (+PAM +AUDIT -SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -BPF_FRAMEWORK -XKBCOMMON +UTMP -SYSVINIT default-hierarchy=unified)
2024-07-20T14:22:35,584349+00:00 systemd[1]: Detected virtualization kvm.
2024-07-20T14:22:35,584355+00:00 systemd[1]: Detected architecture x86-64.
2024-07-20T14:22:35,585144+00:00 systemd[1]: Hostname set to <master2>.
2024-07-20T14:22:35,585371+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-07-20T14:22:35,686176+00:00 systemd[1]: Queued start job for default target Multi-User System.
2024-07-20T14:22:35,700470+00:00 systemd[1]: Created slice Slice /system/getty.
2024-07-20T14:22:35,701013+00:00 systemd[1]: Created slice Slice /system/modprobe.
2024-07-20T14:22:35,701523+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2024-07-20T14:22:35,702008+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2024-07-20T14:22:35,702567+00:00 systemd[1]: Created slice User and Session Slice.
2024-07-20T14:22:35,702830+00:00 systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
2024-07-20T14:22:35,703097+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2024-07-20T14:22:35,703358+00:00 systemd[1]: Expecting device /dev/disk/by-partlabel/disk-disk1-ESP...
2024-07-20T14:22:35,703594+00:00 systemd[1]: Expecting device /dev/hvc0...
2024-07-20T14:22:35,703798+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp1s0...
2024-07-20T14:22:35,704028+00:00 systemd[1]: Expecting device /sys/subsystem/net/devices/enp2s0...
2024-07-20T14:22:35,704270+00:00 systemd[1]: Reached target Local Encrypted Volumes.
2024-07-20T14:22:35,704490+00:00 systemd[1]: Reached target Containers.
2024-07-20T14:22:35,704703+00:00 systemd[1]: Reached target Path Units.
2024-07-20T14:22:35,704904+00:00 systemd[1]: Reached target Remote File Systems.
2024-07-20T14:22:35,705113+00:00 systemd[1]: Reached target Slice Units.
2024-07-20T14:22:35,705340+00:00 systemd[1]: Reached target Swaps.
2024-07-20T14:22:35,706499+00:00 systemd[1]: Listening on Process Core Dump Socket.
2024-07-20T14:22:35,706800+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2024-07-20T14:22:35,707084+00:00 systemd[1]: Listening on Journal Socket.
2024-07-20T14:22:35,707388+00:00 systemd[1]: Listening on Userspace Out-Of-Memory (OOM) Killer Socket.
2024-07-20T14:22:35,707797+00:00 systemd[1]: Listening on udev Control Socket.
2024-07-20T14:22:35,708069+00:00 systemd[1]: Listening on udev Kernel Socket.
2024-07-20T14:22:35,709037+00:00 systemd[1]: Mounting Huge Pages File System...
2024-07-20T14:22:35,710179+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2024-07-20T14:22:35,715732+00:00 systemd[1]: Mounting Kernel Debug File System...
2024-07-20T14:22:35,718672+00:00 systemd[1]: Starting domainname.service...
2024-07-20T14:22:35,721323+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2024-07-20T14:22:35,725212+00:00 systemd[1]: Starting Load Kernel Module configfs...
2024-07-20T14:22:35,727237+00:00 systemd[1]: Starting Load Kernel Module drm...
2024-07-20T14:22:35,729199+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2024-07-20T14:22:35,730706+00:00 systemd[1]: Starting Load Kernel Module fuse...
2024-07-20T14:22:35,732237+00:00 systemd[1]: Starting mount-pstore.service...
2024-07-20T14:22:35,734228+00:00 systemd[1]: Starting Create SUID/SGID Wrappers...
2024-07-20T14:22:35,734468+00:00 systemd[1]: File System Check on Root Device was skipped because of an unmet condition check (ConditionPathIsReadWrite=!/).
2024-07-20T14:22:35,738203+00:00 systemd[1]: Starting Journal Service...
2024-07-20T14:22:35,744670+00:00 systemd[1]: Starting Load Kernel Modules...
2024-07-20T14:22:35,745515+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2024-07-20T14:22:35,749217+00:00 systemd[1]: Starting Coldplug All udev Devices...
2024-07-20T14:22:35,750517+00:00 systemd[1]: Mounted Huge Pages File System.
2024-07-20T14:22:35,752302+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2024-07-20T14:22:35,752598+00:00 systemd[1]: Mounted Kernel Debug File System.
2024-07-20T14:22:35,753303+00:00 systemd[1]: domainname.service: Deactivated successfully.
2024-07-20T14:22:35,754078+00:00 systemd[1]: Finished domainname.service.
2024-07-20T14:22:35,754708+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2024-07-20T14:22:35,755284+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-07-20T14:22:35,756210+00:00 systemd[1]: Finished Load Kernel Module configfs.
2024-07-20T14:22:35,761252+00:00 systemd[1]: Mounting Kernel Configuration File System...
2024-07-20T14:22:35,768244+00:00 systemd[1]: Starting Create Static Device Nodes in /dev gracefully...
2024-07-20T14:22:35,769718+00:00 NET: Registered PF_ALG protocol family
2024-07-20T14:22:35,771957+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-07-20T14:22:35,772057+00:00 systemd[1]: Finished Load Kernel Module drm.
2024-07-20T14:22:35,772427+00:00 systemd[1]: Mounted Kernel Configuration File System.
2024-07-20T14:22:35,785388+00:00 EXT4-fs (dm-0): re-mounted f67ea5fa-6f44-4a0e-b615-a043a7582837 r/w. Quota mode: none.
2024-07-20T14:22:35,789355+00:00 systemd[1]: Finished Remount Root and Kernel File Systems.
2024-07-20T14:22:35,789803+00:00 systemd-journald[387]: Collecting audit messages is disabled.
2024-07-20T14:22:35,796227+00:00 systemd[1]: Starting Load/Save OS Random Seed...
2024-07-20T14:22:35,796612+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-07-20T14:22:35,796711+00:00 systemd[1]: Finished Load Kernel Module efi_pstore.
2024-07-20T14:22:35,800441+00:00 fuse: init (API version 7.39)
2024-07-20T14:22:35,801576+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-07-20T14:22:35,801668+00:00 systemd[1]: Finished Load Kernel Module fuse.
2024-07-20T14:22:35,808199+00:00 systemd[1]: Mounting FUSE Control File System...
2024-07-20T14:22:35,809571+00:00 systemd[1]: Mounted FUSE Control File System.
2024-07-20T14:22:35,817329+00:00 systemd[1]: Finished Create Static Device Nodes in /dev gracefully.
2024-07-20T14:22:35,824251+00:00 systemd[1]: Starting Create Static Device Nodes in /dev...
2024-07-20T14:22:35,824700+00:00 systemd[1]: Finished Load/Save OS Random Seed.
2024-07-20T14:22:35,836264+00:00 systemd[1]: Finished Create Static Device Nodes in /dev.
2024-07-20T14:22:35,837160+00:00 systemd[1]: Reached target Preparation for Local File Systems.
2024-07-20T14:22:35,847107+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2024-07-20T14:22:35,848259+00:00 systemd[1]: Starting Rule-based Manager for Device Events and Files...
2024-07-20T14:22:35,848609+00:00 systemd[1]: Started Journal Service.
2024-07-20T14:22:35,867185+00:00 tun: Universal TUN/TAP device driver, 1.6
2024-07-20T14:22:35,868969+00:00 systemd-journald[387]: Received client request to flush runtime journal.
2024-07-20T14:22:35,875442+00:00 loop: module loaded
2024-07-20T14:22:35,976828+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input2
2024-07-20T14:22:35,983000+00:00 ACPI: button: Power Button [PWRF]
2024-07-20T14:22:35,991473+00:00 cirrus 0000:00:01.0: vgaarb: deactivate vga console
2024-07-20T14:22:35,995949+00:00 Console: switching to colour dummy device 80x25
2024-07-20T14:22:35,996909+00:00 [drm] Initialized cirrus 2.0.0 2019 for 0000:00:01.0 on minor 0
2024-07-20T14:22:35,998168+00:00 fbcon: cirrusdrmfb (fb0) is primary device
2024-07-20T14:22:36,004092+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2024-07-20T14:22:36,022254+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2024-07-20T14:22:36,022314+00:00 i2c i2c-0: 1/1 memory slots populated (from DMI)
2024-07-20T14:22:36,022315+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2024-07-20T14:22:36,039624+00:00 Console: switching to colour frame buffer device 128x48
2024-07-20T14:22:36,066616+00:00 iTCO_wdt iTCO_wdt.1.auto: Found a ICH9 TCO device (Version=2, TCOBASE=0x0660)
2024-07-20T14:22:36,066706+00:00 iTCO_wdt iTCO_wdt.1.auto: initialized. heartbeat=30 sec (nowayout=0)
2024-07-20T14:22:36,069401+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2024-07-20T14:22:36,069531+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2024-07-20T14:22:36,078695+00:00 mousedev: PS/2 mouse device common for all mice
2024-07-20T14:22:36,138141+00:00 cirrus 0000:00:01.0: [drm] fb0: cirrusdrmfb frame buffer device
2024-07-20T14:22:36,187953+00:00 kvm_amd: Nested Virtualization enabled
2024-07-20T14:22:36,187956+00:00 kvm_amd: Nested Paging disabled
2024-07-20T14:22:36,194747+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:22:36,194754+00:00 powernow_k8: Power state transitions not supported
2024-07-20T14:22:36,198717+00:00 EDAC MC: Ver: 3.0.0
2024-07-20T14:22:37,432203+00:00 8021q: 802.1Q VLAN Support v1.8
2024-07-20T14:22:37,575366+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2024-07-20T14:22:37,599381+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2024-07-20T14:22:37,599494+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2024-07-20T14:22:37,630107+00:00 8021q: adding VLAN 0 to HW filter on device enp1s0
2024-07-20T14:22:37,644879+00:00 8021q: adding VLAN 0 to HW filter on device enp2s0
2024-07-20T14:22:37,724562+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:22:37,724566+00:00 public: port 1(enp1s0) entered disabled state
2024-07-20T14:22:37,724576+00:00 virtio_net virtio0 enp1s0: entered allmulticast mode
2024-07-20T14:22:37,724652+00:00 virtio_net virtio0 enp1s0: entered promiscuous mode
2024-07-20T14:22:37,726428+00:00 public: port 1(enp1s0) entered blocking state
2024-07-20T14:22:37,726430+00:00 public: port 1(enp1s0) entered forwarding state
2024-07-20T14:22:37,746484+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:22:37,746488+00:00 private: port 1(vlan4000) entered disabled state
2024-07-20T14:22:37,746497+00:00 vlan4000: entered allmulticast mode
2024-07-20T14:22:37,746499+00:00 virtio_net virtio1 enp2s0: entered allmulticast mode
2024-07-20T14:22:37,746588+00:00 vlan4000: entered promiscuous mode
2024-07-20T14:22:37,746589+00:00 virtio_net virtio1 enp2s0: entered promiscuous mode
2024-07-20T14:22:37,748336+00:00 private: port 1(vlan4000) entered blocking state
2024-07-20T14:22:37,748339+00:00 private: port 1(vlan4000) entered forwarding state
2024-07-20T14:22:39,119668+00:00 NET: Registered PF_PACKET protocol family
2024-07-20T14:22:44,833569+00:00 Bridge firewalling registered
2024-07-20T14:25:15,404081+00:00 Initializing XFRM netlink socket
