> Error while running 'cilium-dbg bpf tunnel list':  exit status 1

