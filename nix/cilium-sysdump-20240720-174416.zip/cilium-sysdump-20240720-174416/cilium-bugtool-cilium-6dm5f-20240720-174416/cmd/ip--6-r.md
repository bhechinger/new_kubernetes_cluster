fe80::/64 dev enp1s0 proto kernel metric 256 pref medium
fe80::/64 dev enp2s0 proto kernel metric 256 pref medium
fe80::/64 dev vlan4000 proto kernel metric 256 pref medium
fe80::/64 dev private proto kernel metric 256 pref medium
fe80::/64 dev public proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
