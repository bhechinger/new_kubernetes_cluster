Endpoint   Source   FQDN   TTL   ExpirationTime   IPs   
