goroutine 55 [running]:
runtime/pprof.writeGoroutineStacks({0x3f07700, 0xc001670030})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x6a
runtime/pprof.writeGoroutine({0x3f07700?, 0xc001670030?}, 0xc0031c9b00?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x25
runtime/pprof.(*Profile).WriteTo(0x394e735?, {0x3f07700?, 0xc001670030?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x146
github.com/google/gops/agent.handle({0x7f6b4dfaef80?, 0xc001670030}, {0xc001094000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xd2
github.com/google/gops/agent.listen({0x3f44240, 0xc000072ba0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1a5
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x379

goroutine 1 [select, 199 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc0000e4460)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:232 +0x16e
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc0000e4460)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:216 +0x112
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0xc000bd0600?, {0x3940fc9?, 0x4?, 0x3940e35?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:39 +0x17b
github.com/spf13/cobra.(*Command).execute(0xc000004300, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:987 +0xaa3
github.com/spf13/cobra.(*Command).ExecuteC(0xc000004300)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1115 +0x3ff
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1039
github.com/cilium/cilium/daemon/cmd.Execute(0xc0000e4460?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:79 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x57

goroutine 45 [select, 2 minutes]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008d3b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 31 [select, 199 minutes]:
io.(*pipe).read(0xc00186df20, {0xc000cfe000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x7f6b4e3da6c8?, {0xc000cfe000?, 0x410ba5?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000bebf28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc0008d3f20?, 0xc0013d4350, 0xc000f92350)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 32 [select, 199 minutes]:
io.(*pipe).read(0xc00186df80, {0xc000e96000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc000e96000?, 0x410ba5?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000bd8f28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0013d4360, 0xc000f92370)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 49 [select, 199 minutes]:
io.(*pipe).read(0xc000345bc0, {0xc000ed4000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc000ed4000?, 0x410ba5?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000bd9f28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0013d4370, 0xc000f92390)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 50 [select, 199 minutes]:
io.(*pipe).read(0xc000345c20, {0xc000ee4000, 0x10000, 0x425e3c?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x6121940?, {0xc000ee4000?, 0x410ba5?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x1b
bufio.(*Scanner).Scan(0xc000bdaf28)
	/usr/local/go/src/bufio/scan.go:214 +0x81b
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0013d4380, 0xc000f923b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x125
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x385

goroutine 1084 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc0016f2c90, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0002b7c70?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc0016f2c40, {0x3f59438, 0xc000149db0}, {0xc001433580, 0x35}, 0x1, {0xc001a305e5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1065
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 46 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x58
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x90

goroutine 56 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40fd40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0002b0100?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0002b0100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0002b0100)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000144080)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000144080)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc000706000, {0x3f44240, 0xc000144080})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc000706000)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xa8
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xc5

goroutine 173 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000da90e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 175 [chan receive, 96 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:151 +0x71
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:145 +0x67

goroutine 176 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000da9180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 177 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000da9220)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 178 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000356500, {{{0x395f226, 0xd}}, {0x0, 0x0}, 0xc0001441c0, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 64 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 180
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 61 [IO wait]:
internal/poll.runtime_pollWait(0x7f6b4e40fc48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ba1580?, 0xc001d82000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ba1580, {0xc001d82000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ba1580, {0xc001d82000?, 0x33ccd60?, 0xc000073360?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00172c7f0, {0xc001d82000?, 0xc001d82000?, 0x5?})
	/usr/local/go/src/net/net.go:179 +0x45
crypto/tls.(*atLeastReader).Read(0xc0034d66f0, {0xc001d82000?, 0xc0034d66f0?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:805 +0x3b
bytes.(*Buffer).ReadFrom(0xc001a33ea8, {0x3f0ca20, 0xc0034d66f0})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001a33c00, {0x7f6b4e121998?, 0xc0016781f8}, 0xa000?)
	/usr/local/go/src/crypto/tls/conn.go:827 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc001a33c00, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:625 +0x250
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:587
crypto/tls.(*Conn).Read(0xc001a33c00, {0xc000325000, 0x1000, 0xfa6aa5?})
	/usr/local/go/src/crypto/tls/conn.go:1369 +0x158
bufio.(*Reader).Read(0xc000d3c3c0, {0xc001a1f620, 0x9, 0x6069af0?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc000d3c3c0}, {0xc001a1f620, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc001a1f620, 0x9, 0x126f000?}, {0x3f07920?, 0xc000d3c3c0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001a1f5e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000a45f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2275 +0x11f
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000bcc780)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2170 +0x65
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 60
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:821 +0xcbe

goroutine 63 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001a01578, 0x56)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0016eeaa0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001a01550, 0xc001755300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000da9cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000569650}, 0x1, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001596550?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000da9cc0, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0000733e0, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 180
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 222 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00142fe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 202
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 206 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0xc000da8b40, 0xc0000caa20, 0xc0000caae0, 0xc0000cab40)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:335 +0x286
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0xc000da8b40, {0x3f59438?, 0xc0000c95e0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:227 +0x305
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0xc000da8b40, {0x3f59438, 0xc0000c95e0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:169 +0x97
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:149 +0x156

goroutine 46909 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031be0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002fab080?, 0xc001b34000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002fab080, {0xc001b34000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002fab080, {0xc001b34000?, 0x703620?, 0xc000d99b80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001670e78, {0xc001b34000?, 0x0?, 0xc002879a00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00142a900, {0xc001b34000?, 0xc0020fcba0?, 0xc00313dd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003020f60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003020f60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00142a900)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 46908
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 209 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001c0e398, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001396680?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0e370, 0xc0018b5940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ae05a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc00004f080}, 0x1, 0xc001753c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001094eb0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ae05a0, 0xc001753c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000145240, 0xc001753c20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 181
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 210 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 181
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 202 [chan receive, 2 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0xc0017f64e0, {0x3f59438?, 0xc0007ae280?}, 0x17cab45?)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xae
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:106 +0x31
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:105 +0x2c5

goroutine 221 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 203
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 194 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 63
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 196 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 63
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 197 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000c63140}, {0x7f6b4e121c58, 0xc001a01550}, {0x3f8d658?, 0x38fdc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001a1f6c0, {0x0?, 0x0?}, 0xc0000ca1e0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001a1f6c0, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ce1300?, {0x3f0dec0, 0xc0000c8dc0}, 0x1, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001a1f6c0, 0xc0000ca1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 63
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 187 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001a1f6c0, 0xc0000ca1e0, 0xc001753380, 0x74692065636e6973?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 197
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 92059 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f90f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003442e80?, 0xc00342f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003442e80, {0xc00342f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003442e80, {0xc00342f000?, 0x703620?, 0xc002511e00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144b7e0, {0xc00342f000?, 0x0?, 0xc002904680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001595560, {0xc00342f000?, 0xc002734ae0?, 0xc001919d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003450b40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003450b40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001595560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 92058
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 203 [select, 6 minutes]:
github.com/cilium/cilium/pkg/statedb.graveyardWorker(0xc0011c0a80, {0x3f59438, 0xc0000c9310}, 0xc001ad2f80?)
	/go/src/github.com/cilium/cilium/pkg/statedb/graveyard.go:28 +0x136
created by github.com/cilium/cilium/pkg/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/statedb/db.go:231 +0x152

goroutine 205 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 213 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 209
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 223 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00142ff80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 202
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 215 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 209
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 216 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc001ba8040}, {0x7f6b4e121c58, 0xc001c0e370}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e142a0, {0x0?, 0x0?}, 0xc001753c20, 0x17cf244?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e142a0, 0xc001753c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001432880?, {0x3f0dec0, 0xc0009e9720}, 0x1, 0xc001753c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e142a0, 0xc001753c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 209
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 219 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e142a0, 0xc001753c20, 0xc000bd46c0, 0xc001af8f10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 216
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 88843 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002c04648, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f375d0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002c04630, {0xc002501801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002501801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc00340c780)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00340c780)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc00340c780, {0x326cdc0, 0xc0032bd6e0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0039e9230, {0xc000aa3800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003339680, 0xc0021328a0?, {0x3f3b448, 0xc0032b2f40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000da5740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00244ae00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 547
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 91390 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002429cc8, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001ee4d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002429cb0, {0xc0012a619c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0012a6190?}, {0xc0012a619c?, 0xc001ee4ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc002429c80}, {0xc0012a619c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000d679f8, {0xc0024f4800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003061770, 0xc00262bd40?, {0x3f3b448, 0xc00247f640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001241d40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0014bbc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 372
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 224 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0016f2410, 0xaa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00142fe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc0009e9b30}, 0xc000bd4a80, {0x3f6a9c8, 0xc001678570})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 202
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 225 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 202
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 232 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x2f
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:75 +0x199

goroutine 207 [chan receive, 199 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:350 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:349 +0x14f

goroutine 208 [syscall, 12 minutes]:
syscall.Syscall6(0x454a2f?, 0x49?, 0xc001c8fc38?, 0x41e576?, 0x662d400?, 0xc001c8fca0?, 0x4109fd?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7f6b4e12ea48?, {0xc001c8fd70?, 0x58?, 0xc0005c2400?}, 0xc002734e40?, 0xc002734e40?, 0x1400000058?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc002734e40?, {0xc001c8fd70, 0x10000, 0x10000}, 0x707365520e010103?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc001946e70?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:366 +0x94
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:363 +0x35f

goroutine 241 [chan receive, 199 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1512 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1511 +0x14f

goroutine 242 [syscall, 178 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0xc002c70a01?, 0x0?, 0xc001ccf878?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7f6b4e140c30?, {0xc001ccf948?, 0x3c?, 0xc00062f800?}, 0xc002d6d600?, 0xc002d6d600?, 0x60000180000003c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc002d6d600?, {0xc001ccf948, 0x10000, 0x10000}, 0xb8ff0173616d6568?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x6?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1528 +0x9a
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1525 +0x35f

goroutine 243 [chan receive, 199 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2338 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2337 +0x13e

goroutine 244 [syscall, 199 minutes]:
syscall.Syscall6(0x454a2f?, 0x28?, 0x3406ce0?, 0x6124e01?, 0x425d05?, 0xc001cefdc8?, 0x4108a5?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.recvfrom(0x7f6b4e120640?, {0xc001cefe98?, 0x5c0?, 0xc00009a800?}, 0xc0021ac000?, 0xc0021ac000?, 0x10000005c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0xc0021ac000?, {0xc001cefe98, 0x10000, 0x10000}, 0x100b0ff01616d65?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc001cffef8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:781 +0x59
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2354 +0x7f
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 206
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2351 +0x34f

goroutine 245 [select, 12 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0xc000fbd0e0, {0x3f59400, 0xc00074fad0}, {0x3f43ff0?, 0xc0014c7600})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:260 +0x24b
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0011fa600, {0x3f59400, 0xc00074fad0}, 0x0?, {0x3f445d0, 0xc000742fc0}, {{{0x0, 0x0, 0x0}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 246 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 245
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x147

goroutine 247 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40fb50, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001072300?, 0xc001d0feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001072300, {0xc001d0feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc00172c9a8, {0xc001d0feb0?, 0x3ef8148?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc00145cc80)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 248 [select, 199 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009ef540, {{{0x3963cb9, 0xe}}, {0x0, 0x0}, 0xc0016d14c0, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 249 [select, 199 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc0018d8820)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0x105
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x3ee

goroutine 231 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f960, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b9dd00?, 0x38801a0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b9dd00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b9dd00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x1?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0xc000c18090)
	/usr/local/go/src/net/unixsock.go:247 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:58 +0xaf
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:53 +0x136

goroutine 279 [select, 199 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xd0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 236
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xcc

goroutine 229 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 228 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94e60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 258 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 227 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40fa58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b9db00?, 0x2fd54c0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b9db00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b9db00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x40a19e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc000835aa0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc000310520, {0x3f59438?, 0xc0008bd9a0}, 0xc000c04780?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xe2
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x192

goroutine 259 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009ef900, {{{0x39565a6, 0xb}}, {0x3f43ff0, 0xc00145ce40}, 0xc0016d19f0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 260 [chan receive, 40 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc00198b7d0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c046c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 261 [chan receive, 40 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 262 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93940)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 263 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f94980)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 264 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3f93c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:346 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:326 +0xa7

goroutine 501 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001c0eb28, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001de5c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0eb00, 0xc000e7c900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ae1a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001a7e990}, 0x1, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171b850?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ae1a40, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007ef680, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 271
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 445 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc0011802e8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001edecc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0011802c0, 0xc000cf2540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e3d60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc000808c60}, 0x1, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171a2b0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e3d60, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000861900, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x25b

goroutine 498 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 272
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 446 [select, 40 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:93 +0x352
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:74 +0x13a

goroutine 458 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc001d55240}, {0x7f6b4e121c58, 0xc0011802c0}, {0x3f8d658?, 0x38fe380}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b20a80, {0x0?, 0x0?}, 0xc000eb8300, 0xc000aace98?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b20a80, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0008189c0?, {0x3f0dec0, 0xc0007ae910}, 0x1, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b20a80, 0xc000eb8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1128 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0xc001407d58)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1127
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:382 +0x78

goroutine 673 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc003245180}, {0x7f6b4e121c58, 0xc001c0ed10}, {0x3f8d658?, 0x38c3780}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000d33a40, {0x0?, 0x0?}, 0xc002126060, 0xc000cf37d8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000d33a40, 0xc002126060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000d84580?, {0x3f0dec0, 0xc0021a70e0}, 0x1, 0xc002126060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000d33a40, 0xc002126060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1085 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000d33a40, 0xc002126060, 0xc0018e2960, 0xc00172c488?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 673
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 1129 [semacquire, 199 minutes]:
sync.runtime_Semacquire(0x339db00?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0xc00251f000?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc00251f000)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0x57
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc00251f000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x105
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1127
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:386 +0xc7

goroutine 274 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 275 [chan receive, 199 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc00061f220, {0x3f59438?, 0xc00061f270})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x5e
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14a

goroutine 276 [select, 2 minutes]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc000da9400, {0x3f59438, 0xc00061f270})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:363 +0x31e
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x75
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 275
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4c

goroutine 277 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 227
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xa5

goroutine 233 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f868, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b9de80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b9de80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b9de80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x447380?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc000c183c0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc000629200, {0x3f44270?, 0xc000c183c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0xa5
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x191

goroutine 234 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 281 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0003e2dc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 235 [syscall]:
syscall.Syscall6(0x2eb29b3?, 0x32bdec0?, 0x2db1bbe?, 0x0?, 0x2db1bbc?, 0x32bdf20?, 0xc001625998?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0xc0004bc5b4?, {0xc001592618?, 0x5fd1880?, 0x46e8d3?}, 0x4e82c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc0003108a0, {0xc001592618?, 0x2, 0x2}, {0xc001625ae8?, 0x73c0d8?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc000e32a80, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(0xc0002b7a40?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328 +0x45
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x82
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x118

goroutine 236 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446e0, {0x3f59400, 0xc000c19a10?}, 0x0, {0x3f445d0?, 0xc0008cfd40}, {{{0xc001583b60, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 237 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3f446a0, {0x3f59400, 0xc000c19a70?}, 0xc001af4f01, {0x3f445d0?, 0xc0008cfd40}, {{{0xc001583b60, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:615 +0x5ea
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 238 [select, 6 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0013310e0, {0x3f59400, 0xc000c19b60}, 0xc001af47d0?, {0x3f445d0, 0xc0008cfd40}, {{{0xc001583b60, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 239 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1071 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0xf4
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1070
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 289 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 280 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001af5fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 282 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc00073a1e0)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:237 +0x89
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:207 +0x1b6

goroutine 283 [select, 96 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc001a3a840)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:691 +0xe5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:704 +0x4f

goroutine 284 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009efb80, {{{0x3990b5c, 0x19}}, {0x0, 0x0}, 0xc0016dfa10, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 285 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009efcc0, {{{0x398150a, 0x15}}, {0x0, 0x0}, 0xc0016dfa50, 0x0, 0x3b61ab0, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 292 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f678, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000467d80?, 0xc0002e2c80?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000467d80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000467d80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000311ba0)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000311ba0)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
github.com/cilium/dns.(*Server).serveTCP(0xc000ff4100, {0x3f44240?, 0xc000311ba0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x142
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000ff4100)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x26c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000ff4100)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 313 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001182360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 345
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 315 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc00130fa50, 0x26)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001182360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc000747630}, 0xc000f60c60, {0x3f6aa20, 0xc000d67458})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 345
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 293 [IO wait]:
internal/poll.runtime_pollWait(0x7f6b4e40f488, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000467e00?, 0xc00120fa00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc000467e00, {0xc00120fa00, 0x200, 0x200}, {0xc00011c570, 0x2c, 0x2c}, 0x7f6b4dfcb228?, 0x5?)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x339
net.(*netFD).readMsgInet4(0xc000467e00, {0xc00120fa00?, 0x41013e?, 0x7f6b4dfcb228?}, {0xc00011c570?, 0xc001d27828?, 0x45c1de?}, 0xc0024b4000?, 0x64?)
	/usr/local/go/src/net/fd_posix.go:84 +0x31
net.(*UDPConn).readMsg(0x3b622b8?, {0xc00120fa00?, 0x419188?, 0x1762?}, {0xc00011c570?, 0x0?, 0xffffffffffffffff?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x15c
net.(*UDPConn).ReadMsgUDPAddrPort(0xc001358b18, {0xc00120fa00?, 0x7f6b4e40f488?, 0x47e538?}, {0xc00011c570?, 0xc001d27988?, 0x47e325?})
	/usr/local/go/src/net/udpsock.go:203 +0x3e
net.(*UDPConn).ReadMsgUDP(0xc000ecd6b0?, {0xc00120fa00?, 0xc000c9b800?, 0xc000252260?}, {0xc00011c570?, 0xc001d279e8?, 0x410c25?})
	/usr/local/go/src/net/udpsock.go:191 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc001358b18?, 0xc001358b18)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x58
github.com/cilium/dns.(*Server).readUDP(0xc000ff4200, 0xc001358b18, 0xc003473180?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xeb
github.com/cilium/dns.defaultReader.ReadUDP({0xc002554d70?}, 0x3f07580?, 0xc003473180?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0xc000ff4200, {0x3f667c8?, 0xc001358b18})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x29c
github.com/cilium/dns.(*Server).ActivateAndServe(0xc000ff4200)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x1c7
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc000ff4200)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x22a
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:696 +0x979

goroutine 316 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 345
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 369 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 317
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 318 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 265
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 378 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0024a02c0}, {0x7f6b4e121c58, 0xc0002f96b0}, {0x3f8d658?, 0x38feec0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e150a0, {0x0?, 0x0?}, 0xc000f61560, 0x40739d?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e150a0, 0xc000f61560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00007d6c0?, {0x3f0dec0, 0xc0007479f0}, 0x1, 0xc000f61560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e150a0, 0xc000f61560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 395
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 371 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 317
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 314 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0011824e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 345
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 405 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 390
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 429 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e155e0, 0xc000f61b60, 0xc00178c660, 0xc001d62fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 424
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 411 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e14d20, 0xc000f61020, 0xc0012d78c0, 0xc001af2710?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 372
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 383 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc000bb03d0, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0011827e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f772e0, {0x3f59438, 0xc000747bd0}, 0xc000f61860, {0x3f6a918, 0xc000d677a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 386
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 417 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001c0e9c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000c0e980?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0e9a0, 0xc000bb0540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ae1720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010bfb90}, 0x1, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001773690?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ae1720, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007ee840, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 267
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 381 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0011827e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 386
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 418 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 267
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 497 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001c0ea78, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001de7c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0ea50, 0xc000e7c8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ae19a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0012f3f80}, 0x1, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001824c30?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ae19a0, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007ef620, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 272
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 317 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc001c0e7b8, 0x13)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001362ca0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0e790, 0xc00130fbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ae1680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010bed20}, 0x1, 0xc000f61020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0017732a0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ae1680, 0xc000f61020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007ee080, 0xc000f61020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 265
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 377 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 395
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 375 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 395
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 423 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 672 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 372 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc0014bbc00}, {0x7f6b4e121c58, 0xc001c0e790}, {0x3f8d658?, 0x38fd480}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e14d20, {0x0?, 0x0?}, 0xc000f61020, 0x422065687420676e?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e14d20, 0xc000f61020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00007d5c0?, {0x3f0dec0, 0xc000747950}, 0x1, 0xc000f61020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e14d20, 0xc000f61020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 317
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 5569 [select, 190 minutes]:
net/http.(*persistConn).writeLoop(0xc00142a360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 5564
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 424 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002404180}, {0x7f6b4e121c58, 0xc001c0e9a0}, {0x3f8d658?, 0x38fd0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e155e0, {0x0?, 0x0?}, 0xc000f61b60, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e155e0, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00007d900?, {0x3f0dec0, 0xc000747e00}, 0x1, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e155e0, 0xc000f61b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 502 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 271
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 11904 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc0014558c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 11901
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 382 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001182960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 386
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 421 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 384 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 386
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 4738 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc000451d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 4719
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 427 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e150a0, 0xc000f61560, 0xc00178c1e0, 0xc001d6ef10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 336 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00101fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 337 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00101fda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 338 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f773e0, {0x3f59438, 0xc000760e60}, 0xc000eb9800, {0x3f6a9c8, 0xc001678570})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:664 +0x5a6
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 339 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 46918 [select, 50 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f3320)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 46916
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 345 [select, 96 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc001a3a840, 0xc0015ade80, 0xc000c14e90?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:40 +0x11d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:28 +0x168

goroutine 1081 [select, 6 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc001ba1100, {0x3f59400, 0xc00074cfc0}, 0x398a51c?, 0x0?, 0xc00186c0c0)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:168 +0x25f
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc001ba1100, {0x3f59400, 0xc00074cfc0}, {0x4a4b64?, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:113 +0x2db
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001331da0, {0x3f59400, 0xc00074cfc0}, 0xc001debfd0?, {0x3f445d0, 0xc00172c488}, {{{0xc000bb3e00, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 347 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00116a4e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 348 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00116a660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 349 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc000aac090, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00116a4e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77260, {0x3f59438, 0xc000761540}, 0xc000eb9ec0, {0x3f6a8c0, 0xc00157d698})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 350 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 351 [select, 96 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:47 +0xc5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:45 +0x1ed

goroutine 1095 [chan receive, 40 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001e00fd0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0027cb680?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 953
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1078 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 354 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00116a720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 355 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00116a8a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 356 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc000aaca10, 0x89)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x5?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00116a720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc0007616d0}, 0xc0012d6120, {0x3f6a708, 0xc00157d7a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 357 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 358 [select, 96 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:42 +0xec
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:40 +0x236

goroutine 1158 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e2000, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc000c82c00}, 0xc000cc4650, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1095
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 360 [select, 46 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPolicyEventLoop(0xc001a3a840, 0xc0015adec0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:41 +0x129
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NetworkPoliciesInit.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:28 +0x157

goroutine 361 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00116a960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 360
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 362 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00116aae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 360
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 363 [sync.Cond.Wait, 46 minutes]:
sync.runtime_notifyListWait(0xc000aace90, 0x3c)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00116a960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f771e0, {0x3f59438, 0xc000761810}, 0xc0012d6360, {0x3f6a868, 0xc00157d860})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 364 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 1094 [select, 199 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc00061edc0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e2780, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0007c0820, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 953
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 366 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc0009c1f18, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000445b80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0009c1ef0, 0xc000aad000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e3180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001296870}, 0x1, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0015adf40?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e3180, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007b7f80, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 268
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 367 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 268
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 457 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 445
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 386 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:125 +0x116
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1 in goroutine 352
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0xe5

goroutine 1141 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f8e08, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ba1b80?, 0xc002c0e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ba1b80, {0xc002c0e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ba1b80, {0xc002c0e000?, 0xc001e01ec8?, 0xc0026f1ce0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0005601b8, {0xc002c0e000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001604900, {0xc002c0e000?, 0x450260?, 0xc001e01ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b5ae40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b5ae40, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001604900)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1139
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1146 [select, 2 minutes]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:384 +0x8b
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1129
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:379 +0x5a

goroutine 390 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc000639208, 0x44)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001397100?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0006391e0, 0xc000aad080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e3220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001296c30}, 0x1, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0018100d0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e3220, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000860000, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 266
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 391 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 266
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 484 [sync.Cond.Wait, 40 minutes]:
sync.runtime_notifyListWait(0xc0011809c8, 0xc8)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000b0e0a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0011809a0, 0xc000eca880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e3ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001256300}, 0x1, 0xc001b23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171aef0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e3ea0, 0xc001b23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000892040, 0xc001b23380)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 270
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 1127 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc00251f000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:391 +0xdc
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x66
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 952
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1ff

goroutine 395 [sync.Cond.Wait, 46 minutes]:
sync.runtime_notifyListWait(0xc0002f96d8, 0x1e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000cda900?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0002f96b0, 0xc000aad0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e32c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0010bf290}, 0x1, 0xc000f61560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001773500?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e32c0, 0xc000f61560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000860060, 0xc000f61560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 269
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 396 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 269
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 511 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b20a80, 0xc000eb8300, 0xc00178d2c0, 0x9eff016665520301?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 458
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 399 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 366
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 89934 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002edc048, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0027fad40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002edc030, {0xc001539a98, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001539a80?}, {0xc001539a98?, 0xc0027face0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc002edc000}, {0xc001539a98, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003b79740, {0xc0030fe400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002711630, 0xc0024384e0?, {0x3f3b448, 0xc003245f40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000bb34e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0024a02c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 401 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 402 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002b03740}, {0x7f6b4e121c58, 0xc0009c1ef0}, {0x3f8d658?, 0x38fdfc0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b202a0, {0x0?, 0x0?}, 0xc0012d6fc0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b202a0, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0002eee00?, {0x3f0dec0, 0xc00077a5f0}, 0x1, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b202a0, 0xc0012d6fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 413 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b202a0, 0xc0012d6fc0, 0xc0012d7da0, 0xc001df1fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 29799 [select, 136 minutes]:
net/http.(*persistConn).writeLoop(0xc00147eea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 29797
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 407 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 390
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 408 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000f977c0}, {0x7f6b4e121c58, 0xc0006391e0}, {0x3f8d658?, 0x38ffa00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b20700, {0x0?, 0x0?}, 0xc0012d7380, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b20700, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0002eeec0?, {0x3f0dec0, 0xc00077a640}, 0x1, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b20700, 0xc0012d7380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 390
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 415 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b20700, 0xc0012d7380, 0xc001870180, 0xc001e1efb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 408
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 9242 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02be80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00270a780?, 0xc001a10000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00270a780, {0xc001a10000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00270a780, {0xc001a10000?, 0xc0028e6ec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000560dc0, {0xc001a10000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013fb560, {0xc001a10000?, 0x450260?, 0xc0028e6ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023d96e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023d96e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013fb560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 9219
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 9243 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc0013fb560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 9219
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 2485 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014880, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0024d6400?, 0xc002462000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0024d6400, {0xc002462000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0024d6400, {0xc002462000?, 0xc001decec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d47d8, {0xc002462000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00165cc60, {0xc002462000?, 0x450260?, 0xc001decec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002454ae0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002454ae0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00165cc60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 2473
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1147 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f8d10, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0017b4300?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0017b4300)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0017b4300)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc001ee1e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc002c134d0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc000706b40, {0x3f44270, 0xc002c134d0})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3f44270?, 0xc002c134d0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:358 +0x78
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1129
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:356 +0x4d9

goroutine 658 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f580, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0017eef60?, 0xc002363eb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0017eef60, {0xc002363eb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0013591f0, {0xc002363eb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000f53b40)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 649
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 450 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc001a3a840, {0x3f99588, 0xc0011813f0}, 0xc0015ade70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:112 +0x585
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:572 +0x51b

goroutine 451 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit(0xc001a3a840, {0x3f59438, 0xc00086a190}, 0xc0015ade70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:79 +0x445
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1045 +0xc5

goroutine 29798 [IO wait, 136 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b5c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00212d600?, 0xc002601000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00212d600, {0xc002601000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00212d600, {0xc002601000?, 0x703620?, 0xc000356640?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016707c0, {0xc002601000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00147eea0, {0xc002601000?, 0xc000159a40?, 0xc002ff2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ed9b00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ed9b00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00147eea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 29797
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 453 [chan receive, 96 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:53 +0x134
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointSliceInit in goroutine 451
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint_slice.go:48 +0x3d8

goroutine 454 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc0019c3780?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 451
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 71871 [select, 46 minutes]:
net/http.(*persistConn).writeLoop(0xc003494c60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 71869
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 461 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018b6960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 462 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018b6ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 463 [sync.Cond.Wait, 40 minutes]:
sync.runtime_notifyListWait(0xc000cf2b50, 0x192)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0018b6960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77160, {0x3f59438, 0xc0007aea50}, 0xc001871140, {0x3f6a810, 0xc000997a40})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 464 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 465 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018b6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 466 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018b6d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 467 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc000cf37d0, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0018b6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f770e0, {0x3f59438, 0xc0007aeb90}, 0xc001871200, {0x3f6a7b8, 0xc0007e2468})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 468 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 469 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018b6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 470 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018b6f60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 446
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 471 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc000cf3f90, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0018b6de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77060, {0x3f59438, 0xc0007aecd0}, 0xc0018712c0, {0x3f6a760, 0xc0007e22e8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 472 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 640 [select, 199 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e23c0, {{{0x3999d77, 0x1b}}, {0x0, 0x0}, 0xc000f13a40, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 477 [sync.Cond.Wait, 178 minutes]:
sync.runtime_notifyListWait(0xc0011807b8, 0xb)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0011538a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001180790, 0xc000eca100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0003e3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc0011bdce0}, 0x1, 0xc001871740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171ad30?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0003e3e00, 0xc001871740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000861fa0, 0xc001871740)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:110 +0x579

goroutine 478 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x7720736578696665?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 18881 [select, 160 minutes]:
net/http.(*persistConn).writeLoop(0xc000d7e5a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 18879
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 480 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0018b7a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 453
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 481 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0018b7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 453
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 482 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc000eca610, 0x67)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x34ba1c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0018b7a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76ee0, {0x3f59438, 0xc0007af270}, 0xc001871920, {0x3f6a658, 0xc00063c678})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 453
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 483 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 453
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 485 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 270
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1120 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f8ff8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ba1200?, 0xc001b4a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ba1200, {0xc001b4a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ba1200, {0xc001b4a000?, 0xc001f02ec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000560168, {0xc001b4a000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001604120, {0xc001b4a000?, 0x450260?, 0xc001f02ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002b5aba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b5aba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001604120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1118
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 2041 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014978, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0021bda80?, 0xc001119000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0021bda80, {0xc001119000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0021bda80, {0xc001119000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0005610e0, {0xc001119000?, 0x0?, 0xc002aed148?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc002aed140, {0xc001119000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc003150ea0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003150ea0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001699b00, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 522 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 523 [select, 199 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:214 +0x1d5
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/operators.go:204 +0x199

goroutine 544 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 529
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 525 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 477
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 526 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc001afed80}, {0x7f6b4e121c58, 0xc001180790}, {0x3f8d658?, 0x38cc0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b21260, {0x0?, 0x0?}, 0xc001871740, 0xc001df85a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b21260, 0xc001871740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000818d80?, {0x3f0dec0, 0xc0008de410}, 0x1, 0xc001871740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b21260, 0xc001871740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 477
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 609 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b21260, 0xc001871740, 0xc00178d5c0, 0xc001dfffb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 526
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 21069 [select, 156 minutes]:
net/http.(*persistConn).writeLoop(0xc00149e480)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 21067
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 505 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 497
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 66553 [select, 56 minutes]:
net/http.(*persistConn).writeLoop(0xc0014ccc60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 66551
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 507 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 497
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 508 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000db4600}, {0x7f6b4e121c58, 0xc001c0ea50}, {0x3f8d658?, 0x38c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000d33420, {0x0?, 0x0?}, 0xc00178cf00, 0xc001989598?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000d33420, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0007b4740?, {0x3f0dec0, 0xc0007a8dc0}, 0x1, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000d33420, 0xc00178cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 497
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 602 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000d33420, 0xc00178cf00, 0xc001b65320, 0xc001f19fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 529 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc001180a78, 0x33)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001025c40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001180a50, 0xc000ecb280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001b3a140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001257590}, 0x1, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171b2d0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001b3a140, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0008931a0, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:808 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:366 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 273
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:364 +0x2a6

goroutine 530 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 273
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 1157 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc000d7efc0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1154
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 533 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 484
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 4066 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014598, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ea6f80?, 0xc001b03000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ea6f80, {0xc001b03000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ea6f80, {0xc001b03000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5ce0, {0xc001b03000?, 0x0?, 0xc0011224e8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0011224e0, {0xc001b03000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002aeecc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002aeecc0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001e9a480, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 535 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 484
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 536 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc002815f40}, {0x7f6b4e121c58, 0xc0011809a0}, {0x3f8d658?, 0x38e2420}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b217a0, {0x0?, 0x0?}, 0xc001b23380, 0x4979746972756365?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b217a0, 0xc001b23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000818fc0?, {0x3f0dec0, 0xc0008de640}, 0x1, 0xc001b23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b217a0, 0xc001b23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 484
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 604 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b217a0, 0xc001b23380, 0xc001b656e0, 0xc001f0cfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 536
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 25473 [select, 146 minutes]:
net/http.(*persistConn).writeLoop(0xc001a28240)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 25455
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 551 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001180b28, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001f1ccc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001180b00, 0xc000ecb840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001b3a1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001a7e000}, 0x1, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171b4d0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001b3a1e0, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000893ca0, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit in goroutine 489
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x317

goroutine 66552 [IO wait, 56 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038b78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00273af00?, 0xc00256b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00273af00, {0xc00256b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00273af00, {0xc00256b000?, 0x703620?, 0xc00329d900?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001359ab8, {0xc00256b000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0014ccc60, {0xc00256b000?, 0xc002d5d740?, 0xc001abbd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00304b4a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00304b4a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0014ccc60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 66551
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 630 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:233 +0xf4
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:231 +0x2f8

goroutine 1124 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f93d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027f7c80?, 0xc00197f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027f7c80, {0xc00197f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027f7c80, {0xc00197f000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d4118, {0xc00197f000?, 0x0?, 0xc0032aa068?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0032aa060, {0xc00197f000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001331a40)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001331a40, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc002afa360, {0x3f59400, 0xc001674c90})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 988
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 546 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 529
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 547 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00244ae00}, {0x7f6b4e121c58, 0xc001180a50}, {0x3f8d658?, 0x38c4ac0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b21b20, {0x0?, 0x0?}, 0xc001b23aa0, 0x1?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b21b20, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000819200?, {0x3f0dec0, 0xc0008de8c0}, 0x1, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b21b20, 0xc001b23aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 529
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 618 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b21b20, 0xc001b23aa0, 0xc0020c63c0, 0xc001f17fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 547
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 89787 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0021c4f00, 0xc002607400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc0000fa190?, 0xc0000fa230?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 536
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 553 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc001180bd8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001f18cc8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001180bb0, 0xc000ecb940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001b3a320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001a7e390}, 0x1, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00171b6d0?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001b3a320, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000893d40, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit in goroutine 489
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:85 +0x4b4

goroutine 9221 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02bc90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002487480?, 0xc0018ef000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002487480, {0xc0018ef000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002487480, {0xc0018ef000?, 0xc001ef1ec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001359758, {0xc0018ef000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000e410e0, {0xc0018ef000?, 0x450260?, 0xc001ef1ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001ed17a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001ed17a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000e410e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 9244
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1083 [syscall, 199 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x29
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x1f

goroutine 1145 [select, 2 minutes]:
github.com/servak/go-fastping.(*Pinger).run(0xc001b8ac60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x5c9
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1129
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x145

goroutine 4741 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0144a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001c2ff00?, 0xc001d97000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001c2ff00, {0xc001d97000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001c2ff00, {0xc001d97000?, 0xc001e1fec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018075f0, {0xc001d97000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00079a5a0, {0xc001d97000?, 0x450260?, 0xc001e1fec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002454360)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002454360, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00079a5a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 4739
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1079 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001331bc0, {0x3f59400, 0xc00074cae0}, 0xc001f3dfd0?, {0x3f445d0, 0xc00172c1b8}, {{{0x0, 0x0, 0x0}}, {0x3f8bac0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1080 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 91206 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002604000, 0xc002c5e900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc002787780?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 458
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 606 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001519180, 0xc001b64a80, 0xc001b65aa0, 0xc001f07fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 597
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 1137 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001604120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1118
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 931 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0024e5e00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 57762 [select, 76 minutes]:
net/http.(*persistConn).writeLoop(0xc000d7e000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 57728
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 90209 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00247b200, 0xc002860d00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc00055b910?, 0xc00055b920?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 591
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 668 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc001c0ed38, 0x2e)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc000144c00?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001c0ed10, 0xc000f97d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0020de960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x447380?, {0x3f0dea0, 0xc001049440}, 0x1, 0xc002126060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001394250?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0020de960, 0xc002126060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x393
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc000565220, 0xc002126060)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc000f29d70, {0x44619c?, 0x29?}, {0x3f5aa90?, 0xc00210ca78}, 0xc002126060)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x556
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:243 +0x4c
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:242 +0x10f

goroutine 2483 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014b68, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0024bb880?, 0xc00245e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0024bb880, {0xc00245e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0024bb880, {0xc00245e000?, 0xc001f4bec8?, 0xc0026f1ce0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d46f8, {0xc00245e000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00165cb40, {0xc00245e000?, 0x450260?, 0xc001f4bec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002454a20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002454a20, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00165cb40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 2465
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1097 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e2a00, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001c3f728, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 953
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1142 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001604900)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1139
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 649 [select, 199 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc0020c9090, {0x3f59438, 0xc0020c9810})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:350 +0x209
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e28c0, {{{0x397d38e, 0x14}}, {0x0, 0x0}, 0xc000081150, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1148 [IO wait]:
internal/poll.runtime_pollWait(0x7f6b4e0f8c18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0017b4600?, 0xc0001d8c00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc0017b4600, {0xc0001d8c00, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x285
net.(*netFD).readFrom(0xc0017b4600, {0xc0001d8c00?, 0x50?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x25
net.(*IPConn).readFrom(0x53ff68?, {0xc0001d8c00, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0xc000560278, {0xc0001d8c00?, 0xc0020a2ec0?, 0xc0020a2e88?})
	/usr/local/go/src/net/iprawsock.go:129 +0x30
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc19f1bc3c107b626?, {0xc0001d8c00?, 0x60ccea0?, 0x60ccea0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x2f
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc001b8ac60, 0xc000d5c0c0, 0xc002b5b320, 0xc000d5c100, 0xc0020a2f10?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x139
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1145
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x377

goroutine 597 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000f5bcc0}, {0x7f6b4e121c58, 0xc001c0eb00}, {0x3f8d658?, 0x38d6500}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001519180, {0x0?, 0x0?}, 0xc001b64a80, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001519180, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000819600?, {0x3f0dec0, 0xc0008df2c0}, 0x1, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001519180, 0xc001b64a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 501
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 596 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 501
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 2484 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc00165cb40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 2465
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 10071 [IO wait, 180 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02baa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0024bbd80?, 0xc001a34000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0024bbd80, {0xc001a34000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0024bbd80, {0xc001a34000?, 0x703620?, 0xc0008908c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001671f20, {0xc001a34000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000c53d40, {0xc001a34000?, 0xc0001599e0?, 0xc0020ebd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001ea9aa0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001ea9aa0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000c53d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 10070
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 62129 [IO wait, 66 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031cd8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ace080?, 0xc00276a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ace080, {0xc00276a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ace080, {0xc00276a000?, 0x703620?, 0xc002d503c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001806350, {0xc00276a000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0028ee120, {0xc00276a000?, 0xc0020c7f20?, 0xc002573d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c8b560)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c8b560, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0028ee120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 62112
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1138 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f94d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001ba1400?, 0xc001b5a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ba1400, {0xc001b5a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001ba1400, {0xc001b5a000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000560170, {0xc001b5a000?, 0x0?, 0xc003460878?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc003460870, {0xc001b5a000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002b5ac60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002b5ac60, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001b8a1b0, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 38607 [select, 116 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f0000)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 38605
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1077 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e2500, {{{0x395302a, 0xa}}, {0x0, 0x0}, 0xc000d93650, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 584 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 551
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 585 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc00275fe80}, {0x7f6b4e121c58, 0xc001180b00}, {0x3f8d658?, 0x38c4540}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0015189a0, {0x0?, 0x0?}, 0xc000eb85a0, 0x656c6269736e6574?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0015189a0, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000819340?, {0x3f0dec0, 0xc0008dec30}, 0x1, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0015189a0, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 551
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 614 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0015189a0, 0xc000eb85a0, 0xc00178dc20, 0xc001755680?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 585
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 3310 [select, 196 minutes]:
net/http.(*persistConn).writeLoop(0xc000d725a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 3308
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91218 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002604048, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0028e4d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002604030, {0xc001550518, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc00155050a?}, {0xc001550518?, 0xc0028e4ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc002604000}, {0xc001550518, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0018e1fb0, {0xc0024f4000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002e3d590, 0xc0032f52c0?, {0x3f3b448, 0xc0034d5940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000cdbb80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001d55240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 458
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 594 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:905 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 501
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:904 +0xab

goroutine 590 [chan receive, 199 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 553
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xab

goroutine 591 [select, 2 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x60ccea0?}, {0x3f3cee0, 0xc000ffebc0}, {0x7f6b4e121c58, 0xc001180bb0}, {0x3f8d658?, 0x38c4280}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:724 +0x17b
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001518e00, {0x0?, 0x0?}, 0xc000eb85a0, 0xc001efdda0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:437 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001518e00, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:357 +0x4c5
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:291 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000819480?, {0x3f0dec0, 0xc0008dedc0}, 0x1, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001518e00, 0xc000eb85a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:290 +0x1cd
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4f
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 553
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 616 [select, 199 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001518e00, 0xc000eb85a0, 0xc0020c6000, 0xc001d23f78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:369 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 591
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:356 +0x49d

goroutine 11907 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02bb98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0020d1b80?, 0xc001b29000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0020d1b80, {0xc001b29000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0020d1b80, {0xc001b29000?, 0xc001f39ec8?, 0xc001183740?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001806e00, {0xc001b29000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001455d40, {0xc001b29000?, 0x450260?, 0xc001f39ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f9e00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f9e00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001455d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 11905
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 4742 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc00079a5a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 4739
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1072 [select, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc00210c9c0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:889 +0x266
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 669
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:881 +0x5a

goroutine 11143 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e015040, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002460380?, 0xc002f8e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002460380, {0xc002f8e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002460380, {0xc002f8e000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d41a0, {0xc002f8e000?, 0x0?, 0xc0010bff58?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0010bff50, {0xc002f8e000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002f78cc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002f78cc0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc0023d1560, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 91555 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0029ee4c8, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0020abb90?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0029ee4b0, {0xc0032ee001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0032ee001?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0008d4780)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0008d4780)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0008d4780, {0x326cdc0, 0xc0032d8c00})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0034471d0, {0xc0000e7c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc003339e50, 0xc0013f6360?, {0x3f3b448, 0xc0032da980})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000b0e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000f5bcc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 597
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 89710 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0027c44c8, 0xb)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc001f45d40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0027c44b0, {0xc00311e920, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc00311e920?}, {0xc00311e920?, 0xc001f45ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc0027c4480}, {0xc00311e920, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003173bd8, {0xc001898500, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0007ae0f0, 0xc00178d3e0?, {0x3f3b448, 0xc0034aa6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00129cf20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000c63140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 197
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 1074 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 992 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1075 [select, 6 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc001331920, {0x3f59400, 0xc00074c4e0}, 0xc00265afd0?, {0x3f445d0, 0xc001807d30}, {{{0xc000bb2140, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:475 +0x425
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 1076 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 1073 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e2280, {{{0x397c75e, 0x14}}, {0x3f43ff0, 0xc001b9ef40}, 0xc0000c84b0, 0x0, 0x3b61ab0, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1062 [select, 80 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000bca5f0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x113
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001a39ea0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x86
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:325 +0xd2
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:322 +0x187e

goroutine 1063 [select, 80 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc0024ec1a0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1138 +0x225
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:328 +0x18c5

goroutine 1123 [select, 199 minutes]:
net/http.(*persistConn).writeLoop(0xc001e486c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1121
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1110 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003568c0, {{{0x3963d99, 0xe}}, {0x3f43ff0, 0xc000df9f80}, 0xc00055a3c0, 0x0, 0x3b61ab0, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 933
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 925 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x105
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:409 +0xcf

goroutine 922 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002511680, {{{0x395ed6d, 0xd}}, {0x0, 0x0}, 0xc001406b58, 0x0, 0x3b61ab0, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 928 [select, 40 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:166 +0x4bd
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:82 +0xa5

goroutine 1156 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f8f00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001859800?, 0xc002bfa000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001859800, {0xc002bfa000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001859800, {0xc002bfa000?, 0xc00265dec8?, 0xc0026f1ce0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5008, {0xc002bfa000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d7efc0, {0xc002bfa000?, 0x450260?, 0xc00265dec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002a94f60)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002a94f60, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d7efc0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1154
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 862 [select, 199 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020e3680, {{{0x39a7c52, 0x1e}}, {0x0, 0x0}, 0xc001321530, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 930
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1122 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f9aa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027f7a00?, 0xc00194d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027f7a00, {0xc00194d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027f7a00, {0xc00194d000?, 0x703620?, 0xc00299ec80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d4110, {0xc00194d000?, 0x0?, 0xc002904680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001e486c0, {0xc00194d000?, 0xc001b22900?, 0xc0028c6d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0013311a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0013311a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001e486c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1121
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 932 [select, 199 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0027cdcc0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0025117c0, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0003e7050, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 933 [chan receive, 40 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001af8fd0?, 0xc0013987f0?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c14e90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1112 [IO wait, 178 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f91e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0029af980?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0029af980)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0029af980)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc001397120)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc001397120)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc0028ec780, {0x3f44240, 0xc001397120})
	/usr/local/go/src/net/http/server.go:3056 +0x364
net/http.(*Server).ListenAndServe(0xc0028ec780)
	/usr/local/go/src/net/http/server.go:2985 +0x71
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1128
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 936 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002511900, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc0014071d0, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 937 [chan receive, 199 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x156
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x36f

goroutine 939 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0028fc000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 942 [select, 199 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3f59438, 0xc0028fa3c0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:761 +0x87
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002511a40, {{{0x39a83d2, 0x1e}}, {0x0, 0x0}, 0xc0003e7680, 0x0, 0x3b61ab0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 943 [chan receive, 40 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc0000967d0?, 0x44619c?)
	/usr/local/go/src/sync/once.go:74 +0xbf
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c14e90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 989 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 945 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002511b80, {{{0x396ce5d, 0x10}}, {0x0, 0x0}, 0xc001407350, 0x0, 0x3b61ab0, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 946 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f298, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0028d4f00?, 0xc002d3feb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0028d4f00, {0xc002d3feb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0013d49a0, {0xc002d3feb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0011efb00)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 988 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f96c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc000b9ca80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b9ca80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc000b9ca80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc002a01e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc00074b560)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc000f1d2c0, {0x3f44270, 0xc00074b560})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3f44270?, 0xc00074b560?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:475 +0x78
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:473 +0x4f9

goroutine 949 [select, 199 minutes]:
github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start.func1()
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:144 +0xc8
created by github.com/cilium/cilium/pkg/ipmasq.(*IPMasqAgent).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipmasq/ipmasq.go:142 +0x16d

goroutine 8563 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02bd88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ef4700?, 0xc0021a0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ef4700, {0xc0021a0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ef4700, {0xc0021a0000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b3980, {0xc0021a0000?, 0x0?, 0xc0016d7088?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0016d7080, {0xc0021a0000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc0025b2060)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0025b2060, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00212ec60, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 952 [sleep, 2 minutes]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x125
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc0028fe4b0, 0x0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x5b1
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x21e

goroutine 953 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00299e000, {{{0x395ed53, 0xd}}, {0x0, 0x0}, 0xc000ccdd00, 0x0, 0xc001407db8, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 954 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 955 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 956 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 957 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 958 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 959 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 960 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 961 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 962 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 963 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 964 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 965 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 966 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 967 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 968 [select, 2 minutes]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x12d
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 969 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f1a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0028f2780?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0028f2780)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0028f2780)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000ccdd60)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000ccdd60)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
net/http.(*Server).Serve(0xc00016c3c0, {0x3f44240, 0xc000ccdd60})
	/usr/local/go/src/net/http/server.go:3056 +0x364
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc000c2e600, 0xe}, {0x3f44240, 0xc000ccdd60})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xcf
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x67e

goroutine 91748 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00295a300, 0xc002d6b900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0026ad800?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 424
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 27659 [select, 140 minutes]:
net/http.(*persistConn).writeLoop(0xc000d7f7a0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 27657
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 973 [select]:
github.com/cilium/cilium/pkg/hive/cell.(*scope).start.func1()
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:166 +0x10a
created by github.com/cilium/cilium/pkg/hive/cell.(*scope).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/cell/structured.go:162 +0xa5

goroutine 974 [chan receive, 96 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc0018e8c20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001331500, {0x3f59400, 0xc00299da40}, 0x2be1c6b?, {0x3f445d0, 0xc0018069f0}, {{{0xc0013ed9e0, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 975 [chan receive, 96 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0xc0018eac20, 0x0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:88 +0x1c5
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001331560, {0x3f59400, 0xc00299db90}, 0x2be1c6b?, {0x3f445d0, 0xc0018069f0}, {{{0xc001826180, 0x1, 0x1}}, {0x3f8b9d0, ...}, ...})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:347 +0x6b2
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:162 +0x196

goroutine 998 [syscall, 199 minutes]:
syscall.Syscall6(0xc001236188?, 0x0?, 0xc002a06ce0?, 0x446db1?, 0x0?, 0xc002a06d68?, 0xc0029a11e0?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
os.(*Process).blockUntilWaitable(0xc002d83a40)
	/usr/local/go/src/os/wait_waitid.go:32 +0x76
os.(*Process).wait(0xc002d83a40)
	/usr/local/go/src/os/exec_unix.go:22 +0x25
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0xc002abd1e0)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 953
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4d9

goroutine 999 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0028fc960)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 953
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1066 [select, 199 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000bca820, {0xc00004e4c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000bca820, {0xc00004e4c0?, 0xc002aadcc8?, 0xc0019f9550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0003f1cb0, {0xc00004e4c0?, 0xc0019f95c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc0003f1cb0}, {0xc00004e4c0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0011e7b00, {0xc00004e4c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc00004e4b0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc0019f97a8?, 0xc0011e7b00, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc00004e4b0, {0x7f6b4e010290, 0x6628060}, 0xc0019f9818?, {0x0, 0x0}, {0x37a56a0, 0xc0020dfc20}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00016c4b0, {0x37a56a0?, 0xc0020dfc20})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc000a09460)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00172c488?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1065
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 1064 [IO wait, 80 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f95c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001309780?, 0xc0019da000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001309780, {0xc0019da000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001309780, {0xc0019da000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d4250, {0xc0019da000?, 0xc001dabc10?, 0x3?})
	/usr/local/go/src/net/net.go:179 +0x45
bufio.(*Reader).Read(0xc00186cde0, {0xc001b3ef20, 0x9, 0x7f6b9515c108?})
	/usr/local/go/src/bufio/bufio.go:244 +0x197
io.ReadAtLeast({0x3f07920, 0xc00186cde0}, {0xc001b3ef20, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc001b3ef20, 0x9, 0xc002c26f60?}, {0x3f07920?, 0xc00186cde0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001b3eee0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x85
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc0024ec1a0, {0x3f59400, 0xc0003f19b0}, 0x6628060?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:617 +0x15d
google.golang.org/grpc.(*Server).serveStreams(0xc000629200, {0x3f592e8?, 0x6628060?}, {0x3f71660?, 0xc0024ec1a0}, {0x3f6a138?, 0xc0013d4250?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x3e2
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d8

goroutine 1065 [select, 199 minutes]:
reflect.rselect({0xc00187d200, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc000aa7200?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc000d661b0, {0x3f59400, 0xc00004ecf0}, 0xc00039fa40, {0x7f6b4e0102b8, 0xc000a09460}, 0xc0018d6780, {0x3a15de3?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc000d661b0, {0x3f59400, 0xc00004ecf0}, {0x7f6b4e0102b8?, 0xc000a09460?}, {0x3a15de3, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc00265fa88?, {0x3f6d7f8, 0xc000a09460})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x6e
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x38335e0?, 0xc000d661b0}, {0x3f640d8?, 0xc00016c4b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc000629200, {0x3f59400, 0xc0003f1f80}, {0x3f71660, 0xc0024ec1a0}, 0xc0011e7b00, 0xc000c18f30, 0x608ff20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc000629200, {0x3f71660, 0xc0024ec1a0}, 0xc0011e7b00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1064
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 64352 [IO wait, 60 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038c70, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001c2e280?, 0xc001118000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001c2e280, {0xc001118000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001c2e280, {0xc001118000?, 0x703620?, 0xc0008917c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001670a90, {0xc001118000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d739e0, {0xc001118000?, 0xc002fa7560?, 0xc002661d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003020840)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003020840, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d739e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 64351
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 76960 [IO wait, 36 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0386a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00248f100?, 0xc002782000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00248f100, {0xc002782000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00248f100, {0xc002782000?, 0x703620?, 0xc002d50000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001712f30, {0xc002782000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0005fad80, {0xc002782000?, 0xc002526a20?, 0xc0027f8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ed9200)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ed9200, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0005fad80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 76959
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 92064 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014f48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003443280?, 0xc00345e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003443280, {0xc00345e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003443280, {0xc00345e000?, 0x703620?, 0xc002511cc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144b810, {0xc00345e000?, 0x0?, 0xc000fa7520?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001595680, {0xc00345e000?, 0xc002735ec0?, 0xc0030e4d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003450de0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003450de0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001595680)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 92063
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 16682 [IO wait, 166 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b4d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00310d900?, 0xc0026cc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00310d900, {0xc0026cc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00310d900, {0xc0026cc000?, 0x703620?, 0xc002d51180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b29a8, {0xc0026cc000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001b00c60, {0xc0026cc000?, 0xc0029a8c60?, 0xc001f09d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002d0e540)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002d0e540, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001b00c60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 16681
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 25456 [IO wait, 146 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b1e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003171900?, 0xc002544000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003171900, {0xc002544000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003171900, {0xc002544000?, 0x703620?, 0xc000d99540?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013596a8, {0xc002544000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001a28240, {0xc002544000?, 0xc0027ca240?, 0xc001ab8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002d0e0c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002d0e0c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001a28240)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 25455
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 59971 [select, 70 minutes]:
net/http.(*persistConn).writeLoop(0xc00142ad80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 59969
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 12300 [select, 176 minutes]:
net/http.(*persistConn).writeLoop(0xc000255b00)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 12298
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 42960 [IO wait, 106 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0320b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002801980?, 0xc00277c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002801980, {0xc00277c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002801980, {0xc00277c000?, 0x703620?, 0xc0008d4f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d4030, {0xc00277c000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000c52d80, {0xc00277c000?, 0xc002d5c300?, 0xc001900d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ed9860)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ed9860, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000c52d80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 42959
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 32026 [select, 130 minutes]:
net/http.(*persistConn).writeLoop(0xc000c538c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 32024
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 2486 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc00165cc60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 2473
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 23271 [IO wait, 150 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0141b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002729f80?, 0xc0025cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002729f80, {0xc0025cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002729f80, {0xc0025cb000?, 0x703620?, 0xc000d99040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b2118, {0xc0025cb000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d7e120, {0xc0025cb000?, 0xc000f60180?, 0xc0018e6d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00311d860)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00311d860, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d7e120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 23270
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 55563 [select, 80 minutes]:
net/http.(*persistConn).writeLoop(0xc0028ee480)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 55561
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1194 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014e50, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0021bd000?, 0xc002cc3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0021bd000, {0xc002cc3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0021bd000, {0xc002cc3000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5218, {0xc002cc3000?, 0x0?, 0xc002cc8ff8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc002cc8ff0, {0xc002cc3000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc000d3f140)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc000d3f140, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001bdddd0, {0x3f59400, 0xc001674c90})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 988
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 42993 [select, 106 minutes]:
net/http.(*persistConn).writeLoop(0xc000c52d80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 42959
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 47620 [IO wait, 96 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031610, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003b8cd00?, 0xc003af3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003b8cd00, {0xc003af3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003b8cd00, {0xc003af3000?, 0x703620?, 0xc003ba4000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00167c4e8, {0xc003af3000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003b9e360, {0xc003af3000?, 0xc000eb8d80?, 0xc0030e6d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003ba06c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003ba06c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003b9e360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 47619
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 57761 [IO wait, 76 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038d68, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001869400?, 0xc002575000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001869400, {0xc002575000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001869400, {0xc002575000?, 0x703620?, 0xc00329c640?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001671988, {0xc002575000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d7e000, {0xc002575000?, 0xc002492e40?, 0xc0020a8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002ed9560)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002ed9560, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d7e000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 57728
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1207 [select, 199 minutes]:
reflect.rselect({0xc0007db680, 0x9, 0x419188?})
	/usr/local/go/src/runtime/select.go:589 +0x2c5
reflect.Select({0xc00251ea00?, 0x9, 0x39a9ff2?})
	/usr/local/go/src/reflect/value.go:3104 +0x5ea
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc000d661b0, {0x3f59400, 0xc002c2bf80}, 0xc0002b5960, {0x7f6b4e015238, 0xc000446f00}, 0xc002b28180, {0x3a0d583?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:259 +0x936
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc000d661b0, {0x3f59400, 0xc002c2bf80}, {0x7f6b4e015238?, 0xc000446f00?}, {0x3a0d583, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:170 +0x33d
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc0018e6a88?, {0x3f6d6f0, 0xc000446f00})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x6e
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x38335e0?, 0xc000d661b0}, {0x3f640d8?, 0xc000706e10})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x91
google.golang.org/grpc.(*Server).processStreamingRPC(0xc000629200, {0x3f59400, 0xc002c2be90}, {0x3f71660, 0xc0024ec1a0}, 0xc0007da480, 0xc000c18de0, 0x608fe80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1679 +0x1288
google.golang.org/grpc.(*Server).handleStream(0xc000629200, {0x3f71660, 0xc0024ec1a0}, 0xc0007da480)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1800 +0xf9b
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1064
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x135

goroutine 1195 [runnable]:
github.com/cilium/cilium/pkg/monitor/agent.(*listenerv1_2).drainQueue(0xc002cc9020)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:54 +0x265
created by github.com/cilium/cilium/pkg/monitor/agent.newListenerv1_2 in goroutine 227
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/listener1_2.go:33 +0xd6

goroutine 1208 [select, 199 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0007d7f40, {0xc002c2bf30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:180 +0x8a
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0007d7f40, {0xc002c2bf30?, 0xc002c27218?, 0xc002387550?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:174 +0x15b
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc002c2be00, {0xc002c2bf30?, 0xc0023875c8?, 0x1bc3d65?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:520 +0x2c
io.ReadAtLeast({0x3f18980, 0xc002c2be00}, {0xc002c2bf30, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0007da480, {0xc002c2bf30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:504 +0x96
google.golang.org/grpc.(*parser).recvMsg(0xc002c2bf20, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:600 +0x46
google.golang.org/grpc.recvAndDecompress(0xc0023877a8?, 0xc0007da480, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:734 +0x5a
google.golang.org/grpc.recv(0xc002c2bf20, {0x7f6b4e010290, 0x6628060}, 0xc002387818?, {0x0, 0x0}, {0x37a56a0, 0xc0003e3040}, 0x3?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:800 +0xa6
google.golang.org/grpc.(*serverStream).RecvMsg(0xc000706e10, {0x37a56a0?, 0xc0003e3040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0x16a
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc000446f00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x46
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000c14e90?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:137 +0xd7
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1207
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:134 +0x2f6

goroutine 1209 [sync.Cond.Wait, 199 minutes]:
sync.runtime_notifyListWait(0xc0016f2d90, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0002b7c70?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc0016f2d40, {0x3f59438, 0xc0007d7f90}, {0xc001661bc0, 0x33}, 0x1, {0xc0009fb405, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x8bd
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1207
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:371 +0x16b2

goroutine 1052 [select, 199 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x17c
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1038
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x226

goroutine 1030 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00299e780, {{{0x3952850, 0xa}}, {0x0, 0x0}, 0x3b623c8, 0x0, 0x3b61ab0, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9b9
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 970
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1031 [select, 6 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0xe?, {0x3f59438, 0xc00086a190})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xfe
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:199 +0x19fc

goroutine 1032 [runnable]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc00299e8c0)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x98
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:211 +0x1bdb

goroutine 1033 [runnable]:
syscall.Syscall6(0xc001235fc0?, 0xc001236650?, 0x409280?, 0xc001b13040?, 0xc001623838?, 0x1000000004df2f0?, 0x3f07220?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x30
golang.org/x/sys/unix.EpollWait(0xffffffffffffff00?, {0xc002aad938?, 0x6069af0?, 0x3f07220?}, 0x227d925?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:127
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc000dc6fa0, {0xc002aad938?, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2a5
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc002d72300, 0xc00039ee70?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:354 +0x2c5
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:328
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc001a39650, {0x3f59438, 0xc0008bc050})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x495
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 970
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 1034 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e40f0a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001a0c780?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a0c780)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001a0c780)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x447380?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc001a1c420)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc002d8b400, {0x3f44270?, 0xc001a1c420})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:255 +0x4d
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:254 +0x286b

goroutine 1035 [chan receive, 199 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:260 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:259 +0x28dd

goroutine 1036 [IO wait, 199 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f99a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001331320?, 0xc002e93eb0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001331320, {0xc002e93eb0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0013d4120, {0xc002e93eb0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0012350c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xd2
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 970
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 1037 [select, 199 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc001a1cab0)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xd1
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 970
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1e5

goroutine 1054 [chan receive, 199 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:326 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:325 +0x3479

goroutine 1053 [IO wait, 184 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f97b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001a0de00?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a0de00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001a0de00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000dc7460)
	/usr/local/go/src/net/tcpsock_posix.go:152 +0x1e
net.(*TCPListener).Accept(0xc000dc7460)
	/usr/local/go/src/net/tcpsock.go:315 +0x30
google.golang.org/grpc.(*Server).Serve(0xc000aa7000, {0x3f44240?, 0xc000dc7460})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x462
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:317 +0x56
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 970
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:316 +0x3405

goroutine 1041 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001331f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 974
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1042 [select, 2 minutes]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001e04060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 974
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 1043 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc001235190, 0x24)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x1?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001331f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f77460, {0x3f59438, 0xc0008bc410}, 0xc001b06f00, {0x3f6aa20, 0xc000d67458})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 974
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1044 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 974
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 91749 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00295a348, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002ff3c48?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00295a330, {0xc001177200, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001177200?}, {0xc001177200?, 0xc002ff3ce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc00295a300}, {0xc001177200, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc003b78c18, {0xc00278f000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002577180, 0x8?, {0x3f3b448, 0xc002404200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000394200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002404180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 424
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 1046 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001e04480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 975
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1ba

goroutine 1047 [select, 2 minutes]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001e045a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 975
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x21f

goroutine 1048 [sync.Cond.Wait, 96 minutes]:
sync.runtime_notifyListWait(0xc001235310, 0x85)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x4?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001e04480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x99
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:685
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3f76fe0, {0x3f59438, 0xc0008bc5a0}, 0xc001b07320, {0x3f6a708, 0xc00157d7a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:609 +0x144
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:498 +0x33a
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 975
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:464 +0x586

goroutine 1049 [select, 199 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x137
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 975
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x64a

goroutine 3309 [IO wait, 196 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014788, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00245ca00?, 0xc002466000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00245ca00, {0xc002466000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00245ca00, {0xc002466000?, 0x703620?, 0xc000d98c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001359e48, {0xc002466000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d725a0, {0xc002466000?, 0xc0024921e0?, 0xc001ef5d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002433f80)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002433f80, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d725a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 3308
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 34227 [IO wait, 126 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0323a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002445f00?, 0xc002868000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002445f00, {0xc002868000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002445f00, {0xc002868000?, 0x703620?, 0xc000480c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5ef8, {0xc002868000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0012d9e60, {0xc002868000?, 0xc000f614a0?, 0xc0030e2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002d0e180)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002d0e180, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0012d9e60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 34226
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 38606 [IO wait, 116 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e032498, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001da3900?, 0xc002750000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001da3900, {0xc002750000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001da3900, {0xc002750000?, 0x703620?, 0xc00299f680?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016717a8, {0xc002750000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f0000, {0xc002750000?, 0xc0012d73e0?, 0xc001907d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c1d2c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c1d2c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f0000)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 38605
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 74770 [IO wait, 40 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b9a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0024bbb80?, 0xc001777000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0024bbb80, {0xc001777000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0024bbb80, {0xc001777000?, 0x703620?, 0xc002d51cc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b2760, {0xc001777000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001423560, {0xc001777000?, 0xc002acd380?, 0xc001906d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f8900)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f8900, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001423560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 74769
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 1883 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014a70, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0027f7780?, 0xc002e56000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0027f7780, {0xc002e56000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0027f7780, {0xc002e56000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0005606d8, {0xc002e56000?, 0x0?, 0xc001ac8008?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001ac8000, {0xc002e56000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002e4ecc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e4ecc0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001c43dd0, {0x3f59400, 0xc003307a70})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1112
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 64369 [select, 60 minutes]:
net/http.(*persistConn).writeLoop(0xc000d739e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 64351
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91559 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0024d0900, 0xc0029aa700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc000dc8a30?, 0xc000dc8a40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 1602 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001408120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 1599
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 1601 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014c60, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003153480?, 0xc003164000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003153480, {0xc003164000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003153480, {0xc003164000?, 0xc003143ec8?, 0xc001183740?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000561398, {0xc003164000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001408120, {0xc003164000?, 0x450260?, 0xc003143ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003150ba0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003150ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001408120)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 1599
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 92081 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001595680)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 92063
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 46910 [select, 50 minutes]:
net/http.(*persistConn).writeLoop(0xc00142a900)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 46908
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 5536 [IO wait, 190 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0142b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00270bf00?, 0xc0019d6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00270bf00, {0xc0019d6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00270bf00, {0xc0019d6000?, 0x703620?, 0xc000891e00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001712a70, {0xc0019d6000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00142a360, {0xc0019d6000?, 0xc002d5de60?, 0xc0028c8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0032e51a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0032e51a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00142a360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 5564
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 90198 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00247b248, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f3a330?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00247b230, {0xc002500c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002500c01?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc00340d2c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00340d2c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc00340d2c0, {0x326cdc0, 0xc0032bd980})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001049ef0, {0xc00280fc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0008dea50, 0xc002b28f00?, {0x3f3b448, 0xc0032b3340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000cdab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000ffebc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 591
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 9222 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc000e410e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 9244
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 21068 [IO wait, 156 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b2e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001e16500?, 0xc002740000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001e16500, {0xc002740000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001e16500, {0xc002740000?, 0x703620?, 0xc002511180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000560fe0, {0xc002740000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00149e480, {0xc002740000?, 0xc002527920?, 0xc00324cd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00296d140)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00296d140, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00149e480)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 21067
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 12299 [IO wait, 176 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b7b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002816180?, 0xc002767000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002816180, {0xc002767000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002816180, {0xc002767000?, 0x703620?, 0xc00299edc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001807b58, {0xc002767000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000255b00, {0xc002767000?, 0xc001871c80?, 0xc001ef2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c1cc00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c1cc00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000255b00)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 12298
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 89788 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0021c4f48, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f37be8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0021c4f30, {0xc0024e1801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0024e1801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0008d4c80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0008d4c80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0008d4c80, {0x326cdc0, 0xc0032d8720})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001c1d890, {0xc00278f400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0024d2320, 0xc002d87440?, {0x3f3b448, 0xc0032da480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000da44c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002815f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 536
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 10072 [select, 180 minutes]:
net/http.(*persistConn).writeLoop(0xc000c53d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 10070
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 7862 [select, 186 minutes]:
net/http.(*persistConn).writeLoop(0xc001b00360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 7860
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 50527 [select, 90 minutes]:
net/http.(*persistConn).writeLoop(0xc001b01320)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 50525
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 45149 [IO wait, 100 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031fc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bf1180?, 0xc001b11000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bf1180, {0xc001b11000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bf1180, {0xc001b11000?, 0x703620?, 0xc000891b80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001806fd0, {0xc001b11000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001e48900, {0xc001b11000?, 0xc002439e00?, 0xc002fefd38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00332b860)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00332b860, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001e48900)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 45148
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 4737 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e014690, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001c2f880?, 0xc001c47000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001c2f880, {0xc001c47000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001c2f880, {0xc001c47000?, 0xc001e59ec8?, 0xc001b6b080?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0018075a8, {0xc001c47000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000451d40, {0xc001c47000?, 0x450260?, 0xc001e59ec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002454120)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002454120, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000451d40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 4719
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 7861 [IO wait, 186 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0143a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00244f480?, 0xc002690000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00244f480, {0xc002690000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00244f480, {0xc002690000?, 0x703620?, 0xc000890c80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b31c0, {0xc002690000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001b00360, {0xc002690000?, 0xc0021320c0?, 0xc0017c7d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00268c420)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00268c420, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001b00360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 7860
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 46911 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0318f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002fab300?, 0xc001b6e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002fab300, {0xc001b6e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002fab300, {0xc001b6e000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001670e80, {0xc001b6e000?, 0x0?, 0xc0032ce428?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0032ce420, {0xc001b6e000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc003021020)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003021020, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc000c0de60, {0x3f59400, 0xc002c13650})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1147
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 32025 [IO wait, 130 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02aff8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00280c180?, 0xc001aa6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00280c180, {0xc001aa6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00280c180, {0xc001aa6000?, 0x703620?, 0xc0004aa280?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5c10, {0xc001aa6000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000c538c0, {0xc001aa6000?, 0xc0021c34a0?, 0xc003247d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00332a180)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00332a180, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000c538c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 32024
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 74771 [select, 40 minutes]:
net/http.(*persistConn).writeLoop(0xc001423560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 74769
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 14513 [select, 170 minutes]:
net/http.(*persistConn).writeLoop(0xc001605c20)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 14495
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 81355 [IO wait, 26 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0f92e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00212cb80?, 0xc002683000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00212cb80, {0xc002683000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00212cb80, {0xc002683000?, 0x703620?, 0xc000480f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001713cc0, {0xc002683000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0012d8b40, {0xc002683000?, 0xc002b75740?, 0xc001e88d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002764f00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002764f00, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0012d8b40)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 81354
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 11903 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b8b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0020d1680?, 0xc001b19000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0020d1680, {0xc001b19000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0020d1680, {0xc001b19000?, 0xc001dbaec8?, 0xc001183740?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001806d98, {0xc001b19000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0014558c0, {0xc001b19000?, 0x450260?, 0xc001dbaec8?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f9bc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f9bc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0014558c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 11901
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 40777 [select, 110 minutes]:
net/http.(*persistConn).writeLoop(0xc0017fe6c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 40775
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 40776 [IO wait, 110 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0321b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002e76400?, 0xc001e4d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002e76400, {0xc001e4d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002e76400, {0xc001e4d000?, 0x703620?, 0xc002510f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00172c250, {0xc001e4d000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0017fe6c0, {0xc001e4d000?, 0xc00178d4a0?, 0xc001912d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f80c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f80c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0017fe6c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 40775
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 27658 [IO wait, 140 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b0f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0028f2880?, 0xc0019f8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0028f2880, {0xc0019f8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0028f2880, {0xc0019f8000?, 0x703620?, 0xc002510dc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001807e40, {0xc0019f8000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d7f7a0, {0xc0019f8000?, 0xc002439980?, 0xc001f05d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003102540)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003102540, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d7f7a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 27657
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 45150 [select, 100 minutes]:
net/http.(*persistConn).writeLoop(0xc001e48900)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 45148
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91341 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002429c80, 0xc00289c400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc0007c1ee0?, 0xc0007c1f50?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 372
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 16683 [select, 166 minutes]:
net/http.(*persistConn).writeLoop(0xc001b00c60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 16681
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 18880 [IO wait, 160 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b3d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001bf0a00?, 0xc0017c4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001bf0a00, {0xc0017c4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001bf0a00, {0xc0017c4000?, 0x703620?, 0xc0009ef7c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00172d730, {0xc0017c4000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc000d7e5a0, {0xc0017c4000?, 0xc00178d7a0?, 0xc001902d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc003216120)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc003216120, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc000d7e5a0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 18879
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 91560 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0024d0948, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x662bc50?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0024d0930, {0xc0021d7801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0021d7801?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0008d5a40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0008d5a40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0008d5a40, {0x326cdc0, 0xc0033f59f8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0039e9200, {0xc001c7e800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0024f6370, 0xc0012fd9e0?, {0x3f3b448, 0xc0031e76c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000b0f400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000db4600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 508
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 23272 [select, 150 minutes]:
net/http.(*persistConn).writeLoop(0xc000d7e120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 23270
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91554 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0029ee480, 0xc0027ad100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc000dc8a30?, 0xc000dc8a40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 597
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 83534 [select, 20 minutes]:
net/http.(*persistConn).writeLoop(0xc0016059e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 83532
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91619 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0021dac48, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc0019eed40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0021dac30, {0xc0014b0330, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc0014b0330?}, {0xc0014b0330?, 0xc0019eece0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc0021dac00}, {0xc0014b0330, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0027184f8, {0xc001c7f400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0024cbd10, 0xc00305e180?, {0x3f3b448, 0xc0034447c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001354c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000f977c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 408
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 47621 [select, 96 minutes]:
net/http.(*persistConn).writeLoop(0xc003b9e360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 47619
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 11908 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001455d40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 11905
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91174 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0026f9b48, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f38020?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0026f9b30, {0xc0024e0601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc0024e0601?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0004aaa00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0004aaa00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0004aaa00, {0x326cdc0, 0xc0034d6768})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0032a9200, {0xc0000e6c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002e0e050, 0xc000c050e0?, {0x3f3b448, 0xc0034d4740})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000716900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001ba8040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 216
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 14496 [IO wait, 170 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e02b6c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002e77500?, 0xc001793000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002e77500, {0xc001793000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002e77500, {0xc001793000?, 0x703620?, 0xc0004aa140?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b31d0, {0xc001793000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001605c20, {0xc001793000?, 0xc00262b500?, 0xc001f38d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00332b680)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00332b680, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001605c20)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 14495
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 36423 [IO wait, 120 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0322a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002729900?, 0xc001980000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002729900, {0xc001980000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002729900, {0xc001980000?, 0x703620?, 0xc00299f040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001807ad0, {0xc001980000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001a4eea0, {0xc001980000?, 0xc002f44c00?, 0xc00265ad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00332b7a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00332b7a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001a4eea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 36422
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 46917 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031dd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00250be80?, 0xc001ac4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00250be80, {0xc001ac4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00250be80, {0xc001ac4000?, 0x703620?, 0xc000d99a40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000560888, {0xc001ac4000?, 0x0?, 0xc002879a00?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f3320, {0xc001ac4000?, 0xc0018d6ba0?, 0xc0020e8d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002e4f680)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002e4f680, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f3320)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 46916
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 89933 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002edc000, 0xc002d6bd00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc001a1c030?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 378
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 59970 [IO wait, 70 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031ae8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00237cd00?, 0xc002574000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00237cd00, {0xc002574000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00237cd00, {0xc002574000?, 0x703620?, 0xc000891040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001807900, {0xc002574000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc00142ad80, {0xc002574000?, 0xc002795f80?, 0xc001ee2d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc00311d680)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc00311d680, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc00142ad80)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 59969
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 50526 [IO wait, 90 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001d53a00?, 0xc0010f7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001d53a00, {0xc0010f7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001d53a00, {0xc0010f7000?, 0x703620?, 0xc000357400?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001671a50, {0xc0010f7000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001b01320, {0xc0010f7000?, 0xc00305f980?, 0xc001abed38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002140300)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002140300, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001b01320)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 50525
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 85741 [IO wait, 16 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0382c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0021ce300?, 0xc0026d9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0021ce300, {0xc0026d9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0021ce300, {0xc0026d9000?, 0x703620?, 0xc00340c8c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001712fa0, {0xc0026d9000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f3560, {0xc0026d9000?, 0xc000c05c80?, 0xc002571d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c1dda0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c1dda0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f3560)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 85740
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 89855 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002136c00, 0xc002d6a000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0x3f59400?, 0xc001a1c030?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 526
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 46905 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0319f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002461100?, 0xc001a36000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002461100, {0xc001a36000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002461100, {0xc001a36000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001670d48, {0xc001a36000?, 0x0?, 0xc0010480f8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc0010480f0, {0xc001a36000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc001ea9740)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001ea9740, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc001e090e0, {0x3f59400, 0xc001674c90})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 988
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 89856 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002136c48, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f38020?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002136c30, {0xc002ef8601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002ef8601?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0020e3180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0020e3180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0020e3180, {0x326cdc0, 0xc0034d6780})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00333d0e0, {0xc00278f800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002653590, 0xc0020fc480?, {0x3f3b448, 0xc0034d4780})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000860c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001afed80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 526
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 36424 [select, 120 minutes]:
net/http.(*persistConn).writeLoop(0xc001a4eea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 36422
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 34228 [select, 126 minutes]:
net/http.(*persistConn).writeLoop(0xc0012d9e60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 34226
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 53357 [IO wait, 86 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031708, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002c89100?, 0xc002946000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002c89100, {0xc002946000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002c89100, {0xc002946000?, 0x703620?, 0xc0025108c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc000561e90, {0xc002946000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001b00ea0, {0xc002946000?, 0xc0021334a0?, 0xc001f3ad38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002d0e300)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002d0e300, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001b00ea0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 53356
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 89458 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc002a9b9c8, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0xc002c1fd40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc002a9b9b0, {0xc000cbaf50, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc000cbaf50?}, {0xc000cbaf50?, 0xc002c1fce0?, 0x40e72c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
io.ReadAtLeast({0x7f6b4e0e5500, 0xc002a9b980}, {0xc000cbaf50, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00266ce70, {0xc00278e800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x85
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002e748c0, 0xc0018e3b60?, {0x3f3b448, 0xc001c0ab80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001362340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc002b03740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 91609 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0021dac00, 0xc002607d00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0024f8140?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 408
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 68981 [select, 50 minutes]:
net/http.(*persistConn).writeLoop(0xc001ace360)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 68979
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 71870 [IO wait, 46 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038890, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc00349a380?, 0xc00349e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00349a380, {0xc00349e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00349a380, {0xc00349e000?, 0x703620?, 0xc002d51040?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014b9180, {0xc00349e000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc003494c60, {0xc00349e000?, 0xc000f60900?, 0xc001905d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002a5efc0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002a5efc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc003494c60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 71869
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 76977 [select, 36 minutes]:
net/http.(*persistConn).writeLoop(0xc0005fad80)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 76959
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 92060 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc001595560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 92058
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 90101 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0381c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003152080?, 0xc0025d3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003152080, {0xc0025d3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003152080, {0xc0025d3000?, 0x703620?, 0xc000d99e00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014b8690, {0xc0025d3000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f06c0, {0xc0025d3000?, 0xc0018c3aa0?, 0xc0030c3d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002c1c480)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002c1c480, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f06c0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 90100
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 53358 [select, 86 minutes]:
net/http.(*persistConn).writeLoop(0xc001b00ea0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 53356
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 92061 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0384b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003443100?, 0xc001ebc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003443100, {0xc001ebc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003443100, {0xc001ebc000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144b7e8, {0xc001ebc000?, 0x0?, 0xc001a44a58?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001a44a50, {0xc001ebc000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002cb9920)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002cb9920, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00343e630, {0x3f59400, 0xc002c13650})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 1147
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 87913 [select, 10 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f19e0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 87911
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 68980 [IO wait, 50 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0385a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc001e8d280?, 0xc00275c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001e8d280, {0xc00275c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001e8d280, {0xc00275c000?, 0x703620?, 0xc000d98f00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013d5230, {0xc00275c000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc001ace360, {0xc00275c000?, 0xc002492a20?, 0xc00191ed38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023c0480)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023c0480, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc001ace360)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 68979
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 85742 [select, 16 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f3560)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 85740
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 91173 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0026f9b00, 0xc002c5e500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc000ca21d0?, 0xc000ca21e0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 216
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 55562 [IO wait, 80 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e031ec8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003e8ee80?, 0xc003af2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003e8ee80, {0xc003af2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003e8ee80, {0xc003af2000?, 0x703620?, 0xc000891400?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014b8fa8, {0xc003af2000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0028ee480, {0xc003af2000?, 0xc0029a9800?, 0xc003249d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc001ea8180)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc001ea8180, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0028ee480)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 55561
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 88842 [select, 8 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002c04600, 0xc0027ade00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc001b07e60?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 547
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 91660 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0027b9548, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f444e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0027b9530, {0xc001ebf400, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0xc001260270?}, {0xc001ebf400?, 0xc00131f300?, 0x7f6b00000073?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc00340da40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00340da40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc00340da40, {0x326cdc0, 0xc0014b3410})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc002aaf650, {0xc0024f5400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00268f130, 0x662d400?, {0x3f3b448, 0xc003245600})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013edb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc003245180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 673
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 90668 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00288d800, 0xc0029aa800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc0000faac0?, 0xc0000faae0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 585
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 62130 [select, 66 minutes]:
net/http.(*persistConn).writeLoop(0xc0028ee120)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 62112
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 92082 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038798, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc003443500?, 0xc001e97000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc003443500, {0xc001e97000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc003443500, {0xc001e97000?, 0x4e51a5?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00144b818, {0xc001e97000?, 0x0?, 0xc001a44de8?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*connReader).Read(0xc001a44de0, {0xc001e97000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:791 +0x14b
bufio.(*Reader).fill(0xc002455aa0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002455aa0, 0x4)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*conn).serve(0xc00343e990, {0x3f59400, 0xc001674c90})
	/usr/local/go/src/net/http/server.go:2044 +0x75c
created by net/http.(*Server).Serve in goroutine 988
	/usr/local/go/src/net/http/server.go:3086 +0x5cb

goroutine 91687 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0027b9500, 0xc002d6b600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc002b03740?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 673
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 79134 [IO wait, 30 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038a80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0039ba700?, 0xc00199d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0039ba700, {0xc00199d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0039ba700, {0xc00199d000?, 0x703620?, 0xc0008d43c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00167d9b0, {0xc00199d000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f2c60, {0xc00199d000?, 0xc002d5d860?, 0xc001e89d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc002feb740)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc002feb740, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f2c60)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 79133
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 90102 [select, 6 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f06c0)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 90100
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 79135 [select, 30 minutes]:
net/http.(*persistConn).writeLoop(0xc0013f2c60)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 79133
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 87912 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e0383b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc0023c7d00?, 0xc00128f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0023c7d00, {0xc00128f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0023c7d00, {0xc00128f000?, 0x703620?, 0xc00340d180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00167d168, {0xc00128f000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0013f19e0, {0xc00128f000?, 0xc00178d0e0?, 0xc002537d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f92c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f92c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0013f19e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 87911
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 90675 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00288d848, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x159
sync.(*Cond).Wait(0x3f3a380?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00288d830, {0xc002832001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x393fd3a?}, {0xc002832001?, 0x3952c74?, 0xa?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2558 +0x65
encoding/json.(*Decoder).refill(0xc0008d4500)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0008d4500)
	/usr/local/go/src/encoding/json/stream.go:140 +0x9d
encoding/json.(*Decoder).Decode(0xc0008d4500, {0x326cdc0, 0xc0033f4858})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001674750, {0xc00280f000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc002456dc0, 0xc00178c5a0?, {0x3f3b448, 0xc0033b9f00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001024d60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00275fe80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 585
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x125

goroutine 81356 [select, 26 minutes]:
net/http.(*persistConn).writeLoop(0xc0012d8b40)
	/usr/local/go/src/net/http/transport.go:2421 +0xe5
created by net/http.(*Transport).dialConn in goroutine 81354
	/usr/local/go/src/net/http/transport.go:1777 +0x16f1

goroutine 89457 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002a9b980, 0xc002ce2500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xfafea5?, 0xc0021dfa00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 402
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308

goroutine 83533 [IO wait, 20 minutes]:
internal/poll.runtime_pollWait(0x7f6b4e038988, 0x72)
	/usr/local/go/src/runtime/netpoll.go:343 +0x85
internal/poll.(*pollDesc).wait(0xc002ece180?, 0xc001e4c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002ece180, {0xc001e4c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc002ece180, {0xc001e4c000?, 0x703620?, 0xc00340ca00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016b2e88, {0xc001e4c000?, 0x0?, 0xc0024ec680?})
	/usr/local/go/src/net/net.go:179 +0x45
net/http.(*persistConn).Read(0xc0016059e0, {0xc001e4c000?, 0xc002640300?, 0xc003176d38?})
	/usr/local/go/src/net/http/transport.go:1954 +0x4a
bufio.(*Reader).fill(0xc0023f8120)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0xc0023f8120, 0x1)
	/usr/local/go/src/bufio/bufio.go:151 +0x53
net/http.(*persistConn).readLoop(0xc0016059e0)
	/usr/local/go/src/net/http/transport.go:2118 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 83532
	/usr/local/go/src/net/http/transport.go:1776 +0x169f

goroutine 89709 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0027c4480, 0xc000ff5f00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1464 +0xac7
golang.org/x/net/http2.(*clientStream).doRequest(0xc001b8ac60?, 0xc003307800?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1326 +0x18
created by golang.org/x/net/http2.(*ClientConn).RoundTrip in goroutine 197
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1232 +0x308
