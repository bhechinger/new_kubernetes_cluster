KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [public   10.22.20.12 fe80::5054:ff:fe86:ce9b, private   10.22.30.12 fe80::5054:ff:fe6e:9aac (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 3/254 allocated from 10.55.1.0/24, 
Allocated addresses:
  10.55.1.165 (health)
  10.55.1.178 (ingress)
  10.55.1.36 (router)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [public, private]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [public, private]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      21/21 healthy
  Name                                  Last success   Last error     Count   Message
  cilium-health-ep                      30s ago        never          0       no error   
  dns-garbage-collector-job             32s ago        never          0       no error   
  endpoint-1014-regeneration-recovery   never          never          0       no error   
  endpoint-137-regeneration-recovery    never          never          0       no error   
  endpoint-2406-regeneration-recovery   never          never          0       no error   
  endpoint-gc                           4m32s ago      never          0       no error   
  ep-bpf-prog-watchdog                  1s ago         never          0       no error   
  ipcache-inject-labels                 31s ago        3h19m32s ago   0       no error   
  k8s-heartbeat                         2s ago         never          0       no error   
  link-cache                            1s ago         never          0       no error   
  resolve-identity-1014                 4m31s ago      never          0       no error   
  resolve-identity-137                  4m31s ago      never          0       no error   
  resolve-identity-2406                 4m30s ago      never          0       no error   
  sync-host-ips                         31s ago        never          0       no error   
  sync-lb-maps-with-k8s-services        3h19m31s ago   never          0       no error   
  sync-policymap-137                    4m29s ago      never          0       no error   
  sync-policymap-2406                   4m28s ago      never          0       no error   
  sync-utime                            31s ago        never          0       no error   
  template-dir-watcher                  never          never          0       no error   
  update-k8s-node-annotations           3h19m30s ago   never          0       no error   
  write-cni-file                        3h19m32s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.1.36, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 6.11   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                public   10.22.20.12 fe80::5054:ff:fe86:ce9b, private   10.22.30.12 fe80::5054:ff:fe6e:9aac (Direct Routing)
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                     Disabled        
Cluster health:                 6/6 reachable   (2024-07-20T17:44:20Z)
  Name                          IP              Node        Endpoints
  hetzner/master2 (localhost)   10.22.30.12     reachable   reachable
  hetzner/master1               10.22.30.11     reachable   reachable
  hetzner/master3               10.22.30.13     reachable   reachable
  hetzner/worker1               10.22.30.21     reachable   reachable
  hetzner/worker2               10.22.30.22     reachable   reachable
  hetzner/worker3               10.22.30.23     reachable   reachable
Modules Health:
agent
├── controlplane
│   ├── auth
│   │   ├── observer-job-auth request-authentication        [OK] Primed (3h19m, x1)
│   │   ├── observer-job-auth gc-identity-events            [OK] OK (1.753µs) [35] (3h19m, x1)
│   │   └── timer-job-auth gc-cleanup                       [OK] OK (35.639µs) (3h19m, x1)
│   ├── l2-announcer
│   │   └── leader-election                                 [OK]  (3h19m, x1)
│   ├── endpoint-manager
│   │   ├── endpoint-gc                                     [OK] endpoint-gc (3h19m, x40)
│   │   ├── cilium-endpoint-137 
│   │   │   ├── policymap-sync                              [OK] sync-policymap-137 (3h19m, x14)
│   │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h19m, x25)
│   │   ├── cilium-endpoint-1014 
│   │   │   └── datapath-regenerate                         [OK] Endpoint regeneration successful (3h19m, x25)
│   │   └── cilium-endpoint-2406 
│   │       ├── datapath-regenerate                         [OK] Endpoint regeneration successful (3h19m, x24)
│   │       └── policymap-sync                              [OK] sync-policymap-2406 (3h19m, x14)
│   ├── envoy-proxy
│   │   └── timer-job-version-check                         [OK] OK (2.757044ms) (3h19m, x1)
│   ├── stale-endpoint-cleanup                              [OK]  (3h19m, x1)
│   ├── bgp-cp
│   │   └── job-diffstore-events                            [OK] Running (3h19m, x2)
│   ├── daemon
│   │   └── ep-bpf-prog-watchdog                            [OK] ep-bpf-prog-watchdog (3h19m, x400)
│   └── node-manager
│       ├── background-sync                                 [OK] Node validation successful (3h19m, x106)
│       ├── nodes-add                                       [OK] Node adds successful (3h19m, x6)
│       └── nodes-update                                    [OK] Node updates successful (3h17m, x4)
└── datapath
    ├── l2-responder
    │   └── job-l2-responder-reconciler                     [OK] Running (3h19m, x1)
    ├── agent-liveness-updater
    │   └── timer-job-agent-liveness-updater                [OK] OK (26.97µs) (3h19m, x1)
    └── node-address
        └── job-node-address-update                         [OK] 10.55.1.36 (cilium_host), fe80::bcd8:9dff:fe37:3da7 (cilium_host) (3h19m, x1)

