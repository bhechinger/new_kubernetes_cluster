# Cilium debug information

#### Cilium memory map


```
00400000-02d9c000 r-xp 00000000 00:ae 1853017                            /usr/bin/cilium-agent
02d9c000-05f5d000 r--p 0299c000 00:ae 1853017                            /usr/bin/cilium-agent
05f5d000-060b2000 rw-p 05b5d000 00:ae 1853017                            /usr/bin/cilium-agent
060b2000-06840000 rw-p 00000000 00:00 0 
c000000000-c004400000 rw-p 00000000 00:00 0 
c004400000-c008000000 ---p 00000000 00:00 0 
7f6b4de34000-7f6b4e049000 rw-p 00000000 00:00 0 
7f6b4e049000-7f6b4e08a000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7f6b4e08a000-7f6b4e0cb000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7f6b4e0cb000-7f6b4e5eb000 rw-p 00000000 00:00 0 
7f6b4e5eb000-7f6b4e6eb000 rw-p 00000000 00:00 0 
7f6b4e6eb000-7f6b4e800000 rw-p 00000000 00:00 0 
7f6b4e800000-7f6b50800000 rw-p 00000000 00:00 0 
7f6b50800000-7f6b60980000 ---p 00000000 00:00 0 
7f6b60980000-7f6b60981000 rw-p 00000000 00:00 0 
7f6b60981000-7f6b80980000 ---p 00000000 00:00 0 
7f6b80980000-7f6b80981000 rw-p 00000000 00:00 0 
7f6b80981000-7f6b92830000 ---p 00000000 00:00 0 
7f6b92830000-7f6b92831000 rw-p 00000000 00:00 0 
7f6b92831000-7f6b94c06000 ---p 00000000 00:00 0 
7f6b94c06000-7f6b94c07000 rw-p 00000000 00:00 0 
7f6b94c07000-7f6b95000000 ---p 00000000 00:00 0 
7f6b95002000-7f6b95004000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7f6b95004000-7f6b95006000 rw-s 00000000 00:0e 163                        anon_inode:[perf_event]
7f6b95006000-7f6b9503c000 rw-p 00000000 00:00 0 
7f6b9503c000-7f6b950bc000 ---p 00000000 00:00 0 
7f6b950bc000-7f6b950bd000 rw-p 00000000 00:00 0 
7f6b950bd000-7f6b9513c000 ---p 00000000 00:00 0 
7f6b9513c000-7f6b9519c000 rw-p 00000000 00:00 0 
7ffe8ff6a000-7ffe8ff8b000 rw-p 00000000 00:00 0                          [stack]
7ffe8ffee000-7ffe8fff2000 r--p 00000000 00:00 0                          [vvar]
7ffe8fff2000-7ffe8fff4000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.28 (v1.28.10+rke2r1) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "cilium/v2alpha1::CiliumEndpointSlice", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   Strict   [public   10.22.20.12 fe80::5054:ff:fe86:ce9b, private   10.22.30.12 fe80::5054:ff:fe6e:9aac (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           portmap
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.15.5 (v1.15.5-8c7e442c)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 3/254 allocated from 10.55.1.0/24, 
Allocated addresses:
  10.55.1.165 (health)
  10.55.1.178 (ingress)
  10.55.1.36 (router)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       EDT with BPF [BBR] [public, private]
Host Routing:           BPF
Masquerading:           BPF (ip-masq-agent)   [public, private]   10.22.30.0/24 [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      21/21 healthy
  Name                                  Last success   Last error     Count   Message
  cilium-health-ep                      28s ago        never          0       no error   
  dns-garbage-collector-job             30s ago        never          0       no error   
  endpoint-1014-regeneration-recovery   never          never          0       no error   
  endpoint-137-regeneration-recovery    never          never          0       no error   
  endpoint-2406-regeneration-recovery   never          never          0       no error   
  endpoint-gc                           4m30s ago      never          0       no error   
  ep-bpf-prog-watchdog                  29s ago        never          0       no error   
  ipcache-inject-labels                 29s ago        3h19m30s ago   0       no error   
  k8s-heartbeat                         30s ago        never          0       no error   
  link-cache                            14s ago        never          0       no error   
  resolve-identity-1014                 4m29s ago      never          0       no error   
  resolve-identity-137                  4m29s ago      never          0       no error   
  resolve-identity-2406                 4m28s ago      never          0       no error   
  sync-host-ips                         29s ago        never          0       no error   
  sync-lb-maps-with-k8s-services        3h19m29s ago   never          0       no error   
  sync-policymap-137                    4m27s ago      never          0       no error   
  sync-policymap-2406                   4m26s ago      never          0       no error   
  sync-utime                            29s ago        never          0       no error   
  template-dir-watcher                  never          never          0       no error   
  update-k8s-node-annotations           3h19m28s ago   never          0       no error   
  write-cni-file                        3h19m30s ago   never          0       no error   
Proxy Status:            OK, ip 10.55.1.36, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 6.11   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 Strict
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                public   10.22.20.12 fe80::5054:ff:fe86:ce9b, private   10.22.30.12 fe80::5054:ff:fe6e:9aac (Direct Routing)
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend              Service Type   Backend                           
1    10.65.0.1:443         ClusterIP      1 => 10.22.20.11:6443 (active)    
                                          2 => 10.22.20.12:6443 (active)    
                                          3 => 10.22.20.13:6443 (active)    
2    10.65.253.13:443      ClusterIP      1 => 10.22.30.12:4244 (active)    
3    10.65.203.48:80       ClusterIP      1 => 10.55.3.167:4245 (active)    
4    10.65.97.59:80        ClusterIP      1 => 10.55.3.129:8081 (active)    
5    10.65.0.10:53         ClusterIP      1 => 10.55.0.129:53 (active)      
                                          2 => 10.55.2.204:53 (active)      
6    10.65.180.197:6379    ClusterIP      1 => 10.55.3.78:6379 (active)     
                                          2 => 10.55.4.213:6379 (active)    
                                          3 => 10.55.5.149:6379 (active)    
7    10.65.180.197:9101    ClusterIP      1 => 10.55.3.78:9101 (active)     
                                          2 => 10.55.4.213:9101 (active)    
                                          3 => 10.55.5.149:9101 (active)    
8    10.65.145.33:5557     ClusterIP      1 => 10.55.3.19:5557 (active)     
9    10.65.145.33:5556     ClusterIP      1 => 10.55.3.19:5556 (active)     
10   10.65.115.248:8082    ClusterIP      1 => 10.55.3.252:8082 (active)    
11   10.65.192.200:8081    ClusterIP      1 => 10.55.3.50:8081 (active)     
                                          2 => 10.55.3.23:8081 (active)     
12   10.65.243.160:6379    ClusterIP      1 => 10.55.4.218:6379 (active)    
13   10.65.243.160:26379   ClusterIP      1 => 10.55.4.218:26379 (active)   
14   10.65.243.160:9121    ClusterIP      1 => 10.55.4.218:9121 (active)    
15   10.65.148.50:80       ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
16   10.65.148.50:443      ClusterIP      1 => 10.55.3.90:8080 (active)     
                                          2 => 10.55.3.60:8080 (active)     
17   10.65.70.170:26379    ClusterIP      1 => 10.55.5.155:26379 (active)   
18   10.65.70.170:9121     ClusterIP      1 => 10.55.5.155:9121 (active)    
19   10.65.70.170:6379     ClusterIP      1 => 10.55.5.155:6379 (active)    
20   10.65.178.184:6379    ClusterIP      1 => 10.55.3.253:6379 (active)    
21   10.65.178.184:26379   ClusterIP      1 => 10.55.3.253:26379 (active)   
22   10.65.178.184:9121    ClusterIP      1 => 10.55.3.253:9121 (active)    
23   10.65.51.64:443       ClusterIP      1 => 10.55.3.210:8443 (active)    
24   10.65.48.249:443      ClusterIP      1 => 10.55.3.27:10250 (active)    
27   10.65.213.42:9402     ClusterIP      1 => 10.55.4.152:9402 (active)    
28   10.65.174.214:443     ClusterIP      1 => 10.55.4.211:10250 (active)   
29   10.65.155.14:8080     ClusterIP      1 => 10.55.5.129:8080 (active)    
30   10.22.30.12:32495     NodePort       1 => 10.55.5.129:8080 (active)    
31   0.0.0.0:32495         NodePort       1 => 10.55.5.129:8080 (active)    
32   10.22.20.12:32495     NodePort       1 => 10.55.5.129:8080 (active)    
33   10.65.26.204:8080     ClusterIP      1 => 10.55.4.112:8080 (active)    
34   10.22.20.12:30568     NodePort       1 => 10.55.4.112:8080 (active)    
35   10.22.30.12:30568     NodePort       1 => 10.55.4.112:8080 (active)    
36   0.0.0.0:30568         NodePort       1 => 10.55.4.112:8080 (active)    
```

#### Policy get

```
:
 [
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-dex-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "http",
                "protocol": "TCP"
              }
            ]
          },
          {
            "ports": [
              {
                "port": "grpc",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-dex-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "0ca9b40f-9a3f-4ecd-bb56-154eebd0bf62",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-repo-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      },
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-application-controller",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-repo-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "44e84fdf-5ef5-4516-8cf8-2e5e1e3f3523",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-application-controller",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchExpressions": [
              {
                "key": "k8s:io.kubernetes.pod.namespace",
                "operator": "Exists"
              }
            ]
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "controller",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-application-controller",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d14d3df5-1c32-43ce-9f4b-9fd13f1cacf6",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {}
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d6baf548-03ff-49f8-93db-5f25fa513dc6",
        "source": "k8s"
      }
    ]
  }
]
Revision: 233

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                      IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                        
137        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                        ready   
                                                           k8s:node-role.kubernetes.io/etcd=true                                         
                                                           k8s:node-role.kubernetes.io/master=true                                       
                                                           k8s:node.kubernetes.io/instance-type=rke2                                     
                                                           reserved:host                                                                 
1014       Disabled           Disabled          8          reserved:ingress                                        10.55.1.178   ready   
2406       Disabled           Disabled          4          reserved:health                                         10.55.1.165   ready   
```

#### BPF Policy Get 137

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 137

```
Invalid argument: unknown type 137
```


#### Endpoint Get 137

```
[
  {
    "id": 137,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-137-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ae74df02-fa8c-470c-b131-abb8beec9b68"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-137",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:17.768Z",
            "success-count": 40
          },
          "uuid": "fd3075cd-04f2-4934-a3c5-5f04d45039f9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-137",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:19.898Z",
            "success-count": 14
          },
          "uuid": "e8bc16ac-404e-4210-a808-7cac1b232bff"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:node.kubernetes.io/instance-type=rke2",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "be:d8:9d:37:3d:a7",
        "interface-name": "cilium_host",
        "mac": "be:d8:9d:37:3d:a7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 137

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 137

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:25:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:25:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:25:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:25:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:25:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:25:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:25:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:25:17Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:25:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host
     reserved:kube-apiserver

```


#### BPF Policy Get 1014

```
Error: Failed to open map: loading pinned map /sys/fs/bpf/tc/globals/cilium_policy_01014: no such file or directory


```


#### BPF CT List 1014

```
Invalid argument: unknown type 1014
```


#### Endpoint Get 1014

```
[
  {
    "id": 1014,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1014-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a41f940c-3bda-46ab-94c5-624af7ab7e3c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1014",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:17.777Z",
            "success-count": 40
          },
          "uuid": "d33ea36e-ad4c-46e8-b67e-2d75ce52229a"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 8,
        "labels": [
          "reserved:ingress"
        ]
      },
      "labels": {
        "derived": [
          "reserved:ingress"
        ],
        "realized": {},
        "security-relevant": [
          "reserved:ingress"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.1.178"
          }
        ]
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1014

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1014

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:25:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:25:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:25:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:25:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:25:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:25:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:25:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:25:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:25:17Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:25:17Z   OK       waiting-for-identity    Ingress Endpoint creation

```


#### Identity get 8

```
ID   LABELS
8    reserved:ingress

```


#### BPF Policy Get 2406

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    532518   6695      0        
Allow    Ingress     1          ANY          NONE         disabled    157604   1794      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2406

```
Invalid argument: unknown type 2406
```


#### Endpoint Get 2406

```
[
  {
    "id": 2406,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2406-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "598993c3-3bf2-46dd-85e6-b3e4216343cf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2406",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:18.796Z",
            "success-count": 40
          },
          "uuid": "e5695134-6592-4322-ac7a-4153fc521b49"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2406",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-07-20T17:40:20.923Z",
            "success-count": 14
          },
          "uuid": "b1f7e6ef-d65c-42d3-9129-4a5c3ce1a19c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-07-20T16:08:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.1.165",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "4a:65:c5:64:e9:f6",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "76:2d:b1:30:2b:e8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 233,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 233
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 5,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 5
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2406

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2406

```
Timestamp              Status   State                   Message
2024-07-20T16:08:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T16:08:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:50Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T16:08:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T16:08:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T16:08:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T16:08:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T16:08:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T16:08:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:50:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T15:35:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:41Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T15:35:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T15:35:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T15:35:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T15:35:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T15:35:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T15:35:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:33Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:38:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:29Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:38:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:38:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:38:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:38:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:38:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:38:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-07-20T14:32:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:45Z   OK       regenerating            Regenerating endpoint: 
2024-07-20T14:32:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-07-20T14:32:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:32:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-07-20T14:32:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:32:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-07-20T14:32:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-07-20T14:25:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-07-20T14:25:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-07-20T14:25:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-07-20T14:25:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-07-20T14:25:18Z   OK       ready                   Set identity for this endpoint
2024-07-20T14:25:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc001a0dd80)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc000105260,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=21) {
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.Service)(0xc00066bc30)(frontends:[10.65.48.249]/ports=[https]/selector=map[app:rke2-metrics-server app.kubernetes.io/instance:rke2-metrics-server app.kubernetes.io/name:rke2-metrics-server]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.Service)(0xc001a01ad0)(frontends:[10.65.174.214]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.Service)(0xc0024d5c30)(frontends:[10.65.192.200]/ports=[https-repo-server]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-repo-server]),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.Service)(0xc001b39080)(frontends:[10.65.148.50]/ports=[http https]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-server]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.Service)(0xc001b39130)(frontends:[10.65.70.170]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-2]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.Service)(0xc001a00630)(frontends:[10.65.178.184]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-0]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc0001fa630)(frontends:[10.65.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc0001fa790)(frontends:[10.65.253.13]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc001180000)(frontends:[10.65.97.59]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha: (*k8s.Service)(0xc001b38dc0)(frontends:[]/ports=[tcp-server tcp-sentinel http-exporter-port]/selector=map[app:redis-ha release:rke2-argocd]),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.Service)(0xc0011811e0)(frontends:[10.65.155.14]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc0001fa840)(frontends:[10.65.203.48]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.Service)(0xc001181550)(frontends:[10.65.26.204]/ports=[http]/selector=map[name:echo-other-node]),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.Service)(0xc0024d5a20)(frontends:[10.65.115.248]/ports=[https-controller]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-application-controller]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.Service)(0xc0024d5d90)(frontends:[10.65.243.160]/ports=[tcp-server tcp-sentinel http-exporter]/selector=map[app:redis-ha release:rke2-argocd statefulset.kubernetes.io/pod-name:rke2-argocd-redis-ha-server-1]),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.Service)(0xc001b39b80)(frontends:[10.65.51.64]/ports=[https]/selector=map[app.kubernetes.io/instance:rke2-snapshot-validation-webhook app.kubernetes.io/name:rke2-snapshot-validation-webhook]),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.Service)(0xc001a01970)(frontends:[10.65.213.42]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:rke2-cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc0001fa6e0)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.Service)(0xc0011800b0)(frontends:[10.65.0.10]/ports=[udp-53 tcp-53]/selector=map[app.kubernetes.io/instance:rke2-coredns app.kubernetes.io/name:rke2-coredns k8s-app:kube-dns]),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.Service)(0xc001b38e70)(frontends:[10.65.180.197]/ports=[tcp-haproxy http-exporter-port]/selector=map[app:redis-ha-haproxy release:rke2-argocd]),
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.Service)(0xc0024d54a0)(frontends:[10.65.145.33]/ports=[http grpc]/selector=map[app.kubernetes.io/instance:rke2-argocd app.kubernetes.io/name:argocd-dex-server])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) argocd/rke2-argocd-dex-server: (*k8s.EndpointSlices)(0xc00172d3c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=28) "rke2-argocd-dex-server-sv4gw": (*k8s.Endpoints)(0xc002ca0340)(10.55.3.19:5556/TCP,10.55.3.19:5557/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-application-controller: (*k8s.EndpointSlices)(0xc00172d480)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=40) "rke2-argocd-application-controller-fz8wm": (*k8s.Endpoints)(0xc00281e750)(10.55.3.252:8082/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc00172ce50)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc0027e9520)(10.22.20.11:6443/TCP,10.22.20.12:6443/TCP,10.22.20.13:6443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-coredns-rke2-coredns: (*k8s.EndpointSlices)(0xc00172ce70)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-coredns-rke2-coredns-kcjm5": (*k8s.Endpoints)(0xc002ab3d40)(10.55.0.129:53/TCP,10.55.0.129:53/UDP,10.55.2.204:53/TCP,10.55.2.204:53/UDP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-repo-server: (*k8s.EndpointSlices)(0xc001712bf0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=29) "rke2-argocd-repo-server-xmwsw": (*k8s.Endpoints)(0xc0027e8410)(10.55.3.23:8081/TCP,10.55.3.50:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-1: (*k8s.EndpointSlices)(0xc00172d738)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-1-j6rjb": (*k8s.Endpoints)(0xc003026ea0)(10.55.4.218:26379/TCP,10.55.4.218:6379/TCP,10.55.4.218:9121/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager: (*k8s.EndpointSlices)(0xc0005610c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=23) "rke2-cert-manager-qnhfm": (*k8s.Endpoints)(0xc00273f5f0)(10.55.4.152:9402/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-same-node: (*k8s.EndpointSlices)(0xc001358c90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-dcdmx": (*k8s.Endpoints)(0xc0027e89c0)(10.55.5.129:8080/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc00172ce58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-dmr4p": (*k8s.Endpoints)(0xc002e69ba0)(10.22.30.11:4244/TCP,10.22.30.12:4244/TCP,10.22.30.13:4244/TCP,10.22.30.21:4244/TCP,10.22.30.22:4244/TCP,10.22.30.23:4244/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-server: (*k8s.EndpointSlices)(0xc00172d770)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=24) "rke2-argocd-server-8r4gl": (*k8s.Endpoints)(0xc00272d450)(10.55.3.60:8080/TCP,10.55.3.60:8080/TCP,10.55.3.90:8080/TCP,10.55.3.90:8080/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-2: (*k8s.EndpointSlices)(0xc00172d850)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-2-8ts7n": (*k8s.Endpoints)(0xc00281e680)(10.55.5.155:26379/TCP,10.55.5.155:6379/TCP,10.55.5.155:9121/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-haproxy: (*k8s.EndpointSlices)(0xc00172d0c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=34) "rke2-argocd-redis-ha-haproxy-vlh5w": (*k8s.Endpoints)(0xc003027040)(10.55.3.78:6379/TCP,10.55.3.78:9101/TCP,10.55.4.213:6379/TCP,10.55.4.213:9101/TCP,10.55.5.149:6379/TCP,10.55.5.149:9101/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc00172ce68)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-7qjhj": (*k8s.Endpoints)(0xc002bfd110)(10.55.3.129:8081/TCP)
   }
  }),
  (k8s.ServiceID) argocd/rke2-argocd-redis-ha-announce-0: (*k8s.EndpointSlices)(0xc00172d878)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=37) "rke2-argocd-redis-ha-announce-0-9lzv5": (*k8s.Endpoints)(0xc0018828f0)(10.55.3.253:26379/TCP,10.55.3.253:6379/TCP,10.55.3.253:9121/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-snapshot-validation-webhook: (*k8s.EndpointSlices)(0xc001713228)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=38) "rke2-snapshot-validation-webhook-m6rrw": (*k8s.Endpoints)(0xc0030a6340)(10.55.3.210:8443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/rke2-metrics-server: (*k8s.EndpointSlices)(0xc0017134e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "rke2-metrics-server-7sv6h": (*k8s.Endpoints)(0xc003027520)(10.55.3.27:10250/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/rke2-cert-manager-webhook: (*k8s.EndpointSlices)(0xc001359ed8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=31) "rke2-cert-manager-webhook-9smdc": (*k8s.Endpoints)(0xc0024ee5b0)(10.55.4.211:10250/TCP)
   }
  }),
  (k8s.ServiceID) cilium-test/echo-other-node: (*k8s.EndpointSlices)(0xc001359248)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=21) "echo-other-node-zctcd": (*k8s.Endpoints)(0xc0027e8ea0)(10.55.4.112:8080/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc00172ce60)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-9l8c5": (*k8s.Endpoints)(0xc0030e0b60)(10.55.3.167:4245/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*tables.nodeAddressing)(0xc0018dc1e0)({
  localNode: (*node.LocalNodeStore)(0xc000bcc900)({
   Observable: (stream.FuncObservable[github.com/cilium/cilium/pkg/node.LocalNode]) 0x1df7600,
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   value: (node.LocalNode) {
    Node: (types.Node) {
     Name: (string) (len=7) "master2",
     Cluster: (string) (len=7) "hetzner",
     IPAddresses: ([]types.Address) (len=3 cap=4) {
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "InternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.30.12
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=10) "ExternalIP",
       IP: (net.IP) (len=16 cap=16) 10.22.20.12
      },
      (types.Address) {
       Type: (addressing.AddressType) (len=16) "CiliumInternalIP",
       IP: (net.IP) (len=16 cap=26) 10.55.1.36
      }
     },
     IPv4AllocCIDR: (*cidr.CIDR)(0xc00172ccc0)(10.55.1.0/24),
     IPv4SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv6AllocCIDR: (*cidr.CIDR)(<nil>),
     IPv6SecondaryAllocCIDRs: ([]*cidr.CIDR) <nil>,
     IPv4HealthIP: (net.IP) (len=16 cap=26) 10.55.1.165,
     IPv6HealthIP: (net.IP) <nil>,
     IPv4IngressIP: (net.IP) (len=16 cap=26) 10.55.1.178,
     IPv6IngressIP: (net.IP) <nil>,
     ClusterID: (uint32) 0,
     Source: (source.Source) (len=5) "local",
     EncryptionKey: (uint8) 0,
     Labels: (map[string]string) (len=10) {
      (string) (len=28) "node-role.kubernetes.io/etcd": (string) (len=4) "true",
      (string) (len=16) "kubernetes.io/os": (string) (len=5) "linux",
      (string) (len=32) "node.kubernetes.io/instance-type": (string) (len=4) "rke2",
      (string) (len=22) "kubernetes.io/hostname": (string) (len=7) "master2",
      (string) (len=21) "beta.kubernetes.io/os": (string) (len=5) "linux",
      (string) (len=18) "kubernetes.io/arch": (string) (len=5) "amd64",
      (string) (len=32) "beta.kubernetes.io/instance-type": (string) (len=4) "rke2",
      (string) (len=37) "node-role.kubernetes.io/control-plane": (string) (len=4) "true",
      (string) (len=30) "node-role.kubernetes.io/master": (string) (len=4) "true",
      (string) (len=23) "beta.kubernetes.io/arch": (string) (len=5) "amd64"
     },
     Annotations: (map[string]string) (len=4) {
      (string) (len=33) "network.cilium.io/ipv4-Ingress-ip": (string) (len=11) "10.55.1.178",
      (string) (len=32) "network.cilium.io/ipv4-health-ip": (string) (len=11) "10.55.1.165",
      (string) (len=31) "network.cilium.io/ipv4-pod-cidr": (string) (len=12) "10.55.1.0/24",
      (string) (len=34) "network.cilium.io/ipv4-cilium-host": (string) (len=10) "10.55.1.36"
     },
     NodeIdentity: (uint32) 1,
     WireguardPubKey: (string) "",
     BootID: (string) (len=36) "a661dd26-f70d-4016-a2e0-d81cb488d59f"
    },
    OptOutNodeEncryption: (bool) false,
    UID: (types.UID) (len=36) "b525f9c4-b2af-4e0d-991d-2ff975f7d3bb",
    ProviderID: (string) (len=14) "rke2://master2"
   },
   emit: (func(node.LocalNode)) 0x1df7ea0,
   complete: (func(error)) 0x1df7c60
  }),
  db: (*statedb.DB)(0xc0011c0a80)({
   mu: (lock.Mutex) {
    internalMutex: (lock.internalMutex) {
     Mutex: (sync.Mutex) {
      state: (int32) 0,
      sema: (uint32) 0
     }
    }
   },
   tables: (map[string]statedb.TableMeta) (len=4) {
    (string) (len=14) "node-addresses": (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc0007aedc0)({
     table: (string) (len=14) "node-addresses",
     smu: (*lock.sortableMutex)(0xc00186f710)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 3,
      acquireDuration: (time.Duration) 893ns
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
       unique: (bool) false
      }
     }
    }),
    (string) (len=11) "l2-announce": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.L2AnnounceEntry])(0xc0008bdae0)({
     table: (string) (len=11) "l2-announce",
     smu: (*lock.sortableMutex)(0xc001e71c20)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 4,
      acquireDuration: (time.Duration) 61ns
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=6) "origin": (statedb.anyIndexer) {
       name: (string) (len=6) "origin",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=7) "devices": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc0007ae820)({
     table: (string) (len=7) "devices",
     smu: (*lock.sortableMutex)(0xc00186f6b0)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 1,
      acquireDuration: (time.Duration) 3.313µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
      (string) (len=4) "name": (statedb.anyIndexer) {
       name: (string) (len=4) "name",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      },
      (string) (len=8) "selected": (statedb.anyIndexer) {
       name: (string) (len=8) "selected",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    }),
    (string) (len=6) "routes": (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Route])(0xc0007ae870)({
     table: (string) (len=6) "routes",
     smu: (*lock.sortableMutex)(0xc00186f6c8)({
      Mutex: (sync.Mutex) {
       state: (int32) 0,
       sema: (uint32) 0
      },
      seq: (uint64) 2,
      acquireDuration: (time.Duration) 1.002µs
     }),
     primaryAnyIndexer: (statedb.anyIndexer) {
      name: (string) (len=2) "id",
      fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
      unique: (bool) true
     },
     secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
      (string) (len=9) "LinkIndex": (statedb.anyIndexer) {
       name: (string) (len=9) "LinkIndex",
       fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
       unique: (bool) false
      }
     }
    })
   },
   ctx: (*context.cancelCtx)(0xc0000c9310)(context.Background.WithCancel),
   cancel: (context.CancelFunc) 0x4a18e0,
   root: (atomic.Pointer[github.com/hashicorp/go-immutable-radix/v2.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]]) {
    _: ([0]*iradix.Tree[github.com/cilium/cilium/pkg/statedb.tableEntry]) {
    },
    _: (atomic.noCopy) {
    },
    v: (unsafe.Pointer) 0xc000cc5d20
   },
   gcTrigger: (chan struct {}) (cap=1) 0xc0000ca900,
   gcExited: (chan struct {}) 0xc0000ca960,
   gcRateLimitInterval: (time.Duration) 1s,
   metrics: (statedb.Metrics) {
    WriteTxnDuration: (*metric.histogramVec)(0xc001308200)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0013394b8)({
      MetricVec: (*prometheus.MetricVec)(0xc000d510b0)({
       metricMap: (*prometheus.metricMap)(0xc000d51110)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012faea0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0xc001308280)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0013394c0)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51170)({
       metricMap: (*prometheus.metricMap)(0xc000d511a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012faf00)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,package}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0xc001308300)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394c8)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51200)({
       metricMap: (*prometheus.metricMap)(0xc000d51230)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012faf60)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0xc001308380)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394d0)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51290)({
       metricMap: (*prometheus.metricMap)(0xc000d512c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fafc0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0xc001308400)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394d8)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51320)({
       metricMap: (*prometheus.metricMap)(0xc000d51350)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fb020)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0xc001308480)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394e0)({
      MetricVec: (*prometheus.MetricVec)(0xc000d513e0)({
       metricMap: (*prometheus.metricMap)(0xc000d51410)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fb080)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0xc001308500)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394e8)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51470)({
       metricMap: (*prometheus.metricMap)(0xc000d514a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fb0e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0xc001308580)({
     GaugeVec: (*prometheus.GaugeVec)(0xc0013394f0)({
      MetricVec: (*prometheus.MetricVec)(0xc000d51500)({
       metricMap: (*prometheus.metricMap)(0xc000d51530)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fb140)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc105c0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0xc001308600)({
     ObserverVec: (*prometheus.HistogramVec)(0xc0013394f8)({
      MetricVec: (*prometheus.MetricVec)(0xc000d515f0)({
       metricMap: (*prometheus.metricMap)(0xc000d51620)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0012fb1a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xc18da0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xc0ffe0,
       hashAddByte: (func(uint64, uint8) uint64) 0xc10020
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  }),
  nodeAddresses: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc0007aedc0)({
   table: (string) (len=14) "node-addresses",
   smu: (*lock.sortableMutex)(0xc00186f710)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 3,
    acquireDuration: (time.Duration) 893ns
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=1) {
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1e20,
     unique: (bool) false
    }
   }
  }),
  devices: (*statedb.genTable[*github.com/cilium/cilium/pkg/datapath/tables.Device])(0xc0007ae820)({
   table: (string) (len=7) "devices",
   smu: (*lock.sortableMutex)(0xc00186f6b0)({
    Mutex: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    seq: (uint64) 1,
    acquireDuration: (time.Duration) 3.313µs
   }),
   primaryAnyIndexer: (statedb.anyIndexer) {
    name: (string) (len=2) "id",
    fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
    unique: (bool) true
   },
   secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
    (string) (len=8) "selected": (statedb.anyIndexer) {
     name: (string) (len=8) "selected",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    },
    (string) (len=4) "name": (statedb.anyIndexer) {
     name: (string) (len=4) "name",
     fromObject: (func(statedb.object) index.KeySet) 0x24b1bc0,
     unique: (bool) false
    }
   }
  })
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.15.5 8c7e442c 2024-05-10T16:33:07+02:00 go version go1.21.10 linux/amd64
```


#### Kernel version

```
6.8.12
```


#### Cilium environment keys

```
ipam:kubernetes
bgp-announce-lb-ip:false
encryption-strict-mode-cidr:
endpoint-gc-interval:5m0s
enable-k8s-endpoint-slice:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-xt-socket-fallback:true
log-opt:
enable-endpoint-health-checking:true
enable-high-scale-ipcache:false
nodeport-addresses:
cluster-id:0
k8s-require-ipv6-pod-cidr:false
ipsec-key-file:
enable-health-checking:true
annotate-k8s-node:true
bpf-policy-map-max:16384
config-sources:config-map:kube-system/cilium-config
bpf-lb-algorithm:random
vtep-cidr:
node-port-algorithm:random
sidecar-istio-proxy-image:cilium/istio_proxy
allow-localhost:auto
ipv6-service-range:auto
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
agent-health-port:9879
ipam-default-ip-pool:default
cni-log-file:/var/run/cilium/cilium-cni.log
enable-wireguard-userspace-fallback:false
kvstore-lease-ttl:15m0s
enable-remote-node-identity:true
devices:public private
set-cilium-is-up-condition:true
derive-masquerade-ip-addr-from-device:
controller-group-metrics:write-cni-file sync-host-ips sync-lb-maps-with-k8s-services
enable-hubble:true
kube-proxy-replacement-healthz-bind-address:
routing-mode:native
hubble-redact-http-urlquery:false
agent-labels:
enable-gateway-api:true
enable-l2-neigh-discovery:true
bpf-lb-source-range-map-max:0
enable-tracing:false
hubble-export-file-path:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
gops-port:9890
hubble-monitor-events:
dns-max-ips-per-restored-rule:1000
api-rate-limit:
enable-ip-masq-agent:true
bpf-lb-rev-nat-map-max:0
tofqdns-proxy-port:0
dnsproxy-concurrency-processing-grace-period:0s
ipv4-range:auto
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dns-policy-unload-on-shutdown:false
trace-sock:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tunnel-port:0
prepend-iptables-chains:true
log-driver:
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-redact-enabled:false
nodes-gc-interval:5m0s
mesh-auth-mutual-listener-port:0
hubble-export-file-compress:false
k8s-client-burst:20
identity-restore-grace-period:10m0s
k8s-namespace:kube-system
k8s-api-server:
tofqdns-max-deferred-connection-deletes:10000
node-port-bind-protection:true
http-403-msg:
local-router-ipv6:
bpf-policy-map-full-reconciliation-interval:15m0s
service-no-backend-response:reject
bpf-ct-timeout-service-any:1m0s
monitor-aggregation-interval:5s
socket-path:/var/run/cilium/cilium.sock
cflags:
enable-health-check-nodeport:true
route-metric:0
hubble-redact-http-headers-deny:
enable-node-port:false
enable-svc-source-range-check:true
local-max-addr-scope:252
ipv6-cluster-alloc-cidr:f00d::/64
labels:
pprof-port:6060
tofqdns-endpoint-max-ip-per-hostname:50
enable-wireguard:false
ipv6-native-routing-cidr:
fqdn-regex-compile-lru-size:1024
ipv4-service-loopback-address:169.254.42.1
tofqdns-idle-connection-grace-period:0s
hubble-export-file-max-size-mb:10
enable-recorder:false
mesh-auth-enabled:true
keep-config:false
policy-trigger-interval:1s
conntrack-gc-max-interval:0s
enable-xdp-prefilter:false
lib-dir:/var/lib/cilium
restore:true
cni-exclusive:true
preallocate-bpf-maps:false
bpf-lb-maglev-table-size:16381
pprof:false
bpf-lb-maglev-map-max:0
enable-masquerade-to-route-source:false
synchronize-k8s-nodes:true
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-dsr-dispatch:opt
identity-change-grace-period:5s
enable-ipv4-masquerade:true
bpf-lb-acceleration:disabled
endpoint-bpf-prog-watchdog-interval:30s
bpf-lb-sock:false
egress-multi-home-ip-rule-compat:false
auto-create-cilium-node-resource:true
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-lb-rss-ipv4-src-cidr:
encrypt-node:false
cluster-name:hetzner
hubble-disable-tls:false
bpf-auth-map-max:524288
enable-l2-announcements:false
enable-pmtu-discovery:false
k8s-kubeconfig-path:
max-internal-timer-delay:0s
enable-hubble-recorder-api:true
bpf-map-dynamic-size-ratio:0.0025
tofqdns-proxy-response-max-delay:100ms
ipam-multi-pool-pre-allocation:
ipsec-key-rotation-duration:5m0s
identity-heartbeat-timeout:30m0s
proxy-connect-timeout:2
log-system-load:false
envoy-config-timeout:2m0s
enable-cilium-endpoint-slice:true
http-retry-timeout:0
policy-audit-mode:false
encrypt-interface:
http-normalize-path:true
hubble-redact-kafka-apikey:false
install-no-conntrack-iptables-rules:false
hubble-recorder-sink-queue-size:1024
bpf-ct-global-any-max:262144
tofqdns-min-ttl:0
kvstore-periodic-sync:5m0s
hubble-export-file-max-backups:5
ipv4-node:auto
dnsproxy-lock-timeout:500ms
enable-k8s:true
bpf-lb-external-clusterip:false
dnsproxy-concurrency-limit:0
operator-api-serve-addr:127.0.0.1:9234
hubble-export-fieldmask:
mesh-auth-mutual-connect-timeout:5s
hubble-export-denylist:
cmdref:
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-ipv4-big-tcp:false
mesh-auth-queue-size:1024
enable-local-redirect-policy:false
agent-liveness-update-interval:1s
enable-bandwidth-manager:true
bypass-ip-availability-upon-restore:false
enable-well-known-identities:false
hubble-listen-address::4244
mtu:0
use-cilium-internal-ip-for-ipsec:false
srv6-encap-mode:reduced
label-prefix-file:
bpf-ct-timeout-regular-any:1m0s
enable-bbr:true
hubble-export-allowlist:
bpf-nat-global-max:524288
procfs:/host/proc
enable-ipv6:false
clustermesh-config:/var/lib/cilium/clustermesh/
node-port-mode:snat
install-egress-gateway-routes:false
bpf-fragments-map-max:8192
bpf-ct-timeout-service-tcp:2h13m20s
read-cni-conf:
enable-mke:false
enable-icmp-rules:true
enable-ipv6-masquerade:true
vtep-mac:
monitor-queue-size:0
hubble-redact-http-headers-allow:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
policy-cidr-match-mode:
enable-bpf-masquerade:true
local-router-ipv4:
max-connected-clusters:255
pprof-address:localhost
mesh-auth-gc-interval:5m0s
bpf-map-event-buffers:
arping-refresh-period:30s
ipam-cilium-node-update-rate:15s
iptables-random-fully:false
legacy-turn-off-k8s-event-handover:false
remove-cilium-node-taints:true
bpf-root:/sys/fs/bpf
node-port-range:
k8s-service-cache-size:128
enable-health-check-loadbalancer-ip:false
certificates-directory:/var/run/cilium/certs
k8s-client-qps:10
enable-policy:default
enable-ipv6-big-tcp:false
enable-host-legacy-routing:false
l2-announcements-lease-duration:15s
enable-ipv4-egress-gateway:false
enable-auto-protect-node-port-range:true
l2-announcements-renew-deadline:5s
hubble-socket-path:/var/run/cilium/hubble.sock
enable-ipsec-key-watcher:true
envoy-log:
proxy-max-connection-duration-seconds:0
enable-bpf-clock-probe:false
tofqdns-dns-reject-response-code:refused
unmanaged-pod-watcher-interval:15
hubble-flowlogs-config-path:
encryption-strict-mode-allow-remote-node-identities:false
bpf-lb-affinity-map-max:0
cluster-health-port:4240
bpf-neigh-global-max:524288
vlan-bpf-bypass:4000
hubble-redact-http-userinfo:true
enable-ipv4-fragment-tracking:true
datapath-mode:veth
trace-payloadlen:128
http-request-timeout:3600
enable-envoy-config:true
enable-host-port:false
egress-gateway-reconciliation-trigger-interval:1s
k8s-service-proxy-name:
clustermesh-ip-identities-sync-timeout:1m0s
state-dir:/var/run/cilium
enable-session-affinity:false
kvstore:
proxy-xff-num-trusted-hops-ingress:0
ipv4-native-routing-cidr:10.22.30.0/24
conntrack-gc-interval:0s
ipv4-service-range:auto
proxy-idle-timeout-seconds:60
http-max-grpc-timeout:0
endpoint-queue-size:25
dnsproxy-lock-count:131
allow-icmp-frag-needed:true
debug:false
bpf-node-map-max:16384
enable-nat46x64-gateway:false
ipv6-mcast-device:
ip-allocation-timeout:2m0s
enable-service-topology:false
custom-cni-conf:false
egress-masquerade-interfaces:
enable-vtep:false
bgp-announce-pod-cidr:false
enable-k8s-networkpolicy:true
enable-k8s-api-discovery:false
exclude-local-address:
enable-runtime-device-detection:false
enable-monitor:true
ipv6-pod-subnets:
hubble-metrics-server:
enable-ipv6-ndp:false
ipv4-pod-subnets:
cni-external-routing:false
tofqdns-pre-cache:
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-recorder-storage-path:/var/run/cilium/pcaps
l2-announcements-retry-period:2s
enable-bpf-tproxy:false
enable-l7-proxy:true
container-ip-local-reserved-ports:auto
ipv6-node:auto
policy-queue-size:100
kube-proxy-replacement:strict
monitor-aggregation-flags:all
auto-direct-node-routes:true
enable-ipsec:false
allocator-list-timeout:3m0s
bpf-filter-priority:1
enable-l2-pod-announcements:false
identity-allocation-mode:crd
enable-external-ips:false
vtep-mask:
enable-srv6:false
node-port-acceleration:disabled
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
debug-verbose:
enable-encryption-strict-mode:false
hubble-event-buffer-capacity:4095
gateway-api-secrets-namespace:cilium-secrets
http-idle-timeout:0
hubble-skip-unknown-cgroup-ids:true
http-retry-count:3
wireguard-persistent-keepalive:0s
enable-bgp-control-plane:false
mke-cgroup-mount:
max-controller-interval:0
cilium-endpoint-gc-interval:5m0s
direct-routing-device:private
hubble-event-queue-size:0
join-cluster:false
proxy-prometheus-port:0
fixed-identity-mapping:
cni-chaining-mode:portmap
enable-cilium-health-api-server-access:
enable-local-node-route:true
proxy-max-requests-per-connection:0
proxy-gid:1337
config:
version:false
dnsproxy-enable-transparent-mode:false
mesh-auth-spire-admin-socket:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-lb-rss-ipv6-src-cidr:
l2-pod-announcements-interface:
operator-prometheus-serve-addr::9963
enable-metrics:true
cni-chaining-target:
k8s-require-ipv4-pod-cidr:false
mesh-auth-signal-backoff-duration:1s
k8s-heartbeat-timeout:30s
disable-endpoint-crd:false
install-iptables-rules:true
bpf-lb-mode:snat
enable-identity-mark:true
proxy-xff-num-trusted-hops-egress:0
egress-gateway-policy-map-max:16384
bpf-lb-dsr-l4-xlate:frontend
k8s-sync-timeout:3m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
bpf-lb-sock-hostns-only:false
bpf-lb-map-max:65536
iptables-lock-timeout:5s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-cilium-api-server-access:
prometheus-serve-addr::9962
kvstore-opt:
enable-ipv4:true
vtep-endpoint:
enable-unreachable-routes:false
disable-iptables-feeder-rules:
metrics:
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-service-backend-map-max:0
kvstore-max-consecutive-quorum-errors:2
enable-k8s-terminating-endpoint:true
ipv6-range:auto
enable-custom-calls:false
cgroup-root:/run/cilium/cgroupv2
hubble-prefer-ipv6:false
bpf-sock-rev-map-max:262144
endpoint-status:
enable-endpoint-routes:false
bpf-lb-service-map-max:0
tofqdns-enable-dns-compression:true
monitor-aggregation:medium
enable-sctp:false
hubble-metrics:
crd-wait-timeout:5m0s
tunnel-protocol:vxlan
config-dir:/tmp/cilium/config-map
kvstore-connectivity-timeout:2m0s
enable-host-firewall:false
enable-gateway-api-secrets-sync:true
identity-gc-interval:15m0s
disable-envoy-version-check:false
external-envoy-proxy:true
bpf-ct-global-tcp-max:524288
skip-cnp-status-startup-clean:false
enable-stale-cilium-endpoint-cleanup:true
```

