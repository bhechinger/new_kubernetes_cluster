2: prog_array  name hid_jmp_table  flags 0x0
	key 4B  value 4B  max_entries 1024  memlock 8512B
	owner_prog_type tracing  owner jited
3: array  name I__.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
4: array  name E__.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
5: array  name I_init.scope  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
6: array  name E_init.scope  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
7: array  name I_system.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
8: array  name E_system.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
9: array  name I_system_getty.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
10: array  name E_system_getty.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
11: array  name I_system_modpro  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
12: array  name E_system_modpro  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
13: array  name I_system_serial  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
14: array  name E_system_serial  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
15: array  name I_system_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
16: array  name E_system_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
17: array  name I_user.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
18: array  name E_user.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
19: array  name I_dev_hugepages  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
20: array  name E_dev_hugepages  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
21: array  name I_dev_mqueue.mo  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
22: array  name E_dev_mqueue.mo  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
23: array  name I_sys_kernel_de  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
24: array  name E_sys_kernel_de  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
25: array  name I_domainname.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
26: array  name E_domainname.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
27: array  name I_kmod_static_n  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
28: array  name E_kmod_static_n  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
29: array  name I_modprobe_conf  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
30: array  name E_modprobe_conf  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
31: array  name I_modprobe_drm.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
32: array  name E_modprobe_drm.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
33: array  name I_modprobe_efi_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
34: array  name E_modprobe_efi_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
35: array  name I_modprobe_fuse  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
36: array  name E_modprobe_fuse  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
37: array  name I_mount_pstore.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
38: array  name E_mount_pstore.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
39: array  name I_suid_sgid_wra  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
40: array  name E_suid_sgid_wra  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
41: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
42: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
43: array  name I_systemd_modul  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
44: array  name E_systemd_modul  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
45: array  name I_systemd_remou  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
46: array  name E_systemd_remou  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
47: array  name I_systemd_udev_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
48: array  name E_systemd_udev_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
49: array  name I_sys_kernel_co  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
50: array  name E_sys_kernel_co  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
51: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
52: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
53: array  name I_systemd_rando  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
54: array  name E_systemd_rando  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
55: array  name I_sys_fs_fuse_c  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
56: array  name E_sys_fs_fuse_c  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
57: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
58: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
59: array  name I_systemd_udevd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
60: array  name E_systemd_udevd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
61: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
62: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
63: array  name I_systemd_sysct  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
64: array  name E_systemd_sysct  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
65: array  name I_systemd_fsck_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
66: array  name E_systemd_fsck_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
67: array  name I_systemd_vcons  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
68: array  name E_systemd_vcons  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
69: array  name I_boot.mount  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
70: array  name E_boot.mount  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
71: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
72: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
73: array  name I_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
74: array  name E_systemd_journ  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
75: array  name I_systemd_oomd.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
76: array  name E_systemd_oomd.  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
77: array  name I_systemd_times  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
78: array  name E_systemd_times  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
79: array  name I_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
80: array  name E_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
81: array  name I_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
82: array  name E_systemd_updat  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
83: array  name I_audit.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
84: array  name E_audit.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
85: array  name I_dhcpcd.servic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
86: array  name E_dhcpcd.servic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
87: array  name I_logrotate_che  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
88: array  name E_logrotate_che  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
89: array  name I_nscd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
90: array  name E_nscd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
91: array  name I_reload_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
92: array  name E_reload_system  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
93: array  name I_resolvconf.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
94: array  name E_resolvconf.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
95: array  name I_dbus.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
96: array  name E_dbus.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
97: array  name I_systemd_login  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
98: array  name E_systemd_login  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
99: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
100: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
101: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
102: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
103: array  name I_vlan4000_netd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
104: array  name E_vlan4000_netd  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
105: array  name I_public_netdev  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
106: array  name E_public_netdev  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
107: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
108: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
109: array  name I_private_netde  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
110: array  name E_private_netde  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
111: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
112: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
113: array  name I_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
114: array  name E_network_addre  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
115: array  name I_network_setup  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
116: array  name E_network_setup  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
117: array  name I_network_local  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
118: array  name E_network_local  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
119: array  name I_sshd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
120: array  name E_sshd.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
121: array  name I_systemd_user_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
122: array  name E_systemd_user_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
123: array  name I_getty_tty1.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
124: array  name E_getty_tty1.se  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
125: array  name I_serial_getty_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
126: array  name E_serial_getty_  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
127: array  name I_rke2.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
128: array  name E_rke2.service  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
129: array  name I_kubepods.slic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
130: array  name E_kubepods.slic  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
131: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
132: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
133: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
134: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
135: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
136: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
137: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
138: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
140: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
141: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
143: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
144: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
145: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
146: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
148: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
149: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
151: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
152: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
153: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
154: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
155: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
156: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
157: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
158: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
160: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
161: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
162: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
163: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
166: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
167: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
169: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
170: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
172: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
173: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
175: array  name I_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
176: array  name E_kubepods_burs  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
177: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
178: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
179: array  name I_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
180: array  name E_kubepods_best  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
181: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
182: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
183: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
184: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
186: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
187: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
190: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
191: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
193: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
194: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
217: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
218: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
221: array  name I_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
222: array  name E_cri_container  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
258: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 8389568B
259: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 2368B
260: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 336B
261: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 264688B
262: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 336B
263: hash  name cilium_throttle  flags 0x1
	key 8B  value 56B  max_entries 65535  memlock 1049536B
264: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 1050048B
265: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 4320B
266: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 17704B
267: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 5768128B
268: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1056400B
269: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1052416B
270: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1051984B
271: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
272: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
273: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 17826752B
274: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 8913856B
275: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 15729600B
276: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 10486720B
277: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 721856B
278: lpm_trie  name cilium_ipmasq_v  flags 0x1
	key 8B  value 1B  max_entries 16384  memlock 90B
279: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1049536B
280: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6292416B
281: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 0B
283: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 66496B
	btf_id 137
284: lru_hash  name cilium_ratelimi  flags 0x0
	key 4B  value 16B  max_entries 1024  memlock 91072B
	btf_id 138
285: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 328B
	btf_id 139
286: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 144B
287: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
288: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
291: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
293: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
294: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
296: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 408B
	btf_id 201
297: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 720B
	owner_prog_type sched_cls  owner jited
298: array  name I_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
299: array  name E_systemd_tmpfi  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
300: array  name I_user_0.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
301: array  name E_user_0.slice  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
308: array  name I_user_1000.sli  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
309: array  name E_user_1000.sli  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
320: array  name I_logrotate.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
321: array  name E_logrotate.ser  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
