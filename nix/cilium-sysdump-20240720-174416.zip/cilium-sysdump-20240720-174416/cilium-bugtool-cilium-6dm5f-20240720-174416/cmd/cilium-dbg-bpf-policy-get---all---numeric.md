Endpoint ID: 137
Path: /sys/fs/bpf/tc/globals/cilium_policy_00137

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2406
Path: /sys/fs/bpf/tc/globals/cilium_policy_02406

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    532518   6695      0        
Allow    Ingress     1          ANY          NONE         disabled    157604   1794      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


