nameserver 10.22.20.1
options edns0
