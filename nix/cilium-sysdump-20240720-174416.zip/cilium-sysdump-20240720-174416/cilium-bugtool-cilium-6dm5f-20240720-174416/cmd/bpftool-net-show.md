xdp:

tc:
public(5) clsact/ingress cil_from_netdev-public id 837
public(5) clsact/egress cil_to_netdev-public id 843
private(6) clsact/ingress cil_from_netdev-private id 851
private(6) clsact/egress cil_to_netdev-private id 854
cilium_net(7) clsact/ingress cil_to_host-cilium_net id 829
cilium_host(8) clsact/ingress cil_to_host-cilium_host id 816
cilium_host(8) clsact/egress cil_from_host-cilium_host id 822
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 868

flow_dissector:

netfilter:

