key: 18 00 00 00 0a 16 1e 00  value: 00
key: 10 00 00 00 a9 fe 00 00  value: 00
Found 2 elements
