alloc: 35.87MB (37608896 bytes)
total-alloc: 1.40GB (1499865936 bytes)
sys: 72.81MB (76346027 bytes)
lookups: 0
mallocs: 30595375
frees: 30353922
heap-alloc: 35.87MB (37608896 bytes)
heap-sys: 59.66MB (62554112 bytes)
heap-idle: 9.33MB (9781248 bytes)
heap-in-use: 50.33MB (52772864 bytes)
heap-released: 5.32MB (5578752 bytes)
heap-objects: 241453
stack-in-use: 4.34MB (4554752 bytes)
stack-sys: 4.34MB (4554752 bytes)
stack-mspan-inuse: 792.91KB (811944 bytes)
stack-mspan-sys: 954.84KB (977760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 707.62KB (724598 bytes)
gc-sys: 5.38MB (5645472 bytes)
next-gc: when heap-alloc >= 67.43MB (70708888 bytes)
last-gc: 2024-07-20 17:44:45.699598364 +0000 UTC
gc-pause-total: 11.733852ms
gc-pause: 111452
gc-pause-end: 1721497485699598364
num-gc: 127
num-forced-gc: 0
gc-cpu-fraction: 5.273874908733712e-05
enable-gc: true
debug-gc: false
