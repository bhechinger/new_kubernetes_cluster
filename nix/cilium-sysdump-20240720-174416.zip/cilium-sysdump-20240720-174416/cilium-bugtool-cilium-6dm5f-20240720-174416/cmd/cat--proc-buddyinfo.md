Node 0, zone      DMA      0      0      0      0      0      0      0      1      0      1      3 
Node 0, zone    DMA32   1331    317    149     38     10      7      4      5      1      4     10 
Node 0, zone   Normal    113     79     52     62     13     31     36     24     17     10      6 
