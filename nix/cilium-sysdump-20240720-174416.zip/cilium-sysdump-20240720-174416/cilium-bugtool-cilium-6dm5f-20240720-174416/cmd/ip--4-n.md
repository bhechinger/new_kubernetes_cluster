10.22.20.1 dev public lladdr 52:54:00:e8:ea:c8 extern_learn  REACHABLE
10.22.30.23 dev private lladdr 52:54:00:56:ae:d0 extern_learn  REACHABLE
10.22.30.11 dev private lladdr 52:54:00:d6:4c:0f extern_learn  REACHABLE
10.22.20.23 dev public lladdr 52:54:00:56:f8:96 REACHABLE
10.22.20.11 dev public lladdr 52:54:00:92:19:da REACHABLE
10.22.30.22 dev private lladdr 52:54:00:86:1f:a3 extern_learn  REACHABLE
10.22.20.22 dev public lladdr 52:54:00:96:8f:2e REACHABLE
10.22.30.21 dev private lladdr 52:54:00:86:13:c3 extern_learn  REACHABLE
10.22.20.21 dev public lladdr 52:54:00:a6:3e:20 REACHABLE
10.22.30.13 dev private lladdr 52:54:00:7e:e8:40 extern_learn  REACHABLE
10.22.20.13 dev public lladdr 52:54:00:d2:cd:12 REACHABLE
