CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
55       cgroup_inet_ingress multi           sd_fw_ingress                  
54       cgroup_inet_egress multi           sd_fw_egress                   
808      cgroup_inet4_connect multi           cil_sock4_connect                
804      cgroup_inet6_connect multi           cil_sock6_connect                
807      cgroup_inet4_post_bind multi           cil_sock4_post_bind                
806      cgroup_inet6_post_bind multi           cil_sock6_post_bind                
805      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
809      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
811      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
813      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
812      cgroup_inet4_getpeername multi           cil_sock4_getpeername                
810      cgroup_inet6_getpeername multi           cil_sock6_getpeername                
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    63       cgroup_inet_ingress multi           sd_fw_ingress                  
    62       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-config.mount
    57       cgroup_inet_ingress multi           sd_fw_ingress                  
    56       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    26       cgroup_inet_ingress multi           sd_fw_ingress                  
    25       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/dev-mqueue.mount
    24       cgroup_inet_ingress multi           sd_fw_ingress                  
    23       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice
    1000     cgroup_inet_ingress multi           sd_fw_ingress                  
    999      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-0.slice
    998      cgroup_inet_ingress multi           sd_fw_ingress                  
    997      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    1004     cgroup_inet_ingress multi           sd_fw_ingress                  
    1003     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/init.scope
    8        cgroup_inet_ingress multi           sd_fw_ingress                  
    7        cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice
    53       cgroup_inet_ingress multi           sd_fw_ingress                  
    52       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    18       cgroup_inet_ingress multi           sd_fw_ingress                  
    17       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    67       cgroup_inet_ingress multi           sd_fw_ingress                  
    66       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice
    16       cgroup_inet_ingress multi           sd_fw_ingress                  
    15       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-serial\x2dgetty.slice/serial-getty@hvc0.service
    140      cgroup_inet_ingress multi           sd_fw_ingress                  
    139      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/boot.mount
    79       cgroup_inet_ingress multi           sd_fw_ingress                  
    78       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    14       cgroup_inet_ingress multi           sd_fw_ingress                  
    13       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    45       cgroup_inet_ingress multi           sd_fw_ingress                  
    44       cgroup_inet_egress multi           sd_fw_egress                   
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/sshd.service
    134      cgroup_inet_ingress multi           sd_fw_ingress                  
    133      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/rke2.service
    144      cgroup_inet_ingress multi           sd_fw_ingress                  
    143      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dhcpcd.service
    97       cgroup_inet_ingress multi           sd_fw_ingress                  
    96       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/nscd.service
    142      cgroup_inet_ingress multi           sd_fw_ingress                  
    141      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    86       cgroup_inet_ingress multi           sd_fw_ingress                  
    85       cgroup_inet_egress multi           sd_fw_egress                   
    84       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/dbus.service
    107      cgroup_inet_ingress multi           sd_fw_ingress                  
    106      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    89       cgroup_inet_ingress multi           sd_fw_ingress                  
    88       cgroup_inet_egress multi           sd_fw_egress                   
    87       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/system-getty.slice
    12       cgroup_inet_ingress multi           sd_fw_ingress                  
    11       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/system-getty.slice/getty@tty1.service
    138      cgroup_inet_ingress multi           sd_fw_ingress                  
    137      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    110      cgroup_inet_ingress multi           sd_fw_ingress                  
    109      cgroup_inet_egress multi           sd_fw_egress                   
    108      cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/dev-hugepages.mount
    22       cgroup_inet_ingress multi           sd_fw_ingress                  
    21       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice
    180      cgroup_inet_ingress multi           sd_fw_ingress                  
    179      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice
    1716     cgroup_inet_ingress multi           sd_fw_ingress                  
    1715     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice
    338      cgroup_inet_ingress multi           sd_fw_ingress                  
    337      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice/cri-containerd-5d7a4f01caf3d2a01d8e0ab150b714646904cda68c9806fd7547623674c32e20.scope
    446      cgroup_inet_ingress multi           sd_fw_ingress                  
    445      cgroup_inet_egress multi           sd_fw_egress                   
    449      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice/cri-containerd-d418631439f23b226ceef06ef9c8423b4b16fafde100299f43ab160dae252fe6.scope
    454      cgroup_inet_ingress multi           sd_fw_ingress                  
    453      cgroup_inet_egress multi           sd_fw_egress                   
    457      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod456f26cf_e54c_4e97_9198_7b168eb956ea.slice/cri-containerd-db803e3a46dc56c0f1956d45f0890eddb2bca40690f1a69e2909587419a1680c.scope
    349      cgroup_inet_ingress multi           sd_fw_ingress                  
    348      cgroup_inet_egress multi           sd_fw_egress                   
    352      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35631ed5627d9a41305ba1fd170f64ae.slice
    266      cgroup_inet_ingress multi           sd_fw_ingress                  
    265      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35631ed5627d9a41305ba1fd170f64ae.slice/cri-containerd-0b69f449e7e260764cdd654d8842826ae991fe668675629acc3583502b7e8e3e.scope
    277      cgroup_inet_ingress multi           sd_fw_ingress                  
    276      cgroup_inet_egress multi           sd_fw_egress                   
    280      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35631ed5627d9a41305ba1fd170f64ae.slice/cri-containerd-1a75bec2a025f734db855bdd9fb289ee1d0b82d9c2aa45938033256c5e3dd18d.scope
    293      cgroup_inet_ingress multi           sd_fw_ingress                  
    292      cgroup_inet_egress multi           sd_fw_egress                   
    296      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dcd7e23aff1e01f38668aa08df38a79.slice
    210      cgroup_inet_ingress multi           sd_fw_ingress                  
    209      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dcd7e23aff1e01f38668aa08df38a79.slice/cri-containerd-4c8cb95eefb74d1f1b0e5696bd5ee0169aee1fdc749b738d3a47ab3d08d7d94e.scope
    215      cgroup_inet_ingress multi           sd_fw_ingress                  
    214      cgroup_inet_egress multi           sd_fw_egress                   
    218      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dcd7e23aff1e01f38668aa08df38a79.slice/cri-containerd-5abe5ab070973a261dbb390771245cec32ea627898b5df035006f2a717d75008.scope
    223      cgroup_inet_ingress multi           sd_fw_ingress                  
    222      cgroup_inet_egress multi           sd_fw_egress                   
    226      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb606ff35e14c26543f228365a6ce06c1.slice
    184      cgroup_inet_ingress multi           sd_fw_ingress                  
    183      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb606ff35e14c26543f228365a6ce06c1.slice/cri-containerd-e15fa7b25d7832ad913a110ccb9e41e926f685e3ce1f5a5e3712a32a4dd060c5.scope
    189      cgroup_inet_ingress multi           sd_fw_ingress                  
    188      cgroup_inet_egress multi           sd_fw_egress                   
    192      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb606ff35e14c26543f228365a6ce06c1.slice/cri-containerd-860faccdc048cf7fccb2051a50b78c2e5376fc95447b590dd7fa3193a6cc3ddc.scope
    197      cgroup_inet_ingress multi           sd_fw_ingress                  
    196      cgroup_inet_egress multi           sd_fw_egress                   
    200      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05107f15fda2f0ad9cd3b31d8bbf2a15.slice
    262      cgroup_inet_ingress multi           sd_fw_ingress                  
    261      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05107f15fda2f0ad9cd3b31d8bbf2a15.slice/cri-containerd-800a2e46ad18f9cfa63f274c4a1966e643b24dcfaa90ccf6e7ddd9807ee5c3ab.scope
    301      cgroup_inet_ingress multi           sd_fw_ingress                  
    300      cgroup_inet_egress multi           sd_fw_egress                   
    304      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05107f15fda2f0ad9cd3b31d8bbf2a15.slice/cri-containerd-de20bd1a842a90dc30c7b013ebb457269ff214fe42ba5d91c90d3f373b78c4a9.scope
    271      cgroup_inet_ingress multi           sd_fw_ingress                  
    270      cgroup_inet_egress multi           sd_fw_egress                   
    274      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48e0bd5eca8849d81d854f95ab81d0f0.slice
    252      cgroup_inet_ingress multi           sd_fw_ingress                  
    251      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48e0bd5eca8849d81d854f95ab81d0f0.slice/cri-containerd-9037413e0ff2cd6c9bf60807e688a8891fee07d431d4535009f18ffdce9aaa3a.scope
    285      cgroup_inet_ingress multi           sd_fw_ingress                  
    284      cgroup_inet_egress multi           sd_fw_egress                   
    288      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48e0bd5eca8849d81d854f95ab81d0f0.slice/cri-containerd-54c0fadb6ee4bf707e2471ea144a8f9568a355705d8708a1a52d75247d753da0.scope
    257      cgroup_inet_ingress multi           sd_fw_ingress                  
    256      cgroup_inet_egress multi           sd_fw_egress                   
    260      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice
    1718     cgroup_inet_ingress multi           sd_fw_ingress                  
    1717     cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4eb2286_6713_4da7_9d36_c71f9daf12ff.slice
    354      cgroup_inet_ingress multi           sd_fw_ingress                  
    353      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4eb2286_6713_4da7_9d36_c71f9daf12ff.slice/cri-containerd-b0040c1471ca448011290e11015071548db0d5d89a58788b13506b44793341c7.scope
    381      cgroup_inet_ingress multi           sd_fw_ingress                  
    380      cgroup_inet_egress multi           sd_fw_egress                   
    384      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4eb2286_6713_4da7_9d36_c71f9daf12ff.slice/cri-containerd-9caed4d52b0cb98802df2054392031b540a06cc51a108d6fa31edb15e39eb341.scope
    365      cgroup_inet_ingress multi           sd_fw_ingress                  
    364      cgroup_inet_egress multi           sd_fw_egress                   
    368      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96108607_d30b_4039_858b_247327751129.slice
    344      cgroup_inet_ingress multi           sd_fw_ingress                  
    343      cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96108607_d30b_4039_858b_247327751129.slice/cri-containerd-c208b1e69f89759e8dd09353e1c2dcb9d6f08101d4b5c64c1bf5795d447540cd.scope
    373      cgroup_inet_ingress multi           sd_fw_ingress                  
    372      cgroup_inet_egress multi           sd_fw_egress                   
    376      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96108607_d30b_4039_858b_247327751129.slice/cri-containerd-fbeee050adefd5681ff8a76cd979b19db36ac430ea43531e552f0e0815748422.scope
    359      cgroup_inet_ingress multi           sd_fw_ingress                  
    358      cgroup_inet_egress multi           sd_fw_egress                   
    362      cgroup_device   multi                                          
