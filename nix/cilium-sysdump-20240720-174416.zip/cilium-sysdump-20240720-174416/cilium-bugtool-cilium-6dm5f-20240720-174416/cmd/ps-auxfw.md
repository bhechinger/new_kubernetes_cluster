USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3705  2.0  0.3 1241264 16000 ?       Ssl  17:44   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3728  0.0  0.0   7064  2816 ?        R    17:44   0:00  \_ ps auxfw
root        3735  0.0  0.0      0     0 ?        Z    17:44   0:00  \_ [ip] <defunct>
root           1  1.0  3.6 1333984 145640 ?      Ssl  14:25   2:01 cilium-agent --config-dir=/tmp/cilium/config-map
root         133  0.0  0.1 1229772 6912 ?        Sl   14:25   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
