cat: /proc/net/xfrm_stat: No such file or directory
> Error while running 'cat -u /proc/net/xfrm_stat':  exit status 1

