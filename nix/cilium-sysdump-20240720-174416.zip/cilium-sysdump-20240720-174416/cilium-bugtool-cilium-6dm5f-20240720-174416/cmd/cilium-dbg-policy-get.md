[
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-dex-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "http",
                "protocol": "TCP"
              }
            ]
          },
          {
            "ports": [
              {
                "port": "grpc",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-dex-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "0ca9b40f-9a3f-4ecd-bb56-154eebd0bf62",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-repo-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-server",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      },
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "k8s:app.kubernetes.io/instance": "rke2-argocd",
              "k8s:app.kubernetes.io/name": "argocd-application-controller",
              "k8s:io.kubernetes.pod.namespace": "argocd"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "repo-server",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-repo-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "44e84fdf-5ef5-4516-8cf8-2e5e1e3f3523",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-application-controller",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchExpressions": [
              {
                "key": "k8s:io.kubernetes.pod.namespace",
                "operator": "Exists"
              }
            ]
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "controller",
                "protocol": "TCP"
              }
            ]
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-application-controller",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d14d3df5-1c32-43ce-9f4b-9fd13f1cacf6",
        "source": "k8s"
      }
    ]
  },
  {
    "endpointSelector": {
      "matchLabels": {
        "k8s:app.kubernetes.io/instance": "rke2-argocd",
        "k8s:app.kubernetes.io/name": "argocd-server",
        "k8s:io.kubernetes.pod.namespace": "argocd"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {}
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "NetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "rke2-argocd-server",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "argocd",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d6baf548-03ff-49f8-93db-5f25fa513dc6",
        "source": "k8s"
      }
    ]
  }
]
Revision: 233
