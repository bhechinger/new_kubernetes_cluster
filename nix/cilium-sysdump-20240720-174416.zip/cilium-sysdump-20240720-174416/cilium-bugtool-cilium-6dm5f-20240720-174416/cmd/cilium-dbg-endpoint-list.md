ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                      IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                        
137        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                        ready   
                                                           k8s:node-role.kubernetes.io/etcd=true                                         
                                                           k8s:node-role.kubernetes.io/master=true                                       
                                                           k8s:node.kubernetes.io/instance-type=rke2                                     
                                                           reserved:host                                                                 
1014       Disabled           Disabled          8          reserved:ingress                                        10.55.1.178   ready   
2406       Disabled           Disabled          4          reserved:health                                         10.55.1.165   ready   
