2: tracing  name hid_tail_call  tag 7cc47bbf07148bfe  gpl
	loaded_at 2024-07-20T14:22:35+0000  uid 0
	xlated 56B  jited 129B  memlock 4096B  map_ids 2
	btf_id 2
7: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 6
8: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 5
11: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 10
12: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 9
13: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 12
14: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 11
15: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 14
16: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 13
17: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 16
18: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 15
21: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 20
22: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 19
23: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 22
24: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 21
25: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 24
26: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 23
27: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 26
28: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 25
29: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 28
30: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 27
31: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 30
32: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 29
33: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 32
34: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 31
35: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 34
36: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 33
37: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 36
38: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 35
39: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 38
40: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 37
41: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 40
42: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 39
43: cgroup_device  name sd_devices  tag 3a32ccd9e03ea87a  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 504B  jited 318B  memlock 4096B
44: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 42
45: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 41
46: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 44
47: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 43
48: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 46
49: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 45
50: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 48
51: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 47
52: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 8
53: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 7
54: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 4
55: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 3
56: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 50
57: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 49
58: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 52
59: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 51
60: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 54
61: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 53
62: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 56
63: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 55
64: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 58
65: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 57
66: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 60
67: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 59
68: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 62
69: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 61
72: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 66
73: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 65
76: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 68
77: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 67
78: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 70
79: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 69
80: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 72
81: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 71
82: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 74
83: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 73
84: cgroup_device  name sd_devices  tag 63878b01a3de7bae  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 464B  jited 297B  memlock 4096B
85: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 76
86: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 75
87: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 416B  jited 264B  memlock 4096B
88: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 78
89: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 77
90: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 80
91: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 79
92: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 82
93: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:37+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 81
94: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 84
95: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 83
96: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 86
97: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 85
98: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 88
99: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 87
102: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 92
103: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 91
104: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 94
105: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 93
106: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 96
107: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 95
108: cgroup_device  name sd_devices  tag 03e2cf74d47166f5  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 744B  jited 456B  memlock 4096B
109: cgroup_skb  name sd_fw_egress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 98
110: cgroup_skb  name sd_fw_ingress  tag 815d6551cd4d7b0b  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 64B  jited 63B  memlock 4096B  map_ids 97
111: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 100
112: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 99
113: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 102
114: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 101
115: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 104
116: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 103
119: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 106
120: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 105
121: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 108
122: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 107
123: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 110
124: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 109
125: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 112
126: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 111
127: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 114
128: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 113
129: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 116
130: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 115
131: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 118
132: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 117
133: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 120
134: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 119
135: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 122
136: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 121
137: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 124
138: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 123
139: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 126
140: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 125
141: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:45+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 90
142: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:45+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 89
143: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:45+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 128
144: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:22:45+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 127
179: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 130
180: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 129
183: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 136
184: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 135
187: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
188: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 138
189: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 137
192: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:23:33+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
195: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:23:38+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
196: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 141
197: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:38+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 140
200: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:23:38+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
209: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 144
210: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 143
213: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
214: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 146
215: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 145
218: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
221: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
222: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 149
223: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 148
226: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:23:56+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
251: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 152
252: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 151
255: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
256: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 158
257: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 157
260: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
261: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 154
262: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 153
265: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 156
266: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 155
269: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
270: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 161
271: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 160
274: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
275: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
276: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 163
277: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 162
280: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
283: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
284: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 167
285: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 166
288: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:00+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
291: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
292: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 170
293: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 169
296: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
299: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
300: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 173
301: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 172
304: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:01+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
337: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 176
338: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 175
343: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 178
344: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 177
347: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
348: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 182
349: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 181
352: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
353: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 180
354: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 179
357: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
358: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 184
359: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 183
362: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
363: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
364: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 187
365: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 186
368: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:41+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
371: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:49+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
372: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 191
373: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:49+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 190
376: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:49+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
379: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:24:51+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
380: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:51+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 194
381: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:24:51+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 193
384: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:24:51+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
417: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:08+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 64
418: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:08+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 63
444: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:25:14+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
445: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:14+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 218
446: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:14+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 217
449: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:25:14+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
452: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-07-20T14:25:15+0000  uid 0
	xlated 440B  jited 280B  memlock 4096B
453: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:15+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 222
454: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:25:15+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 221
457: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-07-20T14:25:15+0000  uid 0
	xlated 512B  jited 337B  memlock 4096B
804: cgroup_sock_addr  name cil_sock6_connect  tag 068d472a70505afe  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 5496B  jited 2987B  memlock 8192B  map_ids 268,265,262,280,279,269,266,267
	btf_id 140
805: cgroup_sock_addr  name cil_sock4_sendmsg  tag 381b569805c952fd  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 5192B  jited 2792B  memlock 8192B  map_ids 268,265,262,280,279,269,266,267
	btf_id 141
806: cgroup_sock  name cil_sock6_post_bind  tag 8dc07c20ddb00d87  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 1224B  jited 730B  memlock 4096B  map_ids 265,268
	btf_id 142
807: cgroup_sock  name cil_sock4_post_bind  tag 80bc39b2ffc68395  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 824B  jited 483B  memlock 4096B  map_ids 268,265
	btf_id 143
808: cgroup_sock_addr  name cil_sock4_connect  tag 4ac7567395eca7cf  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 5240B  jited 2826B  memlock 8192B  map_ids 268,265,262,280,279,269,266,267
	btf_id 144
809: cgroup_sock_addr  name cil_sock6_sendmsg  tag 9c45a193655af861  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 5464B  jited 2933B  memlock 8192B  map_ids 268,265,262,280,279,269,266,267
	btf_id 145
810: cgroup_sock_addr  name cil_sock6_getpeername  tag 42037bd653c99049  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 2904B  jited 1621B  memlock 4096B  map_ids 262,267,268,265,266
	btf_id 146
811: cgroup_sock_addr  name cil_sock4_recvmsg  tag 87271573c2abff4f  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 2672B  jited 1491B  memlock 4096B  map_ids 262,267,268,265,266
	btf_id 147
812: cgroup_sock_addr  name cil_sock4_getpeername  tag 87271573c2abff4f  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 2672B  jited 1491B  memlock 4096B  map_ids 262,267,268,265,266
	btf_id 148
813: cgroup_sock_addr  name cil_sock6_recvmsg  tag 42037bd653c99049  gpl
	loaded_at 2024-07-20T14:25:17+0000  uid 0
	xlated 2904B  jited 1621B  memlock 4096B  map_ids 262,267,268,265,266
	btf_id 149
815: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 266,288
	btf_id 155
816: sched_cls  name cil_to_host  tag fd128c0c744c0771  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 384B  jited 224B  memlock 4096B  map_ids 266
	btf_id 156
818: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 277,266,275,288,273,274,270
	btf_id 158
819: sched_cls  name tail_handle_ipv4_from_host  tag 9be1c5c1eaf8e7e2  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 264,266,265,271,288
	btf_id 159
820: sched_cls  name __send_drop_notify  tag 98c79fe9f39c4dc3  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 262
	btf_id 160
821: sched_cls  name tail_handle_ipv4_from_netdev  tag b990e7e58530d77a  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 277,266,268,288,264,281,273,274,271,280,279,269,260,276
	btf_id 161
822: sched_cls  name cil_from_host  tag d4910d449c1a5496  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2768B  jited 1799B  memlock 4096B  map_ids 266,272,288,265
	btf_id 162
823: sched_cls  name tail_nodeport_nat_egress_ipv4  tag b52dbe9140eedeac  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 277,266,275,260,288
	btf_id 163
824: sched_cls  name tail_handle_snat_fwd_ipv4  tag 8ed570c264a20835  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 32184B  jited 22534B  memlock 32768B  map_ids 277,264,265,266,273,274,278,275,260,262,288
	btf_id 164
825: sched_cls  name tail_handle_ipv4_from_netdev  tag bc105717bc15d778  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 277,266,268,291,264,281,273,274,271,280,279,269,260,276
	btf_id 166
826: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 266,291
	btf_id 167
827: sched_cls  name tail_nodeport_nat_egress_ipv4  tag b52dbe9140eedeac  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 277,266,275,260,291
	btf_id 168
828: sched_cls  name tail_handle_snat_fwd_ipv4  tag b5ae760ff1541909  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 32184B  jited 22540B  memlock 32768B  map_ids 277,264,265,266,273,274,278,275,260,262,291
	btf_id 169
829: sched_cls  name cil_to_host  tag fd128c0c744c0771  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 384B  jited 224B  memlock 4096B  map_ids 266
	btf_id 170
830: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 277,266,275,291,273,274,270
	btf_id 171
833: sched_cls  name tail_handle_ipv4_from_host  tag 9be1c5c1eaf8e7e2  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 264,266,265,271,291
	btf_id 174
835: sched_cls  name __send_drop_notify  tag 98c79fe9f39c4dc3  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 262
	btf_id 176
836: sched_cls  name tail_handle_snat_fwd_ipv4  tag 84557d12426e758b  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 32184B  jited 22549B  memlock 32768B  map_ids 277,264,265,266,273,274,278,275,260,262,293
	btf_id 178
837: sched_cls  name cil_from_netdev  tag 72a26bdb155998c0  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2160B  jited 1459B  memlock 4096B  map_ids 266,293,265
	btf_id 179
839: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 277,266,275,293,273,274,270
	btf_id 181
840: sched_cls  name tail_handle_ipv4_from_host  tag 9be1c5c1eaf8e7e2  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 264,266,265,271,293
	btf_id 182
841: sched_cls  name __send_drop_notify  tag 98c79fe9f39c4dc3  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 262
	btf_id 183
843: sched_cls  name cil_to_netdev  tag 1af286670a7c265a  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 7976B  jited 5080B  memlock 8192B  map_ids 266,272,263,293,277,273,274,270,262
	btf_id 185
844: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 266,293
	btf_id 186
845: sched_cls  name tail_handle_ipv4_from_netdev  tag 2b844c3760881565  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 277,266,268,293,264,281,273,274,271,280,279,269,260,276
	btf_id 187
846: sched_cls  name tail_nodeport_nat_egress_ipv4  tag b52dbe9140eedeac  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 277,266,275,260,293
	btf_id 188
847: sched_cls  name __send_drop_notify  tag 98c79fe9f39c4dc3  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 376B  jited 225B  memlock 4096B  map_ids 262
	btf_id 190
850: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 297bef66fed1ba2f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 10680B  jited 6729B  memlock 12288B  map_ids 277,266,275,294,273,274,270
	btf_id 193
851: sched_cls  name cil_from_netdev  tag 72a26bdb155998c0  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2160B  jited 1459B  memlock 4096B  map_ids 266,294,265
	btf_id 194
852: sched_cls  name tail_nodeport_nat_egress_ipv4  tag b52dbe9140eedeac  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 25504B  jited 18499B  memlock 28672B  map_ids 277,266,275,260,294
	btf_id 195
853: sched_cls  name tail_handle_snat_fwd_ipv4  tag 1dccf922e4329bdb  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 32232B  jited 22578B  memlock 32768B  map_ids 277,264,265,266,273,274,278,275,260,262,294
	btf_id 196
854: sched_cls  name cil_to_netdev  tag cc0146505e9a0a7b  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 7976B  jited 5080B  memlock 8192B  map_ids 266,272,263,294,277,273,274,270,262
	btf_id 197
855: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 266,294
	btf_id 198
856: sched_cls  name tail_handle_ipv4_from_netdev  tag 23c80e7038afe886  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 13456B  jited 8281B  memlock 16384B  map_ids 277,266,268,294,264,281,273,274,271,280,279,269,260,276
	btf_id 199
857: sched_cls  name tail_handle_ipv4_from_host  tag 9be1c5c1eaf8e7e2  gpl
	loaded_at 2024-07-20T14:25:19+0000  uid 0
	xlated 2240B  jited 1456B  memlock 4096B  map_ids 264,266,265,271,294
	btf_id 200
858: sched_cls  name handle_policy  tag c21a3251db67713b  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 15168B  jited 9123B  memlock 16384B  map_ids 266,273,274,277,297,296,262,270,287,265,261,258,259,260
	btf_id 202
859: sched_cls  name tail_handle_arp  tag d9eeb98f51a4c2f3  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 1488B  jited 919B  memlock 4096B  map_ids 266,297
	btf_id 203
861: sched_cls  name tail_no_service_ipv4  tag 0760d3e77c85b94f  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 4968B  jited 2861B  memlock 8192B  map_ids 266,297
	btf_id 205
862: sched_cls  name __send_drop_notify  tag b52f0dc54917d155  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 400B  jited 230B  memlock 4096B  map_ids 262
	btf_id 206
863: sched_cls  name handle_policy_egress  tag 38a07aab5728ee33  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 640B  jited 446B  memlock 4096B  map_ids 297,266
	btf_id 207
864: sched_cls  name tail_ipv4_ct_ingress  tag fef458332519bfd1  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 6184B  jited 3765B  memlock 8192B  map_ids 266,297,273,274,277,296
	btf_id 208
865: sched_cls  name tail_handle_ipv4  tag abc50de4c8656763  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 8512B  jited 5171B  memlock 12288B  map_ids 277,266,268,273,274,280,279,269,297,260
	btf_id 209
866: sched_cls  name tail_ipv4_ct_egress  tag 6d3ee1bfb78860d6  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 6080B  jited 3713B  memlock 8192B  map_ids 266,297,273,274,277,296
	btf_id 210
867: sched_cls  name tail_handle_ipv4_cont  tag 80684fd6a433492c  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 11448B  jited 6900B  memlock 12288B  map_ids 265,296,262,287,261,258,259,260,273,274,266,270,297,264,271
	btf_id 211
868: sched_cls  name cil_from_container  tag ad9e2f4df6d04289  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 736B  jited 568B  memlock 4096B  map_ids 297,266
	btf_id 212
869: sched_cls  name tail_nodeport_rev_dnat_ingress_ipv4  tag 761d8b1ff7fe424c  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 5648B  jited 3558B  memlock 8192B  map_ids 277,266,273,274,297,270
	btf_id 213
870: sched_cls  name tail_ipv4_to_endpoint  tag c1ec46286f540a08  gpl
	loaded_at 2024-07-20T14:25:20+0000  uid 0
	xlated 10576B  jited 6121B  memlock 12288B  map_ids 265,266,277,273,274,269,296,262,270,287,261,258,259,260,297
	btf_id 214
923: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:37:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 299
924: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:37:36+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 298
997: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 301
998: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 300
999: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 18
1000: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 17
1003: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 309
1004: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T14:47:58+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 308
1537: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:00:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 321
1538: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:00:01+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 320
1711: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:28+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 132
1712: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:28+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 131
1713: cgroup_skb  name sd_fw_egress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:28+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 134
1714: cgroup_skb  name sd_fw_ingress  tag 7dc8126e8768ea37  gpl
	loaded_at 2024-07-20T17:43:28+0000  uid 0
	xlated 312B  jited 201B  memlock 4096B  map_ids 133
