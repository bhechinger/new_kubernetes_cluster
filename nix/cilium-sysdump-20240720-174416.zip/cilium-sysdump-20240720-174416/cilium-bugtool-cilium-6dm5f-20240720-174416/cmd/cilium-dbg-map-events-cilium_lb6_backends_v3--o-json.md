Error: could not get map name events: [GET /map/{name}/events][404] getMapNameEventsNotFound 
> Error while running 'cilium-dbg map events cilium_lb6_backends_v3 -o json':  exit status 1

